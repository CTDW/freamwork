package com.seeease.flywheel_v4.web.infrastructure.dao.fix.repo;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.seeease.flywheel_v4.web.app.fix.request.FixItemDetailRequest;
import com.seeease.flywheel_v4.web.app.fix.request.FixItemPageRequest;
import com.seeease.flywheel_v4.web.app.fix.request.FixItemSaveRequest;
import com.seeease.flywheel_v4.web.infrastructure.dao.fix.entity.FixItem;

/**
 * @Description 维修项目
 * @Date 2024-10-2 21:04
 * @Author by hk
 */
public interface FixItemRepository {

    /**
     * 分页
     *
     * @param request 请求
     * @return 维修项目
     */
    Page<FixItem> page(FixItemPageRequest request);

    /**
     * 详情
     *
     * @param request 请求
     * @return 返回
     */
    FixItem detail(FixItemDetailRequest request);

    /**
     * 新增
     *
     * @param request 请求
     * @return 结果
     */
    Boolean save(FixItemSaveRequest request);

    /**
     * 编辑
     *
     * @param request 请求
     * @return 结果
     */
    Boolean update(FixItemSaveRequest request);

    /**
     * 删除
     *
     * @param request 请求
     * @return 结果
     */
    Boolean delete(FixItemDetailRequest request);

}
