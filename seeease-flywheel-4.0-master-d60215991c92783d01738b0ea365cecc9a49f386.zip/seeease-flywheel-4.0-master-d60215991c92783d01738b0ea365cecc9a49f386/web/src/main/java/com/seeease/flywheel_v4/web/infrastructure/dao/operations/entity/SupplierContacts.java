package com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.seeease.seeeaseframework.mybatis.domain.BaseDomain;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 供应商联系人
 */
@EqualsAndHashCode(callSuper = true)
@TableName(value = "v4_ops_supplier_contacts", autoResultMap = true)
@Data
public class SupplierContacts extends BaseDomain  {
    @TableId(type = IdType.AUTO)
    private Integer id;
    /**
     * 供应商id
     */
    private Integer supplierId;
    /**
     * 联系人姓名
     */
    private String name;
    /**
     * 联系人电话
     */
    private String phone;
    /**
     * 银行名称
     */
    private String bank;
    /**
     * 开户支行名称
     */
    private String bankName;
    /**
     * 银行转账账号
     */
    private String account;
    /**
     * 银行转账户名称
     */
    private String accountName;
}