package com.seeease.flywheel_v4.web.app.sale.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.seeease.flywheel_v4.client.enums.BusinessUnitTypeEnums;
import com.seeease.flywheel_v4.web.app.sale.request.*;
import com.seeease.flywheel_v4.web.app.sale.result.ToBSaleReturnOrderDetailResult;
import com.seeease.flywheel_v4.web.app.sale.result.ToBSaleReturnOrderPageResult;
import com.seeease.flywheel_v4.web.app.sale.result.ToCSaleReturnOrderDetailResult;
import com.seeease.flywheel_v4.web.app.sale.result.ToCSaleReturnOrderPageResult;
import com.seeease.flywheel_v4.web.app.sale.service.SaleReturnOrderService;
import com.seeease.flywheel_v4.web.domain.purchase.mapping.PurchaseOrderMapping;
import com.seeease.flywheel_v4.web.domain.sale.mapping.SaleReturnOrderLineMapping;
import com.seeease.flywheel_v4.web.domain.sale.mapping.SaleReturnOrderMapping;
import com.seeease.flywheel_v4.web.domain.wms.observer.base.WmsSubject;
import com.seeease.flywheel_v4.web.infrastructure.dao.RepositoryFactory;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.Supplier;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.SupplierContacts;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.entity.*;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.enums.SaleModelEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.enums.SaleTypeEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.entity.SysBusinessUnit;
import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.entity.obj.MerchantBusinessUnitExtObj;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.MerchantWms;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.MerchantWmsLine;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.WmsRk;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.obj.ContactInfo;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.MerchantWmsModelEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.MerchantWmsTypeEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.WmsRkTypeEnums;
import com.seeease.flywheel_v4.web.util.SerialNoGenerator;
import com.seeease.goods.rpc.SkuFacade;
import com.seeease.goods.rpc.enums.SkuNodeStateEnums;
import com.seeease.goods.rpc.request.SaleReturnSkuCreateRpcRequest;
import com.seeease.goods.rpc.request.SkuRpcRequest;
import com.seeease.goods.rpc.result.SkuCreateRpcResult;
import com.seeease.goods.rpc.result.SkuRpcResult;
import com.seeease.seeeaseframework.mybatis.domain.WhetherEnum;
import com.seeease.springframework.PageResult;
import com.seeease.springframework.context.UserContext;
import com.seeease.springframework.exception.ValidationUtil;
import com.seeease.springframework.utils.MultiUtils;
import com.seeease.springframework.utils.StringUtils;
import io.seata.spring.annotation.GlobalTransactional;
import lombok.extern.slf4j.Slf4j;
import org.apache.dubbo.config.annotation.DubboReference;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 8/2/24 2:05 下午
 **/
@Service
@Slf4j
public class SaleReturnOrderServiceImpl implements SaleReturnOrderService {

    @Resource
    private RepositoryFactory repositoryFactory;

    @DubboReference(version = "1.0.0", check = false)
    private SkuFacade skuFacade;

    @Resource
    private WmsSubject wmsSubject;


    /**
     * 退货单创建
     *
     * @param request
     * @return
     */
    public Integer returnCreate(SaleReturnOrderCreateRequest request,
                                SaleModelEnums saleModel,
                                ContactInfo buyer,
                                SaleOrder saleOrder) {

        Set<Integer> saleLineIds = MultiUtils.toSet(request.getSkuList(), SaleReturnOrderCreateRequest.Sku::getSaleLineId);
        List<SaleOrderLine> saleLineList = repositoryFactory.getSaleOrderLineRepository().listByIds(saleLineIds);
        for (SaleOrderLine line : saleLineList){
            ValidationUtil.isTrue(
                    line.getNodeState() == SkuNodeStateEnums.JI_SZ || line.getNodeState() == SkuNodeStateEnums.YCK,
                    "skuId:" + line.getSkuId() + "商品状态非已售或寄售中"
            );
        }


        Integer storeId;
        Integer buId = UserContext.getUser().getStore().getId();
        if (saleOrder.getSellType() == SaleTypeEnums.PT){
            storeId = saleOrder.getStoreId();
        }else {
            //一件代发配置

            SysBusinessUnit bu = repositoryFactory.getBusinessUnitRepository().findById(buId);
            if (bu.getExt() != null) {
                MerchantBusinessUnitExtObj ext = JSONObject.parseObject(
                        JSONObject.toJSONString(bu.getExt()),
                        MerchantBusinessUnitExtObj.class
                );
                if (ext.getDobId() != null) {
                    storeId = ext.getDobId();
                }else {
                    storeId = buId;
                }
            }else {
                storeId = buId;
            }
        }





        //修改销售单行状态
        saleLineList.forEach(line -> line.setNodeState(SkuNodeStateEnums.THZ));
        repositoryFactory.getSaleOrderLineRepository().submitBatch(saleLineList);


        //step_1 主单创建
        Integer totalCount = 0;
        BigDecimal totalAmount = BigDecimal.ZERO;
        for (SaleReturnOrderCreateRequest.Sku sku : request.getSkuList()) {
            totalCount += sku.getReturnCount();
            totalAmount = totalAmount.add(sku.getReturnAmount().multiply(new BigDecimal(sku.getReturnCount())));
        }

        String serialNo;
        if (saleModel == SaleModelEnums.C) {
            serialNo = SerialNoGenerator.generalSerial(SerialNoGenerator.Type.TO_C_XS_TH);
        } else {
            serialNo = SerialNoGenerator.generalSerial(SerialNoGenerator.Type.TO_B_XS_TH);
        }
        SaleReturnOrder returnOrder = SaleReturnOrderMapping.INSTANCE.toEntity(
                saleModel,
                storeId,
                totalCount,
                totalAmount,
                serialNo,
                request,
                buId
        );
        repositoryFactory.getSaleReturnOrderRepository().submit(returnOrder);


        //step_2 锁定sku
        request.getSkuList().forEach(sku -> sku.setUuid(UUID.randomUUID().toString()));

        SaleReturnSkuCreateRpcRequest rpcRequest = new SaleReturnSkuCreateRpcRequest();
        rpcRequest.setSerialNo(returnOrder.getSerialNo());
        List<SaleReturnSkuCreateRpcRequest.Sku> skuList = MultiUtils.toList(
                request.getSkuList(),
                SaleReturnOrderMapping.INSTANCE::toTocReturnCreateRpcRequest
        );
        rpcRequest.setSkuList(skuList);
        Map<String, SkuCreateRpcResult> rpcSkuMap = MultiUtils.toMap(
                skuFacade.create(rpcRequest),
                SkuCreateRpcResult::getUuid
        );


        //step_3 销售单行创建
        SysBusinessUnit store = repositoryFactory.getBusinessUnitRepository().findById(storeId);
        boolean pushToStore = store.getType() == BusinessUnitTypeEnums.WAREHOUSE;
        SkuNodeStateEnums nodeState = pushToStore ? SkuNodeStateEnums.DSH : SkuNodeStateEnums.DRK;

        List<SaleReturnOrderLine> lineList = MultiUtils.toList(
                request.getSkuList(),
                sku -> {
                    SkuCreateRpcResult rpcSku = rpcSkuMap.get(sku.getUuid());
                    return SaleReturnOrderLineMapping.INSTANCE.toEntity(
                            rpcSku,
                            sku,
                            returnOrder.getId(),
                            nodeState,
                            returnOrder.getStoreId()
                    );
                }
        );
        repositoryFactory.getSaleReturnOrderLineRepository().submitBatch(lineList);


        //step_4 推送wms
        //推送仓库wms
        if (pushToStore) {
            //仓库wms数据构建
            List<WmsRk> rkList = MultiUtils.toList(
                    lineList,
                    line -> SaleReturnOrderLineMapping.INSTANCE.toWmsRk(
                            line,
                            returnOrder,
                            WmsRkTypeEnums.XS_TH_RK
                    )
            );
            //推送
            wmsSubject.rkDateSubmit(rkList);
        }
        //推送商家wms
        else {
            //发货方客户信息构建
            //构建客户信息

            //商家wms数据构建
            MerchantWms merchantWms = SaleReturnOrderMapping.INSTANCE.toMerchantWms(
                    returnOrder,
                    buyer,
                    MerchantWmsTypeEnums.XS_TH_RK,
                    MerchantWmsModelEnums.RK
            );
            List<MerchantWmsLine> merchantWmsLines = MultiUtils.toList(
                    lineList,
                    line -> SaleReturnOrderLineMapping.INSTANCE.toMerchantWmsLine(line, SkuNodeStateEnums.DRK)
            );
            //推送
            wmsSubject.merchantWmsDataCreate(merchantWms, merchantWmsLines);
        }


        return returnOrder.getId();
    }


    @GlobalTransactional
    @Override
    public Integer tocReturnCreate(ToCSaleReturnOrderCreateRequest request) {
        SaleOrder saleOrder = repositoryFactory.getSaleOrderRepository()
                .findByIdOrSerialNo(request.getSaleId(), null);
        ValidationUtil.notNull(saleOrder, "销售订单不存在");

        //step_1 构建出库单联系人
        ContactInfo buyer;
        if (null != saleOrder.getBuyerId()) {
            SupplierContacts contact = repositoryFactory.getSupplierContactsRepository().findById(saleOrder.getBuyerId());
            Supplier supplier = repositoryFactory.getSupplierRepository().findById(contact.getSupplierId());
            buyer = PurchaseOrderMapping.INSTANCE.toMerchantWmsContactInfo(supplier);
        } else { //三方订单去三方订单里面找
            ThirdSaleOrder thirdSaleOrder = repositoryFactory.getThirdSaleOrderRepository().findByOrderId(saleOrder.getThirdPartyNo());
            buyer = new ContactInfo();
            buyer.setAddress(thirdSaleOrder.getBuyerInfo().getCompleteAddress());
            buyer.setName(thirdSaleOrder.getBuyerName());
            buyer.setPhone(thirdSaleOrder.getBuyerTel());
        }


        //step_2 请求参数转化
        Set<Integer> saleLineIds = MultiUtils.toSet(
                request.getSkuList(),
                ToCSaleReturnOrderCreateRequest.Sku::getLineId
        );
        Map<Integer, SaleOrderLine> saleLineMap = MultiUtils.toMap(
                repositoryFactory.getSaleOrderLineRepository().listByIds(saleLineIds),
                SaleOrderLine::getId
        );


        SaleReturnOrderCreateRequest req = new SaleReturnOrderCreateRequest();
        req.setRemark(request.getRemark());
        req.setThirdReturnId(request.getThirdReturnId());
        List<SaleReturnOrderCreateRequest.Sku> skuList = MultiUtils.toList(
                request.getSkuList(),
                sku -> {
                    SaleOrderLine line = saleLineMap.get(sku.getLineId());
                    return SaleReturnOrderMapping.INSTANCE.toCreateRequest(sku, saleOrder.getId(), line);
                }
        );
        req.setSkuList(skuList);

        return returnCreate(
                req,
                SaleModelEnums.C,
                buyer,
                saleOrder);
    }

    @Override
    public PageResult<ToCSaleReturnOrderPageResult> tocReturnPage(ToCSaleReturnOrderPageRequest request) {
        //客户查询
        Set<Integer> buyerIdList = null;
        if (StringUtils.isNotEmpty(request.getBuyerName())) {
            buyerIdList = MultiUtils.toSet(
                    repositoryFactory.getSupplierContactsRepository().listByNameAndPhone(request.getBuyerName(), null),
                    SupplierContacts::getId
            );
            if (null == buyerIdList) {
                return PageResult.buildEmpty();
            }
        }

        //销售单查询
        //sku查询
        Set<Integer> returnIdList = new HashSet<>();
        List<SaleOrder> saleOrderList;
        if (StringUtils.oneOfNonNull(
                request.getScType(),
                buyerIdList,
                request.getSaleSerialNo(),
                request.getSellType()
        )) {
            saleOrderList = repositoryFactory.getSaleOrderRepository().listForSaleReturn(
                    request.getScType(),
                    buyerIdList,
                    request.getSaleSerialNo(),
                    request.getSellType()
            );
            if (StringUtils.isEmpty(saleOrderList)) {
                return PageResult.buildEmpty();
            }
            Set<Integer> saleIdList = MultiUtils.toSet(saleOrderList, SaleOrder::getId);

            List<SaleReturnOrderLine> lineList = repositoryFactory.getSaleReturnOrderLineRepository()
                    .listBySaleIds(saleIdList);
            if (StringUtils.isEmpty(lineList)) {
                return PageResult.buildEmpty();
            }
            returnIdList.addAll(MultiUtils.toSet(lineList, SaleReturnOrderLine::getReturnId));
        }


        //商品所在查询
        if (null != request.getBelongId()) {
            List<SaleReturnOrderLine> returnOrderLines = repositoryFactory.getSaleReturnOrderLineRepository()
                    .listByStoreId(request.getBelongId());
            if (returnOrderLines.isEmpty()) {
                return PageResult.buildEmpty();
            }

            Set<Integer> partOrderIds = MultiUtils.toSet(returnOrderLines, SaleReturnOrderLine::getReturnId);
            if (returnIdList.isEmpty()) {
                returnIdList = partOrderIds;
            } else {
                returnIdList.retainAll(partOrderIds);
                if (StringUtils.isEmpty(returnIdList)) {
                    return PageResult.buildEmpty();
                }
            }
        }


        if (StringUtils.isNotEmpty(request.getSkuCode())) {
            SkuRpcRequest rpcRequest = new SkuRpcRequest();
            rpcRequest.setSkuCode(request.getSkuCode());
            Set<Integer> skuIdList = MultiUtils.toSet(skuFacade.list(rpcRequest), SkuRpcResult::getId);

            if (StringUtils.isEmpty(skuIdList)) {
                return PageResult.buildEmpty();
            }


            List<SaleReturnOrderLine> lineList = repositoryFactory.getSaleReturnOrderLineRepository()
                    .listBySkuIds(skuIdList);

            if (StringUtils.isEmpty(lineList)) {
                return PageResult.buildEmpty();
            }
            returnIdList.addAll(MultiUtils.toSet(lineList, SaleReturnOrderLine::getReturnId));
        }

        //主表查询
        Integer buId = UserContext.getUser().getStore().getId();
        SysBusinessUnit bu = repositoryFactory.getBusinessUnitRepository().findById(buId);
        if (bu.getType() != BusinessUnitTypeEnums.PLATFORM) {
            request.setBuId(UserContext.getUser().getStore().getId());
        }
        Page<SaleReturnOrder> page = repositoryFactory.getSaleReturnOrderRepository().pageForC(
                request,
                returnIdList
        );
        if (StringUtils.isEmpty(page.getRecords())) {
            return PageResult.buildEmpty();
        }


        //组合

        //销售单数据
        Set<Integer> returnIds = MultiUtils.toSet(page.getRecords(), SaleReturnOrder::getId);
        List<SaleReturnOrderLine> returnLines = repositoryFactory.getSaleReturnOrderLineRepository()
                .listByMainIds(returnIds);
        Map<Integer, Integer> lineMap = new HashMap<>();
        for (SaleReturnOrderLine line : returnLines) {
            lineMap.putIfAbsent(line.getReturnId(), line.getSaleId());
        }

        Set<Integer> saleIdList = MultiUtils.toSet(returnLines, SaleReturnOrderLine::getSaleId);
        saleOrderList = repositoryFactory.getSaleOrderRepository().listByIds(saleIdList);
        Map<Integer, SaleOrder> saleOrderMap = MultiUtils.toMap(saleOrderList, SaleOrder::getId);

        //客户数据
        if (null == buyerIdList) {
            buyerIdList = MultiUtils.toSet(saleOrderList, SaleOrder::getBuyerId);
        }
        Map<Integer, String> buyerMap = MultiUtils.toMap(
                repositoryFactory.getSupplierContactsRepository().listByIds(buyerIdList),
                SupplierContacts::getId,
                SupplierContacts::getName
        );

        //订单来源
        Set<Integer> originIdList = MultiUtils.toSet(page.getRecords(), SaleReturnOrder::getBuId);
        Map<Integer, String> originMap = MultiUtils.toMap(
                repositoryFactory.getBusinessUnitRepository().listByIds(originIdList),
                SysBusinessUnit::getId,
                SysBusinessUnit::getName
        );

        //组合
        List<ToCSaleReturnOrderPageResult> ret = MultiUtils.toList(
                page.getRecords(),
                returnOrder -> {
                    log.info("return_order :{}",JSONObject.toJSONString(returnOrder));
                    Integer saleId = lineMap.get(returnOrder.getId());
                    SaleOrder saleOrder = saleOrderMap.get(saleId);
                    String buyerName = buyerMap.get(saleOrder.getBuyerId());
                    String originName = originMap.get(returnOrder.getBuId());

                    return SaleReturnOrderMapping.INSTANCE.tocPageResult(
                            saleOrder,
                            returnOrder,
                            buyerName,
                            originName
                    );
                }
        );

        return PageResult.<ToCSaleReturnOrderPageResult>builder()
                .result(ret)
                .totalCount(page.getTotal())
                .totalPage(page.getPages())
                .build();
    }

    @Override
    public ToCSaleReturnOrderDetailResult tocReturnDetail(ToCSaleReturnOrderDetailRequest request) {
        SaleReturnOrder returnOrder = repositoryFactory.getSaleReturnOrderRepository().findByIdOrSerialNo(
                request.getId(), request.getSerialNo()
        );
        ValidationUtil.notNull(returnOrder, "退货单id错误");

        //退货行
        List<SaleReturnOrderLine> lineList = repositoryFactory.getSaleReturnOrderLineRepository().listByMainId(returnOrder.getId());

        //销售单
        Integer saleId = lineList.get(0).getSaleId();
        SaleOrder saleOrder = repositoryFactory.getSaleOrderRepository().findByIdOrSerialNo(saleId, null);


        //客户
        String buyerName, buyerPhone, buyerAddress;
        if (null == saleOrder.getBuyerId()) {
            ThirdSaleOrder thirdOrder = repositoryFactory.getThirdSaleOrderRepository().findByOrderId(saleOrder.getThirdPartyNo());
            buyerName = thirdOrder.getBuyerName();
            buyerPhone = thirdOrder.getBuyerTel();
            buyerAddress = thirdOrder.getBuyerInfo().getCompleteAddress();
        } else {
            SupplierContacts buyer = repositoryFactory.getSupplierContactsRepository().findById(saleOrder.getBuyerId());
            Supplier supplier = repositoryFactory.getSupplierRepository().findById(buyer.getSupplierId());
            buyerName = buyer.getName();
            buyerPhone = buyer.getPhone();
            buyerAddress = supplier.getCompleteAddress();
        }


        //订单来源
        SysBusinessUnit origin = repositoryFactory.getBusinessUnitRepository().findById(returnOrder.getBuId());


        //sku查询
        Set<Integer> skuIdList = MultiUtils.toSet(lineList, SaleReturnOrderLine::getSkuId);
        SkuRpcRequest rpcRequest = new SkuRpcRequest();
        rpcRequest.setIdList(skuIdList);
        List<SkuRpcResult> rpcSkuList = skuFacade.list(rpcRequest);
        Map<Integer, SkuRpcResult> skuMap = MultiUtils.toMap(rpcSkuList, SkuRpcResult::getId);

        //经营权
        Set<Integer> sellIdList = MultiUtils.toSet(lineList, SaleReturnOrderLine::getSellerId);
        Map<Integer, String> sellerMap = MultiUtils.toMap(
                repositoryFactory.getBusinessUnitRepository().listByIds(sellIdList),
                SysBusinessUnit::getId,
                SysBusinessUnit::getName
        );

        //商品所在
        Set<Integer> belongIdList = MultiUtils.toSet(lineList, SaleReturnOrderLine::getStoreId);
        Map<Integer, String> belongMap = MultiUtils.toMap(
                repositoryFactory.getBusinessUnitRepository().listByIds(belongIdList),
                SysBusinessUnit::getId,
                SysBusinessUnit::getName
        );


        //数据转换
        List<ToCSaleReturnOrderDetailResult.Sku> retSkuList = MultiUtils.toList(
                lineList,
                line -> {
                    SkuRpcResult sku = skuMap.get(line.getSkuId());
                    String sellerName = sellerMap.get(line.getSellerId());
                    String belongName = belongMap.get(line.getStoreId());
                    return SaleReturnOrderLineMapping.INSTANCE.tocDetailResult(line, sku, sellerName, belongName);
                }
        );

        return SaleReturnOrderMapping.INSTANCE.tocDetailResult(
                returnOrder,
                saleOrder,
                buyerName,
                buyerPhone,
                buyerAddress,
                origin.getName(),
                retSkuList
        );
    }


    /**
     * 销售退货取消
     *
     * @param request
     */
    private void returnCancel(SaleReturnOrderCancelRequest request) {
        SaleReturnOrder returnOrder = repositoryFactory.getSaleReturnOrderRepository().findByIdOrSerialNo(
                request.getId(), null
        );
        ValidationUtil.notNull(returnOrder, "退货单id错误");

        List<SaleReturnOrderLine> lineList = repositoryFactory.getSaleReturnOrderLineRepository()
                .listByMainId(returnOrder.getId());

        //step_1 过滤状态不符合的数据
        SysBusinessUnit bu = repositoryFactory.getBusinessUnitRepository().findById(returnOrder.getStoreId());
        boolean pushToStore = bu.getType() == BusinessUnitTypeEnums.WAREHOUSE;


        lineList = lineList.stream()
                .filter(line -> line.getEndState() == WhetherEnum.NO)
                .collect(Collectors.toList());
        ValidationUtil.isTrue(StringUtils.isNotEmpty(lineList), "无可取消的商品");


        //step_2 调用wms 状态变化
        Set<Integer> skuIdList = MultiUtils.toSet(lineList, SaleReturnOrderLine::getSkuId);
        if (pushToStore) {
            wmsSubject.cancelWmsRk(returnOrder.getSerialNo(), skuIdList);
        } else {
            wmsSubject.cancelMerchantWms(returnOrder.getSerialNo(), skuIdList, SkuNodeStateEnums.DRK, false);
        }

    }


    @GlobalTransactional
    @Override
    public Boolean tocReturnCancel(SaleReturnOrderCancelRequest request) {
        returnCancel(request);
        return true;
    }

    @Override
    public PageResult<ToBSaleReturnOrderPageResult> tobReturnPage(ToBSaleReturnOrderPageRequest request) {
        //客户查询
        Set<Integer> buyerIdList = null;
        if (StringUtils.isNotEmpty(request.getBuyerName())) {
            buyerIdList = MultiUtils.toSet(
                    repositoryFactory.getSupplierContactsRepository()
                            .listByNameAndPhone(request.getBuyerName(), null),
                    SupplierContacts::getId
            );
            if (null == buyerIdList) {
                return PageResult.buildEmpty();
            }
        }

        //销售单查询
        //sku查询
        Set<Integer> returnIdList = new HashSet<>();
        List<SaleOrder> saleOrderList;
        if (StringUtils.oneOfNonNull(
                buyerIdList,
                request.getSaleSerialNo(),
                request.getSellType()
        )) {
            saleOrderList = repositoryFactory.getSaleOrderRepository().listForSaleReturn(
                    null,
                    buyerIdList,
                    request.getSaleSerialNo(),
                    request.getSellType()
            );
            if (StringUtils.isEmpty(saleOrderList)) {
                return PageResult.buildEmpty();
            }
            Set<Integer> saleIdList = MultiUtils.toSet(saleOrderList, SaleOrder::getId);

            List<SaleReturnOrderLine> lineList = repositoryFactory.getSaleReturnOrderLineRepository()
                    .listBySaleIds(saleIdList);
            if (StringUtils.isEmpty(lineList)) {
                return PageResult.buildEmpty();
            }
            returnIdList.addAll(MultiUtils.toSet(lineList, SaleReturnOrderLine::getReturnId));
        }


        if (StringUtils.isNotEmpty(request.getSkuCode())) {
            SkuRpcRequest rpcRequest = new SkuRpcRequest();
            rpcRequest.setSkuCode(request.getSkuCode());
            Set<Integer> skuIdList = MultiUtils.toSet(skuFacade.list(rpcRequest), SkuRpcResult::getId);

            if (StringUtils.isEmpty(skuIdList)) {
                return PageResult.buildEmpty();
            }


            List<SaleReturnOrderLine> lineList = repositoryFactory.getSaleReturnOrderLineRepository()
                    .listBySkuIds(skuIdList);

            if (StringUtils.isEmpty(lineList)) {
                return PageResult.buildEmpty();
            }
            returnIdList.addAll(MultiUtils.toSet(lineList, SaleReturnOrderLine::getReturnId));
        }


        //商品所在查询
        if (null != request.getBelongId()) {
            List<SaleReturnOrderLine> returnOrderLines = repositoryFactory.getSaleReturnOrderLineRepository()
                    .listByStoreId(request.getBelongId());
            if (returnOrderLines.isEmpty()) {
                return PageResult.buildEmpty();
            }

            Set<Integer> partOrderIds = MultiUtils.toSet(returnOrderLines, SaleReturnOrderLine::getReturnId);
            if (returnIdList.isEmpty()) {
                returnIdList = partOrderIds;
            } else {
                returnIdList.retainAll(partOrderIds);
                if (StringUtils.isEmpty(returnIdList)) {
                    return PageResult.buildEmpty();
                }
            }
        }


        //主表查询
        Integer buId = UserContext.getUser().getStore().getId();
        SysBusinessUnit bu = repositoryFactory.getBusinessUnitRepository().findById(buId);
        if (bu.getType() != BusinessUnitTypeEnums.PLATFORM) {
            request.setBuId(UserContext.getUser().getStore().getId());
        }
        Page<SaleReturnOrder> page = repositoryFactory.getSaleReturnOrderRepository().pageForB(
                request,
                returnIdList
        );
        if (StringUtils.isEmpty(page.getRecords())) {
            return PageResult.buildEmpty();
        }


        //组合

        //销售单数据
        Set<Integer> returnIds = MultiUtils.toSet(page.getRecords(), SaleReturnOrder::getId);
        List<SaleReturnOrderLine> returnLines = repositoryFactory.getSaleReturnOrderLineRepository()
                .listByMainIds(returnIds);
        Map<Integer, Integer> lineMap = new HashMap<>();
        for (SaleReturnOrderLine line : returnLines) {
            lineMap.putIfAbsent(line.getReturnId(), line.getSaleId());
        }

        Set<Integer> saleIdList = MultiUtils.toSet(returnLines, SaleReturnOrderLine::getSaleId);
        saleOrderList = repositoryFactory.getSaleOrderRepository().listByIds(saleIdList);
        Map<Integer, SaleOrder> saleOrderMap = MultiUtils.toMap(saleOrderList, SaleOrder::getId);


        //客户数据
        if (null == buyerIdList) {
            buyerIdList = MultiUtils.toSet(saleOrderList, SaleOrder::getBuyerId);
        }
        Map<Integer, String> buyerMap = MultiUtils.toMap(
                repositoryFactory.getSupplierContactsRepository().listByIds(buyerIdList),
                SupplierContacts::getId,
                SupplierContacts::getName
        );

        //订单来源
        Set<Integer> originIdList = MultiUtils.toSet(page.getRecords(), SaleReturnOrder::getBuId);
        Map<Integer, String> originMap = MultiUtils.toMap(
                repositoryFactory.getBusinessUnitRepository().listByIds(originIdList),
                SysBusinessUnit::getId,
                SysBusinessUnit::getName
        );

        //组合
        List<ToBSaleReturnOrderPageResult> ret = MultiUtils.toList(
                page.getRecords(),
                returnOrder -> {
                    Integer saleId = lineMap.get(returnOrder.getId());
                    SaleOrder saleOrder = saleOrderMap.get(saleId);
                    String buyerName = buyerMap.get(saleOrder.getBuyerId());
                    String originName = originMap.get(returnOrder.getBuId());

                    return SaleReturnOrderMapping.INSTANCE.tobPageResult(
                            saleOrder,
                            returnOrder,
                            buyerName,
                            originName
                    );
                }
        );

        return PageResult.<ToBSaleReturnOrderPageResult>builder()
                .result(ret)
                .totalCount(page.getTotal())
                .totalPage(page.getPages())
                .build();
    }

    @Override
    public ToBSaleReturnOrderDetailResult tobReturnDetail(ToBSaleReturnOrderDetailRequest request) {
        SaleReturnOrder returnOrder = repositoryFactory.getSaleReturnOrderRepository().findByIdOrSerialNo(
                request.getId(), null
        );
        ValidationUtil.notNull(returnOrder, "退货单id错误");

        //退货行
        List<SaleReturnOrderLine> lineList = repositoryFactory.getSaleReturnOrderLineRepository().listByMainId(returnOrder.getId());

        //销售单
        Integer saleId = lineList.get(0).getSaleId();
        SaleOrder saleOrder = repositoryFactory.getSaleOrderRepository().findByIdOrSerialNo(saleId, null);

        //客户
        SupplierContacts buyer = repositoryFactory.getSupplierContactsRepository().findById(saleOrder.getBuyerId());

        //联系人
        Supplier supplier = repositoryFactory.getSupplierRepository().findById(buyer.getSupplierId());

        //订单来源
        SysBusinessUnit origin = repositoryFactory.getBusinessUnitRepository().findById(returnOrder.getBuId());


        //sku查询
        Set<Integer> skuIdList = MultiUtils.toSet(lineList, SaleReturnOrderLine::getSkuId);
        SkuRpcRequest rpcRequest = new SkuRpcRequest();
        rpcRequest.setIdList(skuIdList);
        List<SkuRpcResult> rpcSkuList = skuFacade.list(rpcRequest);
        Map<Integer, SkuRpcResult> skuMap = MultiUtils.toMap(rpcSkuList, SkuRpcResult::getId);

        //经营权
        Set<Integer> sellIdList = MultiUtils.toSet(lineList, SaleReturnOrderLine::getSellerId);
        Map<Integer, String> sellerMap = MultiUtils.toMap(
                repositoryFactory.getBusinessUnitRepository().listByIds(sellIdList),
                SysBusinessUnit::getId,
                SysBusinessUnit::getName
        );

        //商品所在
        Set<Integer> belongIdList = MultiUtils.toSet(lineList, SaleReturnOrderLine::getStoreId);
        Map<Integer, String> belongMap = MultiUtils.toMap(
                repositoryFactory.getBusinessUnitRepository().listByIds(belongIdList),
                SysBusinessUnit::getId,
                SysBusinessUnit::getName
        );


        //数据转换
        List<ToBSaleReturnOrderDetailResult.Sku> retSkuList = MultiUtils.toList(
                lineList,
                line -> {
                    SkuRpcResult sku = skuMap.get(line.getSkuId());
                    String sellerName = sellerMap.get(line.getSellerId());
                    String belongName = belongMap.get(line.getStoreId());
                    return SaleReturnOrderLineMapping.INSTANCE.tobDetailResult(line, sku, sellerName, belongName);
                }
        );

        return SaleReturnOrderMapping.INSTANCE.tobDetailResult(
                returnOrder,
                saleOrder,
                buyer.getName(),
                buyer.getPhone(),
                supplier.getCompleteAddress(),
                origin.getName(),
                retSkuList
        );
    }

    @Override
    public Boolean tobReturnCancel(SaleReturnOrderCancelRequest request) {
        returnCancel(request);
        return true;
    }

    @GlobalTransactional
    @Override
    public Boolean tobReturnCreate(ToBSaleReturnOrderCreateRequest request) {
        //steo_1 查询对应sku的销售单行
        Set<Integer> skuIdList = MultiUtils.toSet(request.getSkuList(), ToBSaleReturnOrderCreateRequest.Sku::getSkuId);
        ValidationUtil.isTrue(!skuIdList.isEmpty(), "请选择需要退货的sku");

        ValidationUtil.isTrue(
                StringUtils.oneOfNonNull(request.getBuyerId(), request.getSaleId()),
                "销售单id 或者客户id 其中一个必填"
        );
        Integer buyerId = request.getBuyerId();
        if (null == buyerId) {
            SaleOrder saleOrder = repositoryFactory.getSaleOrderRepository().findByIdOrSerialNo(request.getSaleId(), null);
            buyerId = saleOrder.getBuyerId();
        }

        //stpe_2 查找销售单行
        List<SaleOrderLine> saleLineList = repositoryFactory.getSaleOrderLineRepository()
                .findLatest(skuIdList, Arrays.asList(SkuNodeStateEnums.YCK, SkuNodeStateEnums.JI_SZ));
        ValidationUtil.isTrue(saleLineList.size() == skuIdList.size(), "存在不可退货的sku");


        //step_3 构建客户信息
        SupplierContacts contact = repositoryFactory.getSupplierContactsRepository().findById(buyerId);
        Supplier supplier = repositoryFactory.getSupplierRepository().findById(contact.getSupplierId());
        ContactInfo buyer = PurchaseOrderMapping.INSTANCE.toMerchantWmsContactInfo(supplier);

        Map<Integer, ToBSaleReturnOrderCreateRequest.Sku> paramMap = MultiUtils.toMap(
                request.getSkuList(),
                ToBSaleReturnOrderCreateRequest.Sku::getSkuId
        );

        //step_4 构造请求参数
        saleLineList.stream()
                //根据销售单分组
                .collect(Collectors.groupingBy(SaleOrderLine::getSaleId))
                .forEach((k, v) -> {

                    SaleOrder saleOrder = repositoryFactory.getSaleOrderRepository()
                            .findByIdOrSerialNo(k, null);


                    //参数转化
                    SaleReturnOrderCreateRequest req = new SaleReturnOrderCreateRequest();
                    req.setRemark(request.getRemark());
                    req.setMainSerialNo(SerialNoGenerator.generalSerial(SerialNoGenerator.Type.TO_B_XS_TH));

                    List<SaleReturnOrderCreateRequest.Sku> skuList = MultiUtils.toList(
                            v,
                            saleLine -> {
                                ToBSaleReturnOrderCreateRequest.Sku paramSku = paramMap.get(saleLine.getSkuId());

                                return SaleReturnOrderMapping.INSTANCE.toCreateRequest(
                                        saleLine,
                                        paramSku
                                );
                            }
                    );
                    req.setSkuList(skuList);
                    //执行创建
                    returnCreate(
                            req,
                            SaleModelEnums.B,
                            buyer,
                            saleOrder
                    );
                });


        return true;


    }
}
