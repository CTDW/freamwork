package com.seeease.flywheel_v4.web.domain.excel.strategy.Import;

import com.alibaba.cola.extension.Extension;
import com.seeease.flywheel_v4.web.app.excel.request.PurchaseLuggageImportRequest;
import com.seeease.flywheel_v4.web.app.excel.result.PurchaseSkuImportResult;
import com.seeease.flywheel_v4.web.domain.excel.core.ImportExtPtl;
import com.seeease.goods.rpc.SpuFacade;
import com.seeease.goods.rpc.request.SpuRpcRequest;
import com.seeease.goods.rpc.result.SpuRpcResult;
import com.seeease.springframework.exception.ValidationUtil;
import com.seeease.springframework.utils.MultiUtils;
import com.seeease.springframework.utils.StringUtils;
import org.apache.dubbo.config.annotation.DubboReference;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 *
 * @author 西门 游
 * @version 1.0
 * @since 9/11/24 1:39 下午
 **/
@Service
@Extension(bizId = "import", useCase = "purchaseLuggage")
public class PurchaseLuggageImport implements ImportExtPtl<PurchaseLuggageImportRequest, PurchaseSkuImportResult> {

    @DubboReference(check = false,version = "1.0.0")
    private SpuFacade spuFacade;

    @Override
    public Class<PurchaseLuggageImportRequest> getRequestClass() {
        return PurchaseLuggageImportRequest.class;
    }

    @Override
    public void validate(List<PurchaseLuggageImportRequest> data) {

    }

    @Override
    public List<PurchaseSkuImportResult> handle(List<PurchaseLuggageImportRequest> data) {
        //查找spu
        Set<String> codes = MultiUtils.toSet(data, PurchaseLuggageImportRequest::getGoodsCode);
        SpuRpcRequest rpcRequest = new SpuRpcRequest();
        rpcRequest.setSpuCodes(codes);
        Map<String, SpuRpcResult> spuMap = MultiUtils.toMap(
                spuFacade.list(rpcRequest),
                SpuRpcResult::getGoodsCode
        );

        ValidationUtil.isTrue(spuMap.size() == 1,"不允许导入不同sku的商品");


        ArrayList<PurchaseSkuImportResult> ret = new ArrayList<>();


        for (PurchaseLuggageImportRequest item : data){

            PurchaseSkuImportResult sku = new PurchaseSkuImportResult();

            //step_1 转换附件
            List<PurchaseSkuImportResult.SkuAnnexe> annexe = mappingAnnex(item);
            sku.setAnnexe(annexe);

            //step_2 设置spu属性
            SpuRpcResult spu = spuMap.get(item.getGoodsCode());
            if (null == spu){
                continue;
            }
            sku.setSpuId(spu.getId());
            sku.setUniqueType(spu.getUniqueType());
            sku.setSpuImage(spu.getSpuImage());
            sku.setGoodsName(spu.getGoodsName());
            sku.setCategoryName("箱包/箱包");
            sku.setBrandName(spu.getBrandName());


            //step_3 设置采购价
            sku.setPurchasePrice(item.getPurchasePrice());

            //step_4 设置数量
            sku.setCount(1);

            //step_5 设置唯一码
            sku.setSkuCode(item.getSkuCode());

            //step_6 设置参数
            sku.setSkuParams(mappingParams(item));

            ret.add(sku);
        }


        return ret;
    }


    private List<PurchaseSkuImportResult.SkuParam>  mappingParams(PurchaseLuggageImportRequest item){
        List<PurchaseSkuImportResult.SkuParam> params = new ArrayList<>();

        if (StringUtils.isNotEmpty(item.getEngraving())){
            PurchaseSkuImportResult.SkuParam param = new PurchaseSkuImportResult.SkuParam();
            param.setParamCode("keyin");
            param.setParamName("刻印");
            param.setParamValue(Collections.singletonList(item.getEngraving()));
            params.add(param);
        }
        if (StringUtils.isNotEmpty(item.getYear())){
            PurchaseSkuImportResult.SkuParam param = new PurchaseSkuImportResult.SkuParam();
            param.setParamCode("nianfen");
            param.setParamName("年份");
            param.setParamValue(Collections.singletonList(item.getYear()));
            params.add(param);
        }
        if (StringUtils.isNotEmpty(item.getChip())){
            PurchaseSkuImportResult.SkuParam param = new PurchaseSkuImportResult.SkuParam();
            param.setParamCode("shifouxinpiankuan");
            param.setParamName("是否芯片款");
            param.setParamValue(Collections.singletonList(item.getChip()));
            params.add(param);
        }

        return params;
    }


    private List<PurchaseSkuImportResult.SkuAnnexe> mappingAnnex(PurchaseLuggageImportRequest item){

        List<PurchaseSkuImportResult.SkuAnnexe> annexe = new ArrayList<>();
        if ("是".equals(item.getBox())){
            PurchaseSkuImportResult.SkuAnnexe annexeItem = new PurchaseSkuImportResult.SkuAnnexe();
            annexeItem.setParamName("盒子");
            annexeItem.setSelectType(2);
            annexe.add(annexeItem);
        }

        if ("是".equals(item.getDustBag())){
            PurchaseSkuImportResult.SkuAnnexe annexeItem = new PurchaseSkuImportResult.SkuAnnexe();
            annexeItem.setParamName("防尘袋");
            annexeItem.setSelectType(2);
            annexe.add(annexeItem);
        }

        if ("是".equals(item.getShoulderStrap())){
            PurchaseSkuImportResult.SkuAnnexe annexeItem = new PurchaseSkuImportResult.SkuAnnexe();
            annexeItem.setParamName("肩带");
            annexeItem.setSelectType(2);
            annexe.add(annexeItem);
        }


        if ("是".equals(item.getManual())){
            PurchaseSkuImportResult.SkuAnnexe annexeItem = new PurchaseSkuImportResult.SkuAnnexe();
            annexeItem.setParamName("说明书");
            annexeItem.setSelectType(2);
            annexe.add(annexeItem);
        }


        if ("是".equals(item.getIdCard())){
            PurchaseSkuImportResult.SkuAnnexe annexeItem = new PurchaseSkuImportResult.SkuAnnexe();
            annexeItem.setParamName("身份卡");
            annexeItem.setSelectType(2);
            annexe.add(annexeItem);
        }


        if (StringUtils.isNotEmpty(item.getCard())){
            PurchaseSkuImportResult.SkuAnnexe annexeItem = new PurchaseSkuImportResult.SkuAnnexe();
            annexeItem.setParamName("保卡");
            annexeItem.setSelectType(4);
            annexeItem.setValue(item.getCard());
            annexe.add(annexeItem);
        }

        if ("是".equals(item.getKey())){
            PurchaseSkuImportResult.SkuAnnexe annexeItem = new PurchaseSkuImportResult.SkuAnnexe();
            annexeItem.setParamName("钥匙");
            annexeItem.setSelectType(2);
            annexe.add(annexeItem);
        }

        if ("是".equals(item.getLock())){
            PurchaseSkuImportResult.SkuAnnexe annexeItem = new PurchaseSkuImportResult.SkuAnnexe();
            annexeItem.setParamName("锁");
            annexeItem.setSelectType(2);
            annexe.add(annexeItem);
        }

        if ("是".equals(item.getLeatherTag())){
            PurchaseSkuImportResult.SkuAnnexe annexeItem = new PurchaseSkuImportResult.SkuAnnexe();
            annexeItem.setParamName("皮牌");
            annexeItem.setSelectType(2);
            annexe.add(annexeItem);
        }


        if ("是".equals(item.getFelt())){
            PurchaseSkuImportResult.SkuAnnexe annexeItem = new PurchaseSkuImportResult.SkuAnnexe();
            annexeItem.setParamName("毛毡");
            annexeItem.setSelectType(2);
            annexe.add(annexeItem);
        }


        if ("是".equals(item.getBrandTagCard())){
            PurchaseSkuImportResult.SkuAnnexe annexeItem = new PurchaseSkuImportResult.SkuAnnexe();
            annexeItem.setParamName("品牌标签卡");
            annexeItem.setSelectType(2);
            annexe.add(annexeItem);
        }

        if ("是".equals(item.getShoppingTicket())){
            PurchaseSkuImportResult.SkuAnnexe annexeItem = new PurchaseSkuImportResult.SkuAnnexe();
            annexeItem.setParamName("购物票");
            annexeItem.setSelectType(2);
            annexe.add(annexeItem);
        }



        if (StringUtils.isNotEmpty(item.getFillRemark())){
            PurchaseSkuImportResult.SkuAnnexe annexeItem = new PurchaseSkuImportResult.SkuAnnexe();
            annexeItem.setParamName("补充备注");
            annexeItem.setSelectType(3);
            annexeItem.setValue(item.getFillRemark());
            annexe.add(annexeItem);
        }



        return annexe;
    }
}
