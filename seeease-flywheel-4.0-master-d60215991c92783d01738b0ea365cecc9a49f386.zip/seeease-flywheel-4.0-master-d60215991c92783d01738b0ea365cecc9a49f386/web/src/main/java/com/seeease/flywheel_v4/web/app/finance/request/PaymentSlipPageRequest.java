package com.seeease.flywheel_v4.web.app.finance.request;


import com.fasterxml.jackson.annotation.JsonFormat;
import com.google.common.collect.Sets;
import com.seeease.springframework.PageRequest;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Date;
import java.util.Set;

/**
 * @ Description   :
 * @ Author        :  西门 游
 * @ CreateDate    :  6/6/24
 * @ Version       :  1.0
 */

@EqualsAndHashCode(callSuper = true)
@Data
public class PaymentSlipPageRequest extends PageRequest {
    /**
     * id
     */
    private Set<Integer> ids;

    /**
     * 采购单号
     */
    private String purchaseSerialNo;
    /**
     * 申请打款单号
     */
    private String serialNo;
    /**
     * 供应商名称
     */
    private String supplierName;
    /**
     * 打款单状态
     */
    private Integer state;
    /**
     * sku唯一码
     */
    private String skuCode;
    /**
     * 创建人
     */
    private String createdBy;
    /**
     * 开始时间
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date startTime;
    /**
     * 结束时间
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date endTime;
    /**
     * 核销状态
     */
    private Integer verifyState;

    /**
     * 采购订单id列表
     */
    private Set<Integer> purchaseIdList = Sets.newHashSet();
    /**
     * 供应商id列表
     */
    private Set<Integer> supplierIdList;

    /**
     * 当前操作人业务部门id 用于权限控制
     */
    private Integer buId;
}
