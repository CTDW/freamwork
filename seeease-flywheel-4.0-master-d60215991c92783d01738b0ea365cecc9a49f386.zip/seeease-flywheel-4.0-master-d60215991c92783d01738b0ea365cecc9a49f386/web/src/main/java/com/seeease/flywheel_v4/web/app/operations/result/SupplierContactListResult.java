package com.seeease.flywheel_v4.web.app.operations.result;

import lombok.Data;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/4/24 6:00 下午
 **/
@Data
public class SupplierContactListResult {
    /**
     * id
     */
    private Integer id;
    /**
     * 供应商id
     */
    private Integer supplierId;
    /**
     * 供应商名称
     */
    private String supplierName;
    /**
     * 联系人名称
     */
    private String name;
    /**
     * 联系人电话
     */
    private String phone;
    /**
     * 联系人银行
     */
    private String bank;
    /**
     * 联系人银行账号
     */
    private String account;
    /**
     * 联系人开户行
     */
    private String bankName;
    /**
     * 银行转账户名
     */
    private String accountName;
    /**
     * 供应商类型
     */
    private Integer supplierType;
    /**
     * 供应商地址
     */
    private String supplierAddress;
    /**
     * 创建人
     */
    private String createdBy;
}
