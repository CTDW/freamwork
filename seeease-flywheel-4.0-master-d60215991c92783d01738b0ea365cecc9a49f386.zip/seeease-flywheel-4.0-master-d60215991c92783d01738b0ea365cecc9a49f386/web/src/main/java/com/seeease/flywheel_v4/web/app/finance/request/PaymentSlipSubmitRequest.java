package com.seeease.flywheel_v4.web.app.finance.request;


import com.seeease.springframework.RequestValidGroup;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.util.List;

/**
 * @ Description   :
 * @ Author        :  西门 游
 * @ CreateDate    :  6/6/24
 * @ Version       :  1.0
 */

@Data
public class PaymentSlipSubmitRequest {
    /**
     * 申请打款单id
     */
    @NotNull(message = "id不能为空",groups = {RequestValidGroup.Update.class,RequestValidGroup.State.class})
    private Integer id;
    /**
     * 打款金额
     */
    @NotNull(message = "打款金额不能为空",groups = RequestValidGroup.Update.class)
    private String amount;

    /**
     * 状态
     */
    @NotNull(message = "实际打款金额不能为空",groups = RequestValidGroup.State.class)
    private Integer state;

    /**
     * 采购单id
     */
    @NotNull(message = "采购单id不能为空",groups = RequestValidGroup.Create.class)
    private Integer purchaseId;
    /**
     * 供应商名称
     */
    @NotBlank(message = "供应商名称不能为空")
    private String supplierName;
    /**
     * 联系人名称
     */
    @NotBlank(message = "联系人名称不能为空")
    private String contactName;
    /**
     * 联系人银行
     */
    @NotBlank(message = "联系人银行不能为空")
    private String bank;
    /**
     * 联系人银行账号
     */
    @NotBlank(message = "联系人银行账号不能为空")
    private String account;
    /**
     * 联系人开户行
     */
    @NotBlank(message = "联系人开户行不能为空")
    private String bankName;
    /**
     * 图片列表
     */
    private List<String> images;
    /**
     * 转让协议图片
     */
    private String contractImg;
    /**
     * 回收定价聊天记录/回购承诺函图片
     */
    private String evidenceImg;
    /**
     * 身份证正面图片
     */
    private String idFrontImg;
    /**
     * 身份证反面图片
     */
    private String idBackImg;
    /**
     * 打款凭证图片
     */
    private String payedImg;


}
