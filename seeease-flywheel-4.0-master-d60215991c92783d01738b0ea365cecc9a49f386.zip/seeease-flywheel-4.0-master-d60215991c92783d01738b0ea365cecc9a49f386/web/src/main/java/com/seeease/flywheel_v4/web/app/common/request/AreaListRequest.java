package com.seeease.flywheel_v4.web.app.common.request;

import lombok.Data;

import javax.validation.constraints.NotNull;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 7/25/24 1:37 下午
 **/
@Data
public class AreaListRequest {
    /**
     * 父节点id
     */
    @NotNull(message = "父节点id不能为空")
    private Integer parentId;
}
