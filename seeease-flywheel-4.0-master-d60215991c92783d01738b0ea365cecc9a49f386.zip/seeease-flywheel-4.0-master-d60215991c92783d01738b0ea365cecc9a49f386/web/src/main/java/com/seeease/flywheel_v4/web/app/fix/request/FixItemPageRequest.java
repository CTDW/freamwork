package com.seeease.flywheel_v4.web.app.fix.request;

import com.seeease.springframework.PageRequest;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @Description 维修中心-维修项目 请求值
 * @Date 2024-10-2 20:20
 * @Author by hk
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class FixItemPageRequest extends PageRequest {

    @ApiModelProperty(value = "维修项目名称")
    private String itemName;
}
