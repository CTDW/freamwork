package com.seeease.flywheel_v4.web.app.excel.result;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.format.DateTimeFormat;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 9/11/24 5:00 下午
 **/
@Data
public class PurchaseExportResult implements Serializable {



    @ExcelProperty("采购单号")
    private String serialNo;

    @ExcelProperty("状态")
    private String state;

    @ExcelProperty("类型")
    private String type;

    @ExcelProperty("打款方式")
    private String payType;

    @ExcelProperty("商品名称")
    private String goodsName;

    @ExcelProperty("品牌")
    private String brandName;

    @ExcelProperty("类目")
    private String categoryName;

    @ExcelProperty("入库参数")
    private String param;

    @ExcelProperty("唯一码")
    private String skuCode;

    @ExcelProperty("数量")
    private Integer count;

    @ExcelProperty("附件")
    private String annex;

    @ExcelProperty("采购价")
    private String purchasePrice;

    @ExcelProperty("维修费")
    private BigDecimal repairPrice;

    @ExcelProperty("表带更换费")
    private BigDecimal strapPrice;

    @ExcelProperty("回购价")
    private BigDecimal buybackPrice;

    @ExcelProperty("供应商")
    private String supplierName;

    @ExcelProperty("快递单")
    private String expressNo;

    @ExcelProperty("流程节点")
    private String nodeState;

    @ExcelProperty("备注")
    private String remark;

    @ExcelProperty("实际采购人")
    private String buyerName;

    @ExcelProperty("需求方")
    private String merchantName;

    @ExcelProperty("商品所属")
    private String purchaseSubjectName;

    @ExcelProperty("入库仓")
    private String storeName;

    @ExcelProperty("创建人")
    private String createdBy;

    @DateTimeFormat("yyyy-MM-dd HH:mm:ss")
    @ExcelProperty("创建时间")
    private Date createdTime;

}
