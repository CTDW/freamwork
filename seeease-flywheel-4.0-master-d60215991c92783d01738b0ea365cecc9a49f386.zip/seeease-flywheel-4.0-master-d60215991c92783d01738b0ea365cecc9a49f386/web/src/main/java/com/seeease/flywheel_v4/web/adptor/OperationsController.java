package com.seeease.flywheel_v4.web.adptor;


import com.seeease.flywheel_v4.web.app.operations.request.*;
import com.seeease.flywheel_v4.web.app.operations.result.*;
import com.seeease.flywheel_v4.web.app.operations.service.*;
import com.seeease.flywheel_v4.web.infrastructure.config.IdentifyLogPrinter;
import com.seeease.springframework.PageResult;
import com.seeease.springframework.RequestValidGroup;
import com.seeease.springframework.SingleResponse;
import com.seeease.springframework.log.annotation.LogPrinter;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.validation.groups.Default;
import java.util.List;

/**
 * <p>系统运营</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 5/30/24 5:35 下午
 **/
@RestController
@RequestMapping("ops")
public class OperationsController {

    @Resource
    private SupplierService supplierService;
    @Resource
    private SupplierContactsService supplierContactsService;
    @Resource
    private PricingService pricingService;
    @Resource
    private TransferQuotaService transferQuotaService;



    /**
     * 系统运营-供应商创建
     *
     * @return 创建结果
     */
    @PostMapping("supplier/create")
    @LogPrinter(scenario = "系统运营-供应商创建", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<Boolean> supplierCreate(@Validated @RequestBody SupplierSubmitRequest request) {

        return SingleResponse.of(supplierService.create(request));
    }


    /**
     * 系统运营-供应商更新
     *
     * @return 更新结果
     */
    @PostMapping("supplier/update")
    @LogPrinter(scenario = "系统运营-供应商更新", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<Boolean> supplierUpdate(
            @Validated({RequestValidGroup.Update.class, Default.class})
            @RequestBody SupplierSubmitRequest request) {

        return SingleResponse.of(supplierService.update(request));
    }

    /**
     * 系统运营-联系人删除更新
     *
     * @return 删除结果
     */
    @PostMapping("supplier/contacts/del")
    @LogPrinter(scenario = "系统运营-联系人删除", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<Integer> contactsDel(
            @Validated({RequestValidGroup.Deleted.class})
            @RequestBody SupplierContactSubmitRequest request) {

        supplierContactsService.del(request.getId());
        return SingleResponse.of(request.getId());
    }

    /**
     * 系统运营-联系人创建
     *
     * @return 创建结果
     */
    @PostMapping("supplier/contacts/create")
    @LogPrinter(scenario = "系统运营-联系人创建", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<SupplierContactListResult> contactsCreate(
            @Validated({SupplierContactSubmitRequest.Create.class, Default.class})
            @RequestBody SupplierContactSubmitRequest request) {

        return SingleResponse.of(supplierContactsService.create(request));
    }


    /**
     * 系统运营-供应商分页查询
     *
     * @return 分页结果
     */
    @PostMapping("supplier/page")
    @LogPrinter(scenario = "系统运营-供应商分页查询", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<PageResult<SupplierPageResult>> supplierPage(@RequestBody SupplierPageRequest request) {

        return SingleResponse.of(supplierService.page(request));
    }


    /**
     * 系统运营-联系人列表查询
     *
     * @return 列表结果
     */
    @PostMapping("contact/list")
    @LogPrinter(scenario = "系统运营-联系人列表查询", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<List<SupplierContactListResult>> contactList(@RequestBody ContactListRequest request) {

        return SingleResponse.of(supplierService.contactList(request));
    }


    /**
     * 系统运营-定价管理分页查询
     *
     * @return 分页结果
     */
    @PostMapping("pricing/page")
    @LogPrinter(scenario = "系统运营-定价管理分页查询", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<PageResult<PricingPageResult>> pricingPage(@RequestBody PricingPageRequest request) {

        return SingleResponse.of(pricingService.page(request));
    }


    /**
     * 系统运营-定价管理详情查询
     *
     * @return 详情结果
     */
    @PostMapping("pricing/detail")
    @LogPrinter(scenario = "系统运营-定价管理详情查询", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<PricingDetailResult> pricingDetail(@RequestBody PricingDetailRequest request) {

        return SingleResponse.of(pricingService.detail(request));
    }


    /**
     * 系统运营-sku定价管理状态变更
     *
     * @return 状态变更结果
     */
    @PostMapping("pricing/state")
    @LogPrinter(scenario = "系统运营-sku定价管理状态变更", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<Boolean> pricingState(
            @Validated @RequestBody PricingStateRequest request) {

        return SingleResponse.of(pricingService.state(request));
    }


    /**
     * 系统运营-sku批量定价通过
     *
     * @return 状态变更结果
     */
    @PostMapping("pricing/batch/pass")
    @LogPrinter(scenario = "系统运营-sku批量定价通过", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<Boolean> pricingBatchPass(
            @Validated @RequestBody PricingBatchPassRequest request) {

        return SingleResponse.of(pricingService.batchPass(request));
    }




    /**
     * 系统运营-门店调拨额度创建
     *
     * @return 创建结果
     */
    @PostMapping("transfer/quota/create")
    @LogPrinter(scenario = "系统运营-门店调拨额度创建", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<Boolean> transferQuotaCreate(
            @Validated @RequestBody TransferQuotaSubmitRequest request) {

        return SingleResponse.of(transferQuotaService.create(request));
    }


    /**
     * 系统运营-门店调拨额度更新
     *
     * @return 更新结果
     */
    @PostMapping("transfer/quota/update")
    @LogPrinter(scenario = "系统运营-门店调拨额度更新", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<Boolean> transferQuotaUpdate(
            @Validated({Default.class, RequestValidGroup.Update.class})
            @RequestBody TransferQuotaSubmitRequest request) {

        return SingleResponse.of(transferQuotaService.update(request));
    }


    /**
     * 系统运营-门店调拨额度分页查询
     *
     * @return 分页结果
     */
    @PostMapping("transfer/quota/page")
    @LogPrinter(scenario = "系统运营-门店调拨额度分页查询", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<PageResult<TransferQuotaPageResult>> transferQuotaPage(
            @RequestBody TransferQuotaPageRequest request) {

        return SingleResponse.of(transferQuotaService.page(request));
    }

    /**
     * 系统运营-门店调拨额度删除
     *
     * @return 删除结果
     */
    @PostMapping("transfer/quota/del")
    @LogPrinter(scenario = "系统运营-门店调拨额度删除", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<Boolean> transferQuotaDel(
            @Validated(RequestValidGroup.Deleted.class)
            @RequestBody TransferQuotaSubmitRequest request) {

        return SingleResponse.of(transferQuotaService.del(request.getId()));
    }


}
