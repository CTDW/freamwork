package com.seeease.flywheel_v4.web.app.excel.request;


import com.alibaba.excel.annotation.ExcelProperty;
import lombok.Data;


@Data
public class WmsCkReplaceImportRequest {

    @ExcelProperty(value = "唯一码")
    private String skuCode;
    @ExcelProperty(value = "订单号")
    private String serialNo;
}
