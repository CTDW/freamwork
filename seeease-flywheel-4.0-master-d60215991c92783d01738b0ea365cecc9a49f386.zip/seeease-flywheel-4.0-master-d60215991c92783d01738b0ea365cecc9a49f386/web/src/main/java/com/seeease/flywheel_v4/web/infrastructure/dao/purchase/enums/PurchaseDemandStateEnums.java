package com.seeease.flywheel_v4.web.infrastructure.dao.purchase.enums;


import com.seeease.seeeaseframework.mybatis.transitionstate.IStateEnum;
import com.seeease.seeeaseframework.mybatis.transitionstate.ITransitionStateEnum;
import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * <p>采购需求状态</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/5/24 1:47 下午
 **/
@AllArgsConstructor
@Getter
public enum PurchaseDemandStateEnums implements IStateEnum<Integer> {
    WAIT_CONFIRM(1,"需求待确认"),
    CONFIRMED(2,"采购单已创建"),
    CANCEL(3,"需求已取消")
    ;
    private Integer value;
    private String desc;

    @Getter
    @AllArgsConstructor
    public enum TransitionEnum implements ITransitionStateEnum {

        STEP_1(WAIT_CONFIRM,CONFIRMED,"确认采购需求"),
        STEP_2(WAIT_CONFIRM,CANCEL,"取消采购需求")
        ;
        private PurchaseDemandStateEnums fromState;
        private PurchaseDemandStateEnums toState;
        private String desc;

    }
}
