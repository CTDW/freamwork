package com.seeease.flywheel_v4.web.domain.wms.mapping;


import com.seeease.flywheel_v4.client.enums.BusinessUnitTypeEnums;
import com.seeease.flywheel_v4.web.app.wms.result.MerchantWmsDetailResult;
import com.seeease.flywheel_v4.web.infrastructure.config.EnumMapping;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.MerchantWmsLine;
import com.seeease.goods.rpc.enums.SkuNodeStateEnums;
import com.seeease.goods.rpc.enums.SkuStateEnums;
import com.seeease.goods.rpc.result.SkuRpcResult;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;


/**
 * <p>
 * 商品附件
 * </p>
 *
 * @author 西门 游
 * @since 2023-10-27
 */
@Mapper(componentModel = "spring",
        builder = @Builder(disableBuilder = true),
        nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS,
        nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE,
        imports = {BusinessUnitTypeEnums.class, SkuNodeStateEnums.class, SkuStateEnums.TransitionEnum.class, SkuStateEnums.class})
public interface MerchantWmsLineMapping extends EnumMapping {

    MerchantWmsLineMapping INSTANCE = Mappers.getMapper(MerchantWmsLineMapping.class);


    @Mapping(target = "skuId",source = "sku.id")
    @Mapping(target = "lineId",source = "line.id")
    @Mapping(target = "price",source = "line.price")
    MerchantWmsDetailResult.Sku toDetail(SkuRpcResult sku, MerchantWmsLine line);

}
