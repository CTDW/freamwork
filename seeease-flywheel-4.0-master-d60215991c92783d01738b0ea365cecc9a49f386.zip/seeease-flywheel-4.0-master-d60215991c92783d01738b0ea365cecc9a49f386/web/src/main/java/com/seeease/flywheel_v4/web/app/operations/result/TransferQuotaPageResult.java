package com.seeease.flywheel_v4.web.app.operations.result;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.TransferQuota;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

@Data
public class TransferQuotaPageResult {
    /**
     * 主键id
     * {@link TransferQuota#getId()}
     */
    private Integer id;
    /**
     * 商家名称
     */
    private String merchantName;
    /**
     * 压货总额度
     */
    private BigDecimal osQuota;
    /**
     * 已使用压货总额度
     */
    private BigDecimal usedOsQuota;
    /**
     * 代销总额度
     */
    private BigDecimal ctQuota;
    /**
     * 已使用代销总额度
     */
    private BigDecimal usedCtQuota;
    /**
     * 是否调拨控制
     */
    private Integer isCtl;
    /**
     * 开始时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date startDate;
    /**
     * 结束时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date endDate;
    /**
     * 商家id
     */
    private Integer merchantId;
    /**
     * 类目id列表
     */
    private List<Integer> categoryIds;
    /**
     * 类目名称
     */
    private String categoryNames;

    /**
     * 压货额度
     */
    private List<TransferQuotaLineListResult> osQuotas;
    /**
     * 代销额度
     */
    private List<TransferQuotaLineListResult> ctQuotas;

    /**
     * 创建人
     */
    private String createdBy;

    /**
     * 创建时间
     */
    private Date createdTime;

}
