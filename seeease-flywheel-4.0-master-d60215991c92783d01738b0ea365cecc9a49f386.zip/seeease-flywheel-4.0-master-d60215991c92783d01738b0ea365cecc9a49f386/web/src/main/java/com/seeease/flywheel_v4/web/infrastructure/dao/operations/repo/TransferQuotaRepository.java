package com.seeease.flywheel_v4.web.infrastructure.dao.operations.repo;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.seeease.flywheel_v4.web.app.operations.request.TransferQuotaPageRequest;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.TransferQuota;

import java.util.List;


/**
 *
 * @author 西门 游
 * @version 1.0
 * @since 5/31/24 4:55 下午
 **/
public interface TransferQuotaRepository {

    /**
     * 查找
     * @param merchantId 商家id
     * @return
     */
    List<TransferQuota> listByMerchantId(Integer merchantId);

    /**
     * 提交
     * @param transferQuota
     * @return
     */
    Boolean submit(TransferQuota transferQuota);

    /**
     * 分页
     * @param request
     * @return
     */
    Page<TransferQuota> page(TransferQuotaPageRequest request);

    /**
     * 删除
     * @param id
     * @return
     */
    Boolean delById(Integer id);
}
