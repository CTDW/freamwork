package com.seeease.flywheel_v4.web.app.purchase.request;


import com.seeease.goods.rpc.request.PurchaseSkuCreateRpcRequest;
import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.Collections;
import java.util.List;
import java.util.Map;


/**
 * @ Description   :
 * @ Author        :  西门 游
 * @ CreateDate    :  6/6/24
 * @ Version       :  1.0
 */
@Data
public class PurchaseOrderSubmitRequest {
    /**
     * 采购需求单id列表
     */
    private List<Integer> demandIdList;
    /**
     * 付款比例
     */
    private BigDecimal payRatio= new BigDecimal(100);
    /**
     * 采购类型
     */
    @NotNull(message = "采购类型不能为空")
    private Integer type;
    /**
     * 付款方式
     */
    @NotNull(message = "付款方式不能为空")
    private Integer payType;

    /**
     * 销售单id
     */
    private Integer sellId;

    /**
     * 新销售单id 回购置换时使用
     */
    private Integer newSellId;

    /**
     * 供应商id
     */
    @NotNull(message = "供应商id不能为空")
    private Integer supplierId;
    /**
     * 供应商联系人
     */
    @NotNull(message = "供应商联系人id不能为空")
    private Integer supplierContactId;
    /**
     * 采购人id
     */
    @NotNull(message = "采购人id不能为空")
    private Integer buyerId;
    /**
     * 采购主体id
     */
    @NotNull(message = "采购主体id不能为空")
    private Integer purchaseSubjectId;
    /**
     * 商家id
     */
    private Integer merchantId;
    /**
     * 仓库id
     */
    @NotNull(message = "仓库id不能为空")
    private Integer storeId;
    /**
     * 图片
     */
    private List<String> images;

    /**
     * sku列表
     */
    @Valid
    @NotEmpty(message = "sku不能为空")
    private List<Sku> skuList;
    /**
     * 定价方id
     */
    @NotNull(message = "定价方id不能为空")
    private Integer pricerId;
    /**
     * 备注
     */
    private String remark;

    @Data
    public static class Sku  {
        /**
         * uuid
         */
        private String uuid;
        /**
         * spuId
         */
        @NotNull(message = "spuId不能为空")
        private Integer spuId;
        /**
         * 销售单行id
         */
        private Integer lineId;
        /**
         * 回购政策下标
         */
        private Integer policyIndex;
        /**
         * 采购价
         */
        private BigDecimal purchasePrice;
        /**
         * 回购价
         */
        private BigDecimal buybackPrice;

        /**
         * 采购数量
         */
        @NotNull(message = "采购数量不能为空")
        private Integer count;
        /**
         * 表带根换费
         */
        private BigDecimal strapPrice = BigDecimal.ZERO;
        /**
         * 维修价格
         */
        private BigDecimal repairPrice = BigDecimal.ZERO;
        /**
         * 收货价
         */
        private BigDecimal receiptPrice;
        /**
         * sku参数列表
         */
        private Map<String, List<String>> skuParamMap = Collections.emptyMap();
        /**
         * 附件
         */
        private List<PurchaseSkuCreateRpcRequest.SkuAnnexe> annexe;
        /**
         * 唯一码
         */
        private String skuCode;


    }

}
