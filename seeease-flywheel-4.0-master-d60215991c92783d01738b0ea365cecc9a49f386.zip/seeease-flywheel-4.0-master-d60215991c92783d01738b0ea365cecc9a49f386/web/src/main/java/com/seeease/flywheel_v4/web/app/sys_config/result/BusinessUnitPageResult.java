package com.seeease.flywheel_v4.web.app.sys_config.result;


import lombok.Data;

import java.util.Date;
import java.util.List;

/**
 * @author 西门 游
 * @version 1.0
 * @since 6/3/24 11:26 上午
 **/
@Data
public class BusinessUnitPageResult {
    /**
     * id
     */
    private Integer id;
    /**
     * 名称
     */
    private String name;
    /**
     * 业务单元类型
     */
    private Integer type;
    /**
     * 负责人
     */
    private String head;
    /**
     * 联系方式
     */
    private String phone;
    /**
     * 状态
     */
    private Integer state;
    /**
     * 地址id列表
     */
    private List<Integer> areaCodes;
    /**
     * 省
     */
    private String province;
    /**
     * 市
     */
    private String city;
    /**
     * 街道
     */
    private String street;
    /**
     * 区
     */
    private String area;
    /**
     * 地址详细信息
     */
    private String address;

    /**
     * 备注
     */
    private String remark;

    /**
     * 修改人
     */
    private String updatedBy;

    /**
     * 修改时间
     */
    private Date updatedTime;
    /**
     * 是否自主经营
     */
    public Integer isSell ;
    /**
     * 一件代发业务单元id
     */
    private Integer dobId ;
}
