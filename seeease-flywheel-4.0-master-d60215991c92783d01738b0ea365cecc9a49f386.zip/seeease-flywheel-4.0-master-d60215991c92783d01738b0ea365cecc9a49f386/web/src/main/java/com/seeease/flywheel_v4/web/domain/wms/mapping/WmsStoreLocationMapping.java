package com.seeease.flywheel_v4.web.domain.wms.mapping;


import com.seeease.flywheel_v4.web.app.excel.result.StoreLocationExportResult;
import com.seeease.flywheel_v4.web.app.wms.request.WmsStoreAreaSubmitRequest;
import com.seeease.flywheel_v4.web.app.wms.request.WmsStoreLocationSubmitRequest;
import com.seeease.flywheel_v4.web.app.wms.result.WmsCkPageResult;
import com.seeease.flywheel_v4.web.app.wms.result.WmsStoreAreaListResult;
import com.seeease.flywheel_v4.web.app.wms.result.WmsStoreAreaTreeResult;
import com.seeease.flywheel_v4.web.app.wms.result.WmsStoreLocationPageResult;
import com.seeease.flywheel_v4.web.infrastructure.config.EnumMapping;
import com.seeease.flywheel_v4.web.infrastructure.config.MappingIgnore;
import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.entity.SysBusinessUnit;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.WmsStoreLocation;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.WmsStoreLocationLevelTypeEnums;
import com.seeease.goods.rpc.result.SpuRpcResult;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;


/**
 * <p>
 * 商品附件
 * </p>
 *
 * @author 西门 游
 * @since 2023-10-27
 */
@Mapper(componentModel = "spring",
        builder = @Builder(disableBuilder = true),
        nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS,
        nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE,
        imports = {WmsStoreLocationLevelTypeEnums.class})
public interface WmsStoreLocationMapping extends EnumMapping {

    WmsStoreLocationMapping INSTANCE = Mappers.getMapper(WmsStoreLocationMapping.class);


    WmsStoreAreaTreeResult toTreeResult(WmsStoreLocation storeLocation);

    WmsStoreAreaTreeResult toTreeResult(SysBusinessUnit storeList);

    @MappingIgnore
    void toEntityForUpdate(@MappingTarget WmsStoreLocation area, WmsStoreAreaSubmitRequest request);

    @Mapping(target = "id",source = "location.id")
    @Mapping(target = "mainAreaName",source = "mainAreaName.name")
    @Mapping(target = "mainAreaId",source = "mainAreaName.id")
    @Mapping(target = "childAreaName",source = "childAreaName.name")
    @Mapping(target = "childAreaId",source = "childAreaName.id")
    @Mapping(target = "spuId",source = "spu.id")
    @Mapping(target = "name",source = "location.name")
    @Mapping(target = "state",source = "location.state")
    @Mapping(target = "createdTime",source = "location.createdTime")
    @Mapping(target = "storeId",source = "location.storeId")
    WmsStoreLocationPageResult toPageResult(WmsStoreLocation location,
                                            WmsStoreLocation childAreaName,
                                            WmsStoreLocation mainAreaName,
                                            SpuRpcResult spu);

    @MappingIgnore
    @Mapping(target = "level",expression = "java(0 == request.getPid() ? WmsStoreLocationLevelTypeEnums.MAIN_AREA : WmsStoreLocationLevelTypeEnums.CHILD_AREA)")
    WmsStoreLocation toEntity(WmsStoreAreaSubmitRequest request);


    @MappingIgnore
    @Mapping(target = "level",expression = "java(WmsStoreLocationLevelTypeEnums.LOCATION)")
    @Mapping(target = "pid",source = "request.childAreaId")
    WmsStoreLocation toEntity(Integer storeId,WmsStoreLocationSubmitRequest request);


    @MappingIgnore
    @Mapping(target = "pid",source = "request.childAreaId")
    void toEntityForUpdate(@MappingTarget WmsStoreLocation area, WmsStoreLocationSubmitRequest request);

    WmsStoreAreaListResult toListResult(WmsStoreLocation wmsStoreLocation);

    @Mapping(target = "name",source = "location.name")
    @Mapping(target = "goodsCode",source = "location.goodsCode")
    StoreLocationExportResult toExportResult(WmsCkPageResult.Sku sku, WmsStoreLocationPageResult location);

}
