package com.seeease.flywheel_v4.web.domain.wms.component.express.core.sf;

import com.alibaba.fastjson.JSONObject;
import com.seeease.flywheel_v4.web.domain.wms.component.express.core.PrintResult;
import com.seeease.flywheel_v4.web.domain.wms.component.express.core.ExpressChannel;
import com.seeease.flywheel_v4.web.domain.wms.component.express.core.PlaceOrderDto;
import com.seeease.flywheel_v4.web.domain.wms.component.express.core.PlaceOrderResult;
import com.seeease.flywheel_v4.web.domain.wms.component.express.core.channel.DySfExpress;
import com.seeease.flywheel_v4.web.domain.wms.component.express.core.channel.KsSfExpress;
import com.seeease.flywheel_v4.web.domain.wms.component.express.core.channel.SfExpress;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 9/23/24 10:30 上午
 **/
@Component
public class PlaceOrderHandler {


    private final Map<ExpressChannel.Channel, ExpressChannel<?>> handlerMap = new HashMap<>();

    public PlaceOrderHandler(SfExpress sfExpress, KsSfExpress ksSfExpress, DySfExpress dySfExpress) {
        handlerMap.put(ExpressChannel.Channel.DY_SF, dySfExpress);
        handlerMap.put(ExpressChannel.Channel.KS_SF, ksSfExpress);
        handlerMap.put(ExpressChannel.Channel.SF, sfExpress);
    }

    /**
     * 下单
     *
     * @param dtoMap
     * @return
     */
    public List<PlaceOrderResult> placeOrder(Map<ExpressChannel.Channel, List<PlaceOrderDto>> dtoMap) {
        ArrayList<PlaceOrderResult> ret = new ArrayList<>();
        for (Map.Entry<ExpressChannel.Channel, List<PlaceOrderDto>> entry : dtoMap.entrySet()) {
            ExpressChannel<?> handler = handlerMap.get(entry.getKey());

            for (PlaceOrderDto dto : entry.getValue()) {
                PlaceOrderResult retItem = handler.placeOrder(dto);
                retItem.setChannel(handler.getChannel());
                retItem.setDto(dto);
                ret.add(retItem);
            }
        }
        return ret;
    }


    /**
     * 获取打印面单数据
     */
    public PrintResult getPrintInfo(List<PlaceOrderResult> placeOrderResults) {
        List<PrintResult.DyPrintResult> dyPrintResults = new ArrayList<>();
        List<PrintResult.KsPrintResult> ksPrintResults = new ArrayList<>();
        List<PrintResult.SfPrintResult> sfPrintResults = new ArrayList<>();
        List<String> errorList = new ArrayList<>();

        for (PlaceOrderResult placeOrderResult : placeOrderResults) {

            if (placeOrderResult.getSuccess()) {

                ExpressChannel.Channel channel = placeOrderResult.getChannel();
                ExpressChannel<?> handler = handlerMap.get(channel);
                Object ret = handler.printInfo(placeOrderResult);


                if (ret instanceof PrintResult.DyPrintResult) {
                    dyPrintResults.add((PrintResult.DyPrintResult) ret);
                } else if (ret instanceof PrintResult.KsPrintResult) {
                    ksPrintResults.add((PrintResult.KsPrintResult) ret);
                } else {
                    sfPrintResults.add((PrintResult.SfPrintResult) ret);
                }

            } else {
                errorList.add(placeOrderResult.getBusinessNo() + "异常原因:" + placeOrderResult.getErrMsg());
            }
        }

        PrintResult printResult = new PrintResult();
        printResult.setDyList(dyPrintResults);
        printResult.setKsList(ksPrintResults);
        printResult.setSfList(sfPrintResults);
        printResult.setErrList(errorList);
        return printResult;
    }
}
