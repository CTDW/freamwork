package com.seeease.flywheel_v4.web.infrastructure.config;

import com.alibaba.fastjson.JSONObject;
import com.seeease.springframework.context.UserContext;
import com.seeease.springframework.log.annotation.LogPrinter;
import org.springframework.stereotype.Component;

/**
 * <p>id身份日志打印器</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 12/15/23 1:41下午
 **/
@Component
public class IdentifyLogPrinter implements LogPrinter.PostPrinter {

    @Override
    public String print(String taskId) {
        return "userInfo: " + JSONObject.toJSONString(UserContext.getUser());
    }
}
