package com.seeease.flywheel_v4.web.app.transfer.service.impl;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.google.common.collect.Lists;
import com.seeease.flywheel_v4.client.enums.BusinessUnitTypeEnums;
import com.seeease.flywheel_v4.web.app.transfer.request.TransferTaskCreateRequest;
import com.seeease.flywheel_v4.web.app.transfer.request.TransferTaskPageRequest;
import com.seeease.flywheel_v4.web.app.transfer.result.TransferTaskPageResult;
import com.seeease.flywheel_v4.web.app.transfer.service.TransferTaskService;
import com.seeease.flywheel_v4.web.domain.transfer.mapping.TransferTaskMapping;
import com.seeease.flywheel_v4.web.infrastructure.dao.RepositoryFactory;
import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.entity.SysBusinessUnit;
import com.seeease.flywheel_v4.web.infrastructure.dao.transfer.entity.TransferTask;
import com.seeease.goods.rpc.SkuFacade;
import com.seeease.goods.rpc.request.SkuRpcRequest;
import com.seeease.goods.rpc.result.SkuRpcResult;
import com.seeease.springframework.PageResult;
import com.seeease.springframework.context.UserContext;
import com.seeease.springframework.exception.ValidationUtil;
import com.seeease.springframework.utils.MultiUtils;
import com.seeease.springframework.utils.StringUtils;
import org.apache.dubbo.config.annotation.DubboReference;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 7/2/24 4:37 下午
 **/
@Service
public class TransferTaskServiceImpl implements TransferTaskService {

    @Resource
    private RepositoryFactory repositoryFactory;

    @DubboReference(version = "1.0.0", check = false)
    private SkuFacade skuFacade;

    /**
     * 调入方限制类型
     */
    List<BusinessUnitTypeEnums> condition = Lists.newArrayList(
            BusinessUnitTypeEnums.WAREHOUSE,
            BusinessUnitTypeEnums.MERCHANT,
            BusinessUnitTypeEnums.MAINTENANCE
    );

    @Override
    public Boolean create(TransferTaskCreateRequest request) {

        //仓库校验
        Set<Integer> skuIdList = MultiUtils.toSet(request.getSkuList(), TransferTaskCreateRequest.Sku::getSkuId);
        SkuRpcRequest rpcRequest = new SkuRpcRequest();
        rpcRequest.setIdList(skuIdList);
        List<SkuRpcResult> skuList = skuFacade.list(rpcRequest);

        ValidationUtil.isTrue(
                skuList.size() == request.getSkuList().size(),
                "skuId错误"
        );

        //唯一码校验
        Set<Integer> uniqueSkuIds = MultiUtils.toSet(
                skuList.stream().filter(sku -> sku.getUniqueType() == 1).collect(Collectors.toList()),
                SkuRpcResult::getId
        );
        List<TransferTask> taskList = repositoryFactory.getTransferTaskRepository().listBySkuIds(uniqueSkuIds);
        ValidationUtil.isTrue(taskList.isEmpty(),"存在唯一码重复的调拨任务");


        //仓库校验
        Set<Integer> storeIdList = MultiUtils.toSet(skuList, SkuRpcResult::getStoreId);
        Map<BusinessUnitTypeEnums, List<SysBusinessUnit>> buMap = repositoryFactory.getBusinessUnitRepository().listByIds(storeIdList)
                .stream()
                .collect(Collectors.groupingBy(SysBusinessUnit::getType));

        ValidationUtil.isTrue(
                buMap.containsKey(BusinessUnitTypeEnums.WAREHOUSE) && buMap.size() == 1,
                "调拨任务只能选择sku所在为仓库类型的业务单元"
        );


        //调入方校验
        Map<Integer, Integer> storeMap = MultiUtils.toMap(skuList, SkuRpcResult::getId, SkuRpcResult::getStoreId);
        request.getSkuList().forEach(sku -> {
            ValidationUtil.isTrue(
                    !Objects.equals(storeMap.get(sku.getSkuId()), sku.getToId()),
                    "商品所在和调入方不能为同一个"
            );
        });

        Set<Integer> toIdList = MultiUtils.toSet(request.getSkuList(), TransferTaskCreateRequest.Sku::getToId);
        List<SysBusinessUnit> toList = repositoryFactory.getBusinessUnitRepository().listByIds(toIdList);
        toList.forEach(bu -> ValidationUtil.isTrue(condition.contains(bu.getType()),"调入方类型错误"));




        //创建
        List<TransferTask> transferTaskList = MultiUtils.toList(
                request.getSkuList(),
                sku ->{
                    Integer fromId = storeMap.get(sku.getSkuId());
                    return TransferTaskMapping.INSTANCE.toEntity(sku,fromId);
                }
        );

        repositoryFactory.getTransferTaskRepository().submitBatch(transferTaskList);

        return true;
    }

    @Override
    public PageResult<TransferTaskPageResult> page(TransferTaskPageRequest request) {

        //sku查询
        Set<Integer> skuIdList = null;
        List<SkuRpcResult> skuList = null;
        if (StringUtils.oneOfNonNull(
                request.getSkuCode(),
                request.getBelongId(),
                request.getBrandId(),
                request.getGoodsCode(),
                request.getGoodsName(),
                request.getXyCode(),
                request.getPurchaseType()
        )){
            SkuRpcRequest rpcRequest = TransferTaskMapping.INSTANCE.toSkuRpcRequest(request);
            skuList = skuFacade.list(rpcRequest);

            if (skuList.isEmpty()){
                return PageResult.buildEmpty();
            }
            skuIdList = MultiUtils.toSet(skuList,SkuRpcResult::getId);
        }

        //主表查询
        Integer buId = UserContext.getUser().getStore().getId();
        SysBusinessUnit bu = repositoryFactory.getBusinessUnitRepository().findById(buId);
        if (bu.getType() != BusinessUnitTypeEnums.PLATFORM){
            request.setBuId(buId);
        }

        Page<TransferTask> page = repositoryFactory.getTransferTaskRepository().page(request,skuIdList);
        if (page.getRecords().isEmpty()){
            return PageResult.buildEmpty();
        }

        //sku数据
        if (skuIdList == null){
            skuIdList = MultiUtils.toSet(page.getRecords(),TransferTask::getSkuId);
            SkuRpcRequest rpcRequest = new SkuRpcRequest();
            rpcRequest.setIdList(skuIdList);
            skuList = skuFacade.list(rpcRequest);
        }
        Map<Integer, SkuRpcResult> skuMap = MultiUtils.toMap(skuList, SkuRpcResult::getId, Function.identity());

        //商品所在
        Set<Integer> storeIdList = MultiUtils.toSet(skuList, SkuRpcResult::getStoreId);
        Map<Integer, String> storeMap = MultiUtils.toMap(
                repositoryFactory.getBusinessUnitRepository().listByIds(storeIdList),
                SysBusinessUnit::getId,
                SysBusinessUnit::getName
        );



        //调入方
        Set<Integer> toIdList = MultiUtils.toSet(page.getRecords(), TransferTask::getToId);
        Map<Integer, String> toMap = MultiUtils.toMap(
                repositoryFactory.getBusinessUnitRepository().listByIds(toIdList),
                SysBusinessUnit::getId,
                SysBusinessUnit::getName
        );

        //组合数据
        List<TransferTaskPageResult> ret = MultiUtils.toList(
                page.getRecords(),
                v -> {
                    SkuRpcResult sku = skuMap.get(v.getSkuId());
                    String belongName = storeMap.get(sku.getStoreId());
                    String toName = toMap.get(v.getToId());
                    return TransferTaskMapping.INSTANCE.toPageResult(v, sku, belongName, toName);
                }
        );

        return PageResult.<TransferTaskPageResult>builder()
                .result(ret)
                .totalCount(page.getTotal())
                .totalPage(page.getPages())
                .build();
    }

    @Override
    public Boolean del(Integer id) {
        return repositoryFactory.getTransferTaskRepository().delById(id);
    }
}
