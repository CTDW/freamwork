package com.seeease.flywheel_v4.web.infrastructure.config;

import com.baomidou.mybatisplus.annotation.IEnum;
import com.seeease.flywheel_v4.client.enums.BusinessUnitTypeEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.enums.SupplierQuotaAuditStateEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.enums.SupplierQuotaAuditTypeEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.enums.SupplierTypeEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.enums.PurchasePayTypeEnums;
import com.seeease.flywheel_v4.client.enums.PurchaseTypeEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.enums.SaleModelEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.enums.SaleQualityWayEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.enums.SaleTypeEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.enums.SaleChannelTypeEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.transfer.enums.TransferStateEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.transfer.enums.TransferTypeEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.MerchantWmsModelEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.MerchantWmsTypeEnums;
import com.seeease.goods.rpc.enums.SkuNodeStateEnums;
import com.seeease.goods.rpc.enums.SkuRunTypeEnums;
import com.seeease.goods.rpc.enums.SkuSellWayEnums;
import com.seeease.seeeaseframework.mybatis.domain.WhetherEnum;
import com.seeease.seeeaseframework.mybatis.utils.EnumUtils;

import java.io.Serializable;
/**
 * 枚举通用转换器
 *
 * @ Author        :  西门 游
 * @ CreateDate    :  10/27/23
 * @ Version       :  1.0
 */
public interface EnumMapping {

    default <T extends Serializable> T to(IEnum<T> e) {
        return e.getValue();
    }

    default WhetherEnum to(Integer v) {
       return WhetherEnum.fromValue(v);
    }

    default BusinessUnitTypeEnums toBusinessUnitTypeEnums(Integer v) {
        return EnumUtils.of(BusinessUnitTypeEnums.class, v);
    }

    default SaleChannelTypeEnums toSaleChannelTypeEnums(Integer v) {
        return EnumUtils.of(SaleChannelTypeEnums.class, v);
    }

    default SkuSellWayEnums toSkuSaleChannelPosEnums(Integer v) {
        return EnumUtils.of(SkuSellWayEnums.class, v);
    }

    default SkuRunTypeEnums toSkuManagementTypeEnums(Integer v) {
        return EnumUtils.of(SkuRunTypeEnums.class, v);
    }

    default SupplierTypeEnums toSupplierTypeEnums(Integer v) {
        return EnumUtils.of(SupplierTypeEnums.class, v);
    }

    default PurchaseTypeEnums toPurchaseTypeEnums(Integer v) {
        return EnumUtils.of(PurchaseTypeEnums.class, v);
    }

    default TransferTypeEnums toTransferTypeEnums(Integer v) {
        return EnumUtils.of(TransferTypeEnums.class, v);
    }

    default TransferStateEnums toTransferStateEnums(Integer v) {
        return EnumUtils.of(TransferStateEnums.class, v);
    }

    default MerchantWmsModelEnums toMerchantWmsModelEnums(Integer v) {
        return EnumUtils.of(MerchantWmsModelEnums.class, v);
    }

    default MerchantWmsTypeEnums toMerchantWmsTypeEnums(Integer v) {
        return EnumUtils.of(MerchantWmsTypeEnums.class, v);
    }
    default SupplierQuotaAuditTypeEnums toSupplierQuotaTypeEnums(Integer v) {
        return EnumUtils.of(SupplierQuotaAuditTypeEnums.class, v);
    }
    default SupplierQuotaAuditStateEnums toSupplierQuotaStateEnums(Integer v) {
        return EnumUtils.of(SupplierQuotaAuditStateEnums.class, v);
    }

    default SaleModelEnums toSaleModelEnums(Integer v) {
        return EnumUtils.of(SaleModelEnums.class, v);
    }

    default SaleQualityWayEnums toSaleQualityWayEnums(Integer v) {
        return EnumUtils.of(SaleQualityWayEnums.class, v);
    }

    default SaleTypeEnums toSaleTypeEnums(Integer v) {
        return EnumUtils.of(SaleTypeEnums.class, v);
    }


    default PurchasePayTypeEnums toPurchasePayTypeEnums(Integer v) {
        return EnumUtils.of(PurchasePayTypeEnums.class, v);
    }

    default SkuNodeStateEnums toSkuNodeStateEnums(Integer v) {
        return EnumUtils.of(SkuNodeStateEnums.class, v);
    }
}
