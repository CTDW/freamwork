package com.seeease.flywheel_v4.web.domain.wms.observer.base;

import com.seeease.goods.rpc.enums.SkuNodeStateEnums;
import com.seeease.goods.rpc.enums.SkuStateEnums;

/**
 * <p>sku状态适配</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 7/19/24 6:31 下午
 **/
public interface SkuNodeStateAdaptor {

    default SkuNodeStateEnums adaptSkuNodeState(SkuNodeStateEnums state,String serialNo){return state;}

}
