package com.seeease.flywheel_v4.web.app.wms.request;


import com.seeease.springframework.PageRequest;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.validation.constraints.NotNull;
import java.util.Set;

/**
 * @ Description   :
 * @ Author        :  西门 游
 * @ CreateDate    :  6/6/24
 * @ Version       :  1.0
 */

@EqualsAndHashCode(callSuper = true)
@Data
public class WmsStoreLocationPageRequest extends PageRequest {


    /**
     * 父级id
     */
    @NotNull(message = "pid不能为空")
    private Integer pid;
    /**
     * 库位状态
     */
    private Integer state;

    /**
     * spuIds
     */
    private Set<Integer> spuIds;

    /**
     * 库位名称
     */
    private String name;


}
