package com.seeease.flywheel_v4.web.domain.wms.component.express.core.sf;


import com.alibaba.fastjson.JSONObject;
import com.seeease.springframework.exception.e.ArgumentException;
import com.sf.csim.express.service.CallExpressServiceTools;
import com.sf.csim.express.service.code.ExpressServiceCodeEnum;
import lombok.extern.slf4j.Slf4j;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import org.apache.commons.lang3.StringUtils;

import java.util.Objects;
import java.util.Optional;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 9/20/24 5:15 下午
 **/
@Slf4j
public class SFExpressClient {

    private static final MediaType JSON = MediaType.get("application/x-www-form-urlencode");

    private SFExpressConfig clientConfig;

    public SFExpressClient(SFExpressConfig clientConfig) {
        this.clientConfig = clientConfig;
    }

    /**
     * 创建订单
     *
     * @param request
     * @return
     */
    public SfExpressCreateOrderResult createOrder(SfExpressCreateOrderRequest request) {
        request.setService(ExpressServiceCodeEnum.EXP_RECE_CREATE_ORDER);

        //默认月结帐号
        if (Objects.isNull(request.getMonthlyCard())) {
            request.setMonthlyCard(clientConfig.getMonthlyCard());
        }

        String data = this.execute(request);
        SfExpressCreateOrderResult result = JSONObject.parseObject(data, SfExpressCreateOrderResult.class);
        if (result.getSuccess().equals("true") && result.getErrorCode().equals("S0000")) {
            return result;
        }
        throw new ArgumentException("顺丰创建订单错误:" + result.getErrorMsg());
    }


    /**
     * 发送
     *
     * @param request
     * @return
     */
    private String execute(SfExpressBaseRequest request) {
        try {
            //业务报文
            String msg = JSONObject.toJSONString(request);
            //uuid
            String timeStamp = String.valueOf(System.currentTimeMillis());
            //数字签名
            String digest = CallExpressServiceTools.getMsgDigest(msg, timeStamp, clientConfig.getSecret());
            //数据包
            RequestBody body = RequestBody.create(msg, JSON);

            Request r = new Request.Builder()
                    .url(clientConfig.getGatewayService()
                            + "?serviceCode=" + request.getService().getCode()
                            + "&partnerID=" + clientConfig.getPartnerID()
                            + "&requestID=" + request.getRequestId()
                            + "&timestamp=" + timeStamp
                            + "&msgDigest=" + digest
                            + "&msgData=" + msg)
                    .post(body)
                    .build();
            String responseBody = Objects.requireNonNull(new OkHttpClient().newCall(r).execute().body()).string();
            log.info("顺丰请求成功 request=[{}],result=[{}]", msg, responseBody);

            SfExpressBaseResult result = Optional.of(responseBody)
                    .filter(StringUtils::isNotBlank)
                    .map(t -> JSONObject.parseObject(t, SfExpressBaseResult.class))
                    .orElse(null);
            if (Objects.isNull(result)) {
                throw new ArgumentException("请求异常结果为空");
            }
            if (result.getApiResultCode().equals("A1000")) {
                return result.getApiResultData();
            }
            throw new ArgumentException(result.getApiErrorMsg());
        } catch (Exception e) {
            throw new ArgumentException(e.getMessage());
        }

    }
}
