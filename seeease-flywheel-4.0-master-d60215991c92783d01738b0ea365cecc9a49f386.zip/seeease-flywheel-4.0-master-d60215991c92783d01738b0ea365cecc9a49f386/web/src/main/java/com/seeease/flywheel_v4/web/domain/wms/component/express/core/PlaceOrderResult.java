package com.seeease.flywheel_v4.web.domain.wms.component.express.core;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <p>快递下单入参</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 9/20/24 4:55 下午
 **/
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PlaceOrderResult {
    /**
     * 业务订单号，下单唯一
     */
    private String businessNo;
    /**
     * 快递渠道
     */
    private ExpressChannel.Channel channel;
    /**
     * 请求参数
     */
    private PlaceOrderDto dto;

    /**
     * 物流单号
     */
    private String expressNumber;

    /**
     * 下单成功
     */
    private Boolean success;
    /**
     * 异常消息
     */
    private String errMsg;
}
