package com.seeease.flywheel_v4.web.infrastructure.dao.fix.repo;


import com.seeease.flywheel_v4.web.app.fix.request.FixOrderLogSaveRequest;
import com.seeease.flywheel_v4.web.infrastructure.dao.fix.entity.FixOrderLog;

import java.util.List;

/**
 * @Description 维修日志
 * @Date 2024-10-2 21:04
 * @Author by hk
 */
public interface FixOrderLogRepository {

    /**
     * 根据维修单号查询 维修日志
     *
     * @param fixOrderNumber 维修单号
     * @return 数据
     */
    List<FixOrderLog> getFixLogByNumber(String fixOrderNumber);

    /**
     * 保存维修日志
     *
     * @param request 请求
     */
    void save(FixOrderLogSaveRequest request);

    /**
     * 查询最近一次状态 ，用于回退
     * @param fixOrderNumber 维修单号
     * @return 结果
     */
    Integer getPreOrderStatus(String fixOrderNumber,Integer orderStatus);
}
