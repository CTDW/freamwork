package com.seeease.flywheel_v4.web.adptor;

import com.seeease.flywheel_v4.web.app.purchase.request.*;
import com.seeease.flywheel_v4.web.app.purchase.result.*;
import com.seeease.flywheel_v4.web.app.purchase.service.PurchaseAftersaleService;
import com.seeease.flywheel_v4.web.app.purchase.service.PurchaseDemandService;
import com.seeease.flywheel_v4.web.app.purchase.service.PurchaseOrderLineService;
import com.seeease.flywheel_v4.web.app.purchase.service.PurchaseOrderService;
import com.seeease.flywheel_v4.web.infrastructure.config.IdentifyLogPrinter;
import com.seeease.springframework.PageResult;
import com.seeease.springframework.SingleResponse;
import com.seeease.springframework.log.annotation.LogPrinter;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 5/30/24 5:35 下午
 **/
@RestController
@RequestMapping("purchase")
public class PurchaseController {

    @Resource
    private PurchaseDemandService purchaseDemandService;
    @Resource
    private PurchaseOrderService purchaseOrderService;
    @Resource
    private PurchaseOrderLineService purchaseOrderLineService;
    @Resource
    private PurchaseAftersaleService purchaseAftersaleService;

    /**
     * 采购-采购需求创建
     *
     * @return 创建结果
     */
    @PostMapping("demand/create")
    @LogPrinter(scenario = "采购-采购需求创建", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<Boolean> demandCreate(
            @Validated
            @RequestBody PurchaseDemandSubmitRequest request) {

        return SingleResponse.of(purchaseDemandService.create(request));
    }

    /**
     * 采购-采购需求分页
     *
     * @return 分页结果
     */
    @PostMapping("demand/page")
    @LogPrinter(scenario = "采购-采购需求分页", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<PageResult<PurchaseDemandPageResult>> demandPage(
            @RequestBody PurchaseDemandPageRequest request) {

        return SingleResponse.of(purchaseDemandService.page(request));
    }


    /**
     * 采购-采购需求取消
     *
     * @return 取消结果
     */
    @PostMapping("demand/cancel")
    @LogPrinter(scenario = "采购-采购需求取消", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<Boolean> demandCancel(
            @Validated
            @RequestBody PurchaseDemandCancelRequest request) {

        return SingleResponse.of(purchaseDemandService.cancel(request));
    }

    /**
     * 采购-采购需求详情
     *
     * @return 详情结果
     */
    @PostMapping("demand/details")
    @LogPrinter(scenario = "采购-采购需求详情", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<PurchaseDemandDetailResult> demandDetails(
            @RequestBody PurchaseDemandDetailRequest request) {

        return SingleResponse.of(purchaseDemandService.details(request));
    }


    /**
     * 采购-采购订单创建
     *
     * @return 采购id
     */
    @PostMapping("create")
    @LogPrinter(scenario = "采购-采购订单创建", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<Integer> create(
            @Validated @RequestBody PurchaseOrderSubmitRequest request) {

        return SingleResponse.of(purchaseOrderService.create(request));
    }


    /**
     * 采购-采购订单分页查询
     *
     * @return 分页结果
     */
    @PostMapping("page")
    @LogPrinter(scenario = "采购-采购订单分页查询", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<PageResult<PurchaseOrderPageResult>> page(
            @RequestBody PurchaseOrderPageRequest request) {

        return SingleResponse.of(purchaseOrderService.page(request));
    }


    /**
     * 采购-采购订单行分页查询
     *
     * @return 分页结果
     */
    @PostMapping("/line/page")
    @LogPrinter(scenario = "采购-采购订单行分页查询", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<PageResult<PurchaseOrderLinePageResult>> linePage(
            @Validated @RequestBody PurchaseOrderLinePageRequest request) {

        return SingleResponse.of(purchaseOrderLineService.page(request));
    }


    /**
     * 采购-采购订单详情查询
     *
     * @return 详情结果
     */
    @PostMapping("details")
    @LogPrinter(scenario = "采购-采购订单详情查询", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<PurchaseOrderDetailResult> details(
            @RequestBody PurchaseOrderDetailRequest request) {

        return SingleResponse.of(purchaseOrderService.details(request));
    }

    /**
     * 采购-采购上传快递单号
     *
     * @return 上传结果
     */
    @PostMapping("upload/express")
    @LogPrinter(scenario = "采购-采购上传快递单号", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<Boolean> uploadExpress(
            @RequestBody PurchaseOrderExpressUploadRequest request) {

        return SingleResponse.of(purchaseOrderService.uploadExpress(request));
    }


    /**
     * 采购-取消采购单
     *
     * @return 取消结果
     */
    @PostMapping("cancel")
    @LogPrinter(scenario = "采购-取消采购单", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<Boolean> cancel(
            @RequestBody PurchaseOrderCancelRequest request) {

        return SingleResponse.of(purchaseOrderService.cancel(request));
    }


    /**
     * 采购-采购单行状态变更
     *
     * @return 变更结果
     */
    @PostMapping("line/state")
    @LogPrinter(scenario = "采购-采购单行状态变更", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<Boolean> lineState(
            @RequestBody PurchaseOrderLineStateRequest request) {

        return SingleResponse.of(purchaseOrderLineService.lineState(request));
    }


    /**
     * 采购-采购单行转正常
     *
     * @return 变更结果
     */
    @PostMapping("line/to/normal")
    @LogPrinter(scenario = " 采购-采购单行转正常", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<Boolean> lineToNormal(
            @RequestBody PurchaseOrderLineToNormalRequest request) {

        return SingleResponse.of(purchaseOrderLineService.lineToNormal(request));
    }


    /**
     * 采购售后 -采购售后分页列表
     *
     * @return 分页结果
     */
    @PostMapping("aftersale/page")
    @LogPrinter(scenario = "采购售后 -采购售后分页列表", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<PageResult<PurchaseAftersalePageResult>> aftersalePage(
            @RequestBody PurchaseAftersalePageRequest request) {

        return SingleResponse.of(purchaseAftersaleService.page(request));
    }


    /**
     * 采购售后 -采购售后详情
     *
     * @return 详情结果
     */
    @PostMapping("aftersale/detail")
    @LogPrinter(scenario = " 采购售后 -采购售后详情", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<PurchaseAftersaleDetailResult> aftersaleDetail(
            @RequestBody PurchaseAftersaleDetailRequest request) {

        return SingleResponse.of(purchaseAftersaleService.detail(request));
    }

    /**
     * 采购售后 -采购售后取消
     *
     * @return 操作结果
     */
    @PostMapping("aftersale/cancel")
    @LogPrinter(scenario = "采购售后 -采购售后取消", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<Boolean> aftersaleCancel(
            @RequestBody PurchaseAftersaleCancelRequest request) {

        return SingleResponse.of(purchaseAftersaleService.cancel(request));
    }

    /**
     * 采购售后 -采购退货创建
     *
     * @return 操作结果
     */
    @PostMapping("return/create")
    @LogPrinter(scenario = "采购售后 -采购退货创建", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<Integer> purchaseReturnCreate(
            @RequestBody PurchaseReturnCreateRequest request) {

        return SingleResponse.of(purchaseAftersaleService.returnCreate(request));
    }



}
