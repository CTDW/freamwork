package com.seeease.flywheel_v4.web.app.transfer.service;

import com.seeease.flywheel_v4.web.app.transfer.request.*;
import com.seeease.flywheel_v4.web.app.transfer.result.TransferDetailResult;
import com.seeease.flywheel_v4.web.app.transfer.result.TransferPageResult;
import com.seeease.flywheel_v4.web.app.transfer.result.TransferUsableQuotaResult;
import com.seeease.springframework.PageResult;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 7/2/24 4:36 下午
 **/
public interface TransferService {

    /**
     * 调拨-可用额度数据查询
     *
     * @return 查询结果
     */
    TransferUsableQuotaResult usableQuota(TransferUsableQuotaRequest request);

    /**
     * 调拨-调拨单创建
     *
     * @return 调拨单id
     */
    Integer create(TransferCreateRequest request);

    /**
     * 调拨-调拨单分页
     *
     * @return 分页结果
     */
    PageResult<TransferPageResult> page(TransferPageRequest request);


    /**
     * 调拨-调拨单详情
     *
     * @return 详情结果
     */
    TransferDetailResult detail(TransferDetailRequest request);

    /**
     * 调拨-调拨单取消
     */
    Boolean cancel(TransferCancelRequest request);
}
