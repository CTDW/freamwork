package com.seeease.flywheel_v4.web.domain.excel.strategy.export;

import com.alibaba.cola.extension.Extension;
import com.seeease.flywheel_v4.web.app.excel.result.ThirdOrderExportResult;
import com.seeease.flywheel_v4.web.app.sale.request.ThirdSaleOrderPageRequest;
import com.seeease.flywheel_v4.web.app.sale.result.ThirdSaleOrderPageResult;
import com.seeease.flywheel_v4.web.app.sale.service.ThirdSaleOrderService;
import com.seeease.flywheel_v4.web.domain.excel.core.ExportExtPtl;
import com.seeease.flywheel_v4.web.domain.sale.mapping.ThirdSaleOrderMapping;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.enums.ThirdSaleStateEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.enums.SaleChannelTypeEnums;
import com.seeease.seeeaseframework.mybatis.utils.EnumUtils;
import com.seeease.springframework.utils.MultiUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 9/12/24 10:42 上午
 **/
@Service
@Extension(bizId = "export", useCase = "thirdOrder")
public class ThirdOrderExport implements ExportExtPtl<ThirdSaleOrderPageRequest, ThirdOrderExportResult> {


    @Resource
    private ThirdSaleOrderService thirdSaleOrderService;


    @Override
    public Class<ThirdSaleOrderPageRequest> getRequestClass() {
        return ThirdSaleOrderPageRequest.class;
    }

    @Override
    public Class<ThirdOrderExportResult> getResultClass() {
        return ThirdOrderExportResult.class;
    }

    @Override
    public String getFileName() {
        return "三方单号导出";
    }

    @Override
    public List<ThirdOrderExportResult> handle(ThirdSaleOrderPageRequest request) {
        //step_1 调用三方订单号查询
        request.setLimit(Integer.MAX_VALUE);
        List<ThirdSaleOrderPageResult> list = thirdSaleOrderService.page(request).getResult();

        //step_2 组合数据
        return MultiUtils.toList(
                list,
                item ->{
                   String scType = EnumUtils.of(SaleChannelTypeEnums.class,item.getScType()).getDesc();
                   String state = EnumUtils.of(ThirdSaleStateEnums.class,item.getState()).getDesc();


                   return ThirdSaleOrderMapping.INSTANCE.toExportResult(item,scType,state);
                }
        );
    }
}
