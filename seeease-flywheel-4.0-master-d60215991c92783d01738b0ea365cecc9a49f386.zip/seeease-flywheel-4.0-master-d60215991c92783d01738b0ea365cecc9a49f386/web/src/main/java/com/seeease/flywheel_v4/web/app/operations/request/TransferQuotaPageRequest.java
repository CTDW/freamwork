package com.seeease.flywheel_v4.web.app.operations.request;

import com.seeease.springframework.PageRequest;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Date;


@EqualsAndHashCode(callSuper = true)
@Data
public class TransferQuotaPageRequest extends PageRequest {
    /**
     * 商家id
     */
    private Integer merchantId;
    /**
     * 开始时间
     */
    private Date startDate;
    /**
     * 结束时间
     */
    private Date endDate;

}
