package com.seeease.flywheel_v4.web.app.purchase.service.impl;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.seeease.flywheel_v4.client.enums.BusinessUnitTypeEnums;
import com.seeease.flywheel_v4.web.app.purchase.request.PurchaseAftersaleCancelRequest;
import com.seeease.flywheel_v4.web.app.purchase.request.PurchaseAftersaleDetailRequest;
import com.seeease.flywheel_v4.web.app.purchase.request.PurchaseAftersalePageRequest;
import com.seeease.flywheel_v4.web.app.purchase.request.PurchaseReturnCreateRequest;
import com.seeease.flywheel_v4.web.app.purchase.result.PurchaseAftersaleDetailResult;
import com.seeease.flywheel_v4.web.app.purchase.result.PurchaseAftersalePageResult;
import com.seeease.flywheel_v4.web.app.purchase.service.PurchaseAftersaleService;
import com.seeease.flywheel_v4.web.domain.purchase.mapping.PurchaseAftersaleLineMapping;
import com.seeease.flywheel_v4.web.domain.purchase.mapping.PurchaseAftersaleMapping;
import com.seeease.flywheel_v4.web.domain.purchase.mapping.PurchaseOrderMapping;
import com.seeease.flywheel_v4.web.domain.wms.observer.base.WmsSubject;
import com.seeease.flywheel_v4.web.infrastructure.dao.RepositoryFactory;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.Supplier;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.SupplierContacts;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.entity.PurchaseAftersale;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.entity.PurchaseAftersaleLine;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.entity.PurchaseOrder;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.entity.PurchaseOrderLine;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.enums.PurchaseAftersaleTypeEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.entity.SysBusinessUnit;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.MerchantWms;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.MerchantWmsLine;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.WmsCk;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.obj.ContactInfo;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.MerchantWmsModelEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.MerchantWmsTypeEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.WmsCkTypeEnums;
import com.seeease.flywheel_v4.web.util.SerialNoGenerator;
import com.seeease.goods.rpc.SkuFacade;
import com.seeease.goods.rpc.enums.SkuNodeStateEnums;
import com.seeease.goods.rpc.request.PurchaseReturnSkuCreateRpcRequest;
import com.seeease.goods.rpc.request.SkuRpcRequest;
import com.seeease.goods.rpc.result.SkuCreateRpcResult;
import com.seeease.goods.rpc.result.SkuRpcResult;
import com.seeease.springframework.PageResult;
import com.seeease.springframework.context.UserContext;
import com.seeease.springframework.exception.ValidationUtil;
import com.seeease.springframework.utils.MultiUtils;
import com.seeease.springframework.utils.StringUtils;
import io.seata.spring.annotation.GlobalTransactional;
import org.apache.dubbo.config.annotation.DubboReference;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 7/27/24 3:49 下午
 **/
@Service
public class PurchaseAftersaleServiceImpl implements PurchaseAftersaleService {

    @DubboReference(check = false, version = "1.0.0")
    private SkuFacade skuFacade;

    @Resource
    private RepositoryFactory repositoryFactory;
    @Resource
    private WmsSubject wmsSubject;


    @Override
    public PageResult<PurchaseAftersalePageResult> page(PurchaseAftersalePageRequest request) {

        //sku查询
        Set<Integer> skuIdList = null;
        if (StringUtils.isNotEmpty(request.getSkuCode())) {
            SkuRpcRequest rpcRequest = new SkuRpcRequest();
            rpcRequest.setSkuCode(request.getSkuCode());
            skuIdList = MultiUtils.toSet(skuFacade.list(rpcRequest), SkuRpcResult::getId);

            if (StringUtils.isEmpty(skuIdList)) {
                return PageResult.buildEmpty();
            }
        }

        Set<Integer> mainIds = null;
        if (StringUtils.isNotEmpty(skuIdList)) {
            //行查询
            List<PurchaseAftersaleLine> lineList = repositoryFactory.getPurchaseAftersaleLineRepository()
                    .listbySkuIds(skuIdList);

            if (StringUtils.isEmpty(lineList)) {
                return PageResult.buildEmpty();
            }
            mainIds = MultiUtils.toSet(lineList, PurchaseAftersaleLine::getMainId);
        }


        //主表查询

        Integer buId = UserContext.getUser().getStore().getId();
        SysBusinessUnit bu = repositoryFactory.getBusinessUnitRepository().findById(buId);
        if (bu.getType() != BusinessUnitTypeEnums.PLATFORM){
            request.setBuId(buId);
        }
        Page<PurchaseAftersale> page = repositoryFactory.getPurchaseAftersaleRepository().page(request, mainIds);

        if (page.getRecords().isEmpty()) {
            return PageResult.buildEmpty();
        }

        //订单来源
        Set<Integer> originIdList = MultiUtils.toSet(page.getRecords(), PurchaseAftersale::getBuId);
        Map<Integer, String> originMap = MultiUtils.toMap(
                repositoryFactory.getBusinessUnitRepository().listByIds(originIdList),
                SysBusinessUnit::getId,
                SysBusinessUnit::getName
        );


        //组合
        List<PurchaseAftersalePageResult> ret = MultiUtils.toList(
                page.getRecords(),
                v -> {
                    String originName = originMap.get(v.getBuId());
                    return PurchaseAftersaleMapping.INSTANCE.toPageResult(v, originName);
                }
        );


        return PageResult.<PurchaseAftersalePageResult>builder()
                .result(ret)
                .totalCount(page.getTotal())
                .totalPage(page.getPages())
                .build();
    }

    @Override
    public PurchaseAftersaleDetailResult detail(PurchaseAftersaleDetailRequest request) {
        PurchaseAftersale main = repositoryFactory.getPurchaseAftersaleRepository().findByIdOrSerialNo(
                request.getId(),
                request.getSerialNo()
        );

        ValidationUtil.notNull(main, "id错误");


        //来源
        SysBusinessUnit origin = repositoryFactory.getBusinessUnitRepository().findById(main.getBuId());

        //供应商
        Supplier supplier = repositoryFactory.getSupplierRepository().findById(main.getSupplierId());
        SupplierContacts contact = repositoryFactory.getSupplierContactsRepository().findById(main.getSupplierContactId());


        //sku
        Map<Integer, PurchaseAftersaleLine> lineMap = MultiUtils.toMap(
                repositoryFactory.getPurchaseAftersaleLineRepository().listByMainId(main.getId()),
                PurchaseAftersaleLine::getSkuId,
                Function.identity()
        );


        SkuRpcRequest rpcRequest = new SkuRpcRequest();
        rpcRequest.setIdList(lineMap.keySet());
        List<SkuRpcResult> list = skuFacade.list(rpcRequest);
        //sku数据组合
        List<PurchaseAftersaleDetailResult.Sku> skuList = MultiUtils.toList(
                list,
                v -> PurchaseAftersaleLineMapping.INSTANCE.toSkuResult(v, lineMap.get(v.getId()))
        );


        return PurchaseAftersaleMapping.INSTANCE.toDetailResult(
                main,
                origin,
                supplier,
                contact,
                skuList
        );
    }

    @GlobalTransactional
    @Override
    public Boolean cancel(PurchaseAftersaleCancelRequest request) {
        List<PurchaseAftersaleLine> lineList;
        PurchaseAftersale aftersale;
        if (null != request.getId()) {
            aftersale = repositoryFactory.getPurchaseAftersaleRepository().findByIdOrSerialNo(request.getId(), null);
            ValidationUtil.notNull(aftersale, "id错误");
            lineList = repositoryFactory.getPurchaseAftersaleLineRepository().listByMainId(aftersale.getId());
        } else {
            PurchaseAftersaleLine line = repositoryFactory.getPurchaseAftersaleLineRepository().findById(request.getLineId());
            ValidationUtil.notNull(line, "lineId错误");
            lineList = Collections.singletonList(line);
            aftersale = repositoryFactory.getPurchaseAftersaleRepository().findByIdOrSerialNo(line.getMainId(), null);
        }


        //step_1 状态过滤
        lineList = lineList.stream()
                .filter(v -> {
                    return v.getNodeState().equals(SkuNodeStateEnums.JSZ) ||
                            v.getNodeState().equals(SkuNodeStateEnums.FX) ||
                            v.getNodeState().equals(SkuNodeStateEnums.HH) ||
                            v.getNodeState().equals(SkuNodeStateEnums.THZ);
                }).collect(Collectors.toList());

        ValidationUtil.isTrue(!lineList.isEmpty(), "无可取消的sku");


        //step_2 wms取消
        Set<Integer> skuIdList = MultiUtils.toSet(lineList, PurchaseAftersaleLine::getSkuId);
        SysBusinessUnit bu = repositoryFactory.getBusinessUnitRepository().findById(aftersale.getStoreId());

        if (bu.getType() == BusinessUnitTypeEnums.WAREHOUSE) {
            wmsSubject.cancelWmsCk(aftersale.getSerialNo(), skuIdList,false);
        } else {
            wmsSubject.cancelMerchantWms(aftersale.getSerialNo(), skuIdList, SkuNodeStateEnums.DCK,false);
        }

        return true;
    }

    @GlobalTransactional
    @Override
    public Integer returnCreate(PurchaseReturnCreateRequest request) {
        //step_0 校验
        Set<Integer> skuIdList = MultiUtils.toSet(request.getSkuList(), PurchaseReturnCreateRequest.Sku::getId);
        SkuRpcRequest rpcQueryReq = new SkuRpcRequest();
        rpcQueryReq.setIdList(skuIdList);

        List<SkuRpcResult> skuList = skuFacade.list(rpcQueryReq);


        Map<Integer, List<SkuRpcResult>> skuMap = skuList.stream().collect(Collectors.groupingBy(SkuRpcResult::getStoreId));
        ValidationUtil.isTrue(skuMap.size() == 1, "不同仓库的sku不能同时退货");


        Integer storeId = skuList.get(0).getStoreId();
        SysBusinessUnit bu = repositoryFactory.getBusinessUnitRepository().findById(storeId);
        boolean pushToStore = bu.getType() == BusinessUnitTypeEnums.WAREHOUSE;
        SkuNodeStateEnums nodeState = pushToStore ? SkuNodeStateEnums.THZ : SkuNodeStateEnums.DCK;


        //step_1 获取关联的采购单号
        Set<Integer> purchaseIdList = MultiUtils.toSet(
                repositoryFactory.getPurchaseOrderLineRepository().listBySkuIds(skuIdList),
                PurchaseOrderLine::getPurchaseId);
        String originSerialNo = repositoryFactory.getPurchaseOrderRepository().listByIds(purchaseIdList)
                .stream()
                .map(PurchaseOrder::getSerialNo)
                .collect(Collectors.joining(","));


        //step_2 创建退货主单
        Integer totalCount = 0;
        BigDecimal amount = BigDecimal.ZERO;
        for (PurchaseReturnCreateRequest.Sku sku : request.getSkuList()) {
            totalCount += sku.getCount();
            amount = amount.add(sku.getAmount());
        }

        Integer buId = UserContext.getUser().getStore().getId();
        PurchaseAftersale main = PurchaseAftersaleMapping.INSTANCE.toEntity(
                request,
                totalCount,
                amount,
                buId,
                originSerialNo,
                PurchaseAftersaleTypeEnums.TH
        );
        main.setStoreId(storeId);
        main.setSerialNo(SerialNoGenerator.generalSerial(SerialNoGenerator.Type.CG_TH));
        repositoryFactory.getPurchaseAftersaleRepository().submit(main);


        //step_3 sku采购退货创建
        PurchaseReturnSkuCreateRpcRequest rpcRequest = new PurchaseReturnSkuCreateRpcRequest();
        List<PurchaseReturnSkuCreateRpcRequest.Sku> rpcSkuList = MultiUtils.toList(
                request.getSkuList(),
                PurchaseAftersaleLineMapping.INSTANCE::toSkuRpcCreateRequest
        );
        rpcRequest.setSerialNo(main.getSerialNo());
        rpcRequest.setSkuList(rpcSkuList);
        List<SkuCreateRpcResult> rpcRet = skuFacade.create(rpcRequest);

        //step_4 创建退货行
        List<PurchaseAftersaleLine> lineList = MultiUtils.toList(
                rpcRet,
                line -> PurchaseAftersaleLineMapping.INSTANCE.toEntity(line, main.getId(), nodeState)
        );
        repositoryFactory.getPurchaseAftersaleLineRepository().submitBatch(lineList);


        //step_5 创建wms
        if (pushToStore) {

            List<WmsCk> ckList = MultiUtils.toList(
                    lineList,
                    line -> PurchaseAftersaleLineMapping.INSTANCE.toWmsCk(
                            main,
                            line,
                            SkuNodeStateEnums.JD,
                            WmsCkTypeEnums.CG_TH
                    )
            );
            wmsSubject.ckDataSubmit(ckList);
        }
        else {

            Supplier supplier = repositoryFactory.getSupplierRepository().findById(main.getSupplierId());
            ContactInfo buyer = PurchaseOrderMapping.INSTANCE.toMerchantWmsContactInfo(supplier);
            MerchantWms wms = PurchaseAftersaleMapping.INSTANCE.toMerchantWms(
                    main,
                    MerchantWmsTypeEnums.CG_TH,
                    MerchantWmsModelEnums.CK,
                    totalCount,
                    amount
            );
            wms.setContactInfo(buyer);

            List<MerchantWmsLine> wmsLines = MultiUtils.toList(
                    lineList,
                    line -> PurchaseAftersaleLineMapping.INSTANCE.toMerchantWmsLine(line, SkuNodeStateEnums.DCK)
            );

            wmsSubject.merchantWmsDataCreate(wms, wmsLines);
        }


        return main.getId();
    }
}
