package com.seeease.flywheel_v4.web.app.excel.request;


import com.alibaba.excel.annotation.ExcelProperty;
import lombok.Data;


@Data
public class StoreLocationImportRequest {

    @ExcelProperty(value = "库位名称")
    private String locationName;

    @ExcelProperty(value = "货号")
    private String goodsCode;

    @ExcelProperty(value = "子区")
    private String childAreaName;
}
