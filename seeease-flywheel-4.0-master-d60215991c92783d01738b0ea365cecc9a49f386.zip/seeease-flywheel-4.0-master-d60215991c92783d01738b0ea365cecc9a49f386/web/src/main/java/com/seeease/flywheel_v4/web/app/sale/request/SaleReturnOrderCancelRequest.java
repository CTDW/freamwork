package com.seeease.flywheel_v4.web.app.sale.request;


import lombok.Data;

import javax.validation.constraints.NotNull;


@Data
public class SaleReturnOrderCancelRequest {

    /**
     * 主键id
     */
    @NotNull(message = "退货单id不能为空")
    private Integer id;


}
