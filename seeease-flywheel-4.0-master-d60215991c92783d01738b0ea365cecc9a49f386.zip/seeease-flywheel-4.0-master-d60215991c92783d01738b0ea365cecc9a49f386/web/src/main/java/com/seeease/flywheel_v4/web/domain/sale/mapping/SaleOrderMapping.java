package com.seeease.flywheel_v4.web.domain.sale.mapping;


import com.seeease.flywheel_v4.client.enums.BusinessUnitTypeEnums;
import com.seeease.flywheel_v4.web.app.excel.result.TobOrderExportResult;
import com.seeease.flywheel_v4.web.app.excel.result.TocOrderExportResult;
import com.seeease.flywheel_v4.web.app.sale.request.SaleOrderCreateRequest;
import com.seeease.flywheel_v4.web.app.sale.result.ToBSaleOrderDetailResult;
import com.seeease.flywheel_v4.web.app.sale.result.ToBSaleOrderPageResult;
import com.seeease.flywheel_v4.web.app.sale.result.ToCSaleOrderDetailResult;
import com.seeease.flywheel_v4.web.app.sale.result.ToCSaleOrderPageResult;
import com.seeease.flywheel_v4.web.domain.wms.observer.base.Ext;
import com.seeease.flywheel_v4.web.infrastructure.config.EnumMapping;
import com.seeease.flywheel_v4.web.infrastructure.config.MappingIgnore;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.enums.PurchaseDemandStateEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.entity.SaleOrder;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.entity.SaleOrderLine;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.entity.ThirdSaleOrder;
import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.entity.SysBusinessUnit;
import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.entity.SysSaleChannel;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.MerchantWms;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.obj.ContactInfo;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.MerchantWmsModelEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.MerchantWmsTypeEnums;
import com.seeease.flywheel_v4.web.util.SerialNoGenerator;
import com.seeease.goods.rpc.request.SaleSkuCreateRpcRequest;
import com.seeease.goods.rpc.result.SkuRpcResult;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;


/**
 * <p>
 * </p>
 *
 * @author 西门 游
 * @since 2023-10-27
 */
@Mapper(componentModel = "spring",
        builder = @Builder(disableBuilder = true),
        nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS,
        nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE,
        imports = {BusinessUnitTypeEnums.class,
                PurchaseDemandStateEnums.class,
                PurchaseDemandStateEnums.TransitionEnum.class,
                SerialNoGenerator.class})
public interface SaleOrderMapping extends EnumMapping {

    SaleOrderMapping INSTANCE = Mappers.getMapper(SaleOrderMapping.class);


     ToCSaleOrderDetailResult toCDetailResult(
             String buyerName,
             String buyerPhone,
             String buyerAddress,
             String originName,
             List<ToCSaleOrderDetailResult.Sku> skuList,
             SaleOrder order,
             String sellerAName,
             String sellerBName,
             String sellerCName
     ) ;


    SaleOrder toEntity(Integer storeId,
                       String serialNo,
                       Integer buId,
                       Integer totalCount,
                       BigDecimal totalAmount,
                       SaleOrderCreateRequest request
    );

    @Mapping(target = "skuId",source = "sku.id")
    @Mapping(target = "count",source = "sku.sellCount")
    @Mapping(target = "uuid",source = "sku.uuid")
    SaleSkuCreateRpcRequest.Sku toSaleSkuCreateRpc(SaleOrderCreateRequest.Sku sku);

    @MappingIgnore
    @Mapping(target = "originId",source = "saleOrder.buId")
    @Mapping(target = "state",ignore = true)
    @Mapping(target = "type",source = "type")
    @Mapping(target = "model",source = "model")
    MerchantWms toMerchantWms(SaleOrder saleOrder,
                              MerchantWmsTypeEnums type,
                              MerchantWmsModelEnums model,
                              Integer totalCount,
                              BigDecimal amount,
                              ContactInfo contactInfo,
                              Integer fromId
    );

    @Mapping(target = "originName",source = "origin.name")
    @Mapping(target = "state",source = "order.state")
    @Mapping(target = "id",source = "order.id")
    @Mapping(target = "createdBy",source = "order.createdBy")
    @Mapping(target = "createdTime",source = "order.createdTime")
    ToCSaleOrderPageResult tocPageResult(SaleOrder order,
                                        String buyerName,
                                        String scName,
                                         SysBusinessUnit origin,
                                         String sellerA,
                                         String sellerB,
                                         String sellerC
    );

    ToBSaleOrderPageResult tobPageResult(SaleOrder saleOrder,
                                         String buyerName,
                                         String belongName,
                                         String sellerA,
                                         String sellerB,
                                         String sellerC
    );

    ToBSaleOrderDetailResult tobDetailResult(
            BigDecimal totalProfit,
            String buyerName,
            String buyerPhone,
            String buyerAddress,
            String originName,
            List<ToBSaleOrderDetailResult.Sku> skuList,
            SaleOrder order,
            String sellerAName,
            String sellerBName,
            String sellerCName
    );

    @Mapping(target = "state",source = "state")
    @Mapping(target = "scType",source = "scType")
    @Mapping(target = "nodeState",source = "nodeState")
    @Mapping(target = "param",source = "param")
    @Mapping(target = "annexe",source = "annexe")
    @Mapping(target = "dealPrice",source = "line.dealPrice")
    @Mapping(target = "tocPrice",source = "line.tocPrice")
    @Mapping(target = "newSettlePrice",source = "line.newSettlePrice")
    @Mapping(target = "createdTime",source = "saleOrder.createdTime")
    @Mapping(target = "createdBy",source = "saleOrder.createdBy")
    @Mapping(target = "sellerName",source = "seller.name")
    @Mapping(target = "belongName",source = "belong.name")
    @Mapping(target = "finishTime",source = "saleOrder.finishTime")
    TocOrderExportResult tocExportResult(SaleOrderLine line,
                                         SkuRpcResult sku,
                                         ToCSaleOrderPageResult saleOrder,
                                         String state,
                                         String scType,
                                         String nodeState,
                                         String param,
                                         String annexe,
                                         SysBusinessUnit seller,
                                         SysBusinessUnit belong,
                                         String psName
    );

    @Mapping(target = "state",source = "state")
    @Mapping(target = "scType",source = "scType")
    @Mapping(target = "nodeState",source = "nodeState")
    @Mapping(target = "param",source = "param")
    @Mapping(target = "annexe",source = "annexe")
    @Mapping(target = "dealPrice",source = "line.dealPrice")
    @Mapping(target = "tobPrice",source = "line.tobPrice")
    @Mapping(target = "newSettlePrice",source = "line.newSettlePrice")
    @Mapping(target = "createdTime",source = "saleOrder.createdTime")
    @Mapping(target = "createdBy",source = "saleOrder.createdBy")
    @Mapping(target = "sellerName",source = "seller.name")
    @Mapping(target = "belongName",source = "belong.name")
    @Mapping(target = "finishTime",source = "saleOrder.finishTime")
    TobOrderExportResult tobExportResult(SaleOrderLine line,
                                         SkuRpcResult sku,
                                         ToBSaleOrderPageResult saleOrder,
                                         String state,
                                         String scType,
                                         String nodeState,
                                         String param,
                                         String annexe,
                                         SysBusinessUnit seller,
                                         SysBusinessUnit belong,
                                         String psName
    );

    @Mapping(target = "address", source = "address")
    @Mapping(target = "name",source = "name")
    @Mapping(target = "phone",source = "phone")
    @Mapping(target = "province",source = "province")
    @Mapping(target = "city",source = "city")
    @Mapping(target = "area",source = "area")
    @Mapping(target = "street",source = "street")
    @Mapping(target = "spAddress",expression = "java(from.getAddressDetail())")
    @Mapping(target = "spPhone",source = "from.phone")
    @Mapping(target = "spProvince",source = "from.province")
    @Mapping(target = "spCity",source = "from.city")
    @Mapping(target = "spArea",source = "from.area")
    @Mapping(target = "spStreet",source = "from.street")
    @Mapping(target = "spName",source = "from.name")
    @Mapping(target = "qualityWay",source = "order.qualityWay")
    @Mapping(target = "thirdSaleOrder",source = "thirdSaleOrder")
    @Mapping(target = "billRemark",source = "order.billRemark")
    @Mapping(target = "thirdPartNo",source = "thirdSaleOrder.orderId")
    @Mapping(target = "seller",source = "seller")
    @Mapping(target = "remark",source = "order.sellRemark")
    Ext toCkExt(String address,
                String phone,
                String name,
                String province,
                String city,
                String area,
                String street,
                SaleOrder order,
                SysBusinessUnit from,
                SysSaleChannel saleChannel,
                ThirdSaleOrder thirdSaleOrder,
                ArrayList<Ext.SkuExt> skuExts,
                String seller);
}
