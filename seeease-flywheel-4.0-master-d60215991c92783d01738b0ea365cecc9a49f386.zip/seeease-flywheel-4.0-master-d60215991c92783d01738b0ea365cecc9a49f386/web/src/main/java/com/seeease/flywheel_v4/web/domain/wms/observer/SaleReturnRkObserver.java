package com.seeease.flywheel_v4.web.domain.wms.observer;

import com.seeease.flywheel_v4.web.domain.wms.observer.base.MerchantWmsObserver;
import com.seeease.flywheel_v4.web.domain.wms.observer.base.WmsRkObserver;
import com.seeease.flywheel_v4.web.infrastructure.dao.RepositoryFactory;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.SupplierContacts;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.SupplierQuota;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.SupplierQuotaDetail;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.SupplierQuotaLog;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.enums.SupplierQuotaAuditTypeEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.enums.SupplierQuotaLogTypeEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.entity.SaleOrder;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.entity.SaleOrderLine;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.entity.SaleReturnOrder;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.entity.SaleReturnOrderLine;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.enums.SaleModelEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.enums.SaleTypeEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.MerchantWms;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.MerchantWmsLine;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.WmsRk;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.MerchantWmsModelEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.MerchantWmsTypeEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.WmsRkTypeEnums;
import com.seeease.flywheel_v4.web.infrastructure.listener.SaleOrderStateListener;
import com.seeease.flywheel_v4.web.infrastructure.listener.SaleReturnOrderStateListener;
import com.seeease.goods.rpc.SkuFacade;
import com.seeease.goods.rpc.enums.SkuNodeStateEnums;
import com.seeease.goods.rpc.request.SaleReturnSkuCancelRpcRequest;
import com.seeease.goods.rpc.request.SaleReturnSkuFinishRpcRequest;
import com.seeease.seeeaseframework.mybatis.domain.WhetherEnum;
import com.seeease.springframework.exception.ValidationUtil;
import com.seeease.springframework.utils.MultiUtils;
import org.apache.dubbo.config.annotation.DubboReference;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.List;
import java.util.Set;

/**
 * <p
 * 销售退货入库观察者
 * </p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/21/24 2:46下午
 **/
@Component
public class SaleReturnRkObserver extends SaleBaseObserver
        implements WmsRkObserver, MerchantWmsObserver {

    @Resource
    private RepositoryFactory repositoryFactory;

    @DubboReference(version = "1.0.0", check = false)
    private SkuFacade skuFacade;

    @Resource
    private SaleReturnOrderStateListener stateListener;

    @Resource
    private SaleOrderStateListener saleOrderStateListener;


    @Override
    public SkuNodeStateEnums adaptSkuNodeState(SkuNodeStateEnums state, String serialNo) {
        if (state == SkuNodeStateEnums.YRK){
            return SkuNodeStateEnums.YRK;
        }
        return null;
    }

    //----------------------------------------仓库wms观察者实现-----------------------------------//

    @Override
    public List<WmsRkTypeEnums> getWatchDataType() {
        return wmsRkWatchTypeList;
    }

    @Override
    public void update(List<WmsRk> wmsRkList, SkuNodeStateEnums nodeState, String serialNo) {
        SaleReturnOrder order = repositoryFactory.getSaleReturnOrderRepository()
                .findByIdOrSerialNo(null, serialNo);

        Set<Integer> skuIdList = MultiUtils.toSet(wmsRkList, WmsRk::getSkuId);
        List<SaleReturnOrderLine> lineList = repositoryFactory.getSaleReturnOrderLineRepository()
                .listByMainIdAndSkuIds(order.getId(), skuIdList);

        switch (nodeState) {
            case YRK: //入库
                WmsRk rk = wmsRkList.get(0);
                doRK(order, lineList,rk.getExpressNo());
                break;
            case QX:
                doCancel(order, lineList);

        }
    }


    //----------------------------------------仓库wms观察者实现-----------------------------------//


    //----------------------------------------商家wms观察者实现-----------------------------------//

    @Override
    public MerchantWmsModelEnums model() {
        return MerchantWmsModelEnums.RK;
    }


    @Override
    public List<MerchantWmsTypeEnums> typeList() {
        return merchantWmsRkWatchTypeList;
    }

    @Override
    public void update(MerchantWms main, List<MerchantWmsLine> rkList, SkuNodeStateEnums nodeState) {
        SaleReturnOrder order = repositoryFactory.getSaleReturnOrderRepository()
                .findByIdOrSerialNo(null, main.getSerialNo());

        Set<Integer> skuIdList = MultiUtils.toSet(rkList, MerchantWmsLine::getSkuId);
        List<SaleReturnOrderLine> lineList = repositoryFactory.getSaleReturnOrderLineRepository()
                .listByMainIdAndSkuIds(order.getId(), skuIdList);

        switch (nodeState) {
            case YRK: //入库
                doRK(order, lineList,main.getExpressNo());
                break;
            case QX:
                doCancel(order, lineList);

        }

    }

    //----------------------------------------商家wms观察者实现-----------------------------------//



    /**
     * 取消操作
     *
     * @param order    入库对应的退货单
     * @param lineList 入库的行
     */
    public void doCancel(SaleReturnOrder order, List<SaleReturnOrderLine> lineList) {
        //step_1 销售单行状态变更
        Set<Integer> saleLineIds = MultiUtils.toSet(lineList, SaleReturnOrderLine::getSaleLineId);
        List<SaleOrderLine> saleLineList = repositoryFactory.getSaleOrderLineRepository().listByIds(saleLineIds);
        saleLineList.forEach(line -> {
            if (line.getDealPrice().compareTo(BigDecimal.ZERO) == 0){
                line.setNodeState(SkuNodeStateEnums.JI_SZ);
            }else {
                line.setNodeState(SkuNodeStateEnums.YCK);
            }
        });

        repositoryFactory.getSaleOrderLineRepository().submitBatch(saleLineList);

        //step_2 修改退货单行状态
        lineList.forEach(line -> {
            line.setNodeState(SkuNodeStateEnums.QX);
            line.setEndState(WhetherEnum.YES);
        });
        repositoryFactory.getSaleReturnOrderLineRepository().submitBatch(lineList);


        //step_3 尝试修改销售退货单状态
        stateListener.onEvent(new SaleReturnOrderStateListener.Event(this,order.getId()));


        //stpe_4 调用sku取消
        Set<Integer> skuIdList = MultiUtils.toSet(lineList, SaleReturnOrderLine::getSkuId);
        SaleReturnSkuCancelRpcRequest rpcRequest = new SaleReturnSkuCancelRpcRequest();
        rpcRequest.setSkuIdList(skuIdList);
        rpcRequest.setSerialNo(order.getSerialNo());
        skuFacade.cancel(rpcRequest);

    }



    /**
     * 入库操作
     *
     * @param order    入库对应的退货单
     * @param lineList 入库的行
     */
    public void doRK(SaleReturnOrder order, List<SaleReturnOrderLine> lineList,String expressNo) {
        Integer saleId = lineList.get(0).getSaleId();
        SaleOrder saleOrder = repositoryFactory.getSaleOrderRepository().findByIdOrSerialNo(saleId, null);
        //step_0 修改销售单状态
        Set<Integer> saleLineIds = MultiUtils.toSet(lineList, SaleReturnOrderLine::getSaleLineId);
        List<SaleOrderLine> saleLineList = repositoryFactory.getSaleOrderLineRepository().listByIds(saleLineIds);
        saleLineList.forEach(line -> {
            line.setNodeState(SkuNodeStateEnums.YTH);
            if (saleOrder.getSellType() == SaleTypeEnums.JS){
                line.setEndState(WhetherEnum.YES);
            }
        });
        repositoryFactory.getSaleOrderLineRepository().submitBatch(saleLineList);

        if (saleOrder.getSellType() == SaleTypeEnums.JS){
            saleOrderStateListener.onEvent(new SaleOrderStateListener.Event(this,saleId));
        }


        //step_1 修改行状态
        lineList.forEach(line -> {
            line.setNodeState(SkuNodeStateEnums.YTH);
            line.setEndState(WhetherEnum.YES);
        });

        repositoryFactory.getSaleReturnOrderLineRepository().submitBatch(lineList);


        //step_2 补充快递单号
        order.setExpressNo(expressNo);
        ValidationUtil.isTrue(
                repositoryFactory.getSaleReturnOrderRepository().submit(order),
                "销售退货单绑定快递单号失败"
        );


        //step_3 尝试修改销售退货单状态
        stateListener.onEvent(new SaleReturnOrderStateListener.Event(this,order.getId()));


        //step_4 rpc调用完成
        Set<Integer> skuIdList = MultiUtils.toSet(lineList, SaleReturnOrderLine::getSkuId);
        SaleReturnSkuFinishRpcRequest rpcRequest = new SaleReturnSkuFinishRpcRequest();


        //step_5 如果是同行销售则回滚保证金余额

        if (saleOrder.getModel() == SaleModelEnums.B) {

            SupplierQuotaAuditTypeEnums auditType =  null;
            if (saleOrder.getSellType() == SaleTypeEnums.ZC) {
                auditType = SupplierQuotaAuditTypeEnums.NORMAL;
            }else if (saleOrder.getSellType() == SaleTypeEnums.JS){
                auditType = SupplierQuotaAuditTypeEnums.JS;
            }

            if (null != auditType){
                BigDecimal totalAmount = lineList
                        .stream()
                        .map(SaleReturnOrderLine::getReturnAmount)
                        .reduce(BigDecimal::add)
                        .orElse(BigDecimal.ZERO);


                SupplierContacts contact = repositoryFactory.getSupplierContactsRepository().findById(saleOrder.getBuyerId());
                SupplierQuota quota = repositoryFactory.getSupplierQuotaRepository()
                        .findBySupplierId(contact.getSupplierId());

                if (auditType == SupplierQuotaAuditTypeEnums.NORMAL){
                    quota.setNormalQuota(quota.getNormalQuota().add(totalAmount));
                }else {
                    quota.setJsQuota(quota.getJsQuota().add(totalAmount));
                }

                repositoryFactory.getSupplierQuotaRepository().submit(quota);

                SupplierQuotaDetail detail = repositoryFactory.getSupplierQuotaDetailRepository().findOne(
                        quota.getId(),
                        saleOrder.getCreatedId(),
                        auditType
                );
                detail.setAmount(detail.getAmount().add(totalAmount));
                repositoryFactory.getSupplierQuotaDetailRepository().submit(detail);

                //记录日志
                SupplierQuotaLog log = new SupplierQuotaLog();
                log.setAmountType(auditType);
                log.setType(SupplierQuotaLogTypeEnums.CANCEL);
                log.setAmount(totalAmount);
                log.setQuotaId(quota.getId());
                repositoryFactory.getSupplierQuotaLogRepository().submit(log);
            }

        }

        //一件代发逻辑
        rpcRequest.setSellerId(order.getBuId());
        rpcRequest.setStoreId(order.getStoreId());
        rpcRequest.setSkuIdList(skuIdList);
        rpcRequest.setSerialNo(order.getSerialNo());
        skuFacade.finish(rpcRequest);

    }


}
