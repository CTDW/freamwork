package com.seeease.flywheel_v4.web.app.common.result;


import lombok.Data;


@Data
public class AreaListResult {
    /**
     *
     */
    private Integer id;

    /**
     *
     */
    private String title;

    /**
     *
     */
    private Integer parentId;

    /**
     *
     */
    private String shortName;

    /**
     *
     */
    private Integer areaCode;

    /**
     *
     */
    private Integer zipCode;

    /**
     *
     */
    private String pinyin;

    /**
     *
     */
    private String lng;

    /**
     *
     */
    private String lat;

    /**
     *
     */
    private Integer level;

    /**
     *
     */
    private String position;

    /**
     *
     */
    private Integer sort;

}