package com.seeease.flywheel_v4.web.infrastructure.dao.operations.repo.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.Supplier;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.mapper.SupplierMapper;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.repo.SupplierRepository;
import com.seeease.springframework.PageRequest;
import com.seeease.springframework.utils.StringUtils;
import org.springframework.stereotype.Repository;

import java.util.Collections;
import java.util.List;
import java.util.Set;

/**
 * @author 西门 游
 * @version 1.0
 * @since 5/31/24 4:55 下午
 **/
@Repository
public class SupplierRepositoryImpl extends ServiceImpl<SupplierMapper, Supplier>
        implements SupplierRepository {


    @Override
    public boolean submit(Supplier supplier) {
        return saveOrUpdate(supplier);
    }

    @Override
    public Page<Supplier> page(Set<Integer> supplierIdList,
                               Integer type,
                               String name,
                               Integer state,
                               PageRequest request) {
        LambdaQueryWrapper<Supplier> wq = Wrappers.<Supplier>lambdaQuery()
                .in(StringUtils.isNotEmpty(supplierIdList), Supplier::getId, supplierIdList)
                .eq(null != type, Supplier::getType, type)
                .eq(null != state,Supplier::getState,state)
                .like(StringUtils.isNotEmpty(name), Supplier::getName, name)
                .orderByDesc(Supplier::getUpdatedTime);

        Page<Supplier> page = new Page<>(request.getPage(), request.getLimit());
        baseMapper.selectPage(page,wq);
        return page;
    }

    @Override
    public Supplier findById(Integer id) {
        return baseMapper.selectById(id);
    }

    @Override
    public List<Supplier> listByIds(Set<Integer> ids) {
        if (StringUtils.isEmpty(ids)){
            return Collections.emptyList();
        }
        return baseMapper.selectBatchIds(ids);
    }

    @Override
    public List<Supplier> listByName(String name) {
        LambdaQueryWrapper<Supplier> wq = Wrappers.<Supplier>lambdaQuery()
                .like(StringUtils.isNotEmpty(name), Supplier::getName, name);
        return baseMapper.selectList(wq);
    }
}
