package com.seeease.flywheel_v4.web.app.wms.request;


import lombok.Data;

/**
 * @ Description   :
 * @ Author        :  西门 游
 * @ CreateDate    :  6/6/24
 * @ Version       :  1.0
 */
@Data
public class MerchantWmsCancelRequest {

    /**
     * 行id
     */
    private Integer  lineId;
    /**
     * 主键id
     */
    private Integer id;
}

