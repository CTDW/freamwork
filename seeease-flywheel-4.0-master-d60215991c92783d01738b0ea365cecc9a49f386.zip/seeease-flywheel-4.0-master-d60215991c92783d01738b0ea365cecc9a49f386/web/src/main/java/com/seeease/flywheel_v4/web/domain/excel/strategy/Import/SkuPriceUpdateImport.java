package com.seeease.flywheel_v4.web.domain.excel.strategy.Import;

import com.alibaba.cola.extension.Extension;
import com.seeease.flywheel_v4.web.app.excel.request.SkuPriceUpdateImportRequest;
import com.seeease.flywheel_v4.web.domain.excel.core.ImportExtPtl;
import com.seeease.goods.rpc.SkuFacade;
import com.seeease.goods.rpc.request.SkuPriceUpdateRpcRequest;
import com.seeease.goods.rpc.request.SkuRpcRequest;
import com.seeease.goods.rpc.result.SkuRpcResult;
import com.seeease.springframework.exception.ValidationUtil;
import com.seeease.springframework.utils.MultiUtils;
import org.apache.dubbo.config.annotation.DubboReference;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 *
 * @author 西门 游
 * @version 1.0
 * @since 9/11/24 1:39 下午
 **/
@Service
@Extension(bizId = "import", useCase = "skuPriceUpdate")
public class SkuPriceUpdateImport implements ImportExtPtl<SkuPriceUpdateImportRequest, Void> {

    @DubboReference(check = false,version = "1.0.0")
    private SkuFacade skuFacade;

    @Override
    public Class<SkuPriceUpdateImportRequest> getRequestClass() {
        return SkuPriceUpdateImportRequest.class;
    }

    @Override
    public void validate(List<SkuPriceUpdateImportRequest> data) {

    }

    @Override
    public List<Void> handle(List<SkuPriceUpdateImportRequest> items) {


        Set<String> codes = MultiUtils.toSet(items, SkuPriceUpdateImportRequest::getSkuCode);
        SkuRpcRequest rpcRequest = new SkuRpcRequest();
        rpcRequest.setSkuCodes(codes);
        Map<String, SkuRpcResult> skuCodeMap = MultiUtils.toMap(
                skuFacade.list(rpcRequest),
                SkuRpcResult::getSkuCode
        );


        ArrayList<SkuPriceUpdateRpcRequest> updateRpcRequest = new ArrayList<>();
        for (SkuPriceUpdateImportRequest item : items){

            SkuRpcResult sku = skuCodeMap.get(item.getSkuCode());

            ValidationUtil.notNull(sku,"唯一码:" + item.getSkuCode() + "不存在");

            SkuPriceUpdateRpcRequest rpcItem = new SkuPriceUpdateRpcRequest();
            BeanUtils.copyProperties(item,rpcItem);

            rpcItem.setId(sku.getId());
            updateRpcRequest.add(rpcItem);
        }
        skuFacade.priceUpdate(updateRpcRequest);

        return Collections.emptyList();
    }


}
