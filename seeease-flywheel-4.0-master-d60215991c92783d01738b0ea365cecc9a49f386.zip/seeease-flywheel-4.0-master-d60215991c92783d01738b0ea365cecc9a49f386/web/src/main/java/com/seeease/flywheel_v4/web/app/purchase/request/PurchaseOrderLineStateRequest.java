package com.seeease.flywheel_v4.web.app.purchase.request;


import lombok.Data;

import javax.validation.constraints.NotEmpty;
import java.util.Set;


@Data
public class PurchaseOrderLineStateRequest {
    /**
     * 采购单行id列表
     */
    @NotEmpty(message = "采购单行id不能为空")
    private Set<Integer> idList;

    /**
     * 节点状态
     */
    private Integer nodeState;

}
