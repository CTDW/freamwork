package com.seeease.flywheel_v4.web.app.excel.request;


import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.converters.Converter;
import com.alibaba.excel.converters.ReadConverterContext;
import com.alibaba.excel.enums.CellDataTypeEnum;
import com.seeease.goods.rpc.enums.SkuRunTypeEnums;
import com.seeease.goods.rpc.enums.SkuSellWayEnums;
import lombok.Data;

import java.math.BigDecimal;


@Data
public class SkuPricingImportRequest {

    @ExcelProperty(value = "唯一码")
    private String skuCode;

    @ExcelProperty(value = "结算价")
    private BigDecimal settlePrice;

    @ExcelProperty(value = "同行价")
    private BigDecimal tobPrice;

    @ExcelProperty(value = "零售价")
    private BigDecimal tocPrice;

    @ExcelProperty(value = "收货价")
    private BigDecimal receiptPrice;

    @ExcelProperty(value = "商品渠道定位", converter = SellTypeConverter.class)
    private Integer sellWay;

    @ExcelProperty(value = "自主经营类型", converter = RunTypeConverter.class)
    private Integer runType;

    @ExcelProperty(value = "需求商家")
    private String merchantName;


    public static class SellTypeConverter implements Converter<Integer> {
        @Override
        public Class<?> supportJavaTypeKey() {
            return Integer.class;
        }

        @Override
        public CellDataTypeEnum supportExcelTypeKey() {
            return CellDataTypeEnum.STRING;
        }

        /**
         * 这里读的时候会调用，将Excel中的字段汉字转换成Java的Integer对象
         *
         * @param context context
         * @return Java中的Integer对象
         */
        @Override
        public Integer convertToJavaData(ReadConverterContext<?> context) {
            String stringValue = context.getReadCellData().getStringValue();
            if (stringValue.equals("仅C端销售")) {
                return SkuSellWayEnums.TOC.getValue();
            } else if (stringValue.equals("仅B端销售")) {
                return SkuSellWayEnums.TOB.getValue();
            } else {
                return SkuSellWayEnums.BOTH.getValue();
            }
        }
    }

    public static class RunTypeConverter implements Converter<Integer> {
        @Override
        public Class<?> supportJavaTypeKey() {
            return Integer.class;
        }

        @Override
        public CellDataTypeEnum supportExcelTypeKey() {
            return CellDataTypeEnum.STRING;
        }

        /**
         * 这里读的时候会调用，将Excel中的字段汉字转换成Java的Integer对象
         *
         * @param context context
         * @return Java中的Integer对象
         */
        @Override
        public Integer convertToJavaData(ReadConverterContext<?> context) {
            String stringValue = context.getReadCellData().getStringValue();
            if (stringValue.equals("压货")) {
                return SkuRunTypeEnums.YH.getValue();
            } else {
                return SkuRunTypeEnums.DX.getValue();
            }
        }
    }
}
