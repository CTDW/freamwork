package com.seeease.flywheel_v4.web.domain.operations.mapping;


import com.seeease.flywheel_v4.client.enums.BusinessUnitTypeEnums;
import com.seeease.flywheel_v4.web.app.operations.request.SupplierQuotaAuditRequest;
import com.seeease.flywheel_v4.web.app.operations.request.SupplierQuotaTopUpRequest;
import com.seeease.flywheel_v4.web.app.operations.result.SupplierQuotaAuditDetailResult;
import com.seeease.flywheel_v4.web.app.operations.result.SupplierQuotaAuditPageResult;
import com.seeease.flywheel_v4.web.infrastructure.config.EnumMapping;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.Supplier;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.SupplierQuotaAudit;
import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.entity.SysBusinessUnit;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;


/**
 * <p>
 * 供应商
 * </p>
 *
 * @author 西门 游
 * @since 2023-10-27
 */
@Mapper(componentModel = "spring",
        builder = @Builder(disableBuilder = true),
        nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS,
        nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE,
        imports = {BusinessUnitTypeEnums.class})
public interface SupplierQuotaAuditMapping extends EnumMapping {

    SupplierQuotaAuditMapping INSTANCE = Mappers.getMapper(SupplierQuotaAuditMapping.class);

    SupplierQuotaAudit toEntity(SupplierQuotaTopUpRequest request,
                                Integer buId);



    @Mapping(target = "images",ignore = true)
    @Mapping(target = "pzImages",ignore = true)
    void update(@MappingTarget SupplierQuotaAudit audit, SupplierQuotaAuditRequest request);

    SupplierQuotaAuditPageResult toPageResult(
            SupplierQuotaAudit log,
            String supplierName,
            String purchaseSubjectName,
            String originName);

    @Mapping(target = "id",source = "log.id")
    @Mapping(target = "type",source = "log.type")
    @Mapping(target = "state",source = "log.state")
    @Mapping(target = "account",source = "log.account")
    @Mapping(target = "remark",source = "log.remark")
    @Mapping(target = "createdBy",source = "log.createdBy")
    @Mapping(target = "updatedTime",source = "log.updatedTime")
    @Mapping(target = "updatedBy",source = "log.updatedBy")
    @Mapping(target = "createdTime",source = "log.createdTime")
    @Mapping(target = "supplierName",source = "supplier.name")
    @Mapping(target = "originName",source = "origin.name")
    @Mapping(target = "purchaseSubjectName",source = "subject.name")
    SupplierQuotaAuditDetailResult toDetailResult(
            SupplierQuotaAudit log,
            Supplier supplier,
            SysBusinessUnit origin,
            SysBusinessUnit subject);
}
