package com.seeease.flywheel_v4.web.app.operations.service.impl;

import com.seeease.flywheel_v4.web.app.operations.request.SupplierContactSubmitRequest;
import com.seeease.flywheel_v4.web.app.operations.result.SupplierContactListResult;
import com.seeease.flywheel_v4.web.app.operations.service.SupplierContactsService;
import com.seeease.flywheel_v4.web.domain.operations.mapping.SupplierContactsMapping;
import com.seeease.flywheel_v4.web.infrastructure.dao.RepositoryFactory;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.SupplierContacts;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * <p>供应商联系人</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/4/24 4:43 下午
 **/
@Service
public class SupplierContactsServiceImpl implements SupplierContactsService {
    @Resource
    private RepositoryFactory repositoryFactory;

    @Override
    public Boolean del(Integer id) {

        return repositoryFactory.getSupplierContactsRepository().delById(id);
    }

    @Override
    public SupplierContactListResult create(SupplierContactSubmitRequest request) {
        request.setId(null);
        SupplierContacts contacts = SupplierContactsMapping.INSTANCE.toEntity(request);
        repositoryFactory.getSupplierContactsRepository().submit(contacts);
        SupplierContacts ret = repositoryFactory.getSupplierContactsRepository().findById(contacts.getId());
        return SupplierContactsMapping.INSTANCE.toListResult(ret);
    }
}
