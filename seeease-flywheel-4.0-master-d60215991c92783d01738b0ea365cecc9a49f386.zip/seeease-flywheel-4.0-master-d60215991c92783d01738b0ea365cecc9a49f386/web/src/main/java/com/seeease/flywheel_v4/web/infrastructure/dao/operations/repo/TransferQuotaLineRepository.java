package com.seeease.flywheel_v4.web.infrastructure.dao.operations.repo;

import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.TransferQuotaLine;

import java.util.List;
import java.util.Set;

/**
 *
 * @author 西门 游
 * @version 1.0
 * @since 5/31/24 4:55 下午
 **/
public interface TransferQuotaLineRepository {


    /**
     * 批量提交
     * @param list
     */
    Boolean submitBatch(List<TransferQuotaLine> list);

    /**
     * 列表查询
     * @param tsqId 主表id
     * @return
     */
    List<TransferQuotaLine> listByTsqId(Integer tsqId);

    /**
     * 删除
     * @param idList
     * @return
     */
    Boolean delByIds(Set<Integer> idList);

    /**
     * 列表查询
     * @param tfqIdList 主表id列表
     * @return
     */
    List<TransferQuotaLine> listByTsqIdList(Set<Integer> tfqIdList);
}
