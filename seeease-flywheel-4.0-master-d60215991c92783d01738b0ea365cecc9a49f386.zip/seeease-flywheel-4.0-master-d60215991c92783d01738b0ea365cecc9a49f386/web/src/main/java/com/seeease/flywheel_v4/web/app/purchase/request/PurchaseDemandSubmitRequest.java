package com.seeease.flywheel_v4.web.app.purchase.request;


import lombok.Data;


import javax.validation.constraints.NotNull;


@Data
public class PurchaseDemandSubmitRequest {
    /**
     * 指定采购人id
     */
    @NotNull(message = "指定采购人id不能为空")
    private Integer assignedId;
    /**
     * spuId
     */
    @NotNull(message = "spuId不能为空")
    private Integer spuId;
    /**
     * 需求数量
     */
    @NotNull(message = "需求数量不能为空")
    private Integer count;
    /**
     * 商家单元id
     */
    @NotNull(message = "商家单元id不能为空")
    private Integer merchantId;

    /**
     * 备注说明
     */
    private String remark;


}
