package com.seeease.flywheel_v4.web.infrastructure.dao.operations.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.SupplierQuotaDetail;

/**
 * @author 西门 游
 * @version 1.0
 * @since 5/31/24 4:53 下午
 **/
public interface SupplierQuotaDetailMapper extends BaseMapper<SupplierQuotaDetail> {
}
