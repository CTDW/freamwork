package com.seeease.flywheel_v4.web.adptor;

import com.seeease.flywheel_v4.web.app.transfer.request.*;
import com.seeease.flywheel_v4.web.app.transfer.result.TransferDetailResult;
import com.seeease.flywheel_v4.web.app.transfer.result.TransferPageResult;
import com.seeease.flywheel_v4.web.app.transfer.result.TransferTaskPageResult;
import com.seeease.flywheel_v4.web.app.transfer.result.TransferUsableQuotaResult;
import com.seeease.flywheel_v4.web.app.transfer.service.TransferService;
import com.seeease.flywheel_v4.web.app.transfer.service.TransferTaskService;
import com.seeease.flywheel_v4.web.infrastructure.config.IdentifyLogPrinter;
import com.seeease.springframework.PageResult;
import com.seeease.springframework.SingleResponse;
import com.seeease.springframework.log.annotation.LogPrinter;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 7/2/24 4:32 下午
 **/
@RestController
@RequestMapping("transfer")
public class TransferController {
    @Resource
    private TransferTaskService transferTaskService;
    @Resource
    private TransferService transferService;

    /**
     * 调拨-调拨任务创建
     *
     * @return 更新结果
     */
    @PostMapping("task/create")
    @LogPrinter(scenario = "调拨-调拨任务创建", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<Boolean> taskCreate(@RequestBody TransferTaskCreateRequest request) {

        return SingleResponse.of(transferTaskService.create(request));
    }


    /**
     * 调拨-调拨任务分页
     *
     * @return 分页结果
     */
    @PostMapping("task/page")
    @LogPrinter(scenario = "调拨-调拨任务分页", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<PageResult<TransferTaskPageResult>> taskPage(
            @RequestBody TransferTaskPageRequest request) {

        return SingleResponse.of(transferTaskService.page(request));
    }


    /**
     * 调拨-调拨任务删除
     *
     * @return 删除结果
     */
    @PostMapping("task/del")
    @LogPrinter(scenario = "调拨-调拨任务删除", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<Boolean> taskDel(
           @Validated @RequestBody TransferTaskDelRequest request) {

        return SingleResponse.of(transferTaskService.del(request.getId()));
    }


    /**
     * 调拨-可用额度数据查询
     *
     * @return 查询结果
     */
    @PostMapping("usable/quota")
    @LogPrinter(scenario = "调拨-可用额度数据查询", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<TransferUsableQuotaResult> usableQuota(
            @Validated @RequestBody TransferUsableQuotaRequest request) {

        return SingleResponse.of(transferService.usableQuota(request));
    }




    /**
     * 调拨-调拨单创建
     *
     * @return 调拨单id
     */
    @PostMapping("create")
    @LogPrinter(scenario = "调拨-调拨单创建", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<Integer> create(
            @Validated @RequestBody TransferCreateRequest request) {

        return SingleResponse.of(transferService.create(request));
    }




    /**
     * 调拨-调拨单取消
     */
    @PostMapping("cancel")
    @LogPrinter(scenario = "调拨-调拨单取消", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<Boolean> cancel(
            @Validated @RequestBody TransferCancelRequest request) {

        return SingleResponse.of(transferService.cancel(request));
    }




    /**
     * 调拨-调拨单分页
     *
     * @return 分页结果
     */
    @PostMapping("page")
    @LogPrinter(scenario = "调拨-调拨单分页", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<PageResult<TransferPageResult>> page(
           @RequestBody TransferPageRequest request) {

        return SingleResponse.of(transferService.page(request));
    }



    /**
     * 调拨-调拨单详情
     *
     * @return 详情结果
     */
    @PostMapping("detail")
    @LogPrinter(scenario = "调拨-调拨单详情", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<TransferDetailResult> detail(
            @RequestBody TransferDetailRequest request) {

        return SingleResponse.of(transferService.detail(request));
    }


}
