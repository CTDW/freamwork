package com.seeease.flywheel_v4.web.app.operations.service;

import com.seeease.flywheel_v4.web.app.operations.request.TransferQuotaPageRequest;
import com.seeease.flywheel_v4.web.app.operations.request.TransferQuotaSubmitRequest;
import com.seeease.flywheel_v4.web.app.operations.result.TransferQuotaPageResult;
import com.seeease.springframework.PageResult;

/**

 *
 * @author 西门 游
 * @version 1.0
 * @since 6/4/24 4:43 下午
 **/
public interface TransferQuotaService {


    /**
     * 系统运营-门店调拨额度创建
     *
     * @return 创建结果
     */
    Boolean create(TransferQuotaSubmitRequest request);

    /**
     * 系统运营-门店调拨额度分页查询
     *
     * @return 分页结果
     */
    PageResult<TransferQuotaPageResult> page(TransferQuotaPageRequest request);

    /**
     * 系统运营-门店调拨额度更新
     *
     * @return 更新结果
     */
    Boolean update(TransferQuotaSubmitRequest request);
    /**
     * 系统运营-门店调拨额度删除
     *
     * @return 删除结果
     */
    Boolean del(Integer id);
}
