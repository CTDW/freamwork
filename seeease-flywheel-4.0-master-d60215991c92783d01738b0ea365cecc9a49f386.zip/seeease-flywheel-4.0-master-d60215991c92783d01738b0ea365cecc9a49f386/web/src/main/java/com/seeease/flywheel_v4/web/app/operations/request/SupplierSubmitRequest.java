package com.seeease.flywheel_v4.web.app.operations.request;

import com.seeease.seeeaseframework.mybatis.domain.WhetherEnum;
import com.seeease.springframework.RequestValidGroup;
import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.Collections;
import java.util.List;


@Data
public class SupplierSubmitRequest implements Serializable {

    /**
     * id
     */
    @NotNull(message = "id不能为空",groups = RequestValidGroup.Update.class)
    private Integer id;
    /**
     * 供应商名称
     */
    @NotBlank(message = "供应商名称不能为空")
    private String name;
    /**
     * 供应商类型
     */
    @NotNull(message = "供应商类型不能为空")
    private Integer type;
    /**
     * 状态
     */
    @NotNull(message = "状态不能为空",groups = RequestValidGroup.Update.class)
    private Integer state = WhetherEnum.YES.getValue();
    /**
     * 省
     */
    private String province;
    /**
     * 市
     */
    private String city;
    /**
     * 县区
     */
    private String area;
    /**
     * 详细地址
     */
    private String address;
    /**
     * 省市县区代码
     */
    private List<Integer> areaCodes;
    /**
     * 备注
     */
    private String remark;

    /**
     * 联系人列表
     */
    @Valid
    private List<SupplierContactSubmitRequest> contacts = Collections.emptyList();


}
