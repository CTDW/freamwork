package com.seeease.flywheel_v4.web.app.operations.result;

import lombok.Data;

import java.math.BigDecimal;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/4/24 6:00 下午
 **/
@Data
public class SupplierQuotaResult {
    /**
     * 寄售余额
     */
    private BigDecimal consignmentCredit = BigDecimal.ZERO;
    /**
     * 正常余额
     */
    private BigDecimal normalCredit = BigDecimal.ZERO;


}
