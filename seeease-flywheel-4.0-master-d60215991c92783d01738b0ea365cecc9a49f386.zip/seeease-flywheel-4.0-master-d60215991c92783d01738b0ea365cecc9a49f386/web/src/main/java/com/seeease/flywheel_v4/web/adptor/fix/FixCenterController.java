package com.seeease.flywheel_v4.web.adptor.fix;

import com.seeease.flywheel_v4.web.app.fix.request.*;
import com.seeease.flywheel_v4.web.app.fix.result.FixOrderDetailResult;
import com.seeease.flywheel_v4.web.app.fix.result.FixOrderPageResult;
import com.seeease.flywheel_v4.web.app.fix.result.FixStatusCountResult;
import com.seeease.flywheel_v4.web.app.fix.service.FixOrderService;
import com.seeease.flywheel_v4.web.infrastructure.config.IdentifyLogPrinter;
import com.seeease.springframework.PageResult;
import com.seeease.springframework.SingleResponse;
import com.seeease.springframework.log.annotation.LogPrinter;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * @Description 维修中心 控制层
 * @Date 2024-10-2 10:10
 * @Author by hk
 */
@RestController
@RequestMapping("fix")
@Api(tags = "维修中心 控制层")
public class FixCenterController {

    @Resource
    private FixOrderService fixOrderService;

    @ApiOperation(value = "维修单-分页查询")
    @PostMapping("/fixOrder/page")
    @LogPrinter(scenario = "维修中心-维修单-分页查询", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<PageResult<FixOrderPageResult>> page(@RequestBody FixOrderPageRequest request) {

        return SingleResponse.of(fixOrderService.page(request));
    }

    @ApiOperation(value = "维修单-查询各状态数量")
    @PostMapping("/fixOrder/getStatusCount")
    @LogPrinter(scenario = "维修中心-维修单-查询各状态数量", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<List<FixStatusCountResult>> getStatusCount(@RequestBody FixOrderPageRequest request) {

        return SingleResponse.of(fixOrderService.getStatusCount(request));
    }

    @ApiOperation(value = "维修单-查询详情")
    @PostMapping("/fixOrder/detail")
    @LogPrinter(scenario = "维修中心-维修单-查询详情", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<FixOrderDetailResult> detail(@RequestBody @Validated FixOrderDetailRequest request) {

        return SingleResponse.of(fixOrderService.detail(request));
    }

    @ApiOperation(value = "维修单-新增")
    @PostMapping("/fixOrder/create")
    @LogPrinter(scenario = "维修中心-维修单-新增", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<Boolean> save(@RequestBody @Validated FixOrderSaveRequest request) {
        return SingleResponse.of(fixOrderService.save(request));
    }

    @ApiOperation(value = "维修单-删除")
    @PostMapping("/fixOrder/del")
    @LogPrinter(scenario = "维修中心-维修单-删除", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<Boolean> delete(@RequestBody @Validated FixOrderDetailRequest request) {
        return SingleResponse.of(fixOrderService.delete(request));
    }

    @ApiOperation(value = "维修单-编辑")
    @PostMapping("/fixOrder/update")
    @LogPrinter(scenario = "维修中心-维修单-编辑", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<Boolean> update(@RequestBody @Validated FixOrderSaveRequest request) {
        return SingleResponse.of(fixOrderService.update(request));
    }

    @ApiOperation(value = "维修单-分配")
    @PostMapping("/fixOrder/distribute")
    @LogPrinter(scenario = "维修中心-维修单-分配", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<Boolean> distribute(@RequestBody @Validated FixOrderDistributeRequest request) {
        return SingleResponse.of(fixOrderService.distribute(request));
    }

    @ApiOperation(value = "维修单-重新分配")
    @PostMapping("/fixOrder/reDistribute")
    @LogPrinter(scenario = "维修中心-维修单-重新分配", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<Boolean> reDistribute(@RequestBody @Validated FixOrderDistributeRequest request) {
        return SingleResponse.of(fixOrderService.reDistribute(request));
    }

    @ApiOperation(value = "维修单-取消")
    @PostMapping("/fixOrder/cancel")
    @LogPrinter(scenario = "维修中心-维修单-取消", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<Boolean> cancel(@RequestBody @Validated FixOrderDetailRequest request) {
        return SingleResponse.of(fixOrderService.cancel(request));
    }

    @ApiOperation(value = "维修单-送外")
    @PostMapping("/fixOrder/sendOut")
    @LogPrinter(scenario = "维修中心-维修单-送外", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<Boolean> sendOut(@RequestBody @Validated FixOrderSendOutRequest request) {
        return SingleResponse.of(fixOrderService.sendOut(request));
    }

    @ApiOperation(value = "维修单-完成")
    @PostMapping("/fixOrder/complete")
    @LogPrinter(scenario = "维修中心-维修单-完成", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<Boolean> complete(@RequestBody @Validated FixOrderCompleteRequest request) {
        return SingleResponse.of(fixOrderService.complete(request));
    }

    @ApiOperation(value = "维修单-回退")
    @PostMapping("/fixOrder/fallback")
    @LogPrinter(scenario = "维修中心-维修单-回退", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<Boolean> fallback(@RequestBody @Validated FixOrderDetailRequest request) {
        return SingleResponse.of(fixOrderService.fallback(request));
    }

    @ApiOperation(value = "维修单-跳过")
    @PostMapping("/fixOrder/jump")
    @LogPrinter(scenario = "维修中心-维修单-跳过", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<Boolean> jump(@RequestBody @Validated FixOrderJumpRequest request) {
        return SingleResponse.of(fixOrderService.jump(request));
    }

    @ApiOperation(value = "维修单-维修师扫码领用")
    @PostMapping("/fixOrder/masterUse")
    @LogPrinter(scenario = "维修中心-维修单-维修师扫码领用", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<Boolean> masterUse(@RequestBody @Validated FixOrderMasterUseRequest request) {
        return SingleResponse.of(fixOrderService.masterUse(request));
    }

    @ApiOperation(value = "维修单-完成质检")
    @PostMapping("/fixOrder/completeQuality")
    @LogPrinter(scenario = "维修中心-维修单-完成质检", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<Boolean> completeQuality(@RequestBody @Validated FixOrderDetailRequest request) {
        return SingleResponse.of(fixOrderService.completeQuality(request));
    }
}
