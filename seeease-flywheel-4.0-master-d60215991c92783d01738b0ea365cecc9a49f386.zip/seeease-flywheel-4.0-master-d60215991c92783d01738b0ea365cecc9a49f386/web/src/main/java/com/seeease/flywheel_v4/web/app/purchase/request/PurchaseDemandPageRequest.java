package com.seeease.flywheel_v4.web.app.purchase.request;


import com.fasterxml.jackson.annotation.JsonFormat;
import com.seeease.springframework.PageRequest;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Date;
import java.util.Set;


@EqualsAndHashCode(callSuper = true)
@Data
public class PurchaseDemandPageRequest extends PageRequest  {

    /**
     * 采购需求编号
     */
    private String serialNo;
    /**
     * 状态
     */
    private Integer state;
    /**
     * 类目id
     */
    private Integer categoryId;
    /**
     * 指定我的采购需求
     */
    private Boolean mine;
    /**
     * 商家单元id
     */
    private Integer merchantId;
    /**
     * 采购单号
     */
    private String purchaseSerialNo;
    /**
     * 开始时间
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date startTime;
    /**
     * 结束时间
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date endTime;

    /**
     * spuId列表
     */
    private Set<Integer> spuIdList;


}
