package com.seeease.flywheel_v4.web.app.wms.service;

import com.seeease.flywheel_v4.web.app.wms.request.WmsRkCountUpdateRequest;
import com.seeease.flywheel_v4.web.app.wms.request.WmsRkPageRequest;
import com.seeease.flywheel_v4.web.app.wms.request.WmsRkStateRequest;
import com.seeease.flywheel_v4.web.app.wms.result.WmsRkPageResult;
import com.seeease.springframework.PageResult;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/20/24 11:46 上午
 **/
public interface WmsRkService {
    /**
     * 入库管理分页查询
     *
     * @return 分页结果
     */
    PageResult<WmsRkPageResult> page(WmsRkPageRequest request);

    /**
     * 入库单状态变更
     *
     * @return 变更结果
     */
    Boolean state(WmsRkStateRequest request);

    /**
     * 待入库单据入库数量修改
     *
     * @return 变更结果
     */
    Boolean countUpdate(WmsRkCountUpdateRequest request);
}
