package com.seeease.flywheel_v4.web.app.operations.service.impl;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.seeease.flywheel_v4.client.enums.BusinessUnitTypeEnums;
import com.seeease.flywheel_v4.web.app.operations.request.TransferQuotaLineSubmitRequest;
import com.seeease.flywheel_v4.web.app.operations.request.TransferQuotaPageRequest;
import com.seeease.flywheel_v4.web.app.operations.request.TransferQuotaSubmitRequest;
import com.seeease.flywheel_v4.web.app.operations.result.TransferQuotaLineListResult;
import com.seeease.flywheel_v4.web.app.operations.result.TransferQuotaPageResult;
import com.seeease.flywheel_v4.web.app.operations.service.TransferQuotaService;
import com.seeease.flywheel_v4.web.domain.operations.OpsDomain;
import com.seeease.flywheel_v4.web.domain.operations.mapping.TransferQuotaLineMapping;
import com.seeease.flywheel_v4.web.domain.operations.mapping.TransferQuotaMapping;
import com.seeease.flywheel_v4.web.infrastructure.dao.RepositoryFactory;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.TransferQuota;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.TransferQuotaLine;
import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.entity.SysBusinessUnit;
import com.seeease.goods.rpc.BrandFacade;
import com.seeease.goods.rpc.CategoryFacade;
import com.seeease.goods.rpc.enums.SkuRunTypeEnums;
import com.seeease.goods.rpc.request.BrandRpcRequest;
import com.seeease.goods.rpc.request.CategoryRpcRequest;
import com.seeease.goods.rpc.result.BrandRpcResult;
import com.seeease.goods.rpc.result.CategoryRpcResult;
import com.seeease.springframework.PageResult;
import com.seeease.springframework.exception.ValidationUtil;
import com.seeease.springframework.utils.MultiUtils;
import com.seeease.springframework.utils.StringUtils;
import org.apache.dubbo.config.annotation.DubboReference;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @author 西门 游
 * @version 1.0
 * @since 6/4/24 4:43 下午
 **/
@Service
public class TransferQuotaServiceImpl implements TransferQuotaService {
    @Resource
    private RepositoryFactory repositoryFactory;

    @DubboReference(version = "1.0.0", check = false)
    private CategoryFacade categoryFacade;

    @DubboReference(version = "1.0.0", check = false)
    private BrandFacade brandFacade;

    @Resource
    private OpsDomain opsDomain;


    private TransferQuota submitCheck(TransferQuotaSubmitRequest request) {
        ValidationUtil.isTrue(request.getStartDate().before(request.getEndDate()), "时间错误");

        SysBusinessUnit merchant = repositoryFactory.getBusinessUnitRepository().findById(request.getMerchantId());
        ValidationUtil.notNull(merchant, "商家id错误");
        ValidationUtil.isTrue(merchant.getType() == BusinessUnitTypeEnums.MERCHANT, "商家id错误");

        Map<String, List<TransferQuotaLineSubmitRequest>> ctMap = request.getCtQuotas()
                .stream()
                .collect(Collectors.groupingBy(v -> v.getBrandId() + ":" + v.getCategoryId()));
        ctMap.values().forEach(v -> {
            ValidationUtil.isTrue(v.size() == 1, "代销额度创建参数错误不能存在相同的品牌");
        });

        Map<String, List<TransferQuotaLineSubmitRequest>> oosMap = request.getOsQuotas()
                .stream()
                .collect(Collectors.groupingBy(v -> v.getBrandId() + ":" + v.getCategoryId()));
        oosMap.values().forEach(v -> {
            ValidationUtil.isTrue(v.size() == 1, "压货额度创建参数错误不能存在相同的品牌");
        });

        List<TransferQuota> transferQuotas =
                repositoryFactory.getTransferQuotaRepository().listByMerchantId(merchant.getId());

        for (TransferQuota quota : transferQuotas) {
            if (null != request.getId() && request.getId().equals(quota.getId())) {
                continue;
            }

            ValidationUtil.isTrue(
                    request.getEndDate().before(quota.getStartDate()) ||
                            request.getStartDate().after(quota.getEndDate())
                    ,
                    "时间范围冲突"
            );
        }

        //主表提交
        BigDecimal osQuota = request.getOsQuotas()
                .stream()
                .map(TransferQuotaLineSubmitRequest::getQuota)
                .reduce(BigDecimal::add)
                .get();
        BigDecimal ctQuota = request.getCtQuotas()
                .stream()
                .map(TransferQuotaLineSubmitRequest::getQuota)
                .reduce(BigDecimal::add)
                .get();

        TransferQuota transferQuota = TransferQuotaMapping.INSTANCE.toEntity(request, osQuota, ctQuota);
        repositoryFactory.getTransferQuotaRepository().submit(transferQuota);
        return transferQuota;
    }

    @Transactional
    @Override
    public Boolean create(TransferQuotaSubmitRequest request) {
        TransferQuota transferQuota = this.submitCheck(request);

        //子表提交
        List<TransferQuotaLine> transferQuotaLineList = TransferQuotaLineMapping.INSTANCE.toEntity(
                request,
                transferQuota
        );
        repositoryFactory.getTransferQuotaLineRepository().submitBatch(transferQuotaLineList);
        return true;
    }

    @Transactional
    @Override
    public Boolean update(TransferQuotaSubmitRequest request) {

        TransferQuota transferQuota = this.submitCheck(request);


        //step1 获取旧数据
        List<TransferQuotaLine> oldLineList = repositoryFactory.getTransferQuotaLineRepository()
                .listByTsqId(transferQuota.getId());

        Map<String, TransferQuotaLine> oldMap = MultiUtils.toMap(
                oldLineList,
                v -> v.getBrandId() + ":" + v.getType().getValue(),
                Function.identity()
        );

        //待删除的旧数据id
        Set<Integer> rmIdList = MultiUtils.toSet(oldLineList, TransferQuotaLine::getId);

        //step2. 转换新数据 在 line：137行执行元素的去除
        List<TransferQuotaLine> newLineList = TransferQuotaLineMapping.INSTANCE.toEntity(
                request,
                transferQuota
        );


        //step3. 对比新老数据并且赋值
        for (TransferQuotaLine newLine : newLineList) {
            String key = newLine.getBrandId() + ":" + newLine.getType().getValue();
            if (oldMap.containsKey(key)) {
                TransferQuotaLine oldLine = oldMap.get(key);
                TransferQuotaLineMapping.INSTANCE.copy(newLine, oldLine);
                rmIdList.remove(oldLine.getId());
            }
        }

        if (StringUtils.isNotEmpty(rmIdList)) {
            repositoryFactory.getTransferQuotaLineRepository().delByIds(rmIdList);
        }
        repositoryFactory.getTransferQuotaLineRepository().submitBatch(newLineList);

        return true;
    }

    @Override
    public Boolean del(Integer id) {
        return repositoryFactory.getTransferQuotaRepository().delById(id);
    }


    @Override
    public PageResult<TransferQuotaPageResult> page(TransferQuotaPageRequest request) {

        //step_1主表查询
        Page<TransferQuota> page = repositoryFactory.getTransferQuotaRepository().page(request);

        if (page.getRecords().isEmpty()) {
            return PageResult.buildEmpty();
        }

        //step_2 子表查询
        Set<Integer> tfqIdList = MultiUtils.toSet(page.getRecords(), TransferQuota::getId);

        List<TransferQuotaLine> lineList = repositoryFactory.getTransferQuotaLineRepository()
                .listByTsqIdList(tfqIdList);

        Map<Integer, List<TransferQuotaLine>> lineMap = lineList.stream()
                .collect(Collectors.groupingBy(TransferQuotaLine::getTsqId));


        //step_3 获取已使用额度
        Map<Integer, OpsDomain.TransferUsedQuotaDto> usedQuotaDtoMap = MultiUtils.toMap(
                opsDomain.calTransferUsedQuota(page.getRecords(), lineList),
                OpsDomain.TransferUsedQuotaDto::getId
        );


        //step_4 商家查询查询
        Set<Integer> merchantIdList = MultiUtils.toSet(page.getRecords(), TransferQuota::getMerchantId);
        Map<Integer, String> merchantMap = MultiUtils.toMap(
                repositoryFactory.getBusinessUnitRepository().listByIds(merchantIdList),
                SysBusinessUnit::getId,
                SysBusinessUnit::getName
        );

        //step_5类目查询
        Set<Integer> categoryIdList = page.getRecords().stream()
                .map(TransferQuota::getCategoryIds)
                .flatMap(Collection::stream)
                .collect(Collectors.toSet());

        lineList.forEach(line -> categoryIdList.add(line.getCategoryId()));

        CategoryRpcRequest rpcRequest = new CategoryRpcRequest();
        rpcRequest.setIdList(categoryIdList);
        Map<Integer, String> categoryMap = MultiUtils.toMap(
                categoryFacade.list(rpcRequest),
                CategoryRpcResult::getId,
                CategoryRpcResult::getName
        );

        //step_6 品牌查询
        Set<Integer> brandIdList = MultiUtils.toSet(lineList, TransferQuotaLine::getBrandId);
        BrandRpcRequest brandRpcRequest = new BrandRpcRequest();
        brandRpcRequest.setIdList(brandIdList);
        Map<Integer, String> brandMap = MultiUtils.toMap(
                brandFacade.list(brandRpcRequest),
                BrandRpcResult::getId,
                BrandRpcResult::getName
        );


        //组合数据
        List<TransferQuotaPageResult> ret = MultiUtils.toList(
                page.getRecords(),
                quota -> {
                    OpsDomain.TransferUsedQuotaDto transferQuotaDto = usedQuotaDtoMap.get(quota.getId());
                    Map<Integer, OpsDomain.TransferUsedQuotaDto.Item> detailUsedQuotaMap = MultiUtils.toMap(
                            transferQuotaDto.getItems(),
                            OpsDomain.TransferUsedQuotaDto.Item::getLineId
                    );

                    String merchantName = merchantMap.get(quota.getMerchantId());

                    String categoryNames = quota.getCategoryIds().stream()
                            .map(categoryMap::get)
                            .collect(Collectors.joining(","));


                    Map<Integer, List<TransferQuotaLineListResult>> resultItemMap = lineMap.get(quota.getId())
                            .stream()
                            .map(line -> {
                                OpsDomain.TransferUsedQuotaDto.Item lineUsedQuota = detailUsedQuotaMap.get(line.getId());
                                String brandName = brandMap.get(line.getBrandId());
                                String categoryName = categoryMap.get(line.getCategoryId());

                                return TransferQuotaLineMapping.INSTANCE.toListResult(
                                        lineUsedQuota.getUsedQuota(),
                                        brandName,
                                        categoryName,
                                        line
                                );
                            }).collect(Collectors.groupingBy(TransferQuotaLineListResult::getRunType));


                    return TransferQuotaMapping.INSTANCE.toPageResult(
                            quota,
                            merchantName,
                            categoryMap,
                            brandMap,
                            categoryNames,
                            resultItemMap.get(SkuRunTypeEnums.YH.getValue()),
                            resultItemMap.get(SkuRunTypeEnums.DX.getValue())
                    );

                }
        );

        return PageResult.<TransferQuotaPageResult>builder()
                .result(ret)
                .totalCount(page.getTotal())
                .totalPage(page.getPages())
                .build();
    }


}
