package com.seeease.flywheel_v4.web.app.excel.result;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.format.DateTimeFormat;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 9/11/24 5:00 下午
 **/
@Data
public class PurchaseAftersaleExportResult implements Serializable {

    @ExcelProperty("订单号")
    private String serialNo;

    @ExcelProperty("关联单号")
    private String originSerialNo;

    @ExcelProperty("类型")
    private String type;

    @ExcelProperty("状态")
    private String state;

    @ExcelProperty("供应商/客户")
    private String supplierName;

    @ExcelProperty("手机")
    private String phone;


    @ExcelProperty("详细地址")
    private String detailAddr;

    @ExcelProperty("商品名称")
    private String goodsName;

    @ExcelProperty("品牌")
    private String brandName;

    @ExcelProperty("类目")
    private String categoryName;

    @ExcelProperty("入库参数")
    private String params;

    @ExcelProperty("唯一码")
    private String skuCode;

    @ExcelProperty("数量")
    private Integer totalCount;

    @ExcelProperty("附件")
    private String annex;

    @ExcelProperty("退款金额")
    private String amount;


    @ExcelProperty("创建人")
    private String createdBy;

    @DateTimeFormat("yyyy-MM-dd HH:mm:ss")
    @ExcelProperty("创建时间")
    private Date createdTime;



}
