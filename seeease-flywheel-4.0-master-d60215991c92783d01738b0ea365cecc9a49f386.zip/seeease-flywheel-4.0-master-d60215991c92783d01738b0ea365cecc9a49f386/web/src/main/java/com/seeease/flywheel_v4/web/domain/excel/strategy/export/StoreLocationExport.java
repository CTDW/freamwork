package com.seeease.flywheel_v4.web.domain.excel.strategy.export;

import com.alibaba.cola.extension.Extension;
import com.seeease.flywheel_v4.web.app.excel.result.StoreLocationExportResult;
import com.seeease.flywheel_v4.web.app.wms.request.WmsCkPageRequest;
import com.seeease.flywheel_v4.web.app.wms.request.WmsStoreLocationPageRequest;
import com.seeease.flywheel_v4.web.app.wms.result.WmsCkPageResult;
import com.seeease.flywheel_v4.web.app.wms.result.WmsStoreLocationPageResult;
import com.seeease.flywheel_v4.web.app.wms.service.WmsCkService;
import com.seeease.flywheel_v4.web.app.wms.service.WmsStoreLocationService;
import com.seeease.flywheel_v4.web.domain.excel.ExcelDomain;
import com.seeease.flywheel_v4.web.domain.excel.core.ExportExtPtl;
import com.seeease.flywheel_v4.web.domain.wms.mapping.WmsStoreLocationMapping;
import com.seeease.flywheel_v4.web.infrastructure.dao.RepositoryFactory;
import com.seeease.goods.rpc.SkuFacade;
import com.seeease.seeeaseframework.mybatis.domain.WhetherEnum;
import com.seeease.springframework.utils.MultiUtils;
import org.apache.dubbo.config.annotation.DubboReference;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.*;
import java.util.stream.Collectors;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 9/12/24 10:42 上午
 **/
@Service
@Extension(bizId = "export", useCase = "pickingList")
public class StoreLocationExport implements ExportExtPtl<WmsCkPageRequest, StoreLocationExportResult> {

    @Resource
    private RepositoryFactory repositoryFactory;

    @DubboReference(version = "1.0.0", check = false)
    private SkuFacade skuFacade;

    @Resource
    private WmsCkService wmsCkService;

    @Resource
    private WmsStoreLocationService locationService;

    @Resource
    private ExcelDomain excelDomain;


    @Override
    public Class<WmsCkPageRequest> getRequestClass() {
        return WmsCkPageRequest.class;
    }

    @Override
    public Class<StoreLocationExportResult> getResultClass() {
        return StoreLocationExportResult.class;
    }

    @Override
    public String getFileName() {
        return "拣货单导出";
    }

    @Override
    public List<StoreLocationExportResult> handle(WmsCkPageRequest request) {
        //step_1 调用wms出库分页接口
        request.setLimit(Integer.MAX_VALUE);
        List<WmsCkPageResult> list = wmsCkService.page(request).getResult();
        if (list.isEmpty()) {
            return Collections.emptyList();
        }

        //step_2 获取sku列表数据
        List<WmsCkPageResult.Sku> skuList = list.stream()
                .map(WmsCkPageResult::getSkuList)
                .flatMap(Collection::stream)
                .collect(Collectors.toList());


        //step_3 查找对应库区库位数据
        Set<Integer> spuIds = MultiUtils.toSet(skuList, WmsCkPageResult.Sku::getSpuId);
        WmsStoreLocationPageRequest storeLocationPageRequest = new WmsStoreLocationPageRequest();
        storeLocationPageRequest.setSpuIds(spuIds);
        storeLocationPageRequest.setState(WhetherEnum.YES.getValue());
        Map<Integer, WmsStoreLocationPageResult> locationMap = MultiUtils.toMap(
                locationService.locationPage(storeLocationPageRequest).getResult(),
                WmsStoreLocationPageResult::getSpuId
        );


        //step4_ 组合数据
        return MultiUtils.toList(
                skuList,
                sku ->{
                    WmsStoreLocationPageResult location = locationMap.get(sku.getSpuId());
                    return WmsStoreLocationMapping.INSTANCE.toExportResult(sku,location);
                }
        );

    }
}
