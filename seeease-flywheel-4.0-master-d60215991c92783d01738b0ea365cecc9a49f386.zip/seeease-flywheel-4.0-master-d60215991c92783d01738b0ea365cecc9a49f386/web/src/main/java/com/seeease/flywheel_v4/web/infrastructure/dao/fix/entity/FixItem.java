package com.seeease.flywheel_v4.web.infrastructure.dao.fix.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.seeease.seeeaseframework.mybatis.domain.BaseDomain;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;

/**
 * @Description 维修项目 表
 * @Date 2024-10-2 20:55
 * @Author by hk
 */
@EqualsAndHashCode(callSuper = true)
@TableName(value = "v4_fix_item", autoResultMap = true)
@Data
public class FixItem extends BaseDomain {

    @TableId(type = IdType.AUTO)
    private Long id;

    /**
     * 维修项目名称
     */
    private String itemName;

    /**
     * 默认维修价
     */
    private BigDecimal defaultFixPrice;

}