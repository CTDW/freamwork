package com.seeease.flywheel_v4.web.app.transfer.request;


import com.seeease.springframework.PageRequest;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author 西门 游
 * @version 1.0
 * @since 6/3/24 11:26 上午
 **/
@EqualsAndHashCode(callSuper = true)
@Data
public class TransferDetailRequest extends PageRequest {
    /**
     * 调拨单id
     */
    private Integer id;
    /**
     * 调拨单号
     */
    private String serialNo;


}
