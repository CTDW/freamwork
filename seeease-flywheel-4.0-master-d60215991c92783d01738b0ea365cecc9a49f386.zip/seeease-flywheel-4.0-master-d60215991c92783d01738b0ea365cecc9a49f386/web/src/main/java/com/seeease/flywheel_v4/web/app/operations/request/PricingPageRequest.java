package com.seeease.flywheel_v4.web.app.operations.request;

import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.Pricing;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.entity.PurchaseOrder;
import com.seeease.springframework.PageRequest;
import lombok.Data;
import lombok.EqualsAndHashCode;


@EqualsAndHashCode(callSuper = true)
@Data
public class PricingPageRequest extends PageRequest {
    /**
     * 商品名称
     */
    private String goodsName;
    /**
     * sku编码
     */
    private String skuCode;
    /**
     * 采购类型
     * {@link PurchaseOrder#getType()}
     */
    private Integer purchaseType;
    /**
     * 创建人
     */
    private String createdBy;
    /**
     * 品牌id
     */
    private Integer brandId;
    /**
     * 定价单状态
     * {@link Pricing#getState()}
     */
    private Integer state;
}
