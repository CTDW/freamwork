package com.seeease.flywheel_v4.web.app.sys_config.result;


import lombok.Data;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @author 西门 游
 * @version 1.0
 * @since 6/3/24 11:26上午
 **/
@Data
public class PurchaseBusinessUnitPageResult {
    /**
     * id
     */
    private Integer id;
    /**
     * 名称
     */
    private String name;
    /**
     * 支持的采购类型
     */
    private List<Integer> typeList = new ArrayList<>();
    /**
     * 采购类型名称 逗号拼接
     */
    private String typeName;
    /**
     * 仓库类型业务单元id
     */
    private List<Integer> storeIdList;
    /**
     * 仓库名称 逗号拼接
     */
    private String storeName;

    /**
     * 寄售加点
     */
    private BigDecimal consignmentPoint;
    /**
     * 状态
     */
    private Integer state;

    /**
     * 修改人
     */
    private String updatedBy;

    /**
     * 修改时间
     */
    private Date updatedTime;
    /**
     * 备注
     */
    private String remark;
}
