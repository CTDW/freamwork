package com.seeease.flywheel_v4.web.app.excel.result;

import com.seeease.goods.rpc.request.SkuAnnexeRpcResult;
import com.seeease.goods.rpc.result.ProductParamRpcResult;
import lombok.Data;

import java.math.BigDecimal;
import java.util.List;

/**
 * @date 2024/3/19
 */

@Data
public class TransferSkuImportResult {
    /**
     * skuId
     */
    private Integer id;
    /**
     * 品牌id
     */
    private Integer brandId;
    /**
     * 类目id
     */
    private Integer categoryId;

    /**
     * spu图片
     */
    private String spuImage;
    /**
     * 类目名称
     */
    private String categoryName;
    /**
     * 商品名称
     */
    private String goodsName;
    /**
     * 货号
     */
    private String goodsCode;
    /**
     * 品牌名称
     */
    private String brandName;
    /**
     * 调拨价
     */
    private BigDecimal transferPrice;
    /**
     * sku编码
     */
    private String skuCode;
    /**
     * sku参数列表
     */
    private List<ProductParamRpcResult> skuParams;
    /**
     * 附件
     */
    private List<SkuAnnexeRpcResult> annexe;
    /**
     * 数量
     */
    private Integer count = 1;
    /**
     * 结算价
     */
    private BigDecimal settlePrice;
    /**
     * 最新结算价结算价
     */
    private BigDecimal newSettlePrice;
    /**
     * 是否唯一码管控
     */
    private Integer uniqueType;



}
