package com.seeease.flywheel_v4.web.infrastructure.dao.sale.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.enums.SaleModelEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.enums.SaleQualityWayEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.enums.SaleStateEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.enums.SaleTypeEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.enums.SaleChannelTypeEnums;
import com.seeease.seeeaseframework.mybatis.domain.BaseDomain;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;
import java.util.Date;

/**
 * 销售订单
 */
@EqualsAndHashCode(callSuper = true)
@TableName(value = "v4_sale_order", autoResultMap = true)
@Data
public class SaleOrder extends BaseDomain {
    @TableId(type = IdType.AUTO)
    private Integer id;

    /**
     * 联系人id
     */
    private Integer buyerId;

    /**
     * 定金金额
     */
    private BigDecimal prepayAmount;

    /**
     * 三方单号
     */
    private String thirdPartyNo;

    /**
     * 主单号
     */
    private String mainSerialNo;

    /**
     * 单号
     */
    private String serialNo;

    /**
     * 一件代发id
     */
    private Integer doboId;

    /**
     * 当前创建人业务部门id
     */
    private Integer buId;

    /**
     * 出库方id
     */
    private Integer storeId;


    /**
     * 销售模型 - 同行销售 | 个人销售
     */
    private SaleModelEnums model;

    /**
     * 销售方式
     */
    private SaleTypeEnums sellType;

    /**
     * 状态
     */
    private SaleStateEnums state;

    /**
     * 总数量
     */
    private Integer totalCount;

    /**
     * 总金额
     */
    private BigDecimal totalAmount;


    /**
     * 销售备注
     */
    private String sellRemark;

    /**
     * 面单备注
     */
    private String billRemark;

    /**
     * 质检方式
     */
    private SaleQualityWayEnums qualityWay;

    /**
     * 销售渠道类型枚举
     */
    private SaleChannelTypeEnums scType;

    /**
     * 销售渠道配置id
     */
    private Integer scId;

    /**
     * 快递单号
     */
    private String expressNo;

    /**
     * 三方订单异常信息
     */
    private String unusual;

    /**
     * 三方单号合并后的合并id
     */
    private String mergedId;

    /**
     * 第一销售人id
     */
    private Integer sellerAId;

    /**
     * 第二销售人id
     */
    private Integer sellerBId;

    /**
     * 第三销售人id
     */
    private Integer sellerCId;


    /**
     * 完成时间
     */
    private Date finishTime;
}