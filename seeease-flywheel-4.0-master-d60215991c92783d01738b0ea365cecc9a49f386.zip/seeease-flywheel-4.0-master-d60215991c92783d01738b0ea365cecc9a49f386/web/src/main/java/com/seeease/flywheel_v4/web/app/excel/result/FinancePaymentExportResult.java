package com.seeease.flywheel_v4.web.app.excel.result;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.format.DateTimeFormat;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 9/11/24 5:00 下午
 **/
@Data
public class FinancePaymentExportResult implements Serializable {


    @ExcelProperty("关联单号")
    private String purchaseSerialNo;

    @ExcelProperty("打款单")
    private String serialNo;

    @ExcelProperty("打款金额")
    private BigDecimal amount;

    @ExcelProperty("实际打款金额")
    private BigDecimal payAmount;

    @ExcelProperty("供应商/客户")
    private String  supplierName;

    @ExcelProperty("状态")
    private String state;

    @ExcelProperty("订单类型")
    private String purchaseType;

    @ExcelProperty("核销状态")
    private String verifyState;

    @ExcelProperty("打款方式")
    private String payType;

    @ExcelProperty("数量")
    private Integer count;

    @ExcelProperty("创建人")
    private String createdBy;

    @DateTimeFormat("yyyy-MM-dd HH:mm:ss")
    @ExcelProperty("创建时间")
    private Date createdTime;

    @ExcelProperty("打款账户")
    private String purchaseSubjectName;




}
