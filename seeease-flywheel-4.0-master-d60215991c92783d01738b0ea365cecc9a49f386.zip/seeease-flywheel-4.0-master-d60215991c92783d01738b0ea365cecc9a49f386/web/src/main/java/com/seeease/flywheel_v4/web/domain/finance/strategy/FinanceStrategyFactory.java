package com.seeease.flywheel_v4.web.domain.finance.strategy;


import com.seeease.flywheel_v4.web.app.finance.request.PaymentSlipSubmitRequest;
import com.seeease.flywheel_v4.web.domain.finance.strategy.paymentSlip.PostCreateStrategy;
import com.seeease.flywheel_v4.web.domain.finance.strategy.paymentSlip.PreCreateStrategy;
import com.seeease.flywheel_v4.web.infrastructure.dao.finance.entity.FinancePaymentSlip;
import com.seeease.flywheel_v4.client.enums.PurchaseTypeEnums;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.List;

/**
 * <p>
 * 财务模块策略工厂
 * </p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/13/24 10:22 上午
 **/
@Component
public class FinanceStrategyFactory {
    /**
     * 申请打款单创建前置校验策略
     */
    @Resource
    private List<PreCreateStrategy> paymentSlipPreStrategyList;
    /**
     * 申请打款单创建后置处理器
     */
    @Resource
    private List<PostCreateStrategy> paymentSlipPostStrategyList = Collections.emptyList();


    /**
     * 查找到对应的申请打款单校验策略并执行
     *
     * @param request           申请打款单创建请求
     * @param purchaseTypeEnums 采购类型
     */
    public void findPaymentSlipPreStrategyAndDo(PaymentSlipSubmitRequest request,
                                                PurchaseTypeEnums purchaseTypeEnums) {
        for (PreCreateStrategy strategy : paymentSlipPreStrategyList) {
            if (strategy.match(purchaseTypeEnums)) {
                strategy.check(request);
                break;
            }
        }
    }


    /**
     * 查找到对应的申请打款单后置处理策略并执行
     *
     * @param request           申请打款单创建请求
     * @param purchaseTypeEnums 采购类型
     * @param paymentSlip 创建后的申请打款单
     */
    public void findPaymentSlipPostStrategyAndDo(PaymentSlipSubmitRequest request,
                                                 PurchaseTypeEnums purchaseTypeEnums,
                                                 FinancePaymentSlip paymentSlip) {
        for (PostCreateStrategy strategy : paymentSlipPostStrategyList) {
            if (strategy.match(purchaseTypeEnums)) {
                strategy.post(request, paymentSlip);
                break;
            }
        }
    }
}
