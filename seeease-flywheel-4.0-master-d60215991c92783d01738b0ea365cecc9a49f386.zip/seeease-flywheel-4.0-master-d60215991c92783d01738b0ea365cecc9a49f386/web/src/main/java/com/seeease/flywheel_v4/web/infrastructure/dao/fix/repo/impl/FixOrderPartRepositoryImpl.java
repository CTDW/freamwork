package com.seeease.flywheel_v4.web.infrastructure.dao.fix.repo.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.seeease.flywheel_v4.web.app.fix.common.FixPartsDto;
import com.seeease.flywheel_v4.web.app.fix.request.FixOrderPartPageRequest;
import com.seeease.flywheel_v4.web.infrastructure.dao.fix.entity.FixOrderPart;
import com.seeease.flywheel_v4.web.infrastructure.dao.fix.mapper.FixOrderPartMapper;
import com.seeease.flywheel_v4.web.infrastructure.dao.fix.repo.FixOrderPartRepository;
import com.seeease.springframework.utils.StringUtils;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @Description 维修配件
 * @Date 2024-10-2 21:05
 * @Author by hk
 */
@Repository
public class FixOrderPartRepositoryImpl extends ServiceImpl<FixOrderPartMapper, FixOrderPart>
        implements FixOrderPartRepository {

    /**
     * 分页
     *
     * @param request 请求
     * @return 维修配件
     */
    @Override
    public Page<FixOrderPart> page(FixOrderPartPageRequest request) {
        LambdaQueryWrapper<FixOrderPart> wq = Wrappers.<FixOrderPart>lambdaQuery()
                // 维修单号
                .eq(StringUtils.isNotEmpty(request.getOrderNumber()), FixOrderPart::getOrderNumber, request.getOrderNumber())
                // 商品名称
                .eq(StringUtils.isNotEmpty(request.getGoodsName()), FixOrderPart::getGoodsName, request.getGoodsName())
                // 货号
                .eq(StringUtils.isNotEmpty(request.getArticleNo()), FixOrderPart::getArticleNo, request.getArticleNo())
                // 分类
                .eq(StringUtils.isNotEmpty(request.getClassification()), FixOrderPart::getClassification, request.getClassification())
                // 品牌
                .eq(StringUtils.isNotEmpty(request.getGoodsBrand()), FixOrderPart::getGoodsBrand, request.getGoodsBrand()
                );

        Page<FixOrderPart> page = Page.of(request.getPage(), request.getLimit());
        baseMapper.selectPage(page, wq);
        return page;
    }

    @Override
    public List<FixOrderPart> getFixPartByNumber(String fixOrderNumber) {
        QueryWrapper<FixOrderPart> queryWrapper = new QueryWrapper<>();
        queryWrapper.lambda().eq(FixOrderPart::getOrderNumber, fixOrderNumber);
        return baseMapper.selectList(queryWrapper);
    }

    public List<Long> getFixPartIdByNumber(String fixOrderNumber) {
        return baseMapper.getFixPartIdByNumber(fixOrderNumber);
    }

    /**
     * 维修单新增时，同时新增配件信息
     *
     * @param partList       配件
     * @param fixOrderNumber 维修单号
     * @return 结果
     */
    @Override
    public Boolean save(List<FixPartsDto> partList, String fixOrderNumber) {

        List<FixOrderPart> orderParts = partList.stream().map(x -> x.toEntity(false, fixOrderNumber)).collect(Collectors.toList());

        return saveBatch(orderParts);
    }

    /**
     * 维修单编辑时，同时编辑配件信息
     *
     * @param partList       配件
     * @param fixOrderNumber 维修单号
     * @return 结果
     */
    @Override
    public Boolean update(List<FixPartsDto> partList, String fixOrderNumber) {

        // 是否需要删除
        List<Long> oldDataList = getFixPartIdByNumber(fixOrderNumber);
        List<Long> updateIdList = partList.stream().filter(x -> x.getId() != null).map(FixPartsDto::getId).collect(Collectors.toList());
        List<Long> needDeleteId = new ArrayList<>();
        for (Long oldId : oldDataList) {
            if (!updateIdList.contains(oldId)) {
                needDeleteId.add(oldId);
            }
        }
        if (needDeleteId.size() > 0) {
            baseMapper.deleteBatchIds(needDeleteId);
        }

        List<FixOrderPart> orderParts = partList.stream().map(x -> x.toEntity(true, fixOrderNumber)).collect(Collectors.toList());

        saveOrUpdateBatch(orderParts);

        return true;
    }


}
