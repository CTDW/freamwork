package com.seeease.flywheel_v4.web.app.purchase.request;


import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.util.Set;


@Data
public class PurchaseOrderCancelRequest {
    /**
     * 采购单id
     */
    @NotNull(message = "采购单id不能为空")
    private Integer id;

}
