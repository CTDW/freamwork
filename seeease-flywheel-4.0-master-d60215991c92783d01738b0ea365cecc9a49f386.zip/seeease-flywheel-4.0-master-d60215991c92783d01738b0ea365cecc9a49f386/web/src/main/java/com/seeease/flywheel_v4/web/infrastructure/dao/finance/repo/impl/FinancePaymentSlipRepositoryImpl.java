package com.seeease.flywheel_v4.web.infrastructure.dao.finance.repo.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.seeease.flywheel_v4.web.app.finance.request.PaymentSlipPageRequest;
import com.seeease.flywheel_v4.web.infrastructure.dao.finance.entity.FinancePaymentSlip;
import com.seeease.flywheel_v4.web.infrastructure.dao.finance.mapper.FinancePaymentSlipMapper;
import com.seeease.flywheel_v4.web.infrastructure.dao.finance.repo.FinancePaymentSlipRepository;
import com.seeease.seeeaseframework.mybatis.transitionstate.UpdateByIdCheckState;
import com.seeease.springframework.utils.DateUtils;
import com.seeease.springframework.utils.StringUtils;
import org.springframework.stereotype.Repository;

/**
 * @author 西门 游
 * @version 1.0
 * @since 5/31/24 4:53 下午
 **/
@Repository
public class FinancePaymentSlipRepositoryImpl extends ServiceImpl<FinancePaymentSlipMapper, FinancePaymentSlip>
        implements FinancePaymentSlipRepository {
    @Override
    public Boolean submit(FinancePaymentSlip paymentSlip) {
        return saveOrUpdate(paymentSlip);
    }

    @Override
    public FinancePaymentSlip findById(Integer id) {
        return getById(id);
    }

    @Override
    public Page<FinancePaymentSlip> page(PaymentSlipPageRequest request) {
        if (null != request.getStartTime() && null != request.getEndTime()) {
            request.setStartTime(DateUtils.getTimesmorning(request.getStartTime()));
            request.setEndTime(DateUtils.getTimesnight(request.getEndTime()));
        }

        LambdaQueryWrapper<FinancePaymentSlip> wq = Wrappers.<FinancePaymentSlip>lambdaQuery()
                .in(StringUtils.isNotEmpty(request.getIds()),FinancePaymentSlip::getId,request.getIds())
                .eq(null != request.getBuId(),FinancePaymentSlip::getBuId,request.getBuId())
                .in(StringUtils.isNotEmpty(request.getSupplierIdList()), FinancePaymentSlip::getSupplierId, request.getSupplierIdList())
                .eq(StringUtils.isNotEmpty(request.getSerialNo()), FinancePaymentSlip::getSerialNo, request.getSerialNo())
                .in(StringUtils.isNotEmpty(request.getPurchaseIdList()), FinancePaymentSlip::getPurchaseId, request.getPurchaseIdList())
                .eq(null != request.getState(), FinancePaymentSlip::getState, request.getState())
                .eq(null != request.getVerifyState(), FinancePaymentSlip::getVerifyState, request.getVerifyState())
                .eq(StringUtils.isNotEmpty(request.getCreatedBy()), FinancePaymentSlip::getCreatedBy, request.getCreatedBy())
                .between(null != request.getStartTime() && null != request.getEndTime(), FinancePaymentSlip::getCreatedTime, request.getStartTime(), request.getEndTime())
                .eq(null != request.getPurchaseSerialNo(), FinancePaymentSlip::getPurchaseSerialNo, request.getPurchaseSerialNo())
                .orderByDesc(FinancePaymentSlip::getCreatedTime);

        Page<FinancePaymentSlip> page = new Page<>(request.getPage(), request.getLimit());
        baseMapper.selectPage(page, wq);
        return page;
    }

    @Override
    public FinancePaymentSlip findByIdOrSerial(Integer id, String serialNo) {
        LambdaQueryWrapper<FinancePaymentSlip> wq = Wrappers.<FinancePaymentSlip>lambdaQuery()
                .eq(StringUtils.isNotEmpty(serialNo), FinancePaymentSlip::getSerialNo, serialNo)
                .eq(null != id, FinancePaymentSlip::getId, id);

        return getOne(wq);
    }

    @Override
    public Boolean submitWithState(FinancePaymentSlip paymentSlip) {
        UpdateByIdCheckState.update(baseMapper, paymentSlip);
        return true;
    }
}
