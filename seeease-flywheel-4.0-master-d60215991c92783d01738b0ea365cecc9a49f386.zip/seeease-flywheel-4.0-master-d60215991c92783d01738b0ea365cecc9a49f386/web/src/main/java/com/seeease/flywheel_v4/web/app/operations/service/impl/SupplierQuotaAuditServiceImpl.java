package com.seeease.flywheel_v4.web.app.operations.service.impl;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.seeease.flywheel_v4.web.app.operations.request.SupplierQuotaAuditDetailRequest;
import com.seeease.flywheel_v4.web.app.operations.request.SupplierQuotaAuditPageRequest;
import com.seeease.flywheel_v4.web.app.operations.request.SupplierQuotaAuditRequest;
import com.seeease.flywheel_v4.web.app.operations.request.SupplierQuotaTopUpRequest;
import com.seeease.flywheel_v4.web.app.operations.result.SupplierQuotaAuditDetailResult;
import com.seeease.flywheel_v4.web.app.operations.result.SupplierQuotaAuditPageResult;
import com.seeease.flywheel_v4.web.app.operations.service.SupplierQuotaAuditService;
import com.seeease.flywheel_v4.web.domain.operations.mapping.SupplierQuotaAuditMapping;
import com.seeease.flywheel_v4.web.infrastructure.dao.RepositoryFactory;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.*;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.enums.SupplierQuotaAuditStateEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.enums.SupplierQuotaLogTypeEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.entity.SysBusinessUnit;
import com.seeease.springframework.PageResult;
import com.seeease.springframework.context.UserContext;
import com.seeease.springframework.exception.ValidationUtil;
import com.seeease.springframework.utils.MultiUtils;
import com.seeease.springframework.utils.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.*;

/**
 * <p>供应商</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/4/24 4:43 下午
 **/
@Service
public class SupplierQuotaAuditServiceImpl implements SupplierQuotaAuditService {
    @Resource
    private RepositoryFactory repositoryFactory;

    @Override
    public Boolean create(SupplierQuotaTopUpRequest request) {

        Integer buId = UserContext.getUser().getStore().getId();
        SupplierQuotaAudit audit = SupplierQuotaAuditMapping.INSTANCE.toEntity(request, buId);
        return repositoryFactory.getSupplierQuotaAuditRepository().submit(audit);
    }

    @Transactional
    @Override
    public Boolean audit(SupplierQuotaAuditRequest request) {
        SupplierQuotaAudit audit = repositoryFactory.getSupplierQuotaAuditRepository().finById(request.getId());
        ValidationUtil.notNull(audit, "id错误");

        SupplierQuotaAuditMapping.INSTANCE.update(audit, request);
        audit.setPzImages(request.getImages());


        if (Objects.equals(request.getState(), SupplierQuotaAuditStateEnums.FAIL.getValue()) ||
                Objects.equals(request.getState(), SupplierQuotaAuditStateEnums.PASS.getValue())) {
            audit.setAuditTime(new Date());

            if (Objects.equals(request.getState(), SupplierQuotaAuditStateEnums.PASS.getValue())) {
                //step_1 查询是否存在余额记录 并且更新
                SupplierQuota supplierQuota = repositoryFactory.getSupplierQuotaRepository()
                        .findBySupplierId(audit.getSupplierId());

                if (null == supplierQuota) {
                    supplierQuota = new SupplierQuota();
                    supplierQuota.setSupplierId(audit.getSupplierId());
                    supplierQuota.setJsQuota(BigDecimal.ZERO);
                    supplierQuota.setNormalQuota(BigDecimal.ZERO);
                }

                switch (audit.getType()) {
                    case NORMAL:
                        supplierQuota.setNormalQuota(supplierQuota.getNormalQuota().add(audit.getAmount()));
                        break;
                    case JS:
                        supplierQuota.setJsQuota(supplierQuota.getJsQuota().add(audit.getAmount()));
                        break;
                }
                repositoryFactory.getSupplierQuotaRepository().submit(supplierQuota);

                //step_2 详情数据更新
                SupplierQuotaDetail detail = repositoryFactory.getSupplierQuotaDetailRepository().findOne(
                        supplierQuota.getId(),
                        audit.getCreatedId(),
                        audit.getType()
                );
                if (null != detail) {
                    detail.setAmount(detail.getAmount().add(audit.getAmount()));
                    detail.setAmountType(audit.getType());
                } else {
                    detail = new SupplierQuotaDetail();
                    detail.setQuotaId(supplierQuota.getId());
                    detail.setAmount(audit.getAmount());
                    detail.setUserid(audit.getCreatedId());
                    detail.setUserName(audit.getCreatedBy());
                    detail.setAmountType(audit.getType());
                }
                repositoryFactory.getSupplierQuotaDetailRepository().submit(detail);

                //step_3 新增日志
                SupplierQuotaLog log = new SupplierQuotaLog();
                log.setQuotaId(supplierQuota.getId());
                log.setAmount(audit.getAmount());
                log.setAmountType(audit.getType());
                log.setType(SupplierQuotaLogTypeEnums.TOP_UP);
                repositoryFactory.getSupplierQuotaLogRepository().submit(log);

            }
        }
        return repositoryFactory.getSupplierQuotaAuditRepository().submit(audit);
    }

    @Override
    public PageResult<SupplierQuotaAuditPageResult> page(SupplierQuotaAuditPageRequest request) {
        //供应商查询
        Set<Integer> supplierIds = null;
        if (StringUtils.isNotEmpty(request.getSupplierName())) {
            List<Supplier> suppliers = repositoryFactory.getSupplierRepository().listByName(request.getSupplierName());
            if (StringUtils.isEmpty(suppliers)) {
                return PageResult.buildEmpty();
            }
            supplierIds = MultiUtils.toSet(suppliers, Supplier::getId);
        }

        //主表查询
        Page<SupplierQuotaAudit> page = repositoryFactory.getSupplierQuotaAuditRepository().page(
                request,
                supplierIds
        );
        if (StringUtils.isEmpty(page.getRecords())) {
            return PageResult.buildEmpty();
        }

        //供应商
        if (null == supplierIds) {
            supplierIds = MultiUtils.toSet(page.getRecords(), SupplierQuotaAudit::getSupplierId);
        }
        Map<Integer, String> supplerNameMap = MultiUtils.toMap(
                repositoryFactory.getSupplierRepository().listByIds(supplierIds),
                Supplier::getId,
                Supplier::getName
        );


        //主体查询
        Set<Integer> subjectIds = MultiUtils.toSet(page.getRecords(), SupplierQuotaAudit::getPurchaseSubjectId);
        Map<Integer, String> subjectMap = MultiUtils.toMap(
                repositoryFactory.getBusinessUnitRepository().listByIds(subjectIds),
                SysBusinessUnit::getId,
                SysBusinessUnit::getName
        );


        //来源
        Set<Integer> buIds = MultiUtils.toSet(page.getRecords(), SupplierQuotaAudit::getBuId);
        Map<Integer, String> originMap = MultiUtils.toMap(
                repositoryFactory.getBusinessUnitRepository().listByIds(buIds),
                SysBusinessUnit::getId,
                SysBusinessUnit::getName
        );


        //组合
        List<SupplierQuotaAuditPageResult> ret = MultiUtils.toList(
                page.getRecords(),
                log -> {
                    String supplierName = supplerNameMap.get(log.getSupplierId());
                    String purchaseSubjectName = subjectMap.get(log.getPurchaseSubjectId());
                    String originName = originMap.get(log.getBuId());
                    return SupplierQuotaAuditMapping.INSTANCE.toPageResult(
                            log,
                            supplierName,
                            purchaseSubjectName,
                            originName
                    );
                }
        );

        return PageResult.<SupplierQuotaAuditPageResult>builder()
                .result(ret)
                .totalCount(page.getTotal())
                .totalPage(page.getPages())
                .build();
    }

    @Override
    public SupplierQuotaAuditDetailResult detail(SupplierQuotaAuditDetailRequest request) {
        SupplierQuotaAudit audit = repositoryFactory.getSupplierQuotaAuditRepository().finById(request.getId());
        ValidationUtil.notNull(audit, "id错误");

        //供应商
        Supplier supplier = repositoryFactory.getSupplierRepository().findById(audit.getSupplierId());

        //来源
        SysBusinessUnit origin = repositoryFactory.getBusinessUnitRepository().findById(audit.getBuId());
        //主体
        SysBusinessUnit subject = repositoryFactory.getBusinessUnitRepository().findById(audit.getPurchaseSubjectId());

        return SupplierQuotaAuditMapping.INSTANCE.toDetailResult(
                audit,
                supplier,
                origin,
                subject
        );
    }
}
