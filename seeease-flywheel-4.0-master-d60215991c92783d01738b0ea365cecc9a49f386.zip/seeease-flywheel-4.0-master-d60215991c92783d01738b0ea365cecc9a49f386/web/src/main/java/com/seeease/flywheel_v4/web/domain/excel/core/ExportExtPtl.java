package com.seeease.flywheel_v4.web.domain.excel.core;


import com.alibaba.cola.extension.ExtensionPointI;
import com.alibaba.excel.EasyExcel;
import com.alibaba.fastjson.JSONObject;
import com.seeease.springframework.exception.e.ArgumentException;
import com.seeease.springframework.utils.DateUtils;
import lombok.SneakyThrows;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Date;
import java.util.List;

/**
 * @author Tiro
 * @date 2023/3/30
 */
public interface ExportExtPtl<T, R> extends ExtensionPointI {
    /**
     * 获取入参class
     */
    Class<T> getRequestClass();

    /**
     * 获取返回值class
     */
    Class<R> getResultClass();

    /**
     * 获取excel文件名称
     */
    String getFileName();

    /**
     * 导出逻辑处理
     */
    List<R> handle(T t);

    /**
     * 参数转换
     *
     * @param cmd
     */
    default T convert(ExportCmd<T> cmd) {
        return JSONObject.parseObject(JSONObject.toJSONString(cmd.getRequest()), getRequestClass());
    }

    /**
     * 写入excel
     */
    @SneakyThrows
    default void write(List<R> result, HttpServletResponse response)  {


        // 设置字符编码
        response.setCharacterEncoding("utf-8");

        response.setHeader("Pragma", "public");
        response.setContentType("application/vnd.ms-excel");
        String postfix = DateUtils.toDateString(DateUtils.YMD2, new Date());
        String fileName = URLEncoder.encode( getFileName() + postfix + ".xlsx", "UTF-8");
        response.setHeader("Content-Disposition", "attachment;filename=" + fileName );
        try {
            EasyExcel.write(response.getOutputStream(), getResultClass())
                    .sheet("导出列表")
                    .doWrite(result);
        } catch (IOException e) {
            throw new ArgumentException("导出异常");
        }
    }
}