package com.seeease.flywheel_v4.web.app.purchase.request;


import lombok.Data;


@Data
public class PurchaseAftersaleCancelRequest {

    /**
     * 行id
     */
    private Integer lineId;

    /**
     * id
     */
    private Integer id;



}
