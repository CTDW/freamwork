package com.seeease.flywheel_v4.web.infrastructure.dao.purchase.repo;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.seeease.flywheel_v4.web.app.purchase.request.PurchaseOrderLinePageRequest;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.entity.PurchaseOrderLine;
import com.seeease.goods.rpc.enums.SkuNodeStateEnums;
import com.seeease.seeeaseframework.mybatis.domain.WhetherEnum;

import java.util.List;
import java.util.Set;

/**
 *
 * @author 西门 游
 * @version 1.0
 * @since 5/31/24 4:55 下午
 **/
public interface PurchaseOrderLineRepository {
    /**
     * 批量提交
     * @param lineList
     * @return 提交结果
     */
    void submitBatch(List<PurchaseOrderLine> lineList);


    /**
     * 列表查询
     * @param purchaseId 采购id
     * @return
     */
    List<PurchaseOrderLine> listByPurchaseId(Integer purchaseId);

    /**
     * 列表查询
     * @param skuIdList
     * @return
     */
    List<PurchaseOrderLine> listByIds(Set<Integer> skuIdList);

    /**
     * 列表查询
     * @param nodeState
     * @return
     */
    List<PurchaseOrderLine> listByNodeState(Integer nodeState);


    /**
     * 查询
     * @param purchaseId 采购单id
     * @param skuIdList  skuId列表
     * @return
     */
    List<PurchaseOrderLine> findByPurchaseIdAndSkuIds(Integer purchaseId,
                                                      Set<Integer> skuIdList);

    /**
     * 查找
     * @param id 主键id
     * @return
     */
    PurchaseOrderLine finById(Integer id);

    /**
     * 提交
     * @param line
     * @return
     */
    Boolean submit(PurchaseOrderLine line);

    /**
     * 查询
     * @param purchaseId 采购单Id
     * @param skuId    skuId
     * @return
     */
    PurchaseOrderLine findByPurchaseIdAndSkuId(Integer purchaseId, Integer skuId);

    /**
     * 分页查询
     * @param skuIdList  skuid列表
     * @param orderIdList 采购单id列表
     * @param request
     * @return
     */
    Page<PurchaseOrderLine> page(Set<Integer> skuIdList,
                                 Set<Integer> orderIdList,
                                 PurchaseOrderLinePageRequest request);

    /**
     * 查找
     * @param purchaseIdList
     * @return
     */
    List<PurchaseOrderLine> listByPurchaseIds(Set<Integer> purchaseIdList);

    /**
     * 查找
     * @param idList
     * @return
     */
    List<PurchaseOrderLine> findByIdList(Set<Integer> idList);

    /**
     * 查询
     * @param purchaseId
     * @param skuIdList
     * @return
     */
    List<PurchaseOrderLine> listByPurchaseIdAndSkuIds(Integer purchaseId, Set<Integer> skuIdList);

    /**
     * 查找
     * @param skuIdList
     * @return
     */
    List<PurchaseOrderLine> listBySkuIds(Set<Integer> skuIdList);

    /**
     * 更新
     * @param purchaseId
     * @param nodeState
     */
    void updateStateByMainId(Integer purchaseId, SkuNodeStateEnums nodeState);

    /**
     * 更新
     * @param lineIds
     * @param nodeState
     * @param endState
     */
    void updateStateByIds(Set<Integer> lineIds, SkuNodeStateEnums nodeState, WhetherEnum endState);





}
