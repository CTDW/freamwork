package com.seeease.flywheel_v4.web.app.purchase.request;


import lombok.Data;



@Data
public class PurchaseAftersaleDetailRequest   {

    /**
     * 单据号
     */
    private String serialNo;

    /**
     * id
     */
    private Integer id;



}
