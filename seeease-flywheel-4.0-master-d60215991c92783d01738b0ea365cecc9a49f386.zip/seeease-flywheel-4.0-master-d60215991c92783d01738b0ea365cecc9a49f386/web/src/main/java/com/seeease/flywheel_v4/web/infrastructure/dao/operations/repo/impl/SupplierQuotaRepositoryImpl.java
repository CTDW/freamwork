package com.seeease.flywheel_v4.web.infrastructure.dao.operations.repo.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.seeease.flywheel_v4.web.app.operations.request.SupplierQuotaPageRequest;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.SupplierQuota;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.mapper.SupplierQuotaMapper;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.repo.SupplierQuotaRepository;
import com.seeease.springframework.utils.StringUtils;
import org.springframework.stereotype.Repository;

import java.util.Set;

/**
 * @author 西门 游
 * @version 1.0
 * @since 5/31/24 4:55 下午
 **/
@Repository
public class SupplierQuotaRepositoryImpl extends ServiceImpl<SupplierQuotaMapper, SupplierQuota>
        implements SupplierQuotaRepository {


    @Override
    public Boolean submit(SupplierQuota supplierQuota) {
        return saveOrUpdate(supplierQuota);
    }

    @Override
    public SupplierQuota findBySupplierId(Integer supplierId) {
        LambdaQueryWrapper<SupplierQuota> wq = Wrappers.<SupplierQuota>lambdaQuery()
                .eq(SupplierQuota::getSupplierId, supplierId);
        return baseMapper.selectOne(wq);
    }

    @Override
    public Page<SupplierQuota> page(Set<Integer> supplierIds, SupplierQuotaPageRequest request) {
        LambdaQueryWrapper<SupplierQuota> wq = Wrappers.<SupplierQuota>lambdaQuery()
                .in(StringUtils.isNotEmpty(supplierIds),SupplierQuota::getSupplierId, supplierIds);

        Page<SupplierQuota> page = Page.of(request.getPage(), request.getLimit());
        baseMapper.selectPage(page,wq);
        return page;
    }

    @Override
    public SupplierQuota findById(Integer id) {
        return getById(id);
    }
}
