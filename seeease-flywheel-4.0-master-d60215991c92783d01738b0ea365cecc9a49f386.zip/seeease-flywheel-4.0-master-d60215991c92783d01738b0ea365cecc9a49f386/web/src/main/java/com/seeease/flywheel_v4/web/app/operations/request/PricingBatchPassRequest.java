package com.seeease.flywheel_v4.web.app.operations.request;

import com.seeease.springframework.PageRequest;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.validation.constraints.NotNull;
import java.util.Set;


@EqualsAndHashCode(callSuper = true)
@Data
public class PricingBatchPassRequest extends PageRequest {

    /**
     * 定价管理ids
     */
    @NotNull(message = "ids不能为空")
    private Set<Integer> ids;

}
