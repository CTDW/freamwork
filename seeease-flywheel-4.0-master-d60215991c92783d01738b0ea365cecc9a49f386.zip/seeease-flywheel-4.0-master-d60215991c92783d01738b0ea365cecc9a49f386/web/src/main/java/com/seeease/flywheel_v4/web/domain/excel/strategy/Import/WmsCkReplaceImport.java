//package com.seeease.flywheel_v4.web.domain.excel.strategy.Import;
//
//import com.alibaba.cola.extension.Extension;
//import com.seeease.flywheel_v4.web.app.excel.request.WmsCkReplaceImportRequest;
//import com.seeease.flywheel_v4.web.domain.excel.core.ImportExtPtl;
//import com.seeease.flywheel_v4.web.infrastructure.dao.RepositoryFactory;
//import com.seeease.flywheel_v4.web.infrastructure.dao.sale.entity.SaleOrder;
//import com.seeease.flywheel_v4.web.infrastructure.dao.sale.entity.SaleOrderLine;
//import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.WmsCk;
//import com.seeease.goods.rpc.SkuFacade;
//import com.seeease.goods.rpc.enums.SkuNodeStateEnums;
//import com.seeease.goods.rpc.request.SkuCkReplaceRpcRequest;
//import com.seeease.goods.rpc.request.SkuRpcRequest;
//import com.seeease.goods.rpc.result.SkuCkReplaceRpcResult;
//import com.seeease.goods.rpc.result.SkuRpcResult;
//import com.seeease.springframework.exception.ValidationUtil;
//import com.seeease.springframework.utils.MultiUtils;
//import org.apache.dubbo.config.annotation.DubboReference;
//import org.springframework.stereotype.Service;
//
//import javax.annotation.Resource;
//import java.util.ArrayList;
//import java.util.Collections;
//import java.util.List;
//import java.util.Map;
//import java.util.stream.Collectors;
//
///**
// * @author 西门 游
// * @version 1.0
// * @since 9/11/24 1:39 下午
// **/
//@Service
//@Extension(bizId = "import", useCase = "wmsCkReplace")
//public class WmsCkReplaceImport implements ImportExtPtl<WmsCkReplaceImportRequest, Void> {
//
//    @DubboReference(check = false,version = "1.0.0")
//    private SkuFacade skuFacade;
//    @Resource
//    private RepositoryFactory repositoryFactory;
//
//    @Override
//    public Class<WmsCkReplaceImportRequest> getRequestClass() {
//        return WmsCkReplaceImportRequest.class;
//    }
//
//    @Override
//    public void validate(List<WmsCkReplaceImportRequest> data) {
//    }
//
//    @Override
//    public List<Void> handle(List<WmsCkReplaceImportRequest> items) {
//
//        Map<String, List<WmsCkReplaceImportRequest>> group = items.stream()
//                .collect(Collectors.groupingBy(WmsCkReplaceImportRequest::getSerialNo));
//
//
//        for (Map.Entry<String, List<WmsCkReplaceImportRequest>> entry : group.entrySet()) {
//            List<String> newSkuCodes = entry.getValue()
//                    .stream()
//                    .map(WmsCkReplaceImportRequest::getSkuCode).collect(Collectors.toList());
//            List<WmsCk> cks = repositoryFactory.getWmsCkRepository()
//                    .listBySerialNo(entry.getKey())
//                    .stream()
//                    .filter(ck -> ck.getNodeState() == SkuNodeStateEnums.DD)
//                    .collect(Collectors.toList());
//
//            ValidationUtil.isTrue(
//                    newSkuCodes.size() <= cks.size(),
//                    "订单号:" + entry.getKey() + "需要替换的唯一码超出当前待出库数量"
//            );
//
//            ArrayList<SkuCkReplaceRpcRequest> rpcRequest = new ArrayList<>();
//            for (int i = 0; i < newSkuCodes.size(); i++) {
//                WmsCk ck = cks.get(i);
//                SkuRpcRequest skuRpcRequest = new SkuRpcRequest();
//                skuRpcRequest.setIdList(Collections.singleton(ck.getSkuId()));
//                SkuRpcResult sku = skuFacade.list(skuRpcRequest).get(0);
//
//
//
//                SkuCkReplaceRpcRequest item = new SkuCkReplaceRpcRequest();
//                item.setNewGoodsCode(newSkuCodes.get(i));
//                item.setOldGoodsCode(sku.getSkuCode());
//                rpcRequest.add(item);
//            }
//
//            List<SkuCkReplaceRpcResult> replaceRet = skuFacade.ckReplace(rpcRequest);
//
//
//            Map<Integer, Integer> skuIdMap = MultiUtils.toMap(
//                    replaceRet,
//                    SkuCkReplaceRpcResult::getOldId,
//                    SkuCkReplaceRpcResult::getNewId
//            );
//
//            //修改wms出库的skuId
//            cks.forEach(ck -> {
//                Integer newSkuId = skuIdMap.get(ck.getSkuId());
//                ck.setSkuId(newSkuId);
//            });
//            repositoryFactory.getWmsCkRepository().submitBatch(cks);
//
//
//            //修改销售单skuId
//            SaleOrder saleOrder = repositoryFactory.getSaleOrderRepository().findByIdOrSerialNo(null, entry.getKey());
//            List<SaleOrderLine> lineList = repositoryFactory.getSaleOrderLineRepository().listByMainId(saleOrder.getId());
//            lineList.forEach(line -> {
//                Integer newSkuId = skuIdMap.get(line.getSkuId());
//                line.setSkuId(newSkuId);
//            });
//            repositoryFactory.getSaleOrderLineRepository().submitBatch(lineList);
//        }
//
//        return Collections.emptyList();
//    }
//
//
//}
