package com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.seeease.goods.rpc.enums.SkuRunTypeEnums;
import com.seeease.seeeaseframework.mybatis.domain.BaseDomain;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;

/**
 * 调拨额度控制字表
 */
@EqualsAndHashCode(callSuper = true)
@TableName(value = "v4_ops_transfer_quota_line", autoResultMap = true)
@Data
public class TransferQuotaLine extends BaseDomain {
    @TableId(type = IdType.AUTO)
    private Integer id;
    /**
     * 主表id
     */
    private Integer tsqId;
    /**
     * 品牌id
     */
    private Integer brandId;
    /**
     * 类目id
     */
    private Integer categoryId;
    /**
     * 控制的额度
     */
    private BigDecimal quota;

    /**
     * 控制的类型
     */
    private SkuRunTypeEnums type;

}