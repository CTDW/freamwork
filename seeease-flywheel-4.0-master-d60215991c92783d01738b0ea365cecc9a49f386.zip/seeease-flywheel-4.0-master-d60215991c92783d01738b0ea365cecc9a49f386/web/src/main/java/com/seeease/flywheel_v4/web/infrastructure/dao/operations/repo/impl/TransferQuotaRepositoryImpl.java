package com.seeease.flywheel_v4.web.infrastructure.dao.operations.repo.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.seeease.flywheel_v4.web.app.operations.request.TransferQuotaPageRequest;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.TransferQuota;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.mapper.TransferQuotaMapper;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.repo.TransferQuotaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author 西门 游
 * @version 1.0
 * @since 5/31/24 4:55 下午
 **/
@Repository
public class TransferQuotaRepositoryImpl extends ServiceImpl<TransferQuotaMapper, TransferQuota>
        implements TransferQuotaRepository {


    @Override
    public List<TransferQuota> listByMerchantId(Integer merchantId) {
        LambdaQueryWrapper<TransferQuota> wq = Wrappers.<TransferQuota>lambdaQuery()
                .eq(TransferQuota::getMerchantId, merchantId);
        return baseMapper.selectList(wq);
    }

    @Override
    public Boolean submit(TransferQuota transferQuota) {
        return saveOrUpdate(transferQuota);
    }

    @Override
    public Page<TransferQuota> page(TransferQuotaPageRequest request) {
        LambdaQueryWrapper<TransferQuota> wq = Wrappers.<TransferQuota>lambdaQuery()
                .eq(null != request.getMerchantId(),TransferQuota::getMerchantId,request.getMerchantId())
                .eq(null != request.getStartDate(),TransferQuota::getStartDate,request.getStartDate())
                .eq(null != request.getEndDate(),TransferQuota::getEndDate,request.getEndDate())
                .orderByDesc(TransferQuota::getCreatedTime);

        Page<TransferQuota> page = Page.of(request.getPage(), request.getLimit());
        baseMapper.selectPage(page,wq);
        return page;
    }

    @Override
    public Boolean delById(Integer id) {
        return removeById(id);
    }
}
