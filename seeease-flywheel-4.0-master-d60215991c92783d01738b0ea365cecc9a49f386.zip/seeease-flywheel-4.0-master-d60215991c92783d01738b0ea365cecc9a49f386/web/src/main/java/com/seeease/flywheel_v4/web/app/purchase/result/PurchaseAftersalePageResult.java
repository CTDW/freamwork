package com.seeease.flywheel_v4.web.app.purchase.result;

import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/4/24 6:00 下午
 **/
@Data
public class PurchaseAftersalePageResult {
    /**
     * id
     */
    private Integer id;
    /**
     * 编号
     */
    private String serialNo;
    /**
     * 关联单号
     */
    private String originSerialNo;
    /**
     * 类型
     */
    private Integer type;
    /**
     * 状态
     */
    private Integer state;
    /**
     * 金额
     */
    private BigDecimal amount;
    /**
     * 总数量
     */
    private Integer totalCount;
    /**
     * 来源
     */
    private String originName;
    /**
     * 创建人
     */
    private String createdBy;
    /**
     * 创建时间
     */
    private Date createdTime;
}
