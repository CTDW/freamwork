package com.seeease.flywheel_v4.web.app.transfer.request;


import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.util.List;

/**
 * @author 西门 游
 * @version 1.0
 * @since 6/3/24 11:26 上午
 **/
@Data
public class TransferTaskCreateRequest {


    @NotEmpty(message = "sku数据不能为空")
    @Valid
    private List<Sku> skuList;


    @Data
    public static class Sku{
        /**
         * skuId
         */
        @NotNull(message = "skuId不能为空")
        private Integer skuId;
        /**
         * 调入方id
         */
        @NotNull(message = "调入方id不能为为空")
        private Integer toId;
        /**
         * 调拨数量
         */
        @Min(value = 1,message = "数量最小为1")
        @NotNull(message = "数量不能为空")
        private Integer count;
    }

}
