package com.seeease.flywheel_v4.web.app.wms.request;


import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.List;


/**
 * @ Description   :
 * @ Author        :  西门 游
 * @ CreateDate    :  6/6/24
 * @ Version       :  1.0
 */
@Data
public class WmsCkReplaceRequest {


    @NotNull(message = "item 不能为空")
    @Valid
    private List<Item> items;


    @Data
    public static class Item {
        /**
         * 出入库id
         */
        @NotNull(message = "id不能为空")
        private Integer id;
        /**
         * sku编码
         */
        @NotNull(message = "sku编码")
        private String skuCode;
    }
}
