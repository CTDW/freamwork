package com.seeease.flywheel_v4.web.app.sale.request;


import com.fasterxml.jackson.annotation.JsonFormat;
import com.seeease.springframework.PageRequest;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Date;


@EqualsAndHashCode(callSuper = true)
@Data
public class ToBSaleOrderPageRequest extends PageRequest {

    /**
     * 销售单号
     */
    private String serialNo;
    /**
     * 主单号
     */
    private String mainSerialNo;
    /**
     * 三方单号
     */
    private String thirdPartyNo;
    /**
     * 唯一码
     */
    private String skuCode;
    /**
     * 客户名称
     */
    private String buyerName;
    /**
     * 商品所在
     */
    private Integer belongId;
    /**
     * 销售渠道
     */
    private Integer scType;
    /**
     * 销售方式
     */
    private Integer sellType;
    /**
     * 快递单号
     */
    private String expressNo;
    /**
     * 订单状态
     */
    private Integer state;
    /**
     * 来源id
     */
    private Integer originId;
    /**
     * 开始时间
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date startTime;
    /**
     * 结束时间
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date endTime;
    /**
     * 完成时间开始
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date finishStartTime;
    /**
     * 完成时间结束
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date finishEndTime;
    /**
     * 当前用户部门id 权限控制
     */
    private Integer buId;
}
