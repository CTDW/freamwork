package com.seeease.flywheel_v4.web.infrastructure.dao.sale.repo;


import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.seeease.flywheel_v4.web.app.sale.request.ToBSaleReturnOrderPageRequest;
import com.seeease.flywheel_v4.web.app.sale.request.ToCSaleReturnOrderPageRequest;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.entity.SaleReturnOrder;

import java.util.Set;

/**
 *
 * @author 西门 游
 * @version 1.0
 * @since 5/31/24 4:55 下午
 **/
public interface SaleReturnOrderRepository {

    /**
     * 提交
     * @param order
     */
    Boolean submit(SaleReturnOrder order);

    /**
     * 查找
     * @param id
     * @param serialNo
     * @return
     */
    SaleReturnOrder findByIdOrSerialNo(Integer id, String serialNo);

    /**
     * 查找
     * @param request
     * @param returnIdList
     * @return
     */
    Page<SaleReturnOrder> pageForC(ToCSaleReturnOrderPageRequest request,
                               Set<Integer> returnIdList);


    /**
     * 查询
     * @param thirdReturnId
     * @return
     */
    SaleReturnOrder findByThirdReturnId(String thirdReturnId);

    /**
     * 查找
     * @param request
     * @param returnIdList
     * @return
     */
    Page<SaleReturnOrder> pageForB(ToBSaleReturnOrderPageRequest request, Set<Integer> returnIdList);


}
