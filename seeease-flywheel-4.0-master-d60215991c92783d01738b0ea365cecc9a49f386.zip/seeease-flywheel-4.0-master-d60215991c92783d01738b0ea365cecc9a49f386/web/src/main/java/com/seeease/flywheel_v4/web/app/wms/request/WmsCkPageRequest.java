package com.seeease.flywheel_v4.web.app.wms.request;


import com.fasterxml.jackson.annotation.JsonFormat;
import com.seeease.springframework.PageRequest;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Date;
import java.util.Set;

/**
 * @ Description   :
 * @ Author        :  西门 游
 * @ CreateDate    :  6/6/24
 * @ Version       :  1.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class WmsCkPageRequest extends PageRequest {

    /**
     * ids
     */
    private Set<Integer> ids;
    /**
     * 业务单号
     */
    private String serialNo;
    /**
     * 业务类型
     */
    private Integer type;
    /**
     * 商品名称
     */
    private String goodsName;

    /**
     * 快递单号
     */
    private String expressNo;

    /**
     * 品牌id
     */
    private Integer brandId;
    /**
     * 类目id
     */
    private Integer categoryId;
    /**
     * 蜥蜴编码
     */
    private String xyCode;
    /**
     * 订单来源
     */
    private Integer originId;
    /**
     * 销售渠道
     */
    private Integer scType;
    /**
     * sku编码
     */
    private String skuCode;
    /**
     * 开始时间
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date startTime;
    /**
     * 结束时间
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date endTime;
    /**
     * 节点状态
     */
    private Integer nodeState;
    /**
     * 当前用户业务单元id
     */
    private Integer buId;
}
