package com.seeease.flywheel_v4.web.app.fix.result;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.seeease.flywheel_v4.web.infrastructure.dao.fix.entity.FixOrder;
import io.swagger.annotations.ApiModelProperty;
import lombok.Builder;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @Description 维修中心-维修单 返回值
 * @Date 2024-10-2 20:20
 * @Author by hk
 */
@Data
@Builder
public class FixOrderPageResult implements Serializable {

    @ApiModelProperty(value = "id")
    private Long id;

    @ApiModelProperty(value = "维修单号")
    private String orderNumber;

    @ApiModelProperty(value = "唯一码")
    private String goodsUnique;

    @ApiModelProperty(value = "维修优先级，1：一级 2：")
    private Integer priorityType;

    @ApiModelProperty(value = "品牌")
    private String brand;

    @ApiModelProperty(value = "订单来源")
    private Integer orderSource;

    @ApiModelProperty(value = "订单来源str")
    private String orderSourceStr;

    @ApiModelProperty(value = "订单类型，1：内部 2：外部")
    private Integer orderType;

    @ApiModelProperty(value = "维修单状态 1：维修登记 2：待接修 3：维修中 4：抛光中 5：清洗中 6：师傅组装 7：质检中 " +
            "8：待维修出库 9：送外维修 10：等配件 11：已完成 12:已取消")
    private Integer orderStatus;

    @ApiModelProperty(value = "快递单")
    private String expressNumber;

    @ApiModelProperty(value = "是否加急")
    private Boolean urgent;

    @ApiModelProperty(value = "分数 1-5分")
    private String score;

    @ApiModelProperty(value = "维修师")
    private String fixMaster;

    @ApiModelProperty(value = "创建人")
    private String createdBy;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    @ApiModelProperty(value = "创建时间")
    private Date createdTime;


    public static FixOrderPageResult fromEntity(FixOrder fixOrder) {
        return FixOrderPageResult.builder()

                .id(fixOrder.getId())
                .orderNumber(fixOrder.getOrderNumber())

                .goodsUnique(fixOrder.getGoodsUnique())
                .priorityType(fixOrder.getPriorityType())
                .brand(fixOrder.getBrand())
                .orderSource(fixOrder.getOrderSource())
                .orderSourceStr(fixOrder.getOrderSourceStr())
                .orderType(fixOrder.getOrderType())
                .orderStatus(fixOrder.getOrderStatus())
                .expressNumber(fixOrder.getExpressNumber())

                .urgent(fixOrder.getUrgent())

                .fixMaster(fixOrder.getFixMaster())
                .score(fixOrder.getFixMasterScore())

                .createdBy(fixOrder.getCreatedBy())
                .createdTime(fixOrder.getCreatedTime())
                .build();
    }
}
