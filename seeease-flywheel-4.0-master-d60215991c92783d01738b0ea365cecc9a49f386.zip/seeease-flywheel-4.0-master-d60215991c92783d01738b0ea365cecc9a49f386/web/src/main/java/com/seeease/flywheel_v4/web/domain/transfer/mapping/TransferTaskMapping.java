package com.seeease.flywheel_v4.web.domain.transfer.mapping;


import com.seeease.flywheel_v4.client.enums.BusinessUnitTypeEnums;
import com.seeease.flywheel_v4.web.app.transfer.request.TransferTaskCreateRequest;
import com.seeease.flywheel_v4.web.app.transfer.request.TransferTaskPageRequest;
import com.seeease.flywheel_v4.web.app.transfer.result.TransferTaskPageResult;
import com.seeease.flywheel_v4.web.infrastructure.config.EnumMapping;
import com.seeease.flywheel_v4.web.infrastructure.dao.transfer.entity.TransferTask;
import com.seeease.goods.rpc.request.SkuRpcRequest;
import com.seeease.goods.rpc.result.SkuRpcResult;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;


/**
 * <p>
 * 商品附件
 * </p>
 *
 * @author 西门 游
 * @since 2023-10-27
 */
@Mapper(componentModel = "spring",
        builder = @Builder(disableBuilder = true),
        nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS,
        nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE,
        imports = {BusinessUnitTypeEnums.class})
public interface TransferTaskMapping extends EnumMapping {

    TransferTaskMapping INSTANCE = Mappers.getMapper(TransferTaskMapping.class);


    TransferTask toEntity(TransferTaskCreateRequest.Sku sku,Integer fromId);

    SkuRpcRequest toSkuRpcRequest(TransferTaskPageRequest request);

    @Mapping(target = "id",source = "transferTask.id")
    TransferTaskPageResult toPageResult(TransferTask transferTask,
                                        SkuRpcResult sku,
                                        String belongName,
                                        String toName);
}
