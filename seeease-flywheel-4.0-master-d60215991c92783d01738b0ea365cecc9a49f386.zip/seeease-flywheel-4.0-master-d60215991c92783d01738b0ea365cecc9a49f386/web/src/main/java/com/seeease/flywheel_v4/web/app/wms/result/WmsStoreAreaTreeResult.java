package com.seeease.flywheel_v4.web.app.wms.result;

import lombok.Data;

import java.util.List;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/4/24 6:00 下午
 **/
@Data
public class WmsStoreAreaTreeResult {
    /**
     * 仓库Id
     */
    private Integer storeId;
    /**
     * 库区id
     */
    private Integer id;
    /**
     * 父级库区id
     */
    private Integer pid;
    /**
     * 名称
     */
    private String name;
    /**
     * 级别
     */
    private Integer level;
    /**
     * 子节点
     */
    private List<WmsStoreAreaTreeResult> child;

}
