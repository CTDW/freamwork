package com.seeease.flywheel_v4.web.infrastructure.dao.fix.repo.impl;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.seeease.flywheel_v4.web.app.fix.request.*;
import com.seeease.flywheel_v4.web.app.fix.result.FixStatusCountResult;
import com.seeease.flywheel_v4.web.infrastructure.dao.fix.entity.FixOrder;
import com.seeease.flywheel_v4.web.infrastructure.dao.fix.enums.FixOrderStatusEnum;
import com.seeease.flywheel_v4.web.infrastructure.dao.fix.mapper.FixOrderMapper;
import com.seeease.flywheel_v4.web.infrastructure.dao.fix.repo.FixOrderRepository;
import com.seeease.flywheel_v4.web.util.SerialNoGenerator;
import com.seeease.springframework.utils.StringUtils;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;


/**
 * @Description 维修单
 * @Date 2024-10-2 21:05
 * @Author by hk
 */
@Repository
public class FixOrderRepositoryImpl extends ServiceImpl<FixOrderMapper, FixOrder>
        implements FixOrderRepository {

    private static final String COMMA = ",";

    @Override
    public Page<FixOrder> page(FixOrderPageRequest request) {
        LambdaQueryWrapper<FixOrder> wq = Wrappers.<FixOrder>lambdaQuery()
                // 唯一码
                .like(StringUtils.isNotEmpty(request.getGoodsUnique()), FixOrder::getGoodsUnique, request.getGoodsUnique())
                // 优先级
                .eq(request.getPriorityType() != null, FixOrder::getPriorityType, request.getPriorityType())
                // 来源
                .eq(request.getOrderSource() != null, FixOrder::getOrderSource, request.getOrderSource())
                // 维修师
                .like(StringUtils.isNotEmpty(request.getFixMaster()), FixOrder::getFixMaster, request.getFixMaster())
                // 类型
                .eq(request.getOrderType() != null, FixOrder::getOrderType, request.getOrderType())
                // 创建人
                .eq(StringUtils.isNotEmpty(request.getCreatedBy()), FixOrder::getCreatedBy, request.getCreatedBy())
                // 创建时间
                .le(request.getStartTime() != null, FixOrder::getCreatedTime, request.getStartTime())
                .ge(request.getEndTime() != null, FixOrder::getCreatedTime, request.getEndTime())
                // 状态
                .eq(request.getOrderStatus() != null, FixOrder::getOrderStatus, request.getOrderStatus());

        Page<FixOrder> page = Page.of(request.getPage(), request.getLimit());
        baseMapper.selectPage(page, wq);
        return page;
    }

    /**
     * 维修中心-维修单-查询状态对应数量
     *
     * @param request 请求 * @return 列表结果
     */
    @Override
    public List<FixStatusCountResult> getStatusCount(FixOrderPageRequest request) {
        return baseMapper.getStatusCount(request);
    }

    /**
     * 详情
     *
     * @param id 请求
     * @return 返回
     */
    @Override
    public FixOrder detail(Long id) {
        return getById(id);
    }

    /**
     * 根据维修单号查询
     *
     * @param orderNo 维修单号
     * @return 返回
     */
    @Override
    public FixOrder getByOrderNoOrGoodsUnique(String orderNo) {
        QueryWrapper<FixOrder> queryWrapper = new QueryWrapper<>();
        queryWrapper.lambda().eq(FixOrder::getOrderNumber, orderNo).or()
                .eq(FixOrder::getGoodsUnique, orderNo);
        return getOne(queryWrapper);
    }

    /**
     * 新增
     *
     * @param request 请求
     */
    @Override
    public FixOrder save(FixOrderSaveRequest request) {

        FixOrder fixOrder = FixOrder.toEntity(request);
        // 生成维修单号
        fixOrder.setOrderNumber(SerialNoGenerator.generalSerial(SerialNoGenerator.Type.WX));
        baseMapper.insert(fixOrder);

        return fixOrder;
    }

    /**
     * 编辑
     *
     * @param request 请求
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public Boolean update(FixOrderSaveRequest request) {
        if (request.getId() == null) {
            throw new RuntimeException("维修单id不能为空");
        }

        FixOrder fixOrder = FixOrder.toEntity(request);
        fixOrder.setId(request.getId());
        fixOrder.setUpdatedTime(new Date());
        int update = baseMapper.updateById(fixOrder);

        return update == 1;

    }

    /**
     * 删除
     *
     * @param request 请求
     */
    @Override
    public Boolean delete(FixOrderDetailRequest request) {
        if (request.getId() == null) {
            throw new RuntimeException("维修单id不能为空");
        }
        FixOrder fixOrder = new FixOrder();
        fixOrder.setId(request.getId());
        return removeById(fixOrder);
    }

    /**
     * 分配维修师
     *
     * @param request 请求
     */
    @Override
    public void updateMasterAndOrderStatusToWaitFix(FixOrderDistributeRequest request) {

        FixOrder fixOrder = new FixOrder();
        fixOrder.setId(request.getId());
        fixOrder.setFixMaster(request.getFixMaster());
        fixOrder.setUpdatedTime(new Date());
        fixOrder.setOrderStatus(FixOrderStatusEnum.WAIT_REPAIR.getValue());
        fixOrder.setPreOrderStatus(FixOrderStatusEnum.REGISTER.getValue());
        baseMapper.updateById(fixOrder);

    }

    /**
     * 更新为已取消
     *
     * @param id id
     */
    @Override
    public void updateOrderStatusToCancel(Long id) {
        baseMapper.updateOrderStatusToCancel(id);
    }

    /**
     * 更新为送外维修
     *
     * @param request id
     */
    @Override
    public void updateOrderStatusToSendOut(FixOrderSendOutRequest request, FixOrder fixOrder) {
        String remark = "";
        if (StringUtils.isNotEmpty(fixOrder.getSendOutRemark())) {
            remark = fixOrder.getSendOutRemark();
        }
        remark = remark + COMMA + request.getSendOutRemark();
        if (remark.startsWith(COMMA)) {
            remark = remark.substring(1);
        }
        baseMapper.updateOrderStatusToSendOut(remark, request.getId());
    }

    /**
     * 维修完成
     *
     * @param request 请求
     */
    @Override
    public void complete(FixOrderCompleteRequest request) {

        String masterScores = JSON.toJSONString(request.getMasterScoreList());

        baseMapper.complete(
                request.getSendOutRemark(),
                request.getReturnRemark(),
                request.getReturnExpressNumber(),
                masterScores,
                request.getId());
    }

    /**
     * 回退
     *
     * @param id id
     */
    @Override
    public void updateOrderStatusToPreOrderStatus(Long id,Integer newOrderStatus) {
        baseMapper.updateOrderStatusToPreOrderStatus(id,newOrderStatus);
    }

    /**
     * 跳过
     *
     * @param request 请求
     */
    @Override
    public void updateOrderStatusToAppoint(FixOrderJumpRequest request) {
        baseMapper.updateOrderStatusToAppoint(request.getId(), request.getOrderStatus());
    }

    /**
     * 维修师扫码领用
     *
     * @param request 请求
     */
    @Override
    public void masterUpdateOrderStatusToAppoint(FixOrder fixOrder, FixOrderMasterUseRequest request) {
        String fixMaster = fixOrder.getFixMaster();
        if (!fixMaster.contains(request.getFixMaster())) {
            fixMaster = fixMaster + COMMA + request.getFixMaster();
        }
        baseMapper.masterUpdateOrderStatusToAppoint(fixOrder.getId(), request.getOrderStatus(), fixMaster);
    }

    /**
     * 完成质检
     *
     * @param id id
     */
    @Override
    public void completeQuality(Long id) {
        baseMapper.completeQuality(id);
    }
}
