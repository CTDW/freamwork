package com.seeease.flywheel_v4.web.app.operations.result;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/4/24 6:00 下午
 **/
@Data
public class SupplierQuotaDetailResult {
    /**
     * 政策余额
     */
    private List<Item> normalLogs = new ArrayList<>();
    /**
     * 寄售余额
     */
    private List<Item> consignmentLogs = new ArrayList<>();


    @Data
    public static class Item{
        /**
         * id
         */
        private Integer id;
        /**
         * 充值金额
         */
        private Integer amount;
        /**
         * 充值这条记录的人的名称
         */
        private String name;
    }


}
