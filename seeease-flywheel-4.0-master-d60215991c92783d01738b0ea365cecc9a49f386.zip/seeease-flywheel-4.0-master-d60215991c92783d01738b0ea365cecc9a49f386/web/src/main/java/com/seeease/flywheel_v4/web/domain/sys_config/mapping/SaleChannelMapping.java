package com.seeease.flywheel_v4.web.domain.sys_config.mapping;


import com.seeease.flywheel_v4.web.app.sys_config.request.SaleChannelSubmitRequest;
import com.seeease.flywheel_v4.web.app.sys_config.result.SaleChannelPageResult;
import com.seeease.flywheel_v4.web.infrastructure.config.SimpleMapping;
import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.entity.SysSaleChannel;
import com.seeease.flywheel_v4.client.enums.BusinessUnitTypeEnums;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;

import java.util.Map;


/**
 * <p>
 * 商品附件
 * </p>
 *
 * @author 西门 游
 * @since 2023-10-27
 */
@Mapper(componentModel = "spring",
        builder = @Builder(disableBuilder = true),
        nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS,
        nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE,
        imports = {BusinessUnitTypeEnums.class})
public interface SaleChannelMapping extends SimpleMapping<SaleChannelSubmitRequest, SysSaleChannel> {

    SaleChannelMapping INSTANCE = Mappers.getMapper(SaleChannelMapping.class);


    @Mapping(target = "merchantName",expression = "java(merchantIdMap.get(e.getMerchantId()))")
    SaleChannelPageResult toPageResult(SysSaleChannel e, Map<Integer, String> merchantIdMap);
}
