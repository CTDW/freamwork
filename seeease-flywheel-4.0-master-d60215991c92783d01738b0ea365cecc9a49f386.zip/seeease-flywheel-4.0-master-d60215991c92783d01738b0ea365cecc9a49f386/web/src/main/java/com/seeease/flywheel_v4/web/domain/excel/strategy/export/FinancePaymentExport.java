package com.seeease.flywheel_v4.web.domain.excel.strategy.export;

import com.alibaba.cola.extension.Extension;
import com.seeease.flywheel_v4.web.app.excel.result.FinancePaymentExportResult;
import com.seeease.flywheel_v4.web.app.finance.request.PaymentSlipPageRequest;
import com.seeease.flywheel_v4.web.app.finance.result.PaymentSlipPageResult;
import com.seeease.flywheel_v4.web.app.finance.service.FinancePaymentSlipService;
import com.seeease.flywheel_v4.web.domain.excel.core.ExportExtPtl;
import com.seeease.flywheel_v4.web.domain.finance.mapping.FinancePaymentSlipMapping;
import com.seeease.flywheel_v4.web.infrastructure.dao.RepositoryFactory;
import com.seeease.flywheel_v4.web.infrastructure.dao.finance.enums.PaymentSlipStateEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.finance.enums.PaymentSlipVerifyStateEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.enums.PurchasePayTypeEnums;
import com.seeease.flywheel_v4.client.enums.PurchaseTypeEnums;
import com.seeease.goods.rpc.SkuFacade;
import com.seeease.seeeaseframework.mybatis.utils.EnumUtils;
import com.seeease.springframework.utils.MultiUtils;
import org.apache.dubbo.config.annotation.DubboReference;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.List;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 9/12/24 10:42 上午
 **/
@Service
@Extension(bizId = "export", useCase = "financePayment")
public class FinancePaymentExport implements ExportExtPtl<PaymentSlipPageRequest, FinancePaymentExportResult> {

    @Resource
    private RepositoryFactory repositoryFactory;

    @DubboReference(version = "1.0.0",check = false)
    private SkuFacade skuFacade;

    @Resource
    private FinancePaymentSlipService financePaymentSlipService;


    @Override
    public Class<PaymentSlipPageRequest> getRequestClass() {
        return PaymentSlipPageRequest.class;
    }

    @Override
    public Class<FinancePaymentExportResult> getResultClass() {
        return FinancePaymentExportResult.class;
    }

    @Override
    public String getFileName() {
        return "申请打款单导出";
    }

    @Override
    public List<FinancePaymentExportResult> handle(PaymentSlipPageRequest request) {
        //step_1 调用打款单分页查询
        request.setLimit(Integer.MAX_VALUE);
        List<PaymentSlipPageResult> list = financePaymentSlipService.page(request).getResult();
        if (list.isEmpty()){
            return Collections.emptyList();
        }

        //step_2 数据转换

        return MultiUtils.toList(
                list,
                item ->{
                    String purchaseType = EnumUtils.of(PurchaseTypeEnums.class, item.getPurchaseType()).getDesc();
                    String payType = EnumUtils.of(PurchasePayTypeEnums.class, item.getPayType()).getDesc();
                    String state = EnumUtils.of(PaymentSlipStateEnums.class, item.getState()).getDesc();
                    String verifyState = EnumUtils.of(PaymentSlipVerifyStateEnums.class, item.getVerifyState()).getDesc();

                    return FinancePaymentSlipMapping.INSTANCE.toExportResult(
                            purchaseType,
                            payType,
                            state,
                            verifyState,
                            item
                    );
                }
        );
    }
}
