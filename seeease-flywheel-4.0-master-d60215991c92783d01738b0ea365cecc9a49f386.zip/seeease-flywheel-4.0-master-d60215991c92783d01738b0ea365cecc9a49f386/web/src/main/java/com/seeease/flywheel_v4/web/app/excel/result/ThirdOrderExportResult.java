package com.seeease.flywheel_v4.web.app.excel.result;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.format.DateTimeFormat;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 9/11/24 5:00 下午
 **/
@Data
public class ThirdOrderExportResult implements Serializable {


    @ExcelProperty("三方单号")
    private String thirdPartyNo;

    @ExcelProperty("销售渠道")
    private String scType;

    @ExcelProperty("渠道名称")
    private String scName;

    @ExcelProperty("状态")
    private String state;

    @ExcelProperty("金额")
    private String totalAmount;

    @DateTimeFormat("yyyy-MM-dd HH:mm:ss")
    @ExcelProperty("创建时间")
    private Date createdTime;

    @DateTimeFormat("yyyy-MM-dd HH:mm:ss")
    @ExcelProperty("审核时间")
    private Date auditTime;









}
