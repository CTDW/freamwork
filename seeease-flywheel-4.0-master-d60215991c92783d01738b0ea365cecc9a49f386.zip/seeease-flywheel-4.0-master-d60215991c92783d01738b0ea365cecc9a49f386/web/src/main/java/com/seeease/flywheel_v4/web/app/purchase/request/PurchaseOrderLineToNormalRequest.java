package com.seeease.flywheel_v4.web.app.purchase.request;


import com.seeease.goods.rpc.request.PurchaseSkuCreateRpcRequest;
import lombok.Data;

import javax.validation.constraints.NotEmpty;
import java.util.List;
import java.util.Map;


@Data
public class PurchaseOrderLineToNormalRequest {

    /**
     * 节点状态
     */
    @NotEmpty(message = "采购单行id")
    private Integer lineId;

    /**
     * 唯一码
     */
    private String skuCode;
    /**
     * spuId
     */
    private Integer spuId;

    /**
     * 附件
     */
    private List<PurchaseSkuCreateRpcRequest.SkuAnnexe> annexe;

    /**
     * sku参数
     */
    private Map<String, List<String>> skuParamMap;
}
