package com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.seeease.seeeaseframework.mybatis.domain.BaseDomain;
import com.seeease.seeeaseframework.mybatis.domain.WhetherEnum;
import com.seeease.seeeaseframework.mybatis.type.JsonTypeHandler;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.apache.ibatis.type.JdbcType;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * 调拨额度控制主表
 */
@EqualsAndHashCode(callSuper = true)
@TableName(value = "v4_ops_transfer_quota", autoResultMap = true)
@Data
public class TransferQuota extends BaseDomain {
    @TableId(type = IdType.AUTO)
    private Integer id;

    /**
     * 涉及到的类目id列表
     */
    @TableField(jdbcType = JdbcType.VARCHAR, typeHandler = JsonTypeHandler.class)
    private List<Integer> categoryIds;
    /**
     * 控制的商家id
     */
    private Integer merchantId;
    /**
     * 压货总额度
     */
    private BigDecimal osQuota;
    /**
     * 代销总额度
     */
    private BigDecimal ctQuota;
    /**
     * 是否调拨控制
     */
    private WhetherEnum isCtl;
    /**
     * 开始时间
     */
    private Date startDate;
    /**
     * 结束时间
     */
    private Date endDate;
}