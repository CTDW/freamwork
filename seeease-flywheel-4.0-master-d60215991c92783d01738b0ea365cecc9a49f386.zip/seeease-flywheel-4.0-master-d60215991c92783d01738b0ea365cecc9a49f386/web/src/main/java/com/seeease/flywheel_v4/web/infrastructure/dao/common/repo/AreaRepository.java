package com.seeease.flywheel_v4.web.infrastructure.dao.common.repo;

import com.seeease.flywheel_v4.web.infrastructure.dao.common.entity.Area;

import java.util.List;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 7/25/24 12:03 下午
 **/
public interface AreaRepository {
    /**
     * 查找
     * @param parentId
     * @return
     */
    List<Area> listByPid(Integer parentId);

}
