package com.seeease.flywheel_v4.web.domain.wms.observer.base;

import com.seeease.goods.rpc.enums.SkuNodeStateEnums;

import java.util.List;

/**
 * <p
 *    wms出入库事件观察者
 * </p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/21/24 2:46下午
 **/
public interface WmsObserver<Type,Data> extends SkuNodeStateAdaptor {


    /**
     * 获取观察者对应观察的数据类型
     */
    List<Type> getWatchDataType();

    /**
     * 对数据类型进行匹配 匹配成功则由该观察者进行回调处理
     */
    default boolean matchDataType(Type type){
        return getWatchDataType().contains(type);
    }

    /**
     * 针对于发生了节点状态变动的wms数据进行回调
     * @param nodeState 变动后的节点状态
     * @param data      变动的数据
     * @param serialNo  单据编号
     */
    void update(List<Data> data, SkuNodeStateEnums nodeState,String serialNo);

    /**
     * 针对于未发生节点状态变动但是发生了其他数据变动的回调方法
     * @param data 变动的数据
     * @param serialNo 单据编号
     */
    default void updateWithoutState(List<Data> data,String serialNo){};



}
