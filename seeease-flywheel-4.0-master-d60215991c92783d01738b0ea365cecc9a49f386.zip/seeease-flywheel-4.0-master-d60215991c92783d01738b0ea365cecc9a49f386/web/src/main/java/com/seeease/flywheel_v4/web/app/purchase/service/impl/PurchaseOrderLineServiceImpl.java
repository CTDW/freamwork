package com.seeease.flywheel_v4.web.app.purchase.service.impl;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.seeease.flywheel_v4.client.enums.BusinessUnitTypeEnums;
import com.seeease.flywheel_v4.web.app.purchase.request.PurchaseOrderLinePageRequest;
import com.seeease.flywheel_v4.web.app.purchase.request.PurchaseOrderLineStateRequest;
import com.seeease.flywheel_v4.web.app.purchase.request.PurchaseOrderLineToNormalRequest;
import com.seeease.flywheel_v4.web.app.purchase.result.PurchaseOrderLinePageResult;
import com.seeease.flywheel_v4.web.app.purchase.service.PurchaseOrderLineService;
import com.seeease.flywheel_v4.web.domain.purchase.mapping.PurchaseOrderLineMapping;
import com.seeease.flywheel_v4.web.domain.wms.observer.base.WmsSubject;
import com.seeease.flywheel_v4.web.infrastructure.dao.RepositoryFactory;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.entity.PurchaseOrder;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.entity.PurchaseOrderLine;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.enums.PurchaseAftersaleTypeEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.entity.SysBusinessUnit;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.MerchantWms;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.MerchantWmsLine;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.WmsRk;
import com.seeease.flywheel_v4.web.infrastructure.listener.purchaseAftersale.PurchaseAftersaleCreateListener;
import com.seeease.goods.rpc.SkuFacade;
import com.seeease.goods.rpc.enums.SkuNodeStateEnums;
import com.seeease.goods.rpc.request.SkuRpcRequest;
import com.seeease.goods.rpc.request.SkuUpdateRpcRequest;
import com.seeease.goods.rpc.result.SkuRpcResult;
import com.seeease.seeeaseframework.mybatis.domain.WhetherEnum;
import com.seeease.seeeaseframework.mybatis.utils.EnumUtils;
import com.seeease.springframework.PageResult;
import com.seeease.springframework.exception.ValidationUtil;
import com.seeease.springframework.utils.MultiUtils;
import com.seeease.springframework.utils.StringUtils;
import io.seata.spring.annotation.GlobalTransactional;
import org.apache.dubbo.config.annotation.DubboReference;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/24/24 5:43 下午
 **/
@Service
public class PurchaseOrderLineServiceImpl implements PurchaseOrderLineService {
    @Resource
    private RepositoryFactory repositoryFactory;

    @DubboReference(version = "1.0.0", check = false)
    private SkuFacade skuFacade;

    @Resource
    private WmsSubject wmsSubject;

    @Resource
    private PurchaseAftersaleCreateListener afterSaleListener;

    @GlobalTransactional
    @Override
    public Boolean lineState(PurchaseOrderLineStateRequest request) {

        if (Objects.equals(request.getNodeState(), SkuNodeStateEnums.QX.getValue())) {
            request.setNodeState(SkuNodeStateEnums.JSZ.getValue());
        }
        SkuNodeStateEnums nodeState = EnumUtils.of(SkuNodeStateEnums.class, request.getNodeState());


        List<PurchaseOrderLine> lineList = repositoryFactory.getPurchaseOrderLineRepository()
                .findByIdList(request.getIdList());

        ValidationUtil.isTrue(
                lineList.size() == request.getIdList().size(),
                "采购单行id错误"
        );


        //过滤出实物不符或质检不通过的状态 以及修改成新的状态
        lineList = lineList.stream()
                .filter(l -> {
                    if (nodeState == SkuNodeStateEnums.ZJZ){ //只有质检不通过的才能操作重新质检
                        return l.getNodeState() == SkuNodeStateEnums.ZJ_BTG;
                    }
                    //其余操作 实物不符状态和之间不通过都可以操作
                    return l.getNodeState() == SkuNodeStateEnums.SW_BF || l.getNodeState() == SkuNodeStateEnums.ZJ_BTG;
                })
                .peek(l -> l.setNodeState(nodeState))
                .collect(Collectors.toList());

        ValidationUtil.isTrue(StringUtils.isNotEmpty(lineList), "状态异常无法取消");


        //修改行状态
        repositoryFactory.getPurchaseOrderLineRepository().submitBatch(lineList);


        PurchaseOrder order = repositoryFactory
                .getPurchaseOrderRepository()
                .findById(lineList.get(0).getPurchaseId());
        SysBusinessUnit bu = repositoryFactory.getBusinessUnitRepository().findById(order.getStoreId());
        Set<Integer> skuIdList = MultiUtils.toSet(lineList, PurchaseOrderLine::getSkuId);
        boolean pushToMerchant = bu.getType() == BusinessUnitTypeEnums.MERCHANT;

        //重新质检
        if (nodeState == SkuNodeStateEnums.ZJZ) {
            //商家类型不支持该操作
            ValidationUtil.isTrue(!pushToMerchant, "入库方为商家类型无法点击重新质检");

            // 通知仓库wms
            List<WmsRk> rkList = repositoryFactory.getWmsRkRepository().list(
                            skuIdList,
                            order.getSerialNo(),
                            null
                    ).stream()
                    .peek(v -> v.setNodeState(SkuNodeStateEnums.ZJZ))
                    .collect(Collectors.toList());

            wmsSubject.rkState(rkList,SkuNodeStateEnums.ZJZ);
        }

        //创建采购售后服务单
        else {
            //通知商家wms修改采购入库单的状态
            if (pushToMerchant) {
                MerchantWms merchantWms = repositoryFactory.getMerchantWmsRepository()
                        .listBySerialNo(order.getSerialNo())
                        .get(0);

                List<MerchantWmsLine> merchantWmsLineList = repositoryFactory.getMerchantWmsLineRepository()
                        .listByMainId(merchantWms.getId())
                        .stream()
                        .filter(v -> skuIdList.contains(v.getSkuId()))
                        .peek(v ->{
                            v.setNodeState(SkuNodeStateEnums.QX);
                            v.setEndState(WhetherEnum.YES);
                        })
                        .collect(Collectors.toList());

                wmsSubject.merchantWmsDataSubmit(merchantWms, merchantWmsLineList);
            }
            // 通知仓库wms修改采购入库单的状态
            else {
                List<WmsRk> rkList = repositoryFactory.getWmsRkRepository().list(
                                skuIdList,
                                order.getSerialNo(),
                                null
                        ).stream()
                        .peek(v -> v.setNodeState(SkuNodeStateEnums.QX))
                        .collect(Collectors.toList());

                wmsSubject.rkDateSubmit(rkList);
            }


            //生成采购售后单
            PurchaseAftersaleTypeEnums type;
            if (nodeState == SkuNodeStateEnums.JSZ) {
                type = PurchaseAftersaleTypeEnums.JS;
            } else if (nodeState == SkuNodeStateEnums.FX) {
                type = PurchaseAftersaleTypeEnums.FX;
            } else {
                type = PurchaseAftersaleTypeEnums.HH;
            }

            afterSaleListener.onEvent(
                    new PurchaseAftersaleCreateListener.Event(
                            this,
                            order,
                            lineList,
                            type
                    )
            );
        }


        return true;
    }


    @Override
    public PageResult<PurchaseOrderLinePageResult> page(PurchaseOrderLinePageRequest request) {

        List<SkuRpcResult> skuList = null;
        Set<Integer> skuIdList = null;

        //sku查询
        if (StringUtils.isNotEmpty(request.getSkuCode())) {
            SkuRpcRequest rpcRequest = new SkuRpcRequest();
            rpcRequest.setSkuCode(request.getSkuCode());
            skuList = skuFacade.list(rpcRequest);

            if (skuList.isEmpty()) {
                return PageResult.buildEmpty();
            }

            skuIdList = MultiUtils.toSet(skuList, SkuRpcResult::getId);
        }

        //采购单查询
        Set<Integer> orderIdList = null;
        List<PurchaseOrder> orderList = null;
        if (StringUtils.isNotEmpty(request.getSerialNo())) {
            orderList = repositoryFactory.getPurchaseOrderRepository()
                    .list(
                            request.getSerialNo(),
                            null
                    );
            if (orderList.isEmpty()) {
                return PageResult.buildEmpty();
            }
            orderIdList = MultiUtils.toSet(orderList, PurchaseOrder::getId);
        }


        Page<PurchaseOrderLine> page = repositoryFactory.getPurchaseOrderLineRepository()
                .page(
                        skuIdList,
                        orderIdList,
                        request
                );

        if (page.getRecords().isEmpty()) {
            return PageResult.buildEmpty();
        }

        //数据组合
        //采购数据
        if (orderList == null) {
            orderIdList = MultiUtils.toSet(page.getRecords(), PurchaseOrderLine::getPurchaseId);
            orderList = repositoryFactory.getPurchaseOrderRepository().listByIds(orderIdList);
        }

        Map<Integer, PurchaseOrder> orderMap = MultiUtils.toMap(
                orderList,
                PurchaseOrder::getId,
                Function.identity()
        );


        //sku数据
        if (skuList == null) {
            skuIdList = MultiUtils.toSet(page.getRecords(), PurchaseOrderLine::getSkuId);
            SkuRpcRequest rpcRequest = new SkuRpcRequest();
            rpcRequest.setIdList(skuIdList);
            skuList = skuFacade.list(rpcRequest);
        }

        Map<Integer, SkuRpcResult> skuMap = MultiUtils.toMap(skuList, SkuRpcResult::getId, Function.identity());

        //组合
        List<PurchaseOrderLinePageResult> ret = MultiUtils.toList(
                page.getRecords(),
                v -> {
                    PurchaseOrder order = orderMap.get(v.getPurchaseId());
                    SkuRpcResult sku = skuMap.get(v.getSkuId());
                    return PurchaseOrderLineMapping.INSTANCE.toPageResult(v, order, sku);
                }
        );


        return PageResult.<PurchaseOrderLinePageResult>builder()
                .result(ret)
                .totalCount(page.getTotal())
                .totalPage(page.getPages())
                .build();
    }

    @GlobalTransactional
    @Override
    public Boolean lineToNormal(PurchaseOrderLineToNormalRequest request) {
        PurchaseOrderLine line = repositoryFactory.getPurchaseOrderLineRepository().finById(request.getLineId());
        ValidationUtil.isTrue(line.getNodeState() == SkuNodeStateEnums.SW_BF,"状态错误无法编辑");

        PurchaseOrder order = repositoryFactory.getPurchaseOrderRepository().findById(line.getPurchaseId());

        //step_1 修改采购单行状态
        line.setNodeState(SkuNodeStateEnums.DSH);
        repositoryFactory.getPurchaseOrderLineRepository().submit(line);

        //step_2 修改仓库wms状态
        SysBusinessUnit bu = repositoryFactory.getBusinessUnitRepository().findById(order.getStoreId());
        ValidationUtil.isTrue(bu.getType() == BusinessUnitTypeEnums.WAREHOUSE,"商家入库单无法调用该状态");
        List<WmsRk> rkList = repositoryFactory.getWmsRkRepository().list(
                        Collections.singleton(line.getSkuId()),
                        order.getSerialNo(),
                        null
                ).stream()
                .peek(v -> v.setNodeState(SkuNodeStateEnums.DSH))
                .collect(Collectors.toList());
        wmsSubject.rkDateSubmit(rkList);


        //step_3 修改sku状态
        SkuUpdateRpcRequest rpcRequest = PurchaseOrderLineMapping.INSTANCE.toSkuUpdateRequest(line,request);
        skuFacade.update(rpcRequest);
        return true;
    }
}
