package com.seeease.flywheel_v4.web.app.sys_config.result;

import lombok.Data;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/6/24 10:36 上午
 **/
@Data
public class UserListResult {
    /**
     * id
     */
    private Integer id;
    /**
     * 名称
     */
    private String name;
}
