package com.seeease.flywheel_v4.web.domain.purchase.mapping;


import com.seeease.flywheel_v4.web.app.purchase.request.PurchaseDemandSubmitRequest;
import com.seeease.flywheel_v4.web.app.purchase.result.PurchaseDemandDetailResult;
import com.seeease.flywheel_v4.web.app.purchase.result.PurchaseDemandPageResult;

import com.seeease.flywheel_v4.web.infrastructure.config.SimpleMapping;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.entity.PurchaseDemand;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.enums.PurchaseDemandStateEnums;
import com.seeease.flywheel_v4.client.enums.BusinessUnitTypeEnums;
import com.seeease.goods.rpc.result.SpuRpcResult;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;

import java.util.Date;


/**
 * <p>
 * </p>
 *
 * @author 西门 游
 * @since 2023-10-27
 */
@Mapper(componentModel = "spring",
        builder = @Builder(disableBuilder = true),
        nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS,
        nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE,
        imports = {BusinessUnitTypeEnums.class, PurchaseDemandStateEnums.class,PurchaseDemandStateEnums.TransitionEnum.class})
public interface PurchaseDemandMapping extends SimpleMapping<PurchaseDemandSubmitRequest, PurchaseDemand> {

    PurchaseDemandMapping INSTANCE = Mappers.getMapper(PurchaseDemandMapping.class);

    @Mapping(target = "id",source = "e.id")
    @Mapping(target = "spuId",source = "spu.id")
    PurchaseDemandPageResult toPageResult(PurchaseDemand e,
                                          SpuRpcResult spu,
                                          String merchantName,
                                          String assignedName);



    @Mapping(target = "transitionStateEnum" ,expression = "java(PurchaseDemandStateEnums.TransitionEnum.STEP_2)")
    PurchaseDemand toEntityForCancel(Integer id, Date cancelTime);


    @Mapping(target = "id",source = "demand.id")
    @Mapping(target = "spuId",source = "spu.id")
    PurchaseDemandDetailResult toDetailResult(PurchaseDemand demand,
                                              SpuRpcResult spu,
                                              String merchantName,
                                              String assignedName);
}
