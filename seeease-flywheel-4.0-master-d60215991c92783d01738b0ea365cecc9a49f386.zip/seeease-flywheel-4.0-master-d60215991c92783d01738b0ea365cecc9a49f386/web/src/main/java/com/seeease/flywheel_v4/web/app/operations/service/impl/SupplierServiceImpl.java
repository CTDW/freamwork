package com.seeease.flywheel_v4.web.app.operations.service.impl;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.seeease.flywheel_v4.web.app.operations.request.ContactListRequest;
import com.seeease.flywheel_v4.web.app.operations.request.SupplierPageRequest;
import com.seeease.flywheel_v4.web.app.operations.request.SupplierSubmitRequest;
import com.seeease.flywheel_v4.web.app.operations.result.SupplierContactListResult;
import com.seeease.flywheel_v4.web.app.operations.result.SupplierPageResult;
import com.seeease.flywheel_v4.web.app.operations.service.SupplierService;
import com.seeease.flywheel_v4.web.domain.operations.mapping.SupplierContactsMapping;
import com.seeease.flywheel_v4.web.domain.operations.mapping.SupplierMapping;
import com.seeease.flywheel_v4.web.infrastructure.dao.RepositoryFactory;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.Supplier;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.SupplierContacts;
import com.seeease.springframework.PageResult;
import com.seeease.springframework.utils.MultiUtils;
import com.seeease.springframework.utils.StringUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * <p>供应商</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/4/24 4:43 下午
 **/
@Slf4j
@Service
public class SupplierServiceImpl implements SupplierService {
    @Resource
    private RepositoryFactory repositoryFactory;

    @Transactional(rollbackFor = Exception.class)
    @Override
    public Boolean create(SupplierSubmitRequest request) {
        Supplier supplier = SupplierMapping.INSTANCE.toEntity(request);
        repositoryFactory.getSupplierRepository()
                .submit(supplier);

        List<SupplierContacts> contactsList = MultiUtils.toList(
                request.getContacts(),
                contact -> {
                    contact.setId(null);
                    contact.setSupplierId(supplier.getId());
                    return SupplierContactsMapping.INSTANCE.toEntity(contact);
                }
        );
        repositoryFactory.getSupplierContactsRepository()
                .submitBatch(contactsList);
        return true;
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public Boolean update(SupplierSubmitRequest request) {
        Supplier supplier = SupplierMapping.INSTANCE.toEntity(request);
        return repositoryFactory.getSupplierRepository()
                .submit(supplier);
    }

    @Override
    public PageResult<SupplierPageResult> page(SupplierPageRequest request) {

        //通过供应商联系人查询条件查询出对应的供应商id
        Set<Integer> supplierIdList = Collections.emptySet();
        if (StringUtils.oneOfNonNull(
                request.getContactName(),
                request.getContactPhone()
        )) {

            supplierIdList = MultiUtils.toSet(
                    repositoryFactory.getSupplierContactsRepository().listByNameAndPhone(
                            request.getContactName(),
                            request.getContactPhone()
                    ),
                    SupplierContacts::getSupplierId
            );

            if (StringUtils.isEmpty(supplierIdList)){
                return PageResult.buildEmpty();
            }
        }

        //供应商数据
        Page<Supplier> page = repositoryFactory.getSupplierRepository()
                .page(
                        supplierIdList,
                        request.getType(),
                        request.getName(),
                        request.getState(),
                        request
                );

        if (page.getRecords().isEmpty()) {
            return PageResult.buildEmpty();
        }

        supplierIdList = MultiUtils.toSet(page.getRecords(), Supplier::getId);


        //供应商联系人数据
        Map<Integer, List<SupplierContactListResult>> contactsMap = repositoryFactory.getSupplierContactsRepository()
                .listBySupplierIds(supplierIdList)
                .stream()
                .map(SupplierContactsMapping.INSTANCE::toListResult)
                .collect(Collectors.groupingBy(SupplierContactListResult::getSupplierId));

        //数据组合
        List<SupplierPageResult> ret = MultiUtils.toList(
                page.getRecords(),
                v -> SupplierMapping.INSTANCE.toPageResult(v, contactsMap.get(v.getId()))
        );


        return PageResult.<SupplierPageResult>builder()
                .result(ret)
                .totalCount(page.getTotal())
                .totalPage(page.getPages())
                .build();
    }

    @Override
    public List<SupplierContactListResult> contactList(ContactListRequest request) {
        List<SupplierContacts> contactList = repositoryFactory.getSupplierContactsRepository()
                .listByKey(request.getKey());

        Set<Integer> supplierIds = MultiUtils.toSet(contactList, SupplierContacts::getSupplierId);
        Map<Integer, Supplier> supplierMap = MultiUtils.toMap(
                repositoryFactory.getSupplierRepository().listByIds(supplierIds),
                Supplier::getId
        );


        return MultiUtils.toList(
                contactList,
                contacts -> {
                    Supplier supplier = supplierMap.get(contacts.getSupplierId());
                    return SupplierContactsMapping.INSTANCE.toListResult(contacts,supplier);
                }
                );
    }
}
