package com.seeease.flywheel_v4.web.infrastructure.dao.fix.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.seeease.flywheel_v4.web.app.fix.request.FixOrderPageRequest;
import com.seeease.flywheel_v4.web.app.fix.result.FixStatusCountResult;
import com.seeease.flywheel_v4.web.infrastructure.dao.fix.entity.FixOrder;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Update;

import java.util.List;

/**
 * @Description 维修单
 * @Date 2024-10-2 21:02
 * @Author by hk
 */
public interface FixOrderMapper extends BaseMapper<FixOrder> {

    /**
     * 按状态分组，查询各状态下维修单数量
     *
     * @param request 请求
     * @return 结果
     */
    List<FixStatusCountResult> getStatusCount(FixOrderPageRequest request);

    /**
     * 送外维修
     *
     * @param sendOutRemark 备注
     * @param id            id
     */
    @Update("update v4_fix_order set send_out_remark = #{sendOutRemark}" +
            ",pre_order_status = order_status,order_status = 9 where id = #{id}")
    void updateOrderStatusToSendOut(@Param("sendOutRemark") String sendOutRemark,
                                    @Param("id") Long id);

    /**
     * 维修完成
     *
     * @param sendOutRemark 送修备注
     * @param returnRemark  返回备注
     * @param expressNumber 快递单号
     * @param masterScores  维修师打分
     * @param id            id
     */
    @Update("update v4_fix_order set send_out_remark = #{sendOutRemark}" +
            ",return_remark = #{returnRemark}" +
            ",return_express_number = #{expressNumber}" +
            ",master_scores = #{masterScores}" +
            ",pre_order_status = order_status" +
            ",order_status = 11 where id = #{id}")
    void complete(@Param("sendOutRemark") String sendOutRemark,
                  @Param("returnRemark") String returnRemark,
                  @Param("expressNumber") String expressNumber,
                  @Param("masterScores") String masterScores,
                  @Param("id") Long id);

    /**
     * 取消维修
     *
     * @param id id
     */
    @Update("update v4_fix_order set pre_order_status = order_status" +
            ",order_status = 12 where id = #{id}")
    void updateOrderStatusToCancel(@Param("id") Long id);

    /**
     * 回退
     *
     * @param id id
     * @param newOrderStatus 新状态
     */
    @Update("update v4_fix_order set order_status = #{newOrderStatus}" +
            ",pre_order_status = null where id = #{id}")
    void updateOrderStatusToPreOrderStatus(@Param("id") Long id,
                                           @Param("newOrderStatus") Integer newOrderStatus);

    /**
     * 跳过
     *
     * @param id  id
     * @param newOrderStatus 新状态
     */
    @Update("update v4_fix_order set pre_order_status = order_status," +
            "order_status = #{newOrderStatus} where id = #{id}")
    void updateOrderStatusToAppoint(@Param("id") Long id,
                                    @Param("newOrderStatus") Integer newOrderStatus);

    /**
     * 维修师扫码领用
     *
     * @param id  id
     * @param newOrderStatus 新状态
     */
    @Update("update v4_fix_order set pre_order_status = order_status," +
            "order_status = #{newOrderStatus},fix_master = #{fixMaster} where id = #{id}")
    void masterUpdateOrderStatusToAppoint(@Param("id") Long id,
                                          @Param("newOrderStatus") Integer newOrderStatus,
                                          @Param("fixMaster") String fixMaster);

    /**
     * 完成质检
     *
     * @param id  id
     */
    @Update("update v4_fix_order set pre_order_status = order_status," +
            "order_status = 8 where id = #{id}")
    void completeQuality(@Param("id") Long id);
}
