package com.seeease.flywheel_v4.web.domain.sale.mapping;


import com.seeease.flywheel_v4.web.app.sale.request.SaleOrderCreateRequest;
import com.seeease.flywheel_v4.web.app.sale.result.ToBSaleOrderDetailResult;
import com.seeease.flywheel_v4.web.app.sale.result.ToCSaleOrderDetailResult;
import com.seeease.flywheel_v4.web.infrastructure.config.EnumMapping;
import com.seeease.flywheel_v4.web.infrastructure.config.MappingIgnore;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.enums.PurchaseDemandStateEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.entity.SaleOrder;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.entity.SaleOrderLine;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.entity.obj.BuyBackPolicyObj;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.MerchantWmsLine;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.WmsCk;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.WmsCkTypeEnums;
import com.seeease.flywheel_v4.web.util.SerialNoGenerator;
import com.seeease.goods.rpc.enums.SkuNodeStateEnums;
import com.seeease.goods.rpc.request.SaleSkuCancelRpcRequest;
import com.seeease.goods.rpc.request.SaleSkuFinishRpcRequest;
import com.seeease.goods.rpc.result.SkuBuyBackPolicyRpcResult;
import com.seeease.goods.rpc.result.SkuCreateRpcResult;
import com.seeease.goods.rpc.result.SkuRpcResult;
import com.seeease.seeeaseframework.mybatis.domain.WhetherEnum;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;

import java.math.BigDecimal;
import java.util.List;


/**
 * <p>
 * </p>
 *
 * @author 西门 游
 * @since 2023-10-27
 */
@Mapper(componentModel = "spring",
        builder = @Builder(disableBuilder = true),
        nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS,
        nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE,
        imports = {WhetherEnum.class,
                PurchaseDemandStateEnums.class,
                PurchaseDemandStateEnums.TransitionEnum.class,
                SerialNoGenerator.class,
        WhetherEnum.class})
public interface SaleOrderLineMapping extends EnumMapping {

    SaleOrderLineMapping INSTANCE = Mappers.getMapper(SaleOrderLineMapping.class);



    @MappingIgnore
    @Mapping(target = "count",source = "sku.sellCount")
    @Mapping(target = "skuId",source = "skuRet.id")
    @Mapping(target = "nodeState",source = "nodeState")
    @Mapping(target = "endState",expression = "java(WhetherEnum.NO)")
    SaleOrderLine toEntity(SkuCreateRpcResult skuRet,
                           SaleOrderCreateRequest.Sku sku,
                           SkuNodeStateEnums nodeState,
                           List<BuyBackPolicyObj> policies,
                           Integer saleId
    );

    @MappingIgnore
    @Mapping(target = "type",source = "type")
    @Mapping(target = "originId",source = "saleOrder.buId")
    @Mapping(target = "nodeState",source = "nodeState")
    @Mapping(target = "count",source = "line.count")
    @Mapping(target = "storeId",source = "saleOrder.storeId")
    @Mapping(target = "scId",source = "saleOrder.scId")
    WmsCk toWmsCk(SaleOrder saleOrder,
                  SaleOrderLine line,
                  SkuNodeStateEnums nodeState,
                  WmsCkTypeEnums type,
                  Integer storeId
    );

    @MappingIgnore
    @Mapping(target = "endState",expression = "java(WhetherEnum.NO)")
    @Mapping(target = "nodeState",source = "nodeState")
    @Mapping(target = "price",source = "line.dealPrice")
    MerchantWmsLine toMerchantWmsLine(SaleOrderLine line, SkuNodeStateEnums nodeState);

    @Mapping(target = "lineId",source = "line.id")
    @Mapping(target = "newSettlePrice",source = "line.newSettlePrice")
    @Mapping(target = "spuId",source = "skuRpcResult.spuId")
    @Mapping(target = "dealPrice",source = "line.dealPrice")
    @Mapping(target = "tocPrice",source = "line.tocPrice")
    @Mapping(target = "perfPrice",source = "line.perfPrice")
    ToCSaleOrderDetailResult.Sku tocDetailResult(SaleOrderLine line,
                                                SkuRpcResult skuRpcResult,
                                                String sellerName,
                                                String belongName);

    BuyBackPolicyObj toPolicy(SkuBuyBackPolicyRpcResult.Policy policy);

    SaleSkuCancelRpcRequest.Sku toRpcCancelSku(SaleOrderLine line);


    SaleSkuFinishRpcRequest.Sku toFinishRequest(SaleOrderLine line);

    @Mapping(target = "lineId",source = "line.id")
    @Mapping(target = "newSettlePrice",source = "line.newSettlePrice")
    @Mapping(target = "spuId",source = "sku.spuId")
    @Mapping(target = "dealPrice",source = "line.dealPrice")
    @Mapping(target = "tobPrice",source = "line.tobPrice")
    @Mapping(target = "settledBy",source = "line.settledBy")
    ToBSaleOrderDetailResult.Sku tobDetailResult(
            SaleOrderLine line,
            SkuRpcResult sku,
            String sellerName,
            String belongName,
            BigDecimal profit);
}
