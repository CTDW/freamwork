package com.seeease.flywheel_v4.web.domain.wms.observer;

import com.seeease.flywheel_v4.web.domain.purchase.mapping.PurchaseAftersaleLineMapping;
import com.seeease.flywheel_v4.web.domain.purchase.mapping.PurchaseAftersaleMapping;
import com.seeease.flywheel_v4.web.domain.purchase.mapping.PurchaseOrderMapping;
import com.seeease.flywheel_v4.web.domain.wms.observer.base.Ext;
import com.seeease.flywheel_v4.web.domain.wms.observer.base.MerchantWmsObserver;
import com.seeease.flywheel_v4.web.domain.wms.observer.base.WmsCkObserver;
import com.seeease.flywheel_v4.web.domain.wms.observer.base.WmsSubject;
import com.seeease.flywheel_v4.web.infrastructure.dao.RepositoryFactory;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.Supplier;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.SupplierContacts;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.entity.PurchaseAftersale;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.entity.PurchaseAftersaleLine;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.entity.PurchaseOrder;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.entity.PurchaseOrderLine;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.enums.PurchaseAftersaleTypeEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.entity.SysBusinessUnit;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.MerchantWms;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.MerchantWmsLine;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.WmsCk;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.WmsRk;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.obj.ContactInfo;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.MerchantWmsModelEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.MerchantWmsTypeEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.WmsCkTypeEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.WmsRkTypeEnums;
import com.seeease.flywheel_v4.web.infrastructure.listener.purchase.FinishStateListener;
import com.seeease.flywheel_v4.web.infrastructure.listener.purchaseAftersale.PurchaseAftersaleStateListener;
import com.seeease.goods.rpc.SkuFacade;
import com.seeease.goods.rpc.enums.SkuNodeStateEnums;
import com.seeease.goods.rpc.request.PurchaseReturnSkuCancelRequest;
import com.seeease.goods.rpc.request.PurchaseReturnSkuFinishRpcRequest;
import com.seeease.goods.rpc.request.PurchaseSkuCancelRequest;
import com.seeease.goods.rpc.request.SkuStateEventSubmitRcpRequest;
import com.seeease.seeeaseframework.mybatis.domain.WhetherEnum;
import com.seeease.springframework.utils.MultiUtils;
import com.seeease.springframework.utils.StringUtils;
import org.apache.dubbo.config.annotation.DubboReference;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;

/**
 * <p
 * 采购售后出库观察者
 * </p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/21/24 2:46下午
 **/
@Component
public class PurchaseAftersaleCkObserver
        extends PurchaseAftersaleBaseObserver
        implements WmsCkObserver, MerchantWmsObserver {

    @Resource
    private RepositoryFactory repositoryFactory;
    @Resource
    private PurchaseAftersaleStateListener aftersaleListener;
    @Resource
    private FinishStateListener purchaseListener;

    @Lazy
    @Resource
    private WmsSubject wmsSubject;

    @DubboReference(version = "1.0.0", check = false)
    private SkuFacade skuFacade;




    @Override
    public SkuNodeStateEnums adaptSkuNodeState(SkuNodeStateEnums state, String serialNo) {
        return null;
    }

    //----------------------------------------仓库wms观察者实现-----------------------------------//

    @Override
    public Map<String, Ext> getExt(Set<String> serialNo) {
        //step_1 获取供应商数据
        List<PurchaseAftersale> aftersaleList = repositoryFactory.getPurchaseAftersaleRepository().listBySerialNos(serialNo);
        Set<Integer> supplierIds = MultiUtils.toSet(aftersaleList, PurchaseAftersale::getSupplierId);
        Map<Integer, Supplier> supplierMap = MultiUtils.toMap(
                repositoryFactory.getSupplierRepository().listByIds(supplierIds),
                Supplier::getId
        );

        //step_2 获取联系人数据
        Set<Integer> contactIds = MultiUtils.toSet(aftersaleList, PurchaseAftersale::getSupplierContactId);
        Map<Integer, SupplierContacts> contactMap = MultiUtils.toMap(
                repositoryFactory.getSupplierContactsRepository().listByIds(contactIds),
                SupplierContacts::getId
        );


        //step_3 获取发货方数据
        Set<Integer> fromIds = MultiUtils.toSet(aftersaleList, PurchaseAftersale::getStoreId);
        Map<Integer, SysBusinessUnit> fromMap = MultiUtils.toMap(
                repositoryFactory.getBusinessUnitRepository().listByIds(fromIds),
                SysBusinessUnit::getId
        );


        //step_3 数据组合
        return MultiUtils.toMap(
                aftersaleList,
                PurchaseAftersale::getSerialNo,
                order -> {
                    Supplier supplier = supplierMap.get(order.getSupplierId());
                    SupplierContacts contact = contactMap.get(order.getSupplierContactId());
                    SysBusinessUnit from = fromMap.get(order.getStoreId());
                    String remark = order.getRemark();
                    return PurchaseAftersaleMapping.INSTANCE.toCkExt(supplier,contact,from,remark);
                }
        );
    }




    @Override
    public List<WmsCkTypeEnums> getWatchDataType() {
        return wmsCkWatchTypeList;
    }

    @Override
    public void update(List<WmsCk> wmsCks, SkuNodeStateEnums nodeState, String serialNo) {


        PurchaseAftersale aftersale = repositoryFactory.getPurchaseAftersaleRepository()
                .findByIdOrSerialNo(null, serialNo);

        Set<Integer> skuIdList = MultiUtils.toSet(wmsCks, WmsCk::getSkuId);

        List<PurchaseAftersaleLine> lineList = repositoryFactory.getPurchaseAftersaleLineRepository()
                .listByMainIdAndSkuIds(aftersale.getId(), skuIdList);

        switch (nodeState) {
            case QX: //取消
                doCancel(aftersale, lineList);
                break;
            case YCK: //出库
                WmsCk ck = wmsCks.get(0);

                //step_1 根据出库的类型分组
                Map<WmsCkTypeEnums, List<WmsCk>> ckMap = wmsCks.stream()
                        .collect(Collectors.groupingBy(WmsCk::getType));

                //获取拒收列表
                List<PurchaseAftersaleLine> jsLineList = null;
                List<WmsCk> jsCkList = ckMap.getOrDefault(WmsCkTypeEnums.CG_JS, null);
                if (null != jsCkList) {
                    skuIdList = MultiUtils.toSet(jsCkList, WmsCk::getSkuId);
                    jsLineList = repositoryFactory.getPurchaseAftersaleLineRepository()
                            .listByMainIdAndSkuIds(aftersale.getId(), skuIdList);

                }

                //获取返修列表
                List<PurchaseAftersaleLine> fxLineList = null;
                List<WmsCk> fxCkList = ckMap.getOrDefault(WmsCkTypeEnums.CG_FX, null);
                if (null != fxCkList) {
                    skuIdList = MultiUtils.toSet(fxCkList, WmsCk::getSkuId);
                    fxLineList = repositoryFactory.getPurchaseAftersaleLineRepository()
                            .listByMainIdAndSkuIds(aftersale.getId(), skuIdList);

                }

                //获取换货列表
                List<PurchaseAftersaleLine> hhLineList = null;
                List<WmsCk> hhCKList = ckMap.getOrDefault(WmsCkTypeEnums.CG_HH, null);
                if (null != hhCKList) {
                    skuIdList = MultiUtils.toSet(hhCKList, WmsCk::getSkuId);
                    hhLineList = repositoryFactory.getPurchaseAftersaleLineRepository()
                            .listByMainIdAndSkuIds(aftersale.getId(), skuIdList);

                }

                //获取退货列表
                List<PurchaseAftersaleLine> thLineList = null;
                List<WmsCk> thCKList = ckMap.getOrDefault(WmsCkTypeEnums.CG_TH, null);
                if (null != thCKList) {
                    skuIdList = MultiUtils.toSet(thCKList, WmsCk::getSkuId);
                    thLineList = repositoryFactory.getPurchaseAftersaleLineRepository()
                            .listByMainIdAndSkuIds(aftersale.getId(), skuIdList);

                }

                doCK(aftersale, jsLineList, fxLineList, hhLineList,thLineList,ck.getExpressNo());

                break;

        }

    }

    @Override
    public void updateWithoutState(List<WmsCk> wmsCks, String serialNo) {

    }


    //----------------------------------------商家wms观察者实现-----------------------------------//

    @Override
    public MerchantWmsModelEnums model() {
        return MerchantWmsModelEnums.CK;
    }

    @Override
    public List<MerchantWmsTypeEnums> typeList() {
        return merchantWmsCkWatchTypeList;
    }

    @Override
    public void update(MerchantWms main, List<MerchantWmsLine> ckList, SkuNodeStateEnums nodeState) {

        PurchaseAftersale aftersale = repositoryFactory.getPurchaseAftersaleRepository()
                .findByIdOrSerialNo(null, main.getSerialNo());

        Set<Integer> skuIdList = MultiUtils.toSet(ckList, MerchantWmsLine::getSkuId);

        List<PurchaseAftersaleLine> lineList = repositoryFactory.getPurchaseAftersaleLineRepository()
                .listByMainIdAndSkuIds(aftersale.getId(), skuIdList);

        switch (nodeState) {
            case QX: //取消
                doCancel(aftersale, lineList);
                break;
            case YCK: //出库

                String expressNo = main.getExpressNo();
                List<PurchaseAftersaleLine> jsCkList = null;
                List<PurchaseAftersaleLine> fxCkList = null;
                List<PurchaseAftersaleLine> hhCkList = null;
                List<PurchaseAftersaleLine> thCkList = null;
                if (main.getType() == MerchantWmsTypeEnums.CG_JS_CK) {
                    jsCkList = lineList;
                } else if (main.getType() == MerchantWmsTypeEnums.CG_FX_CK) {
                    fxCkList = lineList;
                } else if (main.getType() == MerchantWmsTypeEnums.CG_HH_CK) {
                    hhCkList = lineList;
                }else {
                    thCkList = lineList;
                }
                doCK(aftersale, jsCkList, fxCkList, hhCkList,thCkList,expressNo);
                break;
        }

    }
    //----------------------------------------商家wms观察者实现-----------------------------------//


    @Override
    public Ext getCkExt(String serialNo){
        //step_1 获取供应商数据
        PurchaseAftersale aftersale = repositoryFactory.getPurchaseAftersaleRepository()
                .findByIdOrSerialNo(null,serialNo);

        //step_2 获取联系人数据
        Supplier supplier = repositoryFactory.getSupplierRepository().findById(aftersale.getSupplierId());
        SupplierContacts contact = repositoryFactory.getSupplierContactsRepository().findById(aftersale.getSupplierContactId());

        //step_3 获取发货方数据
        SysBusinessUnit from = repositoryFactory.getBusinessUnitRepository().findById(aftersale.getStoreId());

        //step_4 数据组合
        return PurchaseAftersaleMapping.INSTANCE.toCkExt(supplier,contact,from,aftersale.getRemark());
    }



    /**
     * 执行取消
     *
     * @param lineList
     */
    private void doCancel(PurchaseAftersale main, List<PurchaseAftersaleLine> lineList) {
        //step_1 变更售后单行状态
        lineList.forEach(l -> {
            l.setNodeState(SkuNodeStateEnums.QX);
            l.setEndState(WhetherEnum.YES);
        });
        repositoryFactory.getPurchaseAftersaleLineRepository().submitBatch(lineList);

        //step_2 尝试变更售后单状态
        aftersaleListener.onEvent(new PurchaseAftersaleStateListener.Event(this, main.getId()));

        /**
         * step_3
         * 类型为采购退货则修改sku状态
         * 如果为其他的则恢复对应采购单据状态为待收货
         */
        if (main.getType() == PurchaseAftersaleTypeEnums.TH) {
            //rpc修改sku
            PurchaseReturnSkuCancelRequest rpcRequest = new PurchaseReturnSkuCancelRequest();

            List<PurchaseReturnSkuCancelRequest.Sku> rpcSkuLis = MultiUtils.toList(
                    lineList,
                    PurchaseAftersaleLineMapping.INSTANCE::toCancelRpcRequest
            );
            rpcRequest.setSkuList(rpcSkuLis);
            rpcRequest.setSerialNo(main.getSerialNo());
            skuFacade.cancel(rpcRequest);
        } else {
            //恢复采购单行状态
            PurchaseOrder purchaseOrder = repositoryFactory.getPurchaseOrderRepository()
                    .findByIdOrSerialNo(null, main.getOriginSerialNo());

            Set<Integer> skuIdList = MultiUtils.toSet(lineList, PurchaseAftersaleLine::getSkuId);
            List<PurchaseOrderLine> purchaseLineList = repositoryFactory.getPurchaseOrderLineRepository().findByPurchaseIdAndSkuIds(
                    purchaseOrder.getId(),
                    skuIdList
            );
            purchaseLineList.forEach(line -> line.setNodeState(SkuNodeStateEnums.SW_BF));
            repositoryFactory.getPurchaseOrderLineRepository().submitBatch(purchaseLineList);

   


            //修改sku状态
            SkuStateEventSubmitRcpRequest rcpRequest = new SkuStateEventSubmitRcpRequest();
            rcpRequest.setNodeState(SkuNodeStateEnums.SW_BF);
            rcpRequest.setSerialNo(main.getSerialNo());
            List<SkuStateEventSubmitRcpRequest.Sku> sku = lineList.stream().map(v -> {
                SkuStateEventSubmitRcpRequest.Sku temp = new SkuStateEventSubmitRcpRequest.Sku();
                temp.setSkuId(v.getSkuId());
                return temp;
            }).collect(Collectors.toList());
            rcpRequest.setSkuList(sku);
            skuFacade.stateEventSubmit(rcpRequest);
        }


    }


    /**
     * 执行出库
     *
     * @param main
     * @param jsCkList 拒收出库的行
     * @param fxCkList 返修出库的行
     * @param hhCkList 换货出库的行
     * @param thCkList 退货出库的行
     * @param expressNo 快递单号
     */
    private void doCK(PurchaseAftersale main,
                      List<PurchaseAftersaleLine> jsCkList,
                      List<PurchaseAftersaleLine> fxCkList,
                      List<PurchaseAftersaleLine> hhCkList,
                      List<PurchaseAftersaleLine> thCkList,
                      String expressNo) {

        main.setExpressNo(expressNo);
        main.setSpTime(new Date());
        repositoryFactory.getPurchaseAftersaleRepository().submit(main);

        //执行退货逻辑
        if (StringUtils.isNotEmpty(thCkList)){
            thCkList.forEach(l -> {
                l.setEndState(WhetherEnum.YES);
                l.setNodeState(SkuNodeStateEnums.YCK);
            });
            repositoryFactory.getPurchaseAftersaleLineRepository().submitBatch(thCkList);


            //采购订单节点变更事件推送
            aftersaleListener.onEvent(new PurchaseAftersaleStateListener.Event(this, main.getId()));

            //修改sku
            PurchaseReturnSkuFinishRpcRequest rpcRequest = new PurchaseReturnSkuFinishRpcRequest();

            List<PurchaseReturnSkuFinishRpcRequest.Sku> skuList = MultiUtils.toList(
                    thCkList,
                    PurchaseAftersaleLineMapping.INSTANCE::toPurchaseReturnFinishRequest
            );
            rpcRequest.setSkuList(skuList);
            rpcRequest.setSerialNo(main.getSerialNo());
            skuFacade.finish(rpcRequest);
        }



        /**
         * 处理拒收的出库逻辑
         */
        if (StringUtils.isNotEmpty(jsCkList)) {

            //step_1 状态变更提交
            jsCkList.forEach(l -> {
                l.setEndState(WhetherEnum.YES);
                l.setNodeState(SkuNodeStateEnums.YCK);
            });
            repositoryFactory.getPurchaseAftersaleLineRepository().submitBatch(jsCkList);
            //采购订单节点变更事件推送
            aftersaleListener.onEvent(new PurchaseAftersaleStateListener.Event(this, main.getId()));


            //step_2 修改采购行终结状态
            PurchaseOrder purchaseOrder = repositoryFactory.getPurchaseOrderRepository()
                    .findByIdOrSerialNo(null, main.getOriginSerialNo());

            Set<Integer> skuIdList = MultiUtils.toSet(jsCkList, PurchaseAftersaleLine::getSkuId);

            List<PurchaseOrderLine> purchaseOrderLineList = repositoryFactory.getPurchaseOrderLineRepository()
                    .listByPurchaseIdAndSkuIds(purchaseOrder.getId(), skuIdList);

            purchaseOrderLineList.forEach( l -> {
                l.setEndState(WhetherEnum.YES);
                l.setNodeState(SkuNodeStateEnums.YCK);
            });
            repositoryFactory.getPurchaseOrderLineRepository().submitBatch(purchaseOrderLineList);

            purchaseListener.onEvent(new FinishStateListener.Event(this,purchaseOrder.getId()));




            //step_3 调用sku的取消逻辑
            PurchaseSkuCancelRequest rpcRequest = new PurchaseSkuCancelRequest();
            rpcRequest.setIdList(MultiUtils.toSet(jsCkList, PurchaseAftersaleLine::getSkuId));
            rpcRequest.setSerialNo(main.getSerialNo());
            skuFacade.cancel(rpcRequest);

        }


        /**
         * 处理返修和换货逻辑
         */

        if (StringUtils.oneOfNonNull(
                fxCkList,
                hhCkList
        )) {
            //商家生成入库单
            if (super.pushToMerchant(main)) {
                Supplier supplier = repositoryFactory.getSupplierRepository().findById(main.getSupplierId());
                ContactInfo contactInfo = PurchaseOrderMapping.INSTANCE.toMerchantWmsContactInfo(supplier);

                HashMap<MerchantWmsTypeEnums, List<PurchaseAftersaleLine>> map = new HashMap<>();
                map.put(MerchantWmsTypeEnums.CG_FX_RK, fxCkList);
                map.put(MerchantWmsTypeEnums.CG_HH_RK, hhCkList);


                for (Map.Entry<MerchantWmsTypeEnums, List<PurchaseAftersaleLine>> e : map.entrySet()) {

                    //计算数量及金额
                    Integer count = 0;
                    BigDecimal amount = BigDecimal.ZERO;
                    for (PurchaseAftersaleLine l : e.getValue()) {
                        count += l.getCount();
                        amount = amount.add(l.getPrice());
                    }

                    //转换提交入库单
                    MerchantWms rk = PurchaseAftersaleMapping.INSTANCE.toMerchantWms(
                            main,
                            contactInfo,
                            e.getKey(),
                            MerchantWmsModelEnums.RK,
                            count,
                            amount
                    );

                    List<MerchantWmsLine> rkLineList = MultiUtils.toList(
                            e.getValue(),
                            v -> PurchaseAftersaleLineMapping.INSTANCE.toMerchantWmsLine(v, SkuNodeStateEnums.DRK)
                    );
                    wmsSubject.merchantWmsDataCreate(rk, rkLineList);
                }

            }
            //仓库生成入库单
            else {
                List<WmsRk> rkList = new ArrayList<>();

                //转换返修入库列表
                if (StringUtils.isNotEmpty(fxCkList)) {
                    List<WmsRk> fx = MultiUtils.toList(
                            fxCkList,
                            line -> PurchaseAftersaleLineMapping.INSTANCE.toWmsRk(
                                    line,
                                    main,
                                    WmsRkTypeEnums.CG_FX
                            )
                    );
                    rkList.addAll(fx);
                }

                //转换换货入库列表
                if (StringUtils.isNotEmpty(hhCkList)) {
                    List<WmsRk> hh = MultiUtils.toList(
                            hhCkList,
                            line -> PurchaseAftersaleLineMapping.INSTANCE.toWmsRk(
                                    line,
                                    main,
                                    WmsRkTypeEnums.CG_HH
                            )
                    );
                    rkList.addAll(hh);
                }

                wmsSubject.rkDateSubmit(rkList);
            }


        }


    }



}
