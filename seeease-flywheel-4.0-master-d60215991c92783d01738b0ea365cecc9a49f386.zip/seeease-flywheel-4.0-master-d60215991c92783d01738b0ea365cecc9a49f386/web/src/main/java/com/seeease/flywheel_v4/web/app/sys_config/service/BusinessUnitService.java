package com.seeease.flywheel_v4.web.app.sys_config.service;

import com.seeease.flywheel_v4.web.app.sys_config.request.*;
import com.seeease.flywheel_v4.web.app.sys_config.result.BusinessUnitListResult;
import com.seeease.flywheel_v4.web.app.sys_config.result.BusinessUnitPageResult;
import com.seeease.flywheel_v4.web.app.sys_config.result.PurchaseBusinessUnitPageResult;
import com.seeease.springframework.PageResult;

import java.util.List;

/**
 * <p>系统业务单元服务</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/3/24 11:19 上午
 **/
public interface BusinessUnitService {
    /**
     * 使用于通用类型业务单元创建
     *
     * @return 创建结果
     */
    Boolean create(BusinessUnitSubmitRequest request);

    /**
     * 使用于通用类型业务单元更新
     *
     * @return 更新结果
     */
    Boolean update(BusinessUnitSubmitRequest request);

    /**
     * 通用类型业务单元分页查询
     *
     * @return 分页结果
     */
    PageResult<BusinessUnitPageResult> page(BusinessUnitPageRequest request);

    /**
     * 业务单元列表查询
     *
     * @return 列表结果
     */
    List<BusinessUnitListResult> list(BusinessUnitListRequest request);

    /**
     * 采购主体单元创建
     *
     * @return 创建结果
     */
    Boolean purchaseCreate(PurchaseBusinessUnitSubmitRequest request);
    /**
     * 采购主体单元更新
     *
     * @return 更新结果
     */
    Boolean purchaseUpdate(PurchaseBusinessUnitSubmitRequest request);

    /**
     * 采购主体单元分页查询
     *
     * @return 分页结果
     */
    PageResult<PurchaseBusinessUnitPageResult> purchasePage(PurchaseBusinessUnitPageRequest request);
}
