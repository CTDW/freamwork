package com.seeease.flywheel_v4.web.infrastructure.dao.purchase.entity;

import com.baomidou.mybatisplus.annotation.*;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.enums.PurchaseOrderStateEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.enums.PurchasePayTypeEnums;
import com.seeease.flywheel_v4.client.enums.PurchaseTypeEnums;
import com.seeease.seeeaseframework.mybatis.domain.BaseDomain;
import com.seeease.seeeaseframework.mybatis.transitionstate.ITransitionStateEnum;
import com.seeease.seeeaseframework.mybatis.transitionstate.TransitionState;
import com.seeease.seeeaseframework.mybatis.transitionstate.TransitionStateEntity;
import com.seeease.seeeaseframework.mybatis.type.JsonTypeHandler;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.apache.ibatis.type.JdbcType;

import java.math.BigDecimal;
import java.util.List;

/**
 * 采购订单
 */
@EqualsAndHashCode(callSuper = true)
@TableName(value = "v4_purchase_order", autoResultMap = true)
@Data
public class PurchaseOrder extends BaseDomain implements TransitionStateEntity {
    @TableId(type = IdType.AUTO)
    private Integer id;
    /**
     * 采购编码
     */
    private String serialNo;
    /**
     * 采购类型
     */
    private PurchaseTypeEnums type;
    /**
     * 采购总金额
     */
    private BigDecimal totalPrice;
    /**
     * 采购总数量
     */
    private Integer totalCount;
    /**
     * 付款比例
     */
    private BigDecimal payRatio;
    /**
     * 付款方式
     */
    private PurchasePayTypeEnums payType;
    /**
     * 供应商id
     */
    private Integer supplierId;
    /**
     * 供应商联系人
     */
    private Integer supplierContactId;
    /**
     * 采购人id
     */
    private Integer buyerId;
    /**
     * 采购主体id
     */
    private Integer purchaseSubjectId;
    /**
     * 商家id
     */
    private Integer merchantId;
    /**
     * 仓库id
     */
    private Integer storeId;
    /**
     * 定价方id
     */
    private Integer pricerId;
    /**
     * 快递单号
     */
    private String expressNo;
    /**
     * 图片
     */
    @TableField(jdbcType = JdbcType.VARCHAR, typeHandler = JsonTypeHandler.class)
    private List<String> images;

    /**
     * 采购单状态
     */
    @TransitionState
    private PurchaseOrderStateEnums state;

    /**
     * 备注
     */
    private String remark;
    /**
     * 申请打开单id
     */
    private Integer fpsId;

    /**
     * 申请打款单编码
     */
    private String fpsSerialNo;

    /**
     * 置换销售单号
     */
    private String newSaleSerialNo;

    /**
     * 回购销售单号
     */
    private String saleSerialNo;

    /**
     * 差额
     */
    private BigDecimal diff;

    /**
     * 创建人业务部门id
     */
    private Integer buId;


    @TableField(exist = false)
    private ITransitionStateEnum transitionStateEnum;
}