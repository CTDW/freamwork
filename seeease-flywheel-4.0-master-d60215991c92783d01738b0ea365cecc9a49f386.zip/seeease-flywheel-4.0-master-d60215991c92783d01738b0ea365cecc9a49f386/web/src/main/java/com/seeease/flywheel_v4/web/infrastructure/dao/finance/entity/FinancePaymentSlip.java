package com.seeease.flywheel_v4.web.infrastructure.dao.finance.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.seeease.flywheel_v4.web.infrastructure.dao.finance.entity.obj.ImageGroupObj;
import com.seeease.flywheel_v4.web.infrastructure.dao.finance.enums.PaymentSlipStateEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.finance.enums.PaymentSlipVerifyStateEnums;
import com.seeease.seeeaseframework.mybatis.domain.BaseDomain;
import com.seeease.seeeaseframework.mybatis.transitionstate.ITransitionStateEnum;
import com.seeease.seeeaseframework.mybatis.transitionstate.TransitionState;
import com.seeease.seeeaseframework.mybatis.transitionstate.TransitionStateEntity;
import com.seeease.seeeaseframework.mybatis.type.JsonTypeHandler;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * 申请打款单
 */
@EqualsAndHashCode(callSuper = true)
@TableName(value = "v4_finance_payment_slip", autoResultMap = true)
@Data
public class FinancePaymentSlip extends BaseDomain implements TransitionStateEntity {
    @TableId(type = IdType.AUTO)
    private Integer id;
    /**
     * 采购单id
     */
    private Integer purchaseId;
    /**
     * 采购单编码
     */
    private String purchaseSerialNo;
    /**
     * 申请打款单单号
     */
    private String serialNo;
    /**
     * 实际打款金额
     */
    private BigDecimal payAmount;
    /**
     * 采购单的采购总金额 字段冗余用于查询
     */
    private BigDecimal amount;
    /**
     * 采购单的供应商id 字段冗余用于查询
     */
    private Integer supplierId;
    /**
     * 采购单的采购主题id 字段冗余用于查询
     */
    private Integer purchaseSubjectId;
    /**
     * 采购单的采购总数量 字段冗余用于显示
     */
    private Integer count;
    /**
     * 采购单类型 字段冗余用于显示
     */
    private Integer purchaseType;
    /**
     * 采购单支付类型 字段冗余用于显示
     */
    private Integer payType;
    /**
     * 打款时间
     */
    private Date payTime;

    /**
     * 打款单状态
     */
    @TransitionState
    private PaymentSlipStateEnums state;
    /**
     * 图片组数据
     */
    @TableField(typeHandler = JsonTypeHandler.class)
    private ImageGroupObj imageGroup;
    /**
     * 图片列表
     */
    @TableField(typeHandler = JsonTypeHandler.class)
    private List<String> images;

    /**
     * 核销状态
     */
    private PaymentSlipVerifyStateEnums verifyState;

    /**
     *  创建人业务单元id
     */
    private Integer buId;


    @TableField(exist = false)
    private ITransitionStateEnum transitionStateEnum;
}