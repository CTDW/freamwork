package com.seeease.flywheel_v4.web.domain.purchase.mapping;


import com.seeease.flywheel_v4.web.app.excel.result.PurchaseExportResult;
import com.seeease.flywheel_v4.web.app.purchase.request.PurchaseOrderLineToNormalRequest;
import com.seeease.flywheel_v4.web.app.purchase.result.PurchaseOrderDetailResult;
import com.seeease.flywheel_v4.web.app.purchase.result.PurchaseOrderLinePageResult;
import com.seeease.flywheel_v4.web.app.purchase.result.PurchaseOrderPageResult;
import com.seeease.flywheel_v4.web.infrastructure.config.EnumMapping;
import com.seeease.flywheel_v4.web.infrastructure.config.MappingIgnore;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.entity.PurchaseOrder;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.entity.PurchaseOrderLine;
import com.seeease.flywheel_v4.client.enums.PurchaseTypeEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.MerchantWmsLine;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.WmsCk;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.WmsRk;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.WmsCkTypeEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.WmsRkTypeEnums;
import com.seeease.goods.rpc.enums.SkuNodeStateEnums;
import com.seeease.goods.rpc.request.SkuStateEventSubmitRcpRequest;
import com.seeease.goods.rpc.request.SkuUpdateRpcRequest;
import com.seeease.goods.rpc.result.SkuCreateRpcResult;
import com.seeease.goods.rpc.result.SkuRpcResult;
import com.seeease.seeeaseframework.mybatis.domain.WhetherEnum;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;

import java.util.List;


/**
 * <p>
 * </p>
 *
 * @author 西门 游
 * @since 2023-10-27
 */
@Mapper(componentModel = "spring",
        builder = @Builder(disableBuilder = true),
        nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS,
        nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE,
        imports = {SkuNodeStateEnums.class, PurchaseTypeEnums.class, WmsRkTypeEnums.class, WhetherEnum.class}
)
public interface PurchaseOrderLineMapping extends EnumMapping {

    PurchaseOrderLineMapping INSTANCE = Mappers.getMapper(PurchaseOrderLineMapping.class);

    @Mapping(target = "nodeState", expression = "java(SkuNodeStateEnums.CG_ZT)")
    @Mapping(target = "skuId", source = "sku.id")
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "endState", expression = "java(WhetherEnum.NO)")
    @Mapping(target = "snapSkuCode", source = "sku.skuCode")
    @Mapping(target = "snapAnnexe", source = "sku.annexe")
    PurchaseOrderLine toEntity(SkuCreateRpcResult sku, Integer purchaseId);

    @Mapping(target = "purchasePrice", source = "line.purchasePrice")
    @Mapping(target = "skuParams", source = "skuRpcResult.skuParams")
    @Mapping(target = "nodeState", source = "line.nodeState")
    @Mapping(target = "skuId", source = "skuRpcResult.id")
    @Mapping(target = "lineId", source = "line.id")
    @Mapping(target = "repairPrice", source = "line.repairPrice")
    @Mapping(target = "receiptPrice", source = "line.receiptPrice")
    PurchaseOrderDetailResult.Sku toSkuResult(SkuRpcResult skuRpcResult,
                                              PurchaseOrderLine line);


    @Mapping(target = "skuList", expression = "java(toSkuStateEventRequest(lineList))")
    SkuStateEventSubmitRcpRequest toSkuStateEventRequest(List<PurchaseOrderLine> lineList,
                                                         SkuNodeStateEnums nodeState,
                                                         String serialNo);


    SkuStateEventSubmitRcpRequest.Sku toSkuStateEventRequest(PurchaseOrderLine line);


    List<SkuStateEventSubmitRcpRequest.Sku> toSkuStateEventRequest(List<PurchaseOrderLine> lineList);


    @MappingIgnore
    @Mapping(target = "serialNo", source = "order.serialNo")
    @Mapping(target = "type", source = "type")
    @Mapping(target = "storeId", source = "order.storeId")
    @Mapping(target = "nodeState", expression = "java(SkuNodeStateEnums.DSH)")
    @Mapping(target = "buId", source = "order.buId")
    WmsRk toWmsRk(PurchaseOrderLine line,
                  PurchaseOrder order,
                  WmsRkTypeEnums type);


    @Mapping(target = "id", source = "line.id")
    @Mapping(target = "createdBy", source = "line.createdBy")
    @Mapping(target = "count", source = "line.count")
    PurchaseOrderLinePageResult toPageResult(PurchaseOrderLine line,
                                             PurchaseOrder order,
                                             SkuRpcResult sku);

    @MappingIgnore
    @Mapping(target = "nodeState", source = "nodeState")
    @Mapping(target = "price", source = "line.purchasePrice")
    MerchantWmsLine toMerchantWmsLine(PurchaseOrderLine line,
                                      SkuNodeStateEnums nodeState);

    @MappingIgnore
    @Mapping(target = "expressNo", ignore = true)
    @Mapping(target = "type", source = "type")
    @Mapping(target = "originId", source = "order.buId")
    @Mapping(target = "nodeState", expression = "java(SkuNodeStateEnums.JD)")
    WmsCk toWmsCk(PurchaseOrderLine line,
                  PurchaseOrder order,
                  WmsCkTypeEnums type);

    SkuUpdateRpcRequest toSkuUpdateRequest(PurchaseOrderLine line, PurchaseOrderLineToNormalRequest request);


    @Mapping(target = "purchasePrice", source = "line.purchasePrice")
    @Mapping(target = "repairPrice", source = "line.repairPrice")
    @Mapping(target = "createdBy", source = "line.createdBy")
    @Mapping(target = "createdTime", source = "line.createdTime")
    @Mapping(target = "state", source = "state")
    @Mapping(target = "type", source = "type")
    @Mapping(target = "payType", source = "payType")
    @Mapping(target = "nodeState", source = "nodeState")
    PurchaseExportResult toExportResult(String state,
                                        String type,
                                        String payType,
                                        PurchaseOrderLine line,
                                        SkuRpcResult sku,
                                        String annex,
                                        String param,
                                        PurchaseOrderPageResult order,
                                        String nodeState
    );
}
