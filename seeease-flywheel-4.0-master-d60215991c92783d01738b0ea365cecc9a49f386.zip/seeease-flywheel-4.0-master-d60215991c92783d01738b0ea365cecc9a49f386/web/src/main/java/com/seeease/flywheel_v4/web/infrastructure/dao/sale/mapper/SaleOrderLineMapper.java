package com.seeease.flywheel_v4.web.infrastructure.dao.sale.mapper;

import com.seeease.flywheel_v4.web.infrastructure.dao.sale.entity.SaleOrderLine;
import com.seeease.seeeaseframework.mybatis.SeeeaseMapper;
import org.apache.ibatis.annotations.Param;

import java.math.BigDecimal;

/**
 * @author 西门 游
 * @version 1.0
 * @since 5/31/24 4:53 下午
 **/
public interface SaleOrderLineMapper extends SeeeaseMapper<SaleOrderLine> {

    BigDecimal claSaleConsignmentPrice(@Param("supplierId") Integer supplierId);
}
