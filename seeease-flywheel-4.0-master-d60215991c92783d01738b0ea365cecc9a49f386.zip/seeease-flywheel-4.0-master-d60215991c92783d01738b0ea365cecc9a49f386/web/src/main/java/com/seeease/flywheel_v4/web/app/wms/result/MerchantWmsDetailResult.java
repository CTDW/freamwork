package com.seeease.flywheel_v4.web.app.wms.result;

import com.seeease.goods.rpc.request.SkuAnnexeRpcResult;
import com.seeease.goods.rpc.result.ProductParamRpcResult;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/4/24 6:00 下午
 **/
@Data
public class MerchantWmsDetailResult {
    /**
     * id
     */
    private Integer id;
    /**
     * 业务单号
     */
    private String serialNo;
    /**
     * 状态
     */
    private Integer state;
    /**
     * 类型
     */
    private Integer type;
    /**
     * 金额
     */
    private BigDecimal amount;
    /**
     * 总数量
     */
    private Integer totalCount;
    /**
     * 订单来源
     */
    private String originName;
    /**
     * 收货方
     */
    private String toName;
    /**
     * 发货方
     */
    private String fromName;

    /**
     * 备注
     */
    private String remark;
    /**
     * 取消时间
     */
    private Date cancelTime;
    /**
     * 发货时间
     */
    private Date spTime;
    /**
     * 收货时间
     */
    private Date recTime;

    /**
     * 创建人
     */
    private String createdBy;
    /**
     * 创建时间
     */
    private Date createdTime;
    /**
     * sku列表
     */
    private List<Sku> skuList;

    /**
     * 姓名
     */
    private String name;
    /**
     * 电话
     */
    private String phone;
    /**
     * 地址
     */
    private String address;
    /**
     * 快递单号
     */
    private String expressNo;




    @Data
    public static class Sku{
        /**
         * 调拨业务单据行id
         */
        private Integer lineId;
        /**
         * skuId
         */
        private Integer skuId;
        /**
         * 商品名称
         */
        private String goodsName;
        /**
         * 类目
         */
        private String categoryName;
        /**
         * 货号
         */
        private String goodsCode;
        /**
         * 品牌
         */
        private String brandName;
        /**
         * 节点状态
         */
        private Integer nodeState;
        /**
         * 价格
         */
        private BigDecimal price;
        /**
         * 数量
         */
        private Integer count;
        /**
         * sku参数列表
         */
        private List<ProductParamRpcResult> skuParams;
        /**
         * 附件
         */
        private List<SkuAnnexeRpcResult> annexe;
        /**
         * 唯一码
         */
        private String skuCode;

        /**
         * 图片
         */
        private String spuImage;
        /**
         * 类目id
         */
        private Integer categoryId;

    }
}
