package com.seeease.flywheel_v4.web.app.operations.service;

import com.seeease.flywheel_v4.web.app.operations.request.SupplierQuotaDetailRequest;
import com.seeease.flywheel_v4.web.app.operations.request.SupplierQuotaPageRequest;
import com.seeease.flywheel_v4.web.app.operations.request.SupplierQuotaRequest;
import com.seeease.flywheel_v4.web.app.operations.request.SupplierQuotaReturnRequest;
import com.seeease.flywheel_v4.web.app.operations.result.SupplierQuotaDetailResult;
import com.seeease.flywheel_v4.web.app.operations.result.SupplierQuotaPageResult;
import com.seeease.flywheel_v4.web.app.operations.result.SupplierQuotaResult;
import com.seeease.springframework.PageResult;

/**
 * <p>供应商</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/4/24 4:43 下午
 **/
public interface SupplierQuotaService {


    /**
     * 系统运营-供应商余额列表
     *
     * @return 列表结果
     */
    PageResult<SupplierQuotaPageResult> page(SupplierQuotaPageRequest request);

    /**
     * 系统运营-供应商余额详情
     *
     * @return 详情结果
     */
    SupplierQuotaDetailResult detail(SupplierQuotaDetailRequest request);

    /**
     * 系统运营-供应商余额退款
     *
     * @return 退款结果
     */
    Boolean returnAmount(SupplierQuotaReturnRequest request);

    /**
     * 系统运营-供应商余额查询
     *
     * @return 结果
     */
    SupplierQuotaResult findOne(SupplierQuotaRequest request);
}
