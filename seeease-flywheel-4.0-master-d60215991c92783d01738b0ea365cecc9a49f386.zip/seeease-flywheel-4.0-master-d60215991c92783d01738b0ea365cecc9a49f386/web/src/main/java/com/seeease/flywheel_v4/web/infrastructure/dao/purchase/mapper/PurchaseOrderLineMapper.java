package com.seeease.flywheel_v4.web.infrastructure.dao.purchase.mapper;

import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.entity.PurchaseOrderLine;
import com.seeease.seeeaseframework.mybatis.SeeeaseMapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author 西门 游
 * @version 1.0
 * @since 5/31/24 4:53 下午
 **/
public interface PurchaseOrderLineMapper extends SeeeaseMapper<PurchaseOrderLine> {



    /**
     * 统计
     * @param purchaseIdList 采购订单id列表逗号分格
     * @param nodeStatesList 节点状态列表逗号分割
     * @return
     */
    @Select("SELECT node_state, SUM(`count`) AS count " +
            " FROM v4_purchase_order_line " +
            " where node_state in (${states}) and purchase_id in (${pids})" +
            " GROUP BY node_state")
    List<Map<String, Object>> statistics(@Param("pids") String purchaseIdList,
                                         @Param("states") String nodeStatesList);

    /**
     * 转换 {@link #statistics(String,String)} 返回结果为map
     * @param purchaseIdList  采购订单id
     * @return
     */
    default Map<String,Integer> statisticsAdapt(String purchaseIdList,String nodeStatesList){
        List<Map<String, Object>> mapList = statistics(purchaseIdList,nodeStatesList);
        Map<String, Integer> countMap = new HashMap<>();
        for (Map<String, Object> map : mapList) {

            countMap.put(String.valueOf(map.get("node_state")), ((BigDecimal)map.get("count")).intValue());
        }
        return countMap;
    }


}
