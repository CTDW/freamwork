package com.seeease.flywheel_v4.web.domain.excel.core;


import com.alibaba.cola.extension.BizScenario;
import com.alibaba.cola.extension.ExtensionExecutor;
import io.seata.spring.annotation.GlobalTransactional;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import java.util.List;

/**
 * @author Tiro
 * @date 2023/3/30
 */
@Component
public class ExcelCmdExe {
    @Resource
    private ExtensionExecutor extensionExecutor;

    /**
     * 导入
     */
    @GlobalTransactional
    @SuppressWarnings("unchecked")
    public <T,R> List<R> handleImport(ImportCmd<T> cmd, MultipartFile file) {
        BizScenario bizScenario = BizScenario.valueOf(cmd.getBizCode(), cmd.getUseCase());
        // 执行参数转换
        List<T> data = extensionExecutor.execute(ImportExtPtl.class, bizScenario, extension -> extension.convert(file));
        // 执行参数校验
        extensionExecutor.executeVoid(ImportExtPtl.class, bizScenario, extension -> extension.validate(data));
        // 执行参数校验
        return extensionExecutor.execute(ImportExtPtl.class, bizScenario, extension -> extension.handle(data));
    }

    /**
     * 导出
     */
    @SuppressWarnings("unchecked")
    public <T>void handleExport(ExportCmd<T> cmd) {
        BizScenario bizScenario = BizScenario.valueOf(cmd.getBizCode(), cmd.getUseCase());
        // 执行参数转换
        Object param = extensionExecutor.execute(ExportExtPtl.class, bizScenario, extension -> extension.convert(cmd));
        // 执行逻辑
        List<?> result = extensionExecutor.execute(ExportExtPtl.class, bizScenario, extension -> extension.handle(param));
        // 写入excel
        extensionExecutor.executeVoid(ExportExtPtl.class,bizScenario,extension -> extension.write(result,cmd.getResponse()));
    }
}
