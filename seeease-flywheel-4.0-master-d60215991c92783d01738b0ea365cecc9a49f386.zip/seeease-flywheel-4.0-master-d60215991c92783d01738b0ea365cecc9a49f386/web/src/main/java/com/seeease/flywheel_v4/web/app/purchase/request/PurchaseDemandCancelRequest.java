package com.seeease.flywheel_v4.web.app.purchase.request;


import lombok.Data;

import javax.validation.constraints.NotEmpty;
import java.util.Date;
import java.util.Set;


@Data
public class PurchaseDemandCancelRequest {
    /**
     * 主键id列表
     */
    @NotEmpty(message = "ids不能为空")
    private Set<Integer> idList;

}
