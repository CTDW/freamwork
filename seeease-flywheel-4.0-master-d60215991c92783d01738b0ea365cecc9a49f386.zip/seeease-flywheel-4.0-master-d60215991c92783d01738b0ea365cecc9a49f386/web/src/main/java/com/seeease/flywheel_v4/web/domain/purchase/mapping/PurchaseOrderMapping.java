package com.seeease.flywheel_v4.web.domain.purchase.mapping;


import com.seeease.flywheel_v4.web.app.purchase.request.PurchaseOrderSubmitRequest;
import com.seeease.flywheel_v4.web.app.purchase.result.PurchaseOrderDetailResult;
import com.seeease.flywheel_v4.web.app.purchase.result.PurchaseOrderPageResult;
import com.seeease.flywheel_v4.web.infrastructure.config.EnumMapping;
import com.seeease.flywheel_v4.web.infrastructure.config.MappingIgnore;
import com.seeease.flywheel_v4.web.infrastructure.dao.finance.entity.FinancePaymentSlip;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.Supplier;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.SupplierContacts;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.entity.PurchaseOrder;
import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.entity.SysUser;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.MerchantWms;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.obj.ContactInfo;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.MerchantWmsModelEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.MerchantWmsTypeEnums;
import com.seeease.flywheel_v4.web.util.SerialNoGenerator;
import com.seeease.goods.rpc.request.PurchaseSkuCreateRpcRequest;
import com.seeease.seeeaseframework.mybatis.domain.WhetherEnum;
import com.seeease.springframework.utils.MultiUtils;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;

import java.math.BigDecimal;
import java.util.List;


/**
 * <p>
 * </p>
 *
 * @author 西门 游
 * @since 2023-10-27
 */
@Mapper(componentModel = "spring",
        builder = @Builder(disableBuilder = true),
        nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS,
        nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE
        , imports = {SerialNoGenerator.class,
        SerialNoGenerator.Type.class, MultiUtils.class, MerchantWmsTypeEnums.class}
)
public interface PurchaseOrderMapping extends EnumMapping {

    PurchaseOrderMapping INSTANCE = Mappers.getMapper(PurchaseOrderMapping.class);


    @Mapping(target = "sellerId", source = "request.storeId")
    @Mapping(target = "purchaseType", source = "request.type")
    @Mapping(target = "skuList", expression = "java(MultiUtils.toList(request.getSkuList(),this::toSkuRpcCreateSkuRequest))")
    PurchaseSkuCreateRpcRequest toSkuRpcCreateRequest(PurchaseOrderSubmitRequest request,
                                                      Integer psOriginId,
                                                      String serialNo,
                                                      WhetherEnum locked
    );

    @Mapping(target = "skuParams", source = "request.skuParamMap")
    PurchaseSkuCreateRpcRequest.Sku toSkuRpcCreateSkuRequest(PurchaseOrderSubmitRequest.Sku request);


    @Mapping(target = "serialNo", expression = "java(SerialNoGenerator.generalSerial(SerialNoGenerator.Type.CG))")
    PurchaseOrder toEntity(PurchaseOrderSubmitRequest request,
                           int totalCount,
                           BigDecimal totalPrice,
                           String saleSerialNo,
                           String newSaleSerialNo,
                           BigDecimal diff
    );

    PurchaseOrderPageResult toPageResult(PurchaseOrder order,
                                         String supplierName,
                                         String buyerName,
                                         String merchantName,
                                         String purchaseSubjectName,
                                         String storeName
    );

    @Mapping(target = "id", source = "purchaseOrder.id")
    @Mapping(target = "state", source = "purchaseOrder.state")
    @Mapping(target = "createdBy", source = "purchaseOrder.createdBy")
    @Mapping(target = "createdTime", source = "purchaseOrder.createdTime")
    @Mapping(target = "type", expression = "java(purchaseOrder.getType().getValue())")
    @Mapping(target = "remark", source = "purchaseOrder.remark")
    @Mapping(target = "supplierId", source = "purchaseOrder.supplierId")
    @Mapping(target = "supplierName", source = "supplier.name")
    @Mapping(target = "supplierAddress", expression = "java(supplier.getCompleteAddress())")
    @Mapping(target = "supplierContact", expression = "java(toCustomerContact(contacts))")
    @Mapping(target = "buyerName", source = "buyer.name")
    PurchaseOrderDetailResult toDetailResult(
            PurchaseOrder purchaseOrder,
            boolean toStore,
            Supplier supplier,
            SupplierContacts contacts,
            String storeName,
            String purchaseSubjectName,
            String merchantName,
            String pricerName,
            String demandSerialNo,
            List<PurchaseOrderDetailResult.Sku> skuList,
            SysUser buyer
    );

    PurchaseOrderDetailResult.SupplierContacts toCustomerContact(SupplierContacts contacts);


    @MappingIgnore
    @Mapping(target = "fpsId", source = "paymentSlip.id")
    @Mapping(target = "fpsSerialNo", source = "paymentSlip.serialNo")
    @Mapping(target = "serialNo", ignore = true)
    @Mapping(target = "state", ignore = true)
    void toEntityForUpdate(@MappingTarget PurchaseOrder purchaseOrder,
                           FinancePaymentSlip paymentSlip);

    @Mapping(target = "address", expression = "java(supplier.getCompleteAddress())")
    ContactInfo toMerchantWmsContactInfo(Supplier supplier);

    @MappingIgnore
    @Mapping(target = "state", ignore = true)
    @Mapping(target = "remark", ignore = true)
    @Mapping(target = "transitionStateEnum", ignore = true)
    @Mapping(target = "amount", source = "order.totalPrice")
    @Mapping(target = "toId", source = "order.storeId")
    @Mapping(target = "type", source = "type")
    @Mapping(target = "originId", source = "order.buId")
    MerchantWms toMerchantWms(PurchaseOrder order,
                              ContactInfo contactInfo,
                              MerchantWmsTypeEnums type,
                              MerchantWmsModelEnums model);


}
