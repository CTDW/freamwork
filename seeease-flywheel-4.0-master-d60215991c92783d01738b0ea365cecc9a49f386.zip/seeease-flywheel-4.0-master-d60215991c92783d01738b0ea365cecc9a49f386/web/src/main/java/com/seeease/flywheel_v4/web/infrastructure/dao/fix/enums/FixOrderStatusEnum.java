package com.seeease.flywheel_v4.web.infrastructure.dao.fix.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @Description 维修单-维修单状态
 * @Date 2024-10-5 22:21
 * @Author by hk
 */
@Getter
@AllArgsConstructor
public enum FixOrderStatusEnum {

    /**
     * 1：维修登记 2：待接修 3：维修中 4：抛光中 5：清洗中 6：师傅组装 7：质检中 " +
     * * "8：待维修出库 9：送外维修 10：等配件 11：已完成 12:已取消
     */

    REGISTER("维修登记", 1, ""),
    WAIT_REPAIR("待接修", 2, ""),
    FIX_ING("维修中", 3, "维修中"),
    POLISHING("抛光中", 4, "抛光任务"),
    CLEANING("清洗中", 5, "清洗任务"),
    INSTALL("师傅组装", 6, "组装任务"),
    QUALITY_CHECK("质检中", 7, "质检任务"),
    WAIT_OUT_STOCK("待维修出库", 8, "待维修出库"),
    SEND_OUT_FIX("送外维修", 9, "送外维修"),
    WAIT_PART("等配件", 10, "等配件"),
    HAS_COMPLETE("已完成", 11, ""),
    HAS_CHANCEL("已取消", 12, ""),

    UNDEFINED("未知", -1, ""),

    ;

    private String name;
    private Integer value;
    private String taskName;

    public static FixOrderStatusEnum parse(Integer value) {
        for (FixOrderStatusEnum orderStatus : FixOrderStatusEnum.values()) {
            if (orderStatus.getValue().equals(value)) {
                return orderStatus;
            }
        }
        return UNDEFINED;
    }

    public static boolean canNotFallBack(Integer orderStatus) {
        // 维修登记 已取消 已完成  无法回退
        return orderStatus.equals(REGISTER.getValue())
                || orderStatus.equals(HAS_COMPLETE.getValue())
                || orderStatus.equals(HAS_CHANCEL.getValue());
    }

    public static boolean canNotJump(Integer orderStatus) {
        // 维修登记 已取消 已完成  无法跳过
        return orderStatus.equals(REGISTER.getValue())
                || orderStatus.equals(HAS_COMPLETE.getValue())
                || orderStatus.equals(HAS_CHANCEL.getValue());
    }

}
