package com.seeease.flywheel_v4.web.app.sale.request;


import lombok.Data;


@Data
public class ToBSaleReturnOrderDetailRequest {

    /**
     * 单号
     */
    private String serialNo;
    /**
     * 主键id
     */
    private Integer id;


}
