package com.seeease.flywheel_v4.web;

import com.seeease.framework.EnableOss;
import com.seeease.framework.EnableRedis;
import com.seeease.springframework.log.annotation.EnableLogPrint;
import org.apache.dubbo.config.spring.context.annotation.EnableDubbo;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;




@EnableDubbo
@MapperScan("com.seeease.flywheel_v4.web.infrastructure.dao.*.mapper")
@EnableDiscoveryClient
@SpringBootApplication
@EnableLogPrint
@EnableRedis(useCache = true)
@EnableOss
public class WebApplication {

    public static void main(String[] args) {
        System.setProperty("nacos.logging.default.config.enabled", "false");
        SpringApplication.run(WebApplication.class, args);
    }

}
