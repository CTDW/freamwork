package com.seeease.flywheel_v4.web.app.purchase.result;


import com.seeease.goods.rpc.request.SkuAnnexeRpcResult;
import com.seeease.goods.rpc.result.ProductParamRpcResult;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * @ Description   :
 * @ Author        :  西门 游
 * @ CreateDate    :  6/6/24
 * @ Version       :  1.0
 */

@Data
public class PurchaseOrderDetailResult {

    /**
     * id
     */
    private Integer id;
    /**
     * 是否推送仓库wms true为是
     */
    private Boolean toStore;
    /**
     * 采购单号
     */
    private String serialNo;
    /**
     * 采购单状态
     */
    private Integer state;
    /**
     * 创建人
     */
    private String createdBy;
    /**
     * 差额
     */
    private BigDecimal diff;

    /**
     * 回购销售单号
     */
    private String saleSerialNo;
    /**
     * 置换销售单号
     */
    private String newSaleSerialNo;

    /**
     * 采购主题名称
     */
    private String purchaseSubjectName;
    /**
     * 采购类型
     */
    private Integer type;
    /**
     * 仓库名称
     */
    private String storeName;

    /**
     * 采购人名称
     */
    private String buyerName;

    /**
     * 打款方式
     */
    private Integer payType;
    /**
     * 申请打款单号
     */
    private String fpsSerialNo;
    /**
     * 申请打款单号 ,分割
     */
    private String demandSerialNo;
    /**
     * 创建时间
     */
    private Date createdTime;
    /**
     * 图片信息
     */
    private List<String> images;
    /**
     * 快递单号
     */
    private String expressNo;
    /**
     * 商家名称
     */
    private String merchantName;
    /**
     * 备注
     */
    private String remark;
    /**
     * 供应商id
     */
    private Integer supplierId;
    /**
     * 供应商名称
     */
    private String supplierName;
    /**
     * 供应商联系人id
     */
    private Integer supplierContactId;
    /**
     * 供应商地址
     */
    private String supplierAddress;
    /**
     * 供应商联系人数据
     */
    private SupplierContacts supplierContact;

    /**
     * 总数量
     */
    private Integer totalCount;

    /**
     * 入库时实际的收货数量
     */
    private Integer actualCount;
    /**
     * 采购总金额
     */
    private BigDecimal totalPrice;
    /**
     * 定价方名称
     */
    private String pricerName;
    /**
     * sku列表数据
     */
    private List<Sku> skuList;

    /**
     * 付款比例
     */
    private BigDecimal payRatio;


    @Data
    public static class Sku {
        /**
         * 采购业务单据行id
         */
        private Integer lineId;
        /**
         * 收货价
         */
        private BigDecimal receiptPrice;
        /**
         * skuId
         */
        private Integer skuId;
        /**
         * spuId
         */
        private Integer spuId;
        /**
         * 商品名称
         */
        private String goodsName;
        /**
         * 类目
         */
        private String categoryName;
        /**
         * 品牌
         */
        private String brandName;
        /**
         * 唯一码类型
         */
        private Integer uniqueType;
        /**
         * 节点状态
         */
        private Integer nodeState;
        /**
         * 采购价
         */
        private BigDecimal purchasePrice;
        /**
         * 采购数量
         */
        private Integer count;
        /**
         * 收货数量
         */
        private Integer actualCount;
        /**
         * sku参数列表
         */
        private List<ProductParamRpcResult> skuParams;
        /**
         * 附件
         */
        private List<SkuAnnexeRpcResult> annexe;
        /**
         * 唯一码
         */
        private String skuCode;

        /**
         * 附件快照
         */
        private List<SkuAnnexeRpcResult> snapAnnexe;

        /**
         * sku唯一码快照
         */
        private String snapSkuCode;


        /**
         * 图片
         */
        private String spuImage;
        /**
         * 类目id
         */
        private Integer categoryId;
        /**
         * 表带根换费
         */
        private BigDecimal strapPrice;
        /**
         * 维修价格
         */
        private BigDecimal repairPrice;
        /**
         * 回购价
         */
        private BigDecimal buybackPrice;
    }


    @Data
    public static class SupplierContacts {
        /**
         * id
         */
        private Integer id;
        /**
         * 供应商id
         */
        private Integer supplierId;



        /**
         * 联系人名称
         */
        private String name;
        /**
         * 联系人电话
         */
        private String phone;
        /**
         * 联系人银行
         */
        private String bank;
        /**
         * 联系人银行账号
         */
        private String account;
        /**
         * 联系人开户行
         */
        private String bankName;
        /**
         * 银行转账户名
         */
        private String accountName;

    }


}
