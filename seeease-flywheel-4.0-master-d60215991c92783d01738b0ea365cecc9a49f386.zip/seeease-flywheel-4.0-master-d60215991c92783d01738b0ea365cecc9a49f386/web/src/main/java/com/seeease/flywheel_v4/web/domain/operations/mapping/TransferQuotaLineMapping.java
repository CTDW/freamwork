package com.seeease.flywheel_v4.web.domain.operations.mapping;


import com.seeease.flywheel_v4.client.enums.BusinessUnitTypeEnums;
import com.seeease.flywheel_v4.web.app.operations.request.TransferQuotaLineSubmitRequest;
import com.seeease.flywheel_v4.web.app.operations.request.TransferQuotaSubmitRequest;
import com.seeease.flywheel_v4.web.app.operations.result.TransferQuotaLineListResult;
import com.seeease.flywheel_v4.web.infrastructure.config.EnumMapping;
import com.seeease.flywheel_v4.web.infrastructure.config.MappingIgnore;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.TransferQuota;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.TransferQuotaLine;
import com.seeease.goods.rpc.enums.SkuRunTypeEnums;
import com.seeease.springframework.utils.MultiUtils;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;


/**
 * <p>

 * </p>
 *
 * @author 西门 游
 * @since 2023-10-27
 */
@Mapper(componentModel = "spring",
        builder = @Builder(disableBuilder = true),
        nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS,
        nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE,
        imports = {BusinessUnitTypeEnums.class})
public interface TransferQuotaLineMapping extends EnumMapping {

    TransferQuotaLineMapping INSTANCE = Mappers.getMapper(TransferQuotaLineMapping.class);

    @Mapping(target = "tsqId",source = "transferQuota.id")
    @MappingIgnore
    TransferQuotaLine toEntity(TransferQuotaLineSubmitRequest quota,
                               TransferQuota transferQuota,
                               SkuRunTypeEnums type);

    default List<TransferQuotaLine> toEntity(TransferQuotaSubmitRequest request, TransferQuota transferQuota){
        List<TransferQuotaLine> ctList = MultiUtils.toList(
                request.getCtQuotas(),
                v -> TransferQuotaLineMapping.INSTANCE.toEntity(v, transferQuota, SkuRunTypeEnums.DX)
        );
        List<TransferQuotaLine> osList = MultiUtils.toList(
                request.getOsQuotas(),
                v -> TransferQuotaLineMapping.INSTANCE.toEntity(v, transferQuota, SkuRunTypeEnums.YH)
        );

        ArrayList<TransferQuotaLine> ret = new ArrayList<>();
        ret.addAll(ctList);
        ret.addAll(osList);
        return ret;
    }

    @Mapping(target = "quota",ignore = true)
    void copy(@MappingTarget TransferQuotaLine newLine, TransferQuotaLine oldLine);


    @Mapping(target = "runType",source = "line.type")
    TransferQuotaLineListResult toListResult(
            BigDecimal usedQuota,
            String brandName,
            String categoryName,
            TransferQuotaLine line
    );
}
