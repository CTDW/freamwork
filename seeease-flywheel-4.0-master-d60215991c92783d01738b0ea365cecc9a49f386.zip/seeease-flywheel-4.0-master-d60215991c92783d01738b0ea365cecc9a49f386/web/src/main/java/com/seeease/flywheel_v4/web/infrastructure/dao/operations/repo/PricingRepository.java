package com.seeease.flywheel_v4.web.infrastructure.dao.operations.repo;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.seeease.flywheel_v4.web.app.operations.request.PricingPageRequest;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.Pricing;

import java.util.List;
import java.util.Set;

/**
 *
 * @author 西门 游
 * @version 1.0
 * @since 5/31/24 4:55 下午
 **/
public interface PricingRepository {

    /**
     * 提交
     * @param pricing
     * @return
     */
    Boolean submit(Pricing pricing);

    /**
     * 分页查询
     * @param request
     * @param skuIdList
     * @return
     */
    Page<Pricing> page(PricingPageRequest request, Set<Integer> skuIdList);

    /**
     * 查找
     * @param id
     */
    Pricing findById(Integer id);

    /**
     * 统计
     *  元素 0待定价数量 1待审核数量 2已定价数量
     * @param request
     * @param skuIdList
     * @return
     */
    List<Integer> statics(PricingPageRequest request, Set<Integer> skuIdList);


    /**
     * 提交
     * @param list
     */
    void submitBatch(List<Pricing> list);

    /**
     * 查找
     * @param skuIdList
     * @return
     */
    List<Pricing> listBySkuIds(Set<Integer> skuIdList);

    /**
     * 查找
     * @param ids
     * @return
     */
    List<Pricing> listByIds(Set<Integer> ids);
}
