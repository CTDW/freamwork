package com.seeease.flywheel_v4.web.infrastructure.dao.sale.mapper;

import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.entity.PurchaseAftersaleLine;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.entity.SaleOrder;
import com.seeease.seeeaseframework.mybatis.SeeeaseMapper;

/**
 * @author 西门 游
 * @version 1.0
 * @since 5/31/24 4:53 下午
 **/
public interface SaleOrderMapper extends SeeeaseMapper<SaleOrder> {
}
