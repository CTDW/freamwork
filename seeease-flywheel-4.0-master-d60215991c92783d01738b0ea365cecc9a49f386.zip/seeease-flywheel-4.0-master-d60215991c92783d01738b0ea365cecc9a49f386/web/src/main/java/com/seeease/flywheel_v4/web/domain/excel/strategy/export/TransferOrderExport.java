package com.seeease.flywheel_v4.web.domain.excel.strategy.export;

import com.alibaba.cola.extension.Extension;
import com.seeease.flywheel_v4.web.app.excel.result.TransferOrderExportResult;
import com.seeease.flywheel_v4.web.app.transfer.request.TransferPageRequest;
import com.seeease.flywheel_v4.web.app.transfer.result.TransferPageResult;
import com.seeease.flywheel_v4.web.app.transfer.service.TransferService;
import com.seeease.flywheel_v4.web.domain.excel.ExcelDomain;
import com.seeease.flywheel_v4.web.domain.excel.core.ExportExtPtl;
import com.seeease.flywheel_v4.web.domain.transfer.mapping.TransferOrderMapping;
import com.seeease.flywheel_v4.web.infrastructure.dao.RepositoryFactory;
import com.seeease.flywheel_v4.web.infrastructure.dao.transfer.entity.TransferOrderLine;
import com.seeease.flywheel_v4.web.infrastructure.dao.transfer.enums.TransferStateEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.transfer.enums.TransferTypeEnums;
import com.seeease.goods.rpc.SkuFacade;
import com.seeease.goods.rpc.request.SkuRpcRequest;
import com.seeease.goods.rpc.result.SkuRpcResult;
import com.seeease.seeeaseframework.mybatis.utils.EnumUtils;
import com.seeease.springframework.utils.MultiUtils;
import org.apache.dubbo.config.annotation.DubboReference;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 9/12/24 10:42 上午
 **/
@Service
@Extension(bizId = "export", useCase = "transferOrder")
public class TransferOrderExport implements ExportExtPtl<TransferPageRequest, TransferOrderExportResult> {

    @Resource
    private TransferService transferService;
    @Resource
    private RepositoryFactory repositoryFactory;
    @DubboReference(version = "1.0.0", check = false)
    private SkuFacade skuFacade;
    @Resource
    private ExcelDomain excelDomain;

    @Override
    public Class<TransferPageRequest> getRequestClass() {
        return TransferPageRequest.class;
    }

    @Override
    public Class<TransferOrderExportResult> getResultClass() {
        return TransferOrderExportResult.class;
    }

    @Override
    public String getFileName() {
        return "调拨导出";
    }

    @Override
    public List<TransferOrderExportResult> handle(TransferPageRequest request) {
        //step_1 调用调拨单分页查询
        request.setLimit(Integer.MAX_VALUE);
        List<TransferPageResult> list = transferService.page(request).getResult();
        if (list.isEmpty()){
            return Collections.emptyList();
        }
        Map<Integer, TransferPageResult> orderMap = MultiUtils.toMap(
                list,
                TransferPageResult::getId
        );

        //step_2 查询调拨单行
        Set<Integer> transferIds = MultiUtils.toSet(list, TransferPageResult::getId);
        List<TransferOrderLine> lineList = repositoryFactory.getTransferOrderLineRepository()
                .listByTransferIds(transferIds);


        //step_3 sku查询
        Set<Integer> skuIds = MultiUtils.toSet(lineList, TransferOrderLine::getSkuId);
        SkuRpcRequest rpcRequest = new SkuRpcRequest();
        rpcRequest.setIdList(skuIds);
        Map<Integer, SkuRpcResult> skuMap = MultiUtils.toMap(
                skuFacade.list(rpcRequest),
                SkuRpcResult::getId
        );

        //step_4 数组组合
        return MultiUtils.toList(
                lineList,
                line ->{
                    TransferPageResult order = orderMap.get(line.getTransferId());
                    SkuRpcResult sku = skuMap.get(line.getSkuId());

                    String state = EnumUtils.of(TransferStateEnums.class,order.getState()).getDesc();
                    String type = EnumUtils.of(TransferTypeEnums.class,order.getType()).getDesc();
                    String nodeState = line.getNodeState().getDesc();
                    String annexe = excelDomain.joinAnnexe(sku.getAnnexe());
                    String param = excelDomain.joinParam(sku.getSkuParams());

                    return TransferOrderMapping.INSTANCE.toExportResult(
                            line,
                            order,
                            sku,
                            state,
                            nodeState,
                            annexe,
                            param,
                            type
                    );
                }
        );


    }
}
