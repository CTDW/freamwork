package com.seeease.flywheel_v4.web.domain.wms.observer;

import com.google.common.collect.Lists;
import com.seeease.flywheel_v4.client.enums.BusinessUnitTypeEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.RepositoryFactory;
import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.entity.SysBusinessUnit;
import com.seeease.flywheel_v4.web.infrastructure.dao.transfer.entity.TransferOrder;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.MerchantWmsTypeEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.WmsCkTypeEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.WmsRkTypeEnums;
import com.seeease.goods.rpc.enums.SkuNodeStateEnums;
import com.seeease.springframework.context.UserContext;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 7/26/24 2:40 下午
 **/
@Component
public class TransferBaseObserver {
    @Resource
    private RepositoryFactory repositoryFactory;

    /**
     * 仓库端wms 出库观察者类型
     */
    protected final List<WmsCkTypeEnums> wmsCkWatchTypeList = Lists.newArrayList(
            WmsCkTypeEnums.DB
    );


    /**
     * 仓库端wms 入库观察者类型
     */
    protected final ArrayList<WmsRkTypeEnums> wmsRkWatchTypeList = Lists.newArrayList(
            WmsRkTypeEnums.DB,
            WmsRkTypeEnums.DB_JS
    );

    /**
     * 商家端wms 出库观察的类型
     */
    protected final List<MerchantWmsTypeEnums> merchantWmsCkWatchTypeList = Lists.newArrayList(
            MerchantWmsTypeEnums.DB_CK
    );

    /**
     * 商家端wms 入库观察的类型
     */
    protected final List<MerchantWmsTypeEnums> merchantWmsRkWatchTypeList = Lists.newArrayList(
            MerchantWmsTypeEnums.DB_RK,
            MerchantWmsTypeEnums.DB_JS
    );


    /**
     * 商家wms 支持的入库操作
     */
    protected final ArrayList<SkuNodeStateEnums> merchantCondition = Lists.newArrayList(
            SkuNodeStateEnums.QX,
            SkuNodeStateEnums.YRK
    );



    /**
     * 仓库wms 支持的入库操作
     */
    protected final ArrayList<SkuNodeStateEnums> storeCondition = Lists.newArrayList(
            SkuNodeStateEnums.SW_BF,
            SkuNodeStateEnums.ZJZ,
            SkuNodeStateEnums.DRK,
            SkuNodeStateEnums.YRK
    );


    /**
     * 判断入库方取消（该取消状态 可能为 SkuNodeStateEnums.JS || SkuNodeStateEnums.SW_BF 产生 ）
     * 状态下 推送新的入库单到门店还是到商家
     *
     * @param order 调拨单
     * @return
     */
    public boolean pushToStore(TransferOrder order) {

        boolean pushToStore = false;
        Integer currentBuId = UserContext.getUser().getStore().getId();
        //当前操作人属于的业务单元类型
        SysBusinessUnit currentBu = repositoryFactory.getBusinessUnitRepository().findById(currentBuId);
        //调入方的业务单元类型
        SysBusinessUnit to = repositoryFactory.getBusinessUnitRepository().findById(order.getToId());
        //调出方的业务单元类型
        SysBusinessUnit from = repositoryFactory.getBusinessUnitRepository().findById(order.getFromId());


        //当前操作人属于调出方
        if (currentBu.getType() == from.getType()) {
            //并且调入方业务单元类型归属于仓库 则推送至仓库
            if (to.getType() == BusinessUnitTypeEnums.WAREHOUSE) {
                pushToStore = true;
            }
        }
        //当前操作人属于调入方
        else {
            //并且调出方业务单元类型归属于仓库 则推送至仓库
            if (from.getType() == BusinessUnitTypeEnums.WAREHOUSE) {
                pushToStore = true;
            }
        }
        return pushToStore;
    }


}
