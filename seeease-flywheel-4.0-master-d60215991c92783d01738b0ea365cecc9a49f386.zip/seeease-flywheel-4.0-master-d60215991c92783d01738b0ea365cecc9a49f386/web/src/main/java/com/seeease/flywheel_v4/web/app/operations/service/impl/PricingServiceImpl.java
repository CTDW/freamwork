package com.seeease.flywheel_v4.web.app.operations.service.impl;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.google.common.collect.Lists;
import com.seeease.flywheel_v4.web.app.operations.request.PricingBatchPassRequest;
import com.seeease.flywheel_v4.web.app.operations.request.PricingDetailRequest;
import com.seeease.flywheel_v4.web.app.operations.request.PricingPageRequest;
import com.seeease.flywheel_v4.web.app.operations.request.PricingStateRequest;
import com.seeease.flywheel_v4.web.app.operations.result.PricingDetailResult;
import com.seeease.flywheel_v4.web.app.operations.result.PricingPageResult;
import com.seeease.flywheel_v4.web.app.operations.service.PricingService;
import com.seeease.flywheel_v4.web.domain.operations.mapping.PricingMapping;
import com.seeease.flywheel_v4.web.infrastructure.dao.RepositoryFactory;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.Pricing;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.Supplier;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.SupplierContacts;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.enums.PricingStateEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.entity.PurchaseOrder;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.entity.PurchaseOrderLine;
import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.entity.SysBusinessUnit;
import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.entity.SysUser;
import com.seeease.goods.rpc.SkuFacade;
import com.seeease.goods.rpc.request.SkuPricingRpcRequest;
import com.seeease.goods.rpc.request.SkuRpcRequest;
import com.seeease.goods.rpc.result.SkuRpcResult;
import com.seeease.seeeaseframework.mybatis.utils.EnumUtils;
import com.seeease.springframework.PageResult;
import com.seeease.springframework.context.UserContext;
import com.seeease.springframework.exception.ValidationUtil;
import com.seeease.springframework.utils.MultiUtils;
import com.seeease.springframework.utils.StringUtils;
import io.seata.spring.annotation.GlobalTransactional;
import org.apache.dubbo.config.annotation.DubboReference;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.*;
import java.util.function.Function;

/**
 * <p>供应商</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/4/24 4:43 下午
 **/
@Service
public class PricingServiceImpl implements PricingService {
    @Resource
    private RepositoryFactory repositoryFactory;
    @DubboReference(version = "1.0.0", check = false)
    private SkuFacade skuFacade;

    @Override
    public PageResult<PricingPageResult> page(PricingPageRequest request) {

        //元素 0待定价数量 1待审核数量 2已定价数量
        List<Integer> statics = Lists.newArrayList(0, 0, 0);


        //sku查询
        Set<Integer> skuIdList = null;
        List<SkuRpcResult> skuList = null;

        if (StringUtils.oneOfNonNull(
                request.getGoodsName(),
                request.getSkuCode(),
                request.getPurchaseType(),
                request.getBrandId()
        )) {
            SkuRpcRequest rpcRequest = PricingMapping.INSTANCE.toSkuRpcRequest(request);
            skuList = skuFacade.list(rpcRequest);

            if (skuList.isEmpty()) {
                return PageResult.buildEmpty(statics);
            }

            skuIdList = MultiUtils.toSet(skuList, SkuRpcResult::getId);
        }


        //主表分页查询
        Page<Pricing> page = repositoryFactory.getPricingRepository().page(request, skuIdList);
        //数据统计
        statics = repositoryFactory.getPricingRepository().statics(request, skuIdList);


        if (page.getRecords().isEmpty()) {
            return PageResult.buildEmpty(statics);
        }

        //sku数据
        if (skuList == null) {
            skuIdList = MultiUtils.toSet(page.getRecords(), Pricing::getSkuId);
            SkuRpcRequest rpcRequest = new SkuRpcRequest();
            rpcRequest.setIdList(skuIdList);
            skuList = skuFacade.list(rpcRequest);
        }
        Map<Integer, SkuRpcResult> skuMap = MultiUtils.toMap(skuList, SkuRpcResult::getId, Function.identity());


        //采购单行数据
        Set<Integer> purchaseIdList = MultiUtils.toSet(page.getRecords(), Pricing::getPurchaseId);
        Map<Integer, Integer> purchaseOrderLineMap = MultiUtils.toMap(
                repositoryFactory.getPurchaseOrderLineRepository().listByPurchaseIds(purchaseIdList),
                PurchaseOrderLine::getSkuId,
                PurchaseOrderLine::getCount
        );

        //审核人
        Set<Integer> reviewIdList = MultiUtils.toSet(page.getRecords(), Pricing::getReviewerId);
        Map<Integer, String> reviewerMap = MultiUtils.toMap(
                repositoryFactory.getUserRepository().listByIds(reviewIdList),
                SysUser::getId,
                SysUser::getName
        );


        //商家名称
        Set<Integer> merchantIdList = MultiUtils.toSet(skuList, SkuRpcResult::getMerchantId);
        Map<Integer, String> merchantMap = MultiUtils.toMap(
                repositoryFactory.getBusinessUnitRepository().listByIds(merchantIdList),
                SysBusinessUnit::getId,
                SysBusinessUnit::getName
        );


        //组合数据
        List<PricingPageResult> ret = MultiUtils.toList(
                page.getRecords(),
                v -> {
                    SkuRpcResult sku = skuMap.get(v.getSkuId());
                    String merchantName = merchantMap.get(sku.getMerchantId());
                    Integer count = purchaseOrderLineMap.get(sku.getId());
                    String reviewer = null != v.getReviewerId() ? reviewerMap.get(v.getReviewerId()) : null;
                    return PricingMapping.INSTANCE.toPageResult(v, sku, count, reviewer, merchantName);
                }
        );


        return PageResult.<PricingPageResult>builder()
                .result(ret)
                .ext(statics)
                .totalCount(page.getTotal())
                .totalPage(page.getPages())
                .build();
    }

    @Override
    public PricingDetailResult detail(PricingDetailRequest request) {
        Pricing pricing = repositoryFactory.getPricingRepository().findById(request.getId());
        ValidationUtil.notNull(pricing, "定价单id错误");

        //sku数据
        SkuRpcRequest rpcRequest = new SkuRpcRequest();
        rpcRequest.setIdList(Collections.singleton(pricing.getSkuId()));
        rpcRequest.setNeedBusinessData(true);
        SkuRpcResult sku = skuFacade.list(rpcRequest).get(0);

        //采购单行数据
        PurchaseOrderLine purchaseOrderLine = repositoryFactory.getPurchaseOrderLineRepository()
                .findByPurchaseIdAndSkuId(pricing.getPurchaseId(), pricing.getSkuId());

        //采购单数据
        PurchaseOrder purchaseOrder = repositoryFactory.getPurchaseOrderRepository().findById(pricing.getPurchaseId());

        //商家数据
        SysBusinessUnit merchant = repositoryFactory.getBusinessUnitRepository().findById(
                pricing.getMerchantId() == null ? sku.getId() : pricing.getMerchantId()
        );

        //采购主体
        SysBusinessUnit purchaseSubject = repositoryFactory.getBusinessUnitRepository().findById(sku.getPurchaseSubjectId());

        //供应商数据
        Supplier supplier = repositoryFactory.getSupplierRepository().findById(purchaseOrder.getSupplierId());
        SupplierContacts contact = repositoryFactory.getSupplierContactsRepository().findById(purchaseOrder.getSupplierContactId());

        return PricingMapping.INSTANCE.toDetailResult(
                pricing,
                sku,
                purchaseOrderLine,
                purchaseOrder,
                merchant,
                supplier,
                contact,
                purchaseSubject
        );
    }

    @GlobalTransactional
    @Override
    public Boolean batchPass(PricingBatchPassRequest request) {
        List<Pricing> pricings = repositoryFactory.getPricingRepository().listByIds(request.getIds());
        ValidationUtil.isTrue(!pricings.isEmpty(), "ids错误");

        ArrayList<SkuPricingRpcRequest> rpcRequest = new ArrayList<>();
        pricings.forEach(pricing -> {
            pricing.setState(PricingStateEnums.OK);
            rpcRequest.add(PricingMapping.INSTANCE.toSkuPriceUpdateRequest(pricing));
            PricingMapping.INSTANCE.addLifeCycle(pricing.getLifeCycle(), PricingStateEnums.TransitionEnum.STEP_3);
        });

        skuFacade.pricing(rpcRequest);
        repositoryFactory.getPricingRepository().submitBatch(pricings);

        return true;
    }

    @GlobalTransactional
    @Override
    public Boolean state(PricingStateRequest request) {
        Pricing pricing = repositoryFactory.getPricingRepository().findById(request.getId());
        ValidationUtil.notNull(pricing, "定价单id错误");

        PricingStateEnums toState = EnumUtils.of(PricingStateEnums.class, request.getState());
        PricingStateEnums.TransitionEnum step = EnumUtils.of(
                PricingStateEnums.TransitionEnum.class,
                pricing.getState(),
                toState
        );

        PricingMapping.INSTANCE.toEntityForUpdate(pricing, request, step);
        if (toState != PricingStateEnums.WAIT_AUDIT) { //添加审核人
            pricing.setReviewerId(UserContext.getUser().getId());
        }

        if (toState == PricingStateEnums.OK) {   //sku价格修改推送
            SkuPricingRpcRequest rpcRequest = PricingMapping.INSTANCE.toSkuPriceUpdateRequest(pricing);
            skuFacade.pricing(Collections.singletonList(rpcRequest));
        }


        ValidationUtil.isTrue(
                repositoryFactory.getPricingRepository().submit(pricing),
                "定价单状态修改失败"
        );


        return true;
    }


}
