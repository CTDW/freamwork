package com.seeease.flywheel_v4.web.infrastructure.dao.purchase.repo;


import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.entity.PurchaseAftersaleLine;

import java.util.List;
import java.util.Set;

/**
 *
 * @author 西门 游
 * @version 1.0
 * @since 5/31/24 4:55 下午
 **/
public interface PurchaseAftersaleLineRepository {

    /**
     * 批量提交
     * @param lines
     */
    void submitBatch(List<PurchaseAftersaleLine> lines);

    /**
     * 查找
     * @param id
     * @param skuIdList
     * @return
     */
    List<PurchaseAftersaleLine> listByMainIdAndSkuIds(Integer id, Set<Integer> skuIdList);

    /**
     * 查询
     * @param mainId
     * @return
     */
    List<PurchaseAftersaleLine> listByMainId(Integer mainId);

    /**
     * 查询
     * @param skuIdList
     * @return
     */
    List<PurchaseAftersaleLine> listbySkuIds(Set<Integer> skuIdList);

    /**
     * 查找
     * @param id
     * @return
     */
    PurchaseAftersaleLine findById(Integer id);

    /**
     * 查找
     * @param afterSaleIds
     * @return
     */
    List<PurchaseAftersaleLine> listByMainIds(Set<Integer> afterSaleIds);
}
