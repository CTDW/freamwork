package com.seeease.flywheel_v4.web.adptor.fix;

import com.seeease.flywheel_v4.web.app.fix.request.FixItemDetailRequest;
import com.seeease.flywheel_v4.web.app.fix.request.FixItemPageRequest;
import com.seeease.flywheel_v4.web.app.fix.request.FixItemSaveRequest;
import com.seeease.flywheel_v4.web.app.fix.result.FixItemPageResult;
import com.seeease.flywheel_v4.web.app.fix.service.FixItemService;
import com.seeease.flywheel_v4.web.infrastructure.config.IdentifyLogPrinter;
import com.seeease.flywheel_v4.web.infrastructure.dao.fix.entity.FixItem;
import com.seeease.springframework.PageResult;
import com.seeease.springframework.SingleResponse;
import com.seeease.springframework.log.annotation.LogPrinter;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;


/**
 * @Description 维修项目
 * @Date 2024-10-2 10:10
 * @Author by hk
 */
@RestController
@RequestMapping("fix")
@Api(tags = "维修项目 控制层")
public class FixItemController {

    @Resource
    private FixItemService fixItemService;

    @ApiOperation(value = "查询维修项目")
    @PostMapping("/fixItem/page")
    @LogPrinter(scenario = "维修中心-设置-维修项目分页列表", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<PageResult<FixItemPageResult>> page(@RequestBody FixItemPageRequest request) {

        return SingleResponse.of(fixItemService.page(request));
    }

    @ApiOperation(value = "维修项目详情")
    @PostMapping("/fixItem/detail")
    @LogPrinter(scenario = "维修中心-设置-维修项目详情", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<FixItem> detail(@RequestBody @Validated FixItemDetailRequest request) {

        return SingleResponse.of(fixItemService.detail(request));
    }

    @ApiOperation(value = "维修项目新增")
    @PostMapping("/fixItem/create")
    @LogPrinter(scenario = "维修中心-设置-维修项目新增", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<Boolean> save(@RequestBody @Validated FixItemSaveRequest request) {
        return SingleResponse.of(fixItemService.save(request));
    }

    @ApiOperation(value = "维修项目删除")
    @PostMapping("/fixItem/del")
    @LogPrinter(scenario = "维修中心-设置-维修项目删除", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<Boolean> delete(@RequestBody @Validated FixItemDetailRequest request) {
        return SingleResponse.of(fixItemService.delete(request));
    }

    @ApiOperation(value = "维修项目编辑")
    @PostMapping("/fixItem/update")
    @LogPrinter(scenario = "维修中心-设置-维修项目编辑", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<Boolean> update(@RequestBody @Validated FixItemSaveRequest request) {
        return SingleResponse.of(fixItemService.update(request));
    }
}
