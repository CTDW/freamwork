package com.seeease.flywheel_v4.web.domain.finance.strategy.paymentSlip;

import com.seeease.flywheel_v4.web.app.finance.request.PaymentSlipSubmitRequest;
import com.seeease.flywheel_v4.client.enums.PurchaseTypeEnums;

/**
 *
 * 申请打款单创建前置校验策略
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/13/24 11:20上午
 **/
public interface PreCreateStrategy {
    /**
     * 创建申请打款单时自定义校验
     */
    void check(PaymentSlipSubmitRequest request);

    /**
     * 匹配对应的参数校验策略
     * @param purchaseTypeEnums 采购类型
     * @return  匹配结果
     */
    default Boolean match(PurchaseTypeEnums purchaseTypeEnums){
        return false;
    }

}
