package com.seeease.flywheel_v4.web.domain.excel.strategy.Import;

import com.alibaba.cola.extension.Extension;
import com.seeease.flywheel_v4.web.app.excel.request.PurchaseWatchImportRequest;
import com.seeease.flywheel_v4.web.app.excel.result.PurchaseSkuImportResult;
import com.seeease.flywheel_v4.web.domain.excel.core.ImportExtPtl;
import com.seeease.goods.rpc.SpuFacade;
import com.seeease.goods.rpc.request.SpuRpcRequest;
import com.seeease.goods.rpc.result.SpuRpcResult;
import com.seeease.springframework.exception.ValidationUtil;
import com.seeease.springframework.utils.MultiUtils;
import com.seeease.springframework.utils.StringUtils;
import org.apache.dubbo.config.annotation.DubboReference;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 *
 * @author 西门 游
 * @version 1.0
 * @since 9/11/24 1:39 下午
 **/
@Service
@Extension(bizId = "import", useCase = "purchaseWatch")
public class PurchaseWatchImport implements ImportExtPtl<PurchaseWatchImportRequest, PurchaseSkuImportResult> {

    @DubboReference(check = false,version = "1.0.0")
    private SpuFacade spuFacade;

    @Override
    public Class<PurchaseWatchImportRequest> getRequestClass() {
        return PurchaseWatchImportRequest.class;
    }

    @Override
    public void validate(List<PurchaseWatchImportRequest> data) {}

    @Override
    public List<PurchaseSkuImportResult> handle(List<PurchaseWatchImportRequest> data) {

        //查找spu
        Set<String> codes = MultiUtils.toSet(data, PurchaseWatchImportRequest::getGoodsCode);
        SpuRpcRequest rpcRequest = new SpuRpcRequest();
        rpcRequest.setGoodsCodes(codes);
        Map<String, SpuRpcResult> spuMap = MultiUtils.toMap(
                spuFacade.list(rpcRequest),
                SpuRpcResult::getGoodsCode
        );

        ValidationUtil.isTrue(!spuMap.isEmpty(),"不存在对应spu数据");

        ArrayList<PurchaseSkuImportResult> ret = new ArrayList<>();


        for (PurchaseWatchImportRequest item : data){

            PurchaseSkuImportResult sku = new PurchaseSkuImportResult();

            //step_1 转换附件
            List<PurchaseSkuImportResult.SkuAnnexe> annexe = mappingAnnex(item);
            sku.setAnnexe(annexe);

            //step_2 设置spu属性
            SpuRpcResult spu = spuMap.get(item.getGoodsCode());
            if (null == spu){
                continue;
            }
            sku.setSpuId(spu.getId());
            sku.setUniqueType(spu.getUniqueType());
            sku.setSpuImage(spu.getSpuImage());
            sku.setGoodsName(spu.getGoodsName());
            sku.setCategoryName("腕表/腕表");
            sku.setBrandName(spu.getBrandName());

            //step_3 设置采购价
            sku.setPurchasePrice(item.getPurchasePrice());

            //step_4 设置数量
            sku.setCount(1);

            //step_5 设置唯一码
            sku.setSkuCode(item.getSkuCode());

            //step_6 设置参数
            sku.setSkuParams(mappingParams(item));

            ret.add(sku);
        }


        return ret;
    }


    private List<PurchaseSkuImportResult.SkuParam> mappingParams(PurchaseWatchImportRequest item){
        List<PurchaseSkuImportResult.SkuParam> params = new ArrayList<>();

        if (StringUtils.isNotEmpty(item.getFineness())){
            PurchaseSkuImportResult.SkuParam param = new PurchaseSkuImportResult.SkuParam();
            param.setParamCode("chengse");
            param.setParamName("成色");
            param.setParamValue(Collections.singletonList(item.getFineness()));
            params.add(param);
        }
        if (StringUtils.isNotEmpty(item.getStrapType())){
            PurchaseSkuImportResult.SkuParam param = new PurchaseSkuImportResult.SkuParam();
            param.setParamCode("biaodaicaizhi");
            param.setParamName("表带类型");
            param.setParamValue(Collections.singletonList(item.getStrapType()));
            params.add(param);
        }

        return params;
    }


    private List<PurchaseSkuImportResult.SkuAnnexe> mappingAnnex(PurchaseWatchImportRequest item){

        List<PurchaseSkuImportResult.SkuAnnexe> annexe = new ArrayList<>();
        if ("是".equals(item.getBox())){
            PurchaseSkuImportResult.SkuAnnexe annexeItem = new PurchaseSkuImportResult.SkuAnnexe();
            annexeItem.setParamName("盒子");
            annexeItem.setSelectType(2);
            annexe.add(annexeItem);
        }

        if ("是".equals(item.getNoAnnexe())){
            PurchaseSkuImportResult.SkuAnnexe annexeItem = new PurchaseSkuImportResult.SkuAnnexe();
            annexeItem.setParamName("无附件");
            annexeItem.setSelectType(2);
            annexe.add(annexeItem);
        }

        if ("是".equals(item.getManual())){
            PurchaseSkuImportResult.SkuAnnexe annexeItem = new PurchaseSkuImportResult.SkuAnnexe();
            annexeItem.setParamName("说明书");
            annexeItem.setSelectType(2);
            annexe.add(annexeItem);
        }

        if (StringUtils.isNotEmpty(item.getFillRemark())){
            PurchaseSkuImportResult.SkuAnnexe annexeItem = new PurchaseSkuImportResult.SkuAnnexe();
            annexeItem.setParamName("补充备注");
            annexeItem.setSelectType(3);
            annexeItem.setValue(item.getFillRemark());
            annexe.add(annexeItem);
        }

        if ("是".equals(item.getBill())){
            PurchaseSkuImportResult.SkuAnnexe annexeItem = new PurchaseSkuImportResult.SkuAnnexe();
            annexeItem.setParamName("发票");
            annexeItem.setSelectType(2);
            annexe.add(annexeItem);
        }

        if (StringUtils.isNotEmpty(item.getCard())){
            PurchaseSkuImportResult.SkuAnnexe annexeItem = new PurchaseSkuImportResult.SkuAnnexe();
            annexeItem.setParamName("保卡");
            annexeItem.setSelectType(4);
            annexeItem.setValue(item.getCard());
            annexe.add(annexeItem);
        }

        if ("是".equals(item.getBlankCard())){
            PurchaseSkuImportResult.SkuAnnexe annexeItem = new PurchaseSkuImportResult.SkuAnnexe();
            annexeItem.setParamName("空白保卡");
            annexeItem.setSelectType(2);
            annexe.add(annexeItem);
        }

        return annexe;
    }
}
