package com.seeease.flywheel_v4.web.app.sys_config.request;



import com.seeease.springframework.RequestValidGroup;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/3/24 11:26 上午
 **/
@Data
public class SaleChannelSubmitRequest {
    @NotNull(message = "id不能为空", groups = RequestValidGroup.Update.class)
    private Integer id;
    /**
     * 名称
     */
    @NotBlank(message = "名称不能为空")
    private String name;
    /**
     * 销售渠道类型
     */
    @NotNull(message = "销售渠道类型不能为空")
    private Integer type;
    /**
     * 渠道隶属商家id 即 sys_business_unit 表中业务类型为商家的主键id
     */
    @NotNull(message = "隶属商家id不能为空")
    private Integer merchantId;
    /**
     * 公司名称
     */
    private String firmName;
    /**
     * 备注
     */
    private String remark;
    /**
     * 营业执照编码
     */
    private String licenseNo;
    /**
     * 三方平台id
     */
    private String thirdNo;
    /**
     * 三方秘钥
     */
    private String secret;

}
