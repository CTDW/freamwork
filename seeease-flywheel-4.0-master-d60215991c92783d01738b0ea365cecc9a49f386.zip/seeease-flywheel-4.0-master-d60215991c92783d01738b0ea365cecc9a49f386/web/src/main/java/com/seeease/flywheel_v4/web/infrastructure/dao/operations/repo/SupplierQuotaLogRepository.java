package com.seeease.flywheel_v4.web.infrastructure.dao.operations.repo;

import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.SupplierQuotaLog;

/**
 *
 * @author 西门 游
 * @version 1.0
 * @since 5/31/24 4:55 下午
 **/
public interface SupplierQuotaLogRepository {
    /**
     * 提交
     * @param log
     */
    Boolean submit(SupplierQuotaLog log);
}
