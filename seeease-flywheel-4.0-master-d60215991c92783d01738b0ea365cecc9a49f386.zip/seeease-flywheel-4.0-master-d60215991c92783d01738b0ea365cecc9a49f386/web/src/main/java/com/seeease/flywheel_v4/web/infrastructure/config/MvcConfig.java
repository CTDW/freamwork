package com.seeease.flywheel_v4.web.infrastructure.config;

import com.alibaba.fastjson.JSONObject;
import com.seeease.springframework.context.LoginUser;
import com.seeease.springframework.context.UserContext;
import org.apache.commons.lang3.StringUtils;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.net.URLDecoder;

@Configuration
public class MvcConfig implements WebMvcConfigurer {
    @Resource
    private UserInterceptor interceptor;


    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**")
                .allowedOrigins("*")
                .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS")
                .allowedHeaders("*")
                .allowCredentials(true);
    }

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(interceptor)
                .addPathPatterns("/**");
    }


    @Component
    public static class UserInterceptor implements HandlerInterceptor {

        @Override
        public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {
            String userHeader = request.getHeader("userVO");
            if (StringUtils.isNotEmpty(userHeader)) {
                userHeader = URLDecoder.decode(userHeader);
                //userVo本地线程缓存，方便后面操作获取
                LoginUser loginUser = JSONObject.parseObject(userHeader, LoginUser.class);
                UserContext.setUser(loginUser);
            }

            return true;
        }

        @Override
        public void afterCompletion(HttpServletRequest request, HttpServletResponse
                response, Object handler, Exception ex) {
            //移除用户信息
            UserContext.clear();
        }
    }
}