package com.seeease.flywheel_v4.web.app.sale.result;


import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;


@Data
public class ToCSaleReturnOrderPageResult {
    /**
     * id
     */
    private Integer id;
    /**
     * 销售退货单号
     */
    private String serialNo;
    /**
     * 销售单号
     */
    private String saleSerialNo;
    /**
     * 状态
     */
    private Integer state;
    /**
     * 销售方式
     */
    private Integer sellType;

    /**
     * 客户名称
     */
    private String buyerName;
    /**
     * 总退狂金额
     */
    private BigDecimal totalAmount;
    /**
     * 销售渠道
     */
    private Integer scType;
    /**
     * 订单来源
     */
    private String originName;
    /**
     * 创建人
     */
    private String createdBy;
    /**
     * 创建时间
     */
    private Date createdTime;
    /**
     * 完成时间
     */
    private Date finishTime;


}
