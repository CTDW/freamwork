package com.seeease.flywheel_v4.web.app.sys_config.service.impl;


import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.seeease.flywheel_v4.web.app.sys_config.request.SaleChannelPageRequest;
import com.seeease.flywheel_v4.web.app.sys_config.request.SaleChannelSubmitRequest;
import com.seeease.flywheel_v4.web.app.sys_config.result.SaleChannelPageResult;
import com.seeease.flywheel_v4.web.app.sys_config.service.SaleChannelService;
import com.seeease.flywheel_v4.web.domain.sys_config.mapping.SaleChannelMapping;
import com.seeease.flywheel_v4.web.infrastructure.dao.RepositoryFactory;

import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.entity.SysBusinessUnit;
import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.entity.SysSaleChannel;
import com.seeease.springframework.PageResult;
import com.seeease.springframework.utils.MultiUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Map;
import java.util.Set;


/**
 * <p>系统销售渠道服务</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/3/24 11:19 上午
 **/
@Service
public class SaleChannelServiceImpl implements SaleChannelService {
    @Resource
    private RepositoryFactory repositoryFactory;


    @Override
    public Boolean create(SaleChannelSubmitRequest request) {
        SysSaleChannel e = SaleChannelMapping.INSTANCE.toEntity(request);
        return repositoryFactory.getSaleChannelRepository()
                .submit(e);
    }

    @Override
    public Boolean update(SaleChannelSubmitRequest request) {
        SysSaleChannel e = SaleChannelMapping.INSTANCE.toEntity(request);
        return repositoryFactory.getSaleChannelRepository()
                .submit(e);
    }

    @Override
    public PageResult<SaleChannelPageResult> page(SaleChannelPageRequest request) {
        Page<SysSaleChannel> page = repositoryFactory.getSaleChannelRepository()
                .page(
                        request.getName(),
                        request.getType(),
                        request.getMerchantId(),
                        request
                );

        Set<Integer> merchantIdList = MultiUtils.toSet(page.getRecords(), SysSaleChannel::getMerchantId);
        Map<Integer, String> merchantIdMap = MultiUtils.toMap(
                repositoryFactory.getBusinessUnitRepository().listByIds(merchantIdList),
                SysBusinessUnit::getId,
                SysBusinessUnit::getName
        );

        return PageResult.<SaleChannelPageResult>builder()
                .result(MultiUtils.toList(page.getRecords(),v -> SaleChannelMapping.INSTANCE.toPageResult(v,merchantIdMap)))
                .totalCount(page.getTotal())
                .totalPage(page.getPages())
                .build();
    }
}
