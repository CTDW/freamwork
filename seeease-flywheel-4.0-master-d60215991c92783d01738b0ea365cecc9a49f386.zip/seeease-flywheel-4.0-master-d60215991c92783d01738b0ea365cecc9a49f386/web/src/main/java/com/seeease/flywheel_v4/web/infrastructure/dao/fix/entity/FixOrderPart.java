package com.seeease.flywheel_v4.web.infrastructure.dao.fix.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.seeease.seeeaseframework.mybatis.domain.BaseDomain;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;

/**
 * @Description 维修配件表
 * @Date 2024-10-4 21:49
 * @Author by hk
 */
@EqualsAndHashCode(callSuper = true)
@TableName(value = "v4_fix_order_part", autoResultMap = true)
@Data
public class FixOrderPart extends BaseDomain {

    @TableId(type = IdType.AUTO)
    private Long id;

    /**
     * 维修单号
     */
    private String orderNumber;

    /**
     * 商品图片
     */
    private String goodsPic;

    /**
     * 商品名称
     */
    private String goodsName;

    /**
     * 品牌
     */
    private String goodsBrand;

    /**
     * 类目
     */
    private String goodsCategory;

    /**
     * 品牌id
     */
    private Integer goodsBrandId;

    /**
     * 类目id
     */
    private Integer goodsCategoryId;

    /**
     * skuCode
     */
    private String skuCode;

    /**
     * 分类
     */
    private String classification;

    /**
     * 货号
     */
    private String articleNo;

    /**
     * 尺寸
     */
    private String size;

    /**
     * 形状
     */
    private String shape;

    /**
     * 机芯号
     */
    private String machineNumber;

    /**
     * 数量
     */
    private Integer count;

    /**
     * 采购价
     */
    private BigDecimal price;

    /**
     * 公价
     */
    private BigDecimal publicPrice;

    /**
     * 零售价
     */
    private BigDecimal salePrice;
}
