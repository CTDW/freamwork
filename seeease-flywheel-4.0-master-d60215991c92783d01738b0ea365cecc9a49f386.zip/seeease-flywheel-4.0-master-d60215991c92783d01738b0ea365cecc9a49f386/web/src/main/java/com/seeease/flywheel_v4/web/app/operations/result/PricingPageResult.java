package com.seeease.flywheel_v4.web.app.operations.result;

import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.entity.PurchaseOrderLine;
import com.seeease.goods.rpc.result.SkuRpcResult;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

@Data
public class PricingPageResult implements Serializable {

    /**
     * id
     */
    private Integer id;
    /**
     * sou图片
     */
    private String spuImage;
    /**
     * 商品名称
     */
    private String goodsName;
    /**
     * 货号
     */
    private String goodsCode;
    /**
     * 类目名称
     */
    private String categoryName;
    /**
     * 品牌
     */
    private String brandName;
    /**
     * sku上的需求商家名称
     * {@link SkuRpcResult#getMerchantId()}
     */
    private String merchantName;
    /**
     * 采购单类型
     */
    private Integer purchaseType;
    /**
     * 采购价
     */
    private BigDecimal purchasePrice;
    /**
     * sku编码
     */
    private String skuCode;
    /**
     * 采购单行数量 注意不是实收数量
     * {@link PurchaseOrderLine#getCount()}
     */
    private Integer count;
    /**
     * 审核人
     */
    private String reviewer;
    /**
     * 创建人
     */
    private String createdBy;
    /**
     * 创建时间
     */
    private Date createdTime;


}
