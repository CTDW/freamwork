package com.seeease.flywheel_v4.web.domain.sale.mapping;


import com.doudian.open.api.order_batchSensitive.OrderBatchSensitiveRequest;
import com.doudian.open.api.order_batchSensitive.OrderBatchSensitiveResponse;
import com.doudian.open.api.order_batchSensitive.data.DecryptInfosItem;
import com.doudian.open.api.order_batchSensitive.param.CipherInfosItem;
import com.doudian.open.api.order_batchSensitive.param.OrderBatchSensitiveParam;
import com.doudian.open.api.order_orderDetail.data.PostAddr;
import com.doudian.open.api.order_orderDetail.data.ShopOrderDetail;
import com.doudian.open.core.AccessToken;
import com.kuaishou.merchant.open.api.domain.order.OrderAddressInfo;
import com.kuaishou.merchant.open.api.domain.order.OrderDetail;
import com.seeease.flywheel_v4.client.enums.BusinessUnitTypeEnums;
import com.seeease.flywheel_v4.web.app.excel.result.ThirdOrderExportResult;
import com.seeease.flywheel_v4.web.app.sale.request.SaleOrderCreateRequest;
import com.seeease.flywheel_v4.web.app.sale.request.ThirdSaleOrderConfirmRequest;
import com.seeease.flywheel_v4.web.app.sale.result.ThirdSaleOrderMergeResult;
import com.seeease.flywheel_v4.web.app.sale.result.ThirdSaleOrderPageResult;
import com.seeease.flywheel_v4.web.infrastructure.config.EnumMapping;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.entity.ThirdSaleOrder;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.entity.obj.BuyerInfoObj;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.enums.SaleQualityWayEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.enums.SaleTypeEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.enums.ThirdSaleStateEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.entity.SysSaleChannel;
import com.seeease.flywheel_v4.web.util.SerialNoGenerator;
import com.seeease.seeeaseframework.mybatis.domain.WhetherEnum;
import com.seeease.springframework.utils.BigDecimalUtil;
import com.seeease.springframework.utils.MultiUtils;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;

import java.math.BigDecimal;
import java.util.*;


/**
 * <p>
 * </p>
 *
 * @author 西门 游
 * @since 2023-10-27
 */
@Mapper(componentModel = "spring",
        builder = @Builder(disableBuilder = true),
        nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS,
        nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE,
        imports = {BusinessUnitTypeEnums.class,
                UUID.class,
                SaleQualityWayEnums.class,
                SaleTypeEnums.class,
                SerialNoGenerator.class, ThirdSaleStateEnums.class, WhetherEnum.class, BigDecimalUtil.class})
public interface ThirdSaleOrderMapping extends EnumMapping {

    ThirdSaleOrderMapping INSTANCE = Mappers.getMapper(ThirdSaleOrderMapping.class);


    default BuyerInfoObj toTiktokBuyer(String orderId,
                                       String encTel,
                                       String encRec,
                                       PostAddr postAddr,
                                       AccessToken accessToken) {
        OrderBatchSensitiveRequest request = new OrderBatchSensitiveRequest();
        OrderBatchSensitiveParam param = new OrderBatchSensitiveParam();
        ArrayList<CipherInfosItem> list = new ArrayList<>();
        //详细地址
        CipherInfosItem encDetailItem = new CipherInfosItem();
        String encAddr = postAddr.getEncryptDetail();
        encDetailItem.setAuthId(orderId);
        encDetailItem.setCipherText(encAddr);
        list.add(encDetailItem);
        //收货电话
        CipherInfosItem encTelItem = new CipherInfosItem();
        encTelItem.setAuthId(orderId);
        encTelItem.setCipherText(encTel);
        list.add(encTelItem);
        //收货ren
        CipherInfosItem encRecItem = new CipherInfosItem();
        encRecItem.setAuthId(orderId);
        encRecItem.setCipherText(encRec);
        list.add(encRecItem);
        param.setCipherInfos(list);
        request.setParam(param);
        OrderBatchSensitiveResponse response = request.execute(accessToken);

        Map<String, String> map = MultiUtils.toMap(
                response.getData().getDecryptInfos(),
                DecryptInfosItem::getCipherText,
                DecryptInfosItem::getDecryptText
        );


        //构造返回对象
        BuyerInfoObj ret = new BuyerInfoObj();
        ret.setProvince(postAddr.getProvince().getName());
        ret.setCity(postAddr.getCity().getName());
        ret.setTown(postAddr.getTown().getName());
        ret.setStreet(postAddr.getStreet().getName());

        ret.setTiktokEncAddr(encAddr);
        ret.setAddress(map.get(encAddr));

        ret.setTiktokEncRec(encRec);
        ret.setRec(map.get(encRec));

        ret.setTiktokEncTel(encTel);
        ret.setTel(map.get(encTel));
        return ret;
    }


    @Mapping(target = "mergeId", source = "order.openAddressId")
    @Mapping(target = "buyerName", source = "buyerInfo.rec")
    @Mapping(target = "buyerTel", source = "buyerInfo.tel")
    @Mapping(target = "state", expression = "java(ThirdSaleStateEnums.WAIT)")
    @Mapping(target = "mergedId", expression = "java(  UUID.randomUUID().toString())")
    @Mapping(target = "billRemark", source = "order.buyerWords")
    @Mapping(target = "buyerInfo", source = "buyerInfo")
    ThirdSaleOrder toEntity(SaleQualityWayEnums qualityWay,
                            BuyerInfoObj buyerInfo,
                            Integer totalCount,
                            BigDecimal totalAmount,
                            Integer scId,
                            ShopOrderDetail order,
                            String qualityCode
    );

    @Mapping(target = "totalAmount", source = "totalAmount")
    @Mapping(target = "scName", source = "sc.name")
    @Mapping(target = "scType", source = "sc.type")
    @Mapping(target = "remark", source = "record.remark")
    @Mapping(target = "createdTime", source = "record.createdTime")
    @Mapping(target = "thirdPartyNo", source = "record.orderId")
    @Mapping(target = "id", source = "record.id")
    ThirdSaleOrderPageResult toPageResult(
            ThirdSaleOrder record,
            SysSaleChannel sc,
            BigDecimal totalAmount);

    @Mapping(target = "buyerName", source = "buyerInfo.rec")
    @Mapping(target = "buyerPhone", source = "buyerInfo.tel")
    @Mapping(target = "buyerAddress", expression = "java(buyerInfo.getCompleteAddress())")
    ThirdSaleOrderMergeResult toMergeDetail(
            Set<String> thirdPartNos,
            BuyerInfoObj buyerInfo,
            Set<Integer> ids,
            List<ThirdSaleOrderMergeResult.Sku> skuList);

    @Mapping(target = "scId", source = "sysSaleChannel.id")
    @Mapping(target = "scType", source = "sysSaleChannel.type")
    @Mapping(target = "sellRemark", source = "request.remark")
    @Mapping(target = "sellType", expression = "java(SaleTypeEnums.PT.getValue())")
    @Mapping(target = "skuList",source = "skuList")
    SaleOrderCreateRequest toTocCreateRequest(
            Integer qualityWay,
            ThirdSaleOrderConfirmRequest request,
            String billRemark,
            String thirdPartyNo,
            String mergedId,
            SysSaleChannel sysSaleChannel,
            List<SaleOrderCreateRequest.Sku> skuList
    );

    @Mapping(target = "province",source = "province")
    @Mapping(target = "city",source = "city")
    @Mapping(target = "town",source = "town")
    @Mapping(target = "street",source = "district")
    @Mapping(target = "address",source = "desensitiseAddress")
    @Mapping(target = "rec",source = "desensitiseConsignee")
    @Mapping(target = "tel",source = "desensitiseMobile")
    @Mapping(target = "ksEncAddr",source = "encryptedAddress")
    @Mapping(target = "ksEncRec",source = "encryptedConsignee")
    @Mapping(target = "ksEncTel",source = "encryptedMobile")
    BuyerInfoObj toKsBuyer(OrderAddressInfo orderAddress);

    @Mapping(target = "id",ignore = true)
    @Mapping(target = "ksSellerId",source = "detail.orderBaseInfo.sellerOpenId")
    @Mapping(target = "title",source = "detail.orderItemInfo.itemTitle")
    @Mapping(target = "qualityWay",expression = "java(SaleQualityWayEnums.XX_ZJ)")
    @Mapping(target = "orderId",source = "detail.orderBaseInfo.oid")
    @Mapping(target = "buyerName",source = "detail.orderAddress.desensitiseConsignee")
    @Mapping(target = "buyerTel",source = "detail.orderAddress.desensitiseMobile")
    @Mapping(target = "totalCount",source = "detail.orderItemInfo.num",defaultValue = "1")
    @Mapping(target = "totalAmount",expression = "java(BigDecimalUtil.centToYuan(String.valueOf(detail.getOrderItemInfo().getPrice())))")
    ThirdSaleOrder toEntity(
            OrderDetail detail,
            Integer scId,
            BuyerInfoObj buyerInfo,
            OrderAddressInfo orderAddress,
            String mergeId,
            String mergedId
    );

    @Mapping(target = "scType",source = "scType")
    @Mapping(target = "state",source = "state")
    ThirdOrderExportResult toExportResult(ThirdSaleOrderPageResult item, String scType,String state);
}
