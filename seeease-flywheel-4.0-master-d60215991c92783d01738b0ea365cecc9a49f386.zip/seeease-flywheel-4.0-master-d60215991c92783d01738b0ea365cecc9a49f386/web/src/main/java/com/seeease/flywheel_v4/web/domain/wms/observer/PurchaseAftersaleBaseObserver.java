package com.seeease.flywheel_v4.web.domain.wms.observer;

import com.google.common.collect.Lists;
import com.seeease.flywheel_v4.client.enums.BusinessUnitTypeEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.RepositoryFactory;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.entity.PurchaseAftersale;
import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.entity.SysBusinessUnit;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.MerchantWmsTypeEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.WmsCkTypeEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.WmsRkTypeEnums;
import com.seeease.goods.rpc.enums.SkuNodeStateEnums;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 7/26/24 11:24 上午
 **/
@Component
public class PurchaseAftersaleBaseObserver {

    @Resource
    private RepositoryFactory repositoryFactory;


    /**
     * 仓库端wms 入库观察者类型
     */
    protected final List<WmsRkTypeEnums> wmsRkWatchTypeList = Lists.newArrayList(
            WmsRkTypeEnums.CG_FX,
            WmsRkTypeEnums.CG_HH
    );

    /**
     * 仓库端wms 禁止操作
     */
    protected final List<SkuNodeStateEnums> wmsRkNotAllow = Lists.newArrayList(
            SkuNodeStateEnums.QX,
            SkuNodeStateEnums.SW_BF,
            SkuNodeStateEnums.ZJ_BTG
    );


    /**
     * 仓库端wms 出库观察的类型
     */
    protected final List<WmsCkTypeEnums> wmsCkWatchTypeList = Lists.newArrayList(
            WmsCkTypeEnums.CG_JS,
            WmsCkTypeEnums.CG_FX,
            WmsCkTypeEnums.CG_HH,
            WmsCkTypeEnums.CG_TH
    );




    /**
     * 商家端wms 入库观察的类型
     */
    protected final List<MerchantWmsTypeEnums> merchantWmsRkWatchTypeList = Lists.newArrayList(
            MerchantWmsTypeEnums.CG_FX_RK,
            MerchantWmsTypeEnums.CG_HH_RK
    );

    /**
     *  商家端wms 出库观察者类型
     */
    protected final List<MerchantWmsTypeEnums> merchantWmsCkWatchTypeList = Lists.newArrayList(
            MerchantWmsTypeEnums.CG_JS_CK,
            MerchantWmsTypeEnums.CG_FX_CK,
            MerchantWmsTypeEnums.CG_HH_CK,
            MerchantWmsTypeEnums.CG_TH
    );






    /**
     * 判断是否入库到商家
     */
    protected boolean pushToMerchant(PurchaseAftersale order){
        SysBusinessUnit store = repositoryFactory.getBusinessUnitRepository().findById(order.getStoreId());
        return store.getType() == BusinessUnitTypeEnums.MERCHANT;
    }


}
