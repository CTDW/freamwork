package com.seeease.flywheel_v4.web.app.excel.result;

import com.alibaba.excel.annotation.ExcelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 9/11/24 5:00 下午
 **/
@Data
public class StoreLocationExportResult implements Serializable {

    @ExcelProperty("商品名称")
    private String goodsName;

    @ExcelProperty("货号")
    private String goodsCode;

    @ExcelProperty("品牌名称")
    private String brandName;

    @ExcelProperty("唯一码")
    private String skuCode;

    @ExcelProperty("数量")
    private Integer count;

    @ExcelProperty("库位")
    private String name;



}
