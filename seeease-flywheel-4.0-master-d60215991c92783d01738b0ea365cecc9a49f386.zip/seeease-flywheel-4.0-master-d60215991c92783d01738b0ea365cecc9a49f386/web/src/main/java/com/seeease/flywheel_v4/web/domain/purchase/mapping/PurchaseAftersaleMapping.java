package com.seeease.flywheel_v4.web.domain.purchase.mapping;


import com.seeease.flywheel_v4.client.enums.BusinessUnitTypeEnums;
import com.seeease.flywheel_v4.web.app.excel.result.PurchaseAftersaleExportResult;
import com.seeease.flywheel_v4.web.app.purchase.request.PurchaseDemandSubmitRequest;
import com.seeease.flywheel_v4.web.app.purchase.request.PurchaseReturnCreateRequest;
import com.seeease.flywheel_v4.web.app.purchase.result.PurchaseAftersaleDetailResult;
import com.seeease.flywheel_v4.web.app.purchase.result.PurchaseAftersalePageResult;
import com.seeease.flywheel_v4.web.domain.wms.observer.base.Ext;
import com.seeease.flywheel_v4.web.infrastructure.config.MappingIgnore;
import com.seeease.flywheel_v4.web.infrastructure.config.SimpleMapping;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.Supplier;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.SupplierContacts;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.entity.PurchaseAftersale;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.entity.PurchaseDemand;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.entity.PurchaseOrder;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.enums.PurchaseAftersaleStateEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.enums.PurchaseAftersaleTypeEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.enums.PurchaseDemandStateEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.entity.SysBusinessUnit;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.MerchantWms;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.obj.ContactInfo;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.MerchantWmsModelEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.MerchantWmsStateEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.MerchantWmsTypeEnums;
import com.seeease.flywheel_v4.web.util.SerialNoGenerator;
import com.seeease.goods.rpc.result.SkuRpcResult;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;

import java.math.BigDecimal;
import java.util.List;


/**
 * <p>
 * </p>
 *
 * @author 西门 游
 * @since 2023-10-27
 */
@Mapper(componentModel = "spring",
        builder = @Builder(disableBuilder = true),
        nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS,
        nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE,
        imports = {BusinessUnitTypeEnums.class,
                PurchaseAftersaleStateEnums.class,
                PurchaseDemandStateEnums.class,
                PurchaseDemandStateEnums.TransitionEnum.class,
                SerialNoGenerator.class,
                MerchantWmsStateEnums.class})
public interface PurchaseAftersaleMapping extends SimpleMapping<PurchaseDemandSubmitRequest, PurchaseDemand> {

    PurchaseAftersaleMapping INSTANCE = Mappers.getMapper(PurchaseAftersaleMapping.class);

    @MappingIgnore
    @Mapping(target = "state",expression = "java(PurchaseAftersaleStateEnums.STARTING)")
    @Mapping(target = "type",source = "type")
    @Mapping(target = "originSerialNo",source = "order.serialNo")
    @Mapping(target = "serialNo",source = "serialNo")
    @Mapping(target = "storeId",source = "order.storeId")
    @Mapping(target = "expressNo",ignore = true)
    @Mapping(target = "remark",ignore = true)
    @Mapping(target = "totalCount",source = "totalCount")
    PurchaseAftersale toEntity(PurchaseOrder order,
                               PurchaseAftersaleTypeEnums type,
                               String serialNo,
                               Integer buId,
                               Integer totalCount,
                               BigDecimal amount);

    @MappingIgnore
    @Mapping(target = "originId",source = "aftersale.buId")
    @Mapping(target = "state",expression = "java(MerchantWmsStateEnums.STARTING)")
    @Mapping(target = "type",source = "type")
    @Mapping(target = "model",source = "model")
    @Mapping(target = "fromId",source = "aftersale.storeId")
    @Mapping(target = "spTime",ignore = true)
    MerchantWms toMerchantWms(PurchaseAftersale aftersale,
                              MerchantWmsTypeEnums type,
                              MerchantWmsModelEnums model,
                              Integer totalCount,
                              BigDecimal amount);



    @MappingIgnore
    @Mapping(target = "state",expression = "java(MerchantWmsStateEnums.STARTING)")
    @Mapping(target = "remark",ignore = true)
    @Mapping(target = "transitionStateEnum",ignore = true)
    @Mapping(target = "toId",source = "order.storeId")
    @Mapping(target = "spTime",ignore = true)
    MerchantWms toMerchantWms(PurchaseAftersale order,
                              ContactInfo contactInfo,
                              MerchantWmsTypeEnums type,
                              MerchantWmsModelEnums model,
                              Integer totalCount,
                              BigDecimal amount);

    PurchaseAftersalePageResult toPageResult(PurchaseAftersale aftersale, String originName);

    @Mapping(target = "id",source = "main.id")
    @Mapping(target = "type",expression = "java(main.getType().getValue())")
    @Mapping(target = "state",expression = "java(main.getState().getValue())")
    @Mapping(target = "createdBy",source = "main.createdBy")
    @Mapping(target = "createdTime",source = "main.createdTime")
    @Mapping(target = "originName",source = "origin.name")
    @Mapping(target = "supplierName",source = "supplier.name")
    @Mapping(target = "supplierType",expression = "java(supplier.getType().getValue())")
    @Mapping(target = "address",expression = "java(supplier.getCompleteAddress())")
    @Mapping(target = "contactName",source = "contact.name")
    @Mapping(target = "contactPhone",source = "contact.phone")
    PurchaseAftersaleDetailResult toDetailResult(PurchaseAftersale main,
                                                 SysBusinessUnit origin,
                                                 Supplier supplier,
                                                 SupplierContacts contact,
                                                 List<PurchaseAftersaleDetailResult.Sku> skuList);

    @Mapping(target = "supplierContactId",source = "request.contactId")
    @Mapping(target = "state",expression = "java(PurchaseAftersaleStateEnums.STARTING)")
    PurchaseAftersale toEntity(PurchaseReturnCreateRequest request,
                               Integer totalCount,
                               BigDecimal amount,
                               Integer buId,
                               String originSerialNo,
                               PurchaseAftersaleTypeEnums type);


    @Mapping(target = "type",source = "type")
    @Mapping(target = "supplierName",source = "supplier.name")
    @Mapping(target = "phone",source = "contacts.phone")
    @Mapping(target = "detailAddr",expression = "java(null != supplier ? supplier.getCompleteAddress() : null)")
    @Mapping(target = "state",source = "state")
    @Mapping(target = "createdBy",source = "afterSaleOrder.createdBy")
    @Mapping(target = "createdTime",source = "afterSaleOrder.createdTime")
    PurchaseAftersaleExportResult toExportResult(String type,
                                                 String state,
                                                 SkuRpcResult sku,
                                                 String params,
                                                 String annex,
                                                 Supplier supplier,
                                                 SupplierContacts contacts,
                                                 PurchaseAftersalePageResult afterSaleOrder
    );


    @Mapping(target = "address",expression = "java(supplier.getCompleteAddress())")
    @Mapping(target = "phone",source = "contact.phone")
    @Mapping(target = "province",source = "supplier.province")
    @Mapping(target = "city",source = "supplier.city")
    @Mapping(target = "area",source = "supplier.area")
    @Mapping(target = "street",source = "supplier.street")
    @Mapping(target = "name",source = "contact.name")
    @Mapping(target = "spAddress",expression = "java(from.getAddressDetail())")
    @Mapping(target = "spPhone",source = "from.phone")
    @Mapping(target = "spProvince",source = "from.province")
    @Mapping(target = "spCity",source = "from.city")
    @Mapping(target = "spArea",source = "from.area")
    @Mapping(target = "spStreet",source = "from.street")
    @Mapping(target = "spName",source = "from.name")
    @Mapping(target = "remark",source = "remark")
    @Mapping(target = "qualityWay",constant = "1")
    Ext toCkExt(Supplier supplier, SupplierContacts contact,SysBusinessUnit from,String remark);
}
