package com.seeease.flywheel_v4.web.app.operations.request;

import com.seeease.springframework.PageRequest;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.validation.constraints.NotBlank;


@EqualsAndHashCode(callSuper = true)
@Data
public class ContactListRequest extends PageRequest {

    /**
     * 查询内容
     */
    @NotBlank(message = "查询内容不能为空")
    private String key;
}
