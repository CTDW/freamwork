package com.seeease.flywheel_v4.web.app.sale.service.impl;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.seeease.flywheel_v4.client.enums.BusinessUnitTypeEnums;
import com.seeease.flywheel_v4.web.app.sale.request.SaleOrderCreateRequest;
import com.seeease.flywheel_v4.web.app.sale.request.ThirdSaleOrderConfirmRequest;
import com.seeease.flywheel_v4.web.app.sale.request.ThirdSaleOrderMergeRequest;
import com.seeease.flywheel_v4.web.app.sale.request.ThirdSaleOrderPageRequest;
import com.seeease.flywheel_v4.web.app.sale.result.ThirdSaleOrderMergeResult;
import com.seeease.flywheel_v4.web.app.sale.result.ThirdSaleOrderPageResult;
import com.seeease.flywheel_v4.web.app.sale.service.SaleOrderService;
import com.seeease.flywheel_v4.web.app.sale.service.ThirdSaleOrderService;
import com.seeease.flywheel_v4.web.domain.sale.mapping.ThirdSaleOrderLineMapping;
import com.seeease.flywheel_v4.web.domain.sale.mapping.ThirdSaleOrderMapping;
import com.seeease.flywheel_v4.web.infrastructure.dao.RepositoryFactory;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.entity.ThirdSaleOrder;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.entity.ThirdSaleOrderLine;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.entity.obj.BuyerInfoObj;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.enums.ThirdSaleStateEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.entity.SysBusinessUnit;
import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.entity.SysSaleChannel;
import com.seeease.goods.rpc.SkuFacade;
import com.seeease.goods.rpc.SpuFacade;
import com.seeease.goods.rpc.enums.SkuStateEnums;
import com.seeease.goods.rpc.request.SkuRpcRequest;
import com.seeease.goods.rpc.request.SpuRpcRequest;
import com.seeease.goods.rpc.result.SkuRpcResult;
import com.seeease.goods.rpc.result.SpuRpcResult;
import com.seeease.seeeaseframework.mybatis.domain.WhetherEnum;
import com.seeease.springframework.PageResult;
import com.seeease.springframework.context.UserContext;
import com.seeease.springframework.exception.ValidationUtil;
import com.seeease.springframework.utils.MultiUtils;
import com.seeease.springframework.utils.StringUtils;
import io.seata.spring.annotation.GlobalTransactional;
import org.apache.dubbo.config.annotation.DubboReference;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 8/2/24 2:05 下午
 **/
@Service
public class ThirdSaleOrderServiceImpl implements ThirdSaleOrderService {

    @Resource
    private RepositoryFactory repositoryFactory;
    @Resource
    private SaleOrderService saleOrderService;

    @DubboReference(version = "1.0.0", check = false)
    private SpuFacade spuFacade;

    @DubboReference(version = "1.0.0", check = false)
    private SkuFacade skuFacade;

    @Override
    public PageResult<ThirdSaleOrderPageResult> page(ThirdSaleOrderPageRequest request) {


        Integer buId = UserContext.getUser().getStore().getId();
        SysBusinessUnit bu = repositoryFactory.getBusinessUnitRepository().findById(buId);
        Set<Integer> scIds = new HashSet<>();
        if (bu.getType() != BusinessUnitTypeEnums.PLATFORM){
            List<SysSaleChannel> saleChannels = repositoryFactory.getSaleChannelRepository().listByMerchantId(buId);
            scIds.addAll(MultiUtils.toSet(saleChannels,SysSaleChannel::getId));
            if (StringUtils.isEmpty(scIds)) {
                return PageResult.buildEmpty();
            }
        }

        if (null != request.getScType()) {
            List<SysSaleChannel> temp = repositoryFactory.getSaleChannelRepository()
                    .listByType(request.getScType());
            if (StringUtils.isEmpty(temp)) {
                return PageResult.buildEmpty();
            }
            Set<Integer> partScIds = MultiUtils.toSet(temp, SysSaleChannel::getId);
            if (StringUtils.isEmpty(scIds)){
                scIds = partScIds;
            }else {
                scIds.retainAll(partScIds);
            }
        }

        //spu查询
        Set<String> orderIds = null;
        if (StringUtils.oneOfNonNull(
                request.getGoodsName(),
                request.getGoodsCode()
        )) {
            SpuRpcRequest rpcRequest = new SpuRpcRequest();
            rpcRequest.setGoodsCode(request.getGoodsCode());
            rpcRequest.setGoodsName(request.getGoodsName());
            List<SpuRpcResult> spuList = spuFacade.list(rpcRequest);
            if (StringUtils.isEmpty(spuList)) {
                return PageResult.buildEmpty();
            }
            Set<Integer> spuIds = MultiUtils.toSet(spuList, SpuRpcResult::getId);

            List<ThirdSaleOrderLine> lines = repositoryFactory.getThirdSaleOrderLineRepository()
                    .listBySpuIds(spuIds);
            if (StringUtils.isEmpty(lines)) {
                return PageResult.buildEmpty();
            }
            orderIds = MultiUtils.toSet(lines, ThirdSaleOrderLine::getOrderId);
        }

        //主表查询
        Page<ThirdSaleOrder> page = repositoryFactory.getThirdSaleOrderRepository().page(
                scIds,
                orderIds,
                request
        );
        if (StringUtils.isEmpty(page.getRecords())) {
            return PageResult.buildEmpty();
        }



        //销售渠道
        if (StringUtils.isEmpty(scIds)) {
            scIds = MultiUtils.toSet(page.getRecords(), ThirdSaleOrder::getScId);
        }
        Map<Integer, SysSaleChannel> scMap = MultiUtils.toMap(
                repositoryFactory.getSaleChannelRepository().listByIds(scIds),
                SysSaleChannel::getId
        );


        //查找是否存在合并后的单据，重新计算价格
        Set<String> mergedIds = MultiUtils.toSet(page.getRecords(), ThirdSaleOrder::getMergedId);
        Map<String, List<ThirdSaleOrder>> orderMap = repositoryFactory.getThirdSaleOrderRepository()
                .listByMergedIds(mergedIds)
                .stream()
                .collect(Collectors.groupingBy(ThirdSaleOrder::getOrderId));


        //组合
        List<ThirdSaleOrderPageResult> ret = MultiUtils.toList(
                page.getRecords(),
                record -> {
                    SysSaleChannel sc = scMap.get(record.getScId());
                    BigDecimal totalAmount = orderMap.get(record.getOrderId()).stream()
                            .map(ThirdSaleOrder::getTotalAmount)
                            .reduce(BigDecimal::add)
                            .orElse(BigDecimal.ZERO);

                    return ThirdSaleOrderMapping.INSTANCE.toPageResult(record, sc, totalAmount);
                }
        );

        return PageResult.<ThirdSaleOrderPageResult>builder()
                .result(ret)
                .totalCount(page.getTotal())
                .totalPage(page.getPages())
                .build();
    }

    @GlobalTransactional
    @Override
    public Boolean confirm(ThirdSaleOrderConfirmRequest request) {

        //step_1 合并单据 并且修改状态
        List<ThirdSaleOrder> orders = repositoryFactory.getThirdSaleOrderRepository().listByIds(request.getIds());
        String mergedId = UUID.randomUUID().toString();
        orders.forEach(order -> {
            order.setMergedId(mergedId);
            order.setState(ThirdSaleStateEnums.OK);
            order.setAuditTime(new Date());
        });
        repositoryFactory.getThirdSaleOrderRepository().submitBatch(orders);


        //step_2 参数转化 创建订单
        List<SaleOrderCreateRequest.Sku> skuList = MultiUtils.toList(
                request.getSkuList(),
                ThirdSaleOrderLineMapping.INSTANCE::toTocCreateRequest
        );

        ThirdSaleOrder order = orders.get(0);
        SysSaleChannel sysSaleChannel = repositoryFactory.getSaleChannelRepository().findById(order.getScId());

        SaleOrderCreateRequest tocCreateReq = ThirdSaleOrderMapping.INSTANCE.toTocCreateRequest(
                order.getQualityWay().getValue(),
                request,
                order.getBillRemark(),
                order.getOrderId(),
                mergedId,
                sysSaleChannel,
                skuList
        );

        saleOrderService.tocCreate(tocCreateReq);

        return true;
    }

    @Override
    public ThirdSaleOrderMergeResult mergeDetail(ThirdSaleOrderMergeRequest request) {
        List<ThirdSaleOrder> orders = repositoryFactory.getThirdSaleOrderRepository().listByIds(request.getIds());

        //step_1 订单创建校验
        Set<String> orderIds = MultiUtils.toSet(orders, ThirdSaleOrder::getOrderId);


        //step_2 状态校验
        Map<ThirdSaleStateEnums, List<ThirdSaleOrder>> stateMap = orders.stream().collect(Collectors.groupingBy(ThirdSaleOrder::getState));
        ValidationUtil.isTrue(
                stateMap.size() == 1 && stateMap.containsKey(ThirdSaleStateEnums.WAIT),
                "只有待审核订单才能合并提交");

        //step_3 mergeId校验
        Map<String, List<ThirdSaleOrder>> mergeIdMap = orders.stream().collect(Collectors.groupingBy(ThirdSaleOrder::getMergeId));
        ValidationUtil.isTrue(mergeIdMap.size() == 1, "客户信息不同无法合并订单");


        //step_4 获取三方行数据
        Set<String> thirdPartNos = MultiUtils.toSet(orders, ThirdSaleOrder::getOrderId);

        List<ThirdSaleOrderLine> lineList = repositoryFactory.getThirdSaleOrderLineRepository()
                .listByOrderIds(orderIds);

        //spu查询
        List<SkuRpcResult> rpcSkuList = new ArrayList<>();
        Map<Integer, SpuRpcResult> spuMap = new HashMap<>();
        Set<Integer> spuIdList = MultiUtils.toSet(lineList, ThirdSaleOrderLine::getSpuId);
        if (StringUtils.isNotEmpty(spuIdList)) {

            //sku列表查询
            SkuRpcRequest skuRpcRequest = new SkuRpcRequest();
            skuRpcRequest.setSpuIdList(spuIdList);
            skuRpcRequest.setState(SkuStateEnums.SALEABLE);
            skuRpcRequest.setPageLimit(lineList.size());
            skuRpcRequest.setPriced(WhetherEnum.YES);
            rpcSkuList = skuFacade.list(skuRpcRequest);

            //spu查询
            SpuRpcRequest spuRpcRequest = new SpuRpcRequest();
            spuRpcRequest.setIdList(spuIdList);
            spuMap = MultiUtils.toMap(
                    spuFacade.list(spuRpcRequest),
                    SpuRpcResult::getId
            );
        }


        /**
         * 1.根据sku的数量打散sku
         * 2.将三方订单行根据spuId分组
         * 3.根据商品所在进行分组,再根据spuId分组
         * 4.对比库存是否足够
         * 5.为三方订单明细分配对应的sku
         */
        //step1
        List<SkuRpcResult> splitSkuList = new ArrayList<>(); //打散后的sku列表
        for (SkuRpcResult sku : rpcSkuList) {
            for (int i = 0; i < sku.getSkuCount(); i++) {
                splitSkuList.add(sku);
            }
        }
        //step2
        Map<Integer, List<ThirdSaleOrderLine>> lineMap = lineList.stream()
                .filter(line -> Objects.nonNull(line.getSpuId()))
                .collect(Collectors.groupingBy(ThirdSaleOrderLine::getSpuId));
        //step3
        Map<Integer, List<SkuRpcResult>> skuStoreMap = splitSkuList.stream()
                .collect(Collectors.groupingBy(SkuRpcResult::getStoreId));

        //step4
        List<SkuRpcResult> targetSkuList = new ArrayList<>();
        for (Map.Entry<Integer, List<SkuRpcResult>> skuStoreMapEntry : skuStoreMap.entrySet()) {

            Map<Integer, List<SkuRpcResult>> spuIdGroup = skuStoreMapEntry.getValue().stream()
                    .collect(Collectors.groupingBy(SkuRpcResult::getSpuId));

            boolean find = true;
            for (Map.Entry<Integer, List<ThirdSaleOrderLine>> entry : lineMap.entrySet()) {
                Integer needSkuCount = entry.getValue().stream().map(ThirdSaleOrderLine::getCount)
                        .reduce(Integer::sum)
                        .orElse(0);

                List<SkuRpcResult> skuList = spuIdGroup.get(entry.getKey());
                int count = null == skuList ? 0 : skuList.size();
                if (needSkuCount > count) {
                    find = false;
                    break;
                }
            }

            if (find) { //对应仓库库存足够匹配
                targetSkuList = skuStoreMapEntry.getValue();
                break;
            }
        }

        //step_5
        //商品所在查询
        Set<Integer> storeIds = MultiUtils.toSet(targetSkuList, SkuRpcResult::getStoreId);
        Map<Integer, String> storeMap = MultiUtils.toMap(
                repositoryFactory.getBusinessUnitRepository().listByIds(storeIds),
                SysBusinessUnit::getId,
                SysBusinessUnit::getName
        );

        Map<Integer, SkuRpcResult> lineSkuMap = new HashMap<>();
        for (ThirdSaleOrderLine line : lineList) {
            Iterator<SkuRpcResult> iterator = targetSkuList.iterator();
            while (iterator.hasNext()) {
                SkuRpcResult next = iterator.next();
                if (line.getSpuId().equals(next.getSpuId())) {
                    lineSkuMap.put(line.getId(), next);
                    iterator.remove();
                    break;
                }
            }
        }



        //组合sku
        ArrayList<ThirdSaleOrderMergeResult.Sku> skuList = new ArrayList<>();

        for (ThirdSaleOrderLine line : lineList) {
            SkuRpcResult sku = lineSkuMap.get(line.getId());
            SpuRpcResult spu = null == line.getSpuId() ? null : spuMap.get(line.getSpuId());
            ThirdSaleOrderMergeResult.Sku item;
            if (sku != null) {
                item = ThirdSaleOrderLineMapping.INSTANCE.toMergeDetail(line, sku);
                item.setBelongName(storeMap.get(sku.getStoreId()));
            } else {
                item = ThirdSaleOrderLineMapping.INSTANCE.toMergeDetail(line, spu);
            }
            item.setDealPrice(line.getPrice());
            skuList.add(item);
        }

        BuyerInfoObj buyerInfo = orders.get(0).getBuyerInfo();
        return ThirdSaleOrderMapping.INSTANCE.toMergeDetail(thirdPartNos, buyerInfo, request.getIds(), skuList);
    }


}
