package com.seeease.flywheel_v4.web.infrastructure.dao.common.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;

/**
 * @TableName area
 */
@TableName(value = "v4_area")
@Data
public class Area implements Serializable {
    /**
     *
     */
    @TableId
    private Integer id;

    /**
     *
     */
    private String title;

    /**
     *
     */
    private Integer parentId;

    /**
     *
     */
    private String shortName;

    /**
     *
     */
    private Integer areaCode;

    /**
     *
     */
    private Integer zipCode;

    /**
     *
     */
    private String pinyin;

    /**
     *
     */
    private String lng;

    /**
     *
     */
    private String lat;

    /**
     *
     */
    private Integer level;

    /**
     *
     */
    private String position;

    /**
     *
     */
    private Integer sort;

    @TableField(exist = false)
    private static final long serialVersionUID = 1L;
}