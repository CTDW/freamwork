package com.seeease.flywheel_v4.web.app.fix.request;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;


/**
 * @Description 维修中心-维修项目 请求值
 * @Date 2024-10-2 20:20
 * @Author by hk
 */
@Data
public class FixItemDetailRequest {

    @ApiModelProperty(value = "id",required = true)
    @NotNull(message = "维修项目id不能为空")
    private Long id;
}
