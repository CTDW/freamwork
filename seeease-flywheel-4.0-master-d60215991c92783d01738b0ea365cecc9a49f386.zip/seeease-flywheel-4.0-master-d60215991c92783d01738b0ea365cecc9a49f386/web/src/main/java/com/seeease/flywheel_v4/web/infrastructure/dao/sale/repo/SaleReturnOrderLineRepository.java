package com.seeease.flywheel_v4.web.infrastructure.dao.sale.repo;


import com.seeease.flywheel_v4.web.infrastructure.dao.sale.entity.SaleReturnOrderLine;

import java.util.List;
import java.util.Set;

/**
 *
 * @author 西门 游
 * @version 1.0
 * @since 5/31/24 4:55 下午
 **/
public interface SaleReturnOrderLineRepository {


    /**
     * 查找
     * @param returnId
     * @return
     */
    List<SaleReturnOrderLine> listByMainId(Integer returnId);

    /**
     * 查找
     * @param returnIds
     * @return
     */
    List<SaleReturnOrderLine> listByMainIds(Set<Integer> returnIds);

    /**
     * 提交
     * @param lineList
     * @return
     */
    void submitBatch(List<SaleReturnOrderLine> lineList);

    /**
     * 查找
     * @param skuIdList
     * @return
     */
    List<SaleReturnOrderLine> listBySkuIds(Set<Integer> skuIdList);

    /**
     * 查找
     * @param returnId
     * @param skuIdList
     * @return
     */
    List<SaleReturnOrderLine> listByMainIdAndSkuIds(Integer returnId, Set<Integer> skuIdList);

    /**
     * 查找
     * @param saleIdList
     * @return
     */
    List<SaleReturnOrderLine> listBySaleIds(Set<Integer> saleIdList);

    /**
     * 查找
     * @param storeId
     * @return
     */
    List<SaleReturnOrderLine> listByStoreId(Integer storeId);
}
