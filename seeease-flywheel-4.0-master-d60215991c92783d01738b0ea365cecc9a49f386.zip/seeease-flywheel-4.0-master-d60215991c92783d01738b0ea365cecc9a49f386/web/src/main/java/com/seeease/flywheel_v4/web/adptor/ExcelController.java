package com.seeease.flywheel_v4.web.adptor;

import com.seeease.flywheel_v4.web.domain.excel.core.ExcelCmdExe;
import com.seeease.flywheel_v4.web.domain.excel.core.ExportCmd;
import com.seeease.flywheel_v4.web.domain.excel.core.ImportCmd;
import com.seeease.springframework.SingleResponse;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Map;

/**
 * <p>excel导入导出</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/29/24 4:34 下午
 **/
@RestController
@RequestMapping("excel")
public class ExcelController {

    @Resource
    private ExcelCmdExe importCmdExe;

    /**
     * 导入统一入口
     */
    @PostMapping("/import/{useCase}")
    public <R> SingleResponse<List<R>> doImport(@RequestParam("file") MultipartFile file,
                                                @PathVariable String useCase) {
        ImportCmd<Map<String, Object>> cmd = new ImportCmd<>();
        cmd.setUseCase(useCase);
        return SingleResponse.of(importCmdExe.handleImport(cmd, file));
    }


    /**
     * 导出统一入口
     */
    @PostMapping("/export/{useCase}")
    public void doExport(@RequestBody Map<String, Object> params,
                                            @PathVariable String useCase,
                                            HttpServletResponse response) {
        ExportCmd<Map<String, Object>> cmd = new ExportCmd<>();
        cmd.setUseCase(useCase);
        cmd.setRequest(params);
        cmd.setResponse(response);
        importCmdExe.handleExport(cmd);
    }

}
