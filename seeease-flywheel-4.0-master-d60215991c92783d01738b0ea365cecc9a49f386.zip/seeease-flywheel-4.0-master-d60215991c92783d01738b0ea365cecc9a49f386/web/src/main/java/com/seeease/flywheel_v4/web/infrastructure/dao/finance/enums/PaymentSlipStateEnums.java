package com.seeease.flywheel_v4.web.infrastructure.dao.finance.enums;


import com.seeease.seeeaseframework.mybatis.transitionstate.IStateEnum;
import com.seeease.seeeaseframework.mybatis.transitionstate.ITransitionStateEnum;
import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * <p>申请打款单</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/5/24 1:47 下午
 **/
@AllArgsConstructor
@Getter
public enum PaymentSlipStateEnums implements IStateEnum<Integer> {
    WAIT_CONFIRM(1,"待确认"),
    CONFIRMED(2,"已确认"),
    TURN_DOWN(3,"驳回"),
    CANCEL(4,"取消"),
    VOID(5,"作废"),
    ;
    private Integer value;
    private String desc;

    @Getter
    @AllArgsConstructor
    public enum TransitionEnum implements ITransitionStateEnum {
        STEP_1(WAIT_CONFIRM,CONFIRMED,"待确认 -> 已确认"),
        STEP_2(WAIT_CONFIRM,TURN_DOWN,"待确认 -> 驳回"),
        STEP_3(CONFIRMED,VOID,"已确认  -> 作废"),
        STEP_4(TURN_DOWN,WAIT_CONFIRM,"驳回 -> 待确认"),
        STEP_5(VOID,WAIT_CONFIRM,"作废  -> 待确认"),
        ;
        private PaymentSlipStateEnums fromState;
        private PaymentSlipStateEnums toState;
        private String desc;

    }
}
