package com.seeease.flywheel_v4.web.app.fix.request;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;


/**
 * @Description 维修中心-维修单-送外维修 请求值
 * @Date 2024-10-2 20:20
 * @Author by hk
 */
@Data
public class FixOrderSendOutRequest {

    @ApiModelProperty(value = "id",required = true)
    @NotNull(message = "维修单id不能为空")
    private Long id;

    @ApiModelProperty(value = "送修备注")
    private String sendOutRemark;
}
