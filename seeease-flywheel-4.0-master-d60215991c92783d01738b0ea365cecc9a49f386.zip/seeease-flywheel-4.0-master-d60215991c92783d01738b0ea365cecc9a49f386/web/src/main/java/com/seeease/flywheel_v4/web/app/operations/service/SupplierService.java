package com.seeease.flywheel_v4.web.app.operations.service;

import com.seeease.flywheel_v4.web.app.operations.request.ContactListRequest;
import com.seeease.flywheel_v4.web.app.operations.request.SupplierPageRequest;
import com.seeease.flywheel_v4.web.app.operations.request.SupplierSubmitRequest;
import com.seeease.flywheel_v4.web.app.operations.result.SupplierContactListResult;
import com.seeease.flywheel_v4.web.app.operations.result.SupplierPageResult;
import com.seeease.springframework.PageResult;

import java.util.List;

/**
 * <p>供应商</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/4/24 4:43 下午
 **/
public interface SupplierService {
    /**
     * 供应商创建
     *
     * @return 创建结果
     */
    Boolean create(SupplierSubmitRequest request);

    /**
     * 供应商更新
     *
     * @return 更新结果
     */
    Boolean update(SupplierSubmitRequest request);

    /**
     * 供应商分页查询
     *
     * @return 分页结果
     */
    PageResult<SupplierPageResult> page(SupplierPageRequest request);


    /**
     * 系统运营-联系人列表查询
     *
     * @return 列表结果
     */
    List<SupplierContactListResult> contactList(ContactListRequest request);
}
