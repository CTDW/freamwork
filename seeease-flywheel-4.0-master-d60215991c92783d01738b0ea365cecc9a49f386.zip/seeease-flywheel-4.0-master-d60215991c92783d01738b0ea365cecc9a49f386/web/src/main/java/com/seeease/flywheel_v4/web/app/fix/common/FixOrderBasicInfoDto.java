package com.seeease.flywheel_v4.web.app.fix.common;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.seeease.flywheel_v4.web.infrastructure.dao.fix.entity.FixOrder;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.Date;

/**
 * @Description 维修单 基础信息
 * @Date 2024-10-4 18:17
 * @Author by hk
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FixOrderBasicInfoDto implements Serializable {

    @ApiModelProperty(value = "维修单号")
    private String orderNumber;

    @ApiModelProperty(value = "维修单状态 1：维修登记 2：待接修 3：维修中 4：抛光中 5：清洗中 6：师傅组装 7：质检中 " +
            "8：待维修出库 9：送外维修 10：等配件 11：已完成 12:已取消")
    private Integer orderStatus;

    @ApiModelProperty(value = "订单类型，1：内部 2：外部", required = true)
    @NotNull(message = "订单类型不能为空")
    private Integer orderType;

    @ApiModelProperty(value = "订单来源 ")
    @NotNull(message = "订单来源不能为空")
    private Integer orderSource;

    @ApiModelProperty(value = "订单来源 ")
    private String orderSourceStr;

    @ApiModelProperty(value = "维修优先级，1：高 2：中 3：低", required = true)
    @NotNull(message = "维修优先级不能为空")
    private Integer priorityType;

    @ApiModelProperty(value = "是否加急", required = true)
    @NotNull(message = "是否加急不能为空")
    private Boolean urgent;

    @ApiModelProperty(value = "维修基地")
    private String fixBase;

    @ApiModelProperty(value = "预计耗时 单位天")
    private Integer consumeTime;

    @ApiModelProperty(value = "快递单")
    private String expressNumber;

    @ApiModelProperty(value = "维修诉求")
    @Length(max = 500, message = "维修诉求，不能超过500字符")
    private String appeal;

    @ApiModelProperty(value = "瑕疵说明")
    @Length(max = 500, message = "瑕疵说明，不能超过500字符")
    private String defectDesc;

    @ApiModelProperty(value = "创建人")
    private String createdBy;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    @ApiModelProperty(value = "创建时间")
    private Date createdTime;

    public static FixOrderBasicInfoDto fromEntity(FixOrder detail) {
        return FixOrderBasicInfoDto.builder()

                .orderNumber(detail.getOrderNumber())
                .orderStatus(detail.getOrderStatus())
                .createdBy(detail.getCreatedBy())
                .createdTime(detail.getCreatedTime())

                .orderType(detail.getOrderType())
                .orderSource(detail.getOrderSource())
                .orderSourceStr(detail.getOrderSourceStr())
                .priorityType(detail.getPriorityType())

                .urgent(detail.getUrgent())
                .fixBase(detail.getFixBase())

                .consumeTime(detail.getConsumeTime())
                .expressNumber(detail.getExpressNumber())
                .appeal(detail.getAppeal())
                .defectDesc(detail.getDefectDesc())
                .build();
    }

    public void toEntity(FixOrder detail) {

        detail.setOrderType(orderType);
        detail.setOrderSource(orderSource);
        detail.setOrderSourceStr(orderSourceStr);
        detail.setPriorityType(priorityType);
        detail.setUrgent(urgent);
        detail.setConsumeTime(consumeTime);
        detail.setExpressNumber(expressNumber);
        detail.setAppeal(appeal);
        detail.setDefectDesc(defectDesc);
    }
}
