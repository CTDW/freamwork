package com.seeease.flywheel_v4.web.app.sale.result;


import com.seeease.goods.rpc.request.SkuAnnexeRpcResult;
import com.seeease.goods.rpc.result.ProductParamRpcResult;
import lombok.Data;

import java.math.BigDecimal;
import java.util.List;
import java.util.Set;


@Data
public class ThirdSaleOrderMergeResult {

    /**
     * ids
     */
    private Set<Integer> ids;
    /**
     * 三方单号列表
     */
    private Set<String> thirdPartNos;

    /**
     * 客户姓名
     */
    private String buyerName;
    /**
     * 客户电话
     */
    private String buyerPhone;
    /**
     * 客户地址
     */
    private String buyerAddress;

    /**
     * sku列表
     */
    private List<Sku> skuList;

    @Data
    public static class Sku{
        /**
         * 采购业务单据行id
         */
        private Integer lineId;
        /**
         * skuId
         */
        private Integer id;
        /**
         * spuId
         */
        private Integer spuId;
        /**
         * 商品名称
         */
        private String goodsName;
        /**
         * 货号
         */
        private String goodsCode;

        /**
         * spu编码
         */
        private String spuCode;
        /**
         * sku参数列表
         */
        private List<ProductParamRpcResult> skuParams;
        /**
         * 附件
         */
        private List<SkuAnnexeRpcResult> annexe;
        /**
         * 唯一码
         */
        private String skuCode;
        /**
         * 类目
         */
        private String categoryName;
        /**
         * 品牌
         */
        private String brandName;
        /**
         * 图片
         */
        private String spuImage;
        /**
         * 类目id
         */
        private Integer categoryId;
        /**
         * 唯一类型
         */
        private Integer uniqueType;

        /**
         * 销售数量
         */
        private Integer count;
        /**
         * 成交价
         */
        private BigDecimal dealPrice;
        /**
         * 商品所在
         */
        private String belongName;
    }


}
