package com.seeease.flywheel_v4.web.app.wms.service.impl;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.google.common.collect.Lists;
import com.seeease.flywheel_v4.web.app.wms.request.WmsRkCountUpdateRequest;
import com.seeease.flywheel_v4.web.app.wms.request.WmsRkPageRequest;
import com.seeease.flywheel_v4.web.app.wms.request.WmsRkStateRequest;
import com.seeease.flywheel_v4.web.app.wms.result.WmsRkPageResult;
import com.seeease.flywheel_v4.web.app.wms.service.WmsRkService;
import com.seeease.flywheel_v4.web.domain.wms.mapping.WmsRkMapping;
import com.seeease.flywheel_v4.web.domain.wms.observer.base.WmsSubject;
import com.seeease.flywheel_v4.web.infrastructure.dao.RepositoryFactory;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.entity.PurchaseOrder;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.entity.PurchaseOrderLine;
import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.entity.SysBusinessUnit;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.WmsRk;
import com.seeease.flywheel_v4.web.util.SerialNoGenerator;
import com.seeease.goods.rpc.SkuFacade;
import com.seeease.goods.rpc.enums.SkuNodeStateEnums;
import com.seeease.goods.rpc.request.SkuCountUpdateRpcRequest;
import com.seeease.goods.rpc.request.SkuRpcRequest;
import com.seeease.goods.rpc.result.SkuRpcResult;
import com.seeease.seeeaseframework.mybatis.utils.EnumUtils;
import com.seeease.springframework.PageResult;
import com.seeease.springframework.context.UserContext;
import com.seeease.springframework.exception.ValidationUtil;
import com.seeease.springframework.utils.MultiUtils;
import com.seeease.springframework.utils.StringUtils;
import io.seata.spring.annotation.GlobalTransactional;
import org.apache.dubbo.config.annotation.DubboReference;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.*;
import java.util.function.Function;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/20/24 11:46 上午
 **/
@Service
public class WmsRkServiceImpl implements WmsRkService {
    @Resource
    private RepositoryFactory repositoryFactory;
    @DubboReference(version = "1.0.0", check = false)
    private SkuFacade skuFacade;
    @Resource
    private WmsSubject wmsSubject;

    @Override
    public PageResult<WmsRkPageResult> page(WmsRkPageRequest request) {

        List<Integer> statistics = Lists.newArrayList(0, 0, 0, 0);
        //sku数据
        Set<Integer> skuIdList = null;
        List<SkuRpcResult> skuList = null;

        //sku查询
        if (StringUtils.oneOfNonNull(
                request.getSkuCode(),
                request.getGoodsName()
        )) {
            SkuRpcRequest skuRpcRequest = WmsRkMapping.INSTANCE.toSkuRcpRequest(request);
            skuList = skuFacade.list(skuRpcRequest);

            skuIdList = MultiUtils.toSet(
                    skuList,
                    SkuRpcResult::getId
            );

            if (skuIdList.isEmpty()){
                return PageResult.buildEmpty(statistics);
            }

        }

        //主表查询
        Integer buId = UserContext.getUser().getStore().getId();
        request.setBuId(buId);
        Page<WmsRk> page = repositoryFactory.getWmsRkRepository().page(request,skuIdList);

        //统计数据结果
        statistics = repositoryFactory.getWmsRkRepository().statistics(request,skuIdList);

        if (page.getRecords().isEmpty()){
            return PageResult.buildEmpty(statistics);
        }

        //重新查询sku列表
        if (null == skuList) {
            skuIdList = MultiUtils.toSet(page.getRecords(), WmsRk::getSkuId);
            SkuRpcRequest skuRpcRequest = new SkuRpcRequest();
            skuRpcRequest.setIdList(skuIdList);
            skuList = skuFacade.list(skuRpcRequest);
        }

        //来源
        Set<Integer> originIds = MultiUtils.toSet(page.getRecords(), WmsRk::getBuId);
        Map<Integer, String> originMap = MultiUtils.toMap(
                repositoryFactory.getBusinessUnitRepository().listByIds(originIds),
                SysBusinessUnit::getId,
                SysBusinessUnit::getName
        );


        //组合数据
        //skuMap数据
        Map<Integer, SkuRpcResult> skuMap = MultiUtils.toMap(
                skuList,
                SkuRpcResult::getId,
                Function.identity()
        );

        //组合
        List<WmsRkPageResult> ret = MultiUtils.toList(
                page.getRecords(),
                v -> {
                    WmsRkPageResult item = WmsRkMapping.INSTANCE.toPageResult(v, skuMap.get(v.getSkuId()));
                    item.setOriginName(originMap.get(v.getBuId()));
                    return item;
                }
        );


        return PageResult.<WmsRkPageResult>builder()
                .result(ret)
                .ext(statistics)
                .totalCount(page.getTotal())
                .totalPage(page.getPages())
                .build();
    }




    @GlobalTransactional
    @Override
    public Boolean state(WmsRkStateRequest request) {
        List<WmsRk> wmsRkList = repositoryFactory.getWmsRkRepository().listByIds(request.getIdList());
        ValidationUtil.isTrue(StringUtils.isNotEmpty(wmsRkList), "入库单据id错误");
        //质检不通过 | 维修 异常原因必填
        final List<Integer> condition = Lists.newArrayList(
                SkuNodeStateEnums.QWX.getValue(),
                SkuNodeStateEnums.ZJ_BTG.getValue()
        );
        ValidationUtil.isTrue(
                !(condition.contains(request.getNodeState()) && StringUtils.isEmpty(request.getReason())),
                "异常原因必填"
        );

        SkuNodeStateEnums nodeState = EnumUtils.of(SkuNodeStateEnums.class, request.getNodeState());

        //step_1 如果是质检不通过 并且是采购入库单需要复制 异常原因至采购单
        if (nodeState == SkuNodeStateEnums.ZJ_BTG){
            WmsRk rk = wmsRkList.get(0);
            if (rk.getSerialNo().startsWith(SerialNoGenerator.Type.CG.getPrefix())){
                PurchaseOrder purchaseOrder = repositoryFactory.getPurchaseOrderRepository().findByIdOrSerialNo(
                        null,
                        rk.getSerialNo()
                );

                PurchaseOrderLine line = repositoryFactory.getPurchaseOrderLineRepository().findByPurchaseIdAndSkuId(
                        purchaseOrder.getId(),
                        rk.getSkuId()
                );
                line.setReason(request.getReason());
                repositoryFactory.getPurchaseOrderLineRepository().submit(line);
            }
        }



        Date rkTime = new Date(); //入库时间
        for (WmsRk wmsRk : wmsRkList) {
            //入库时间添加
            if (Objects.equals(request.getNodeState(), SkuNodeStateEnums.YRK.getValue())) {
                wmsRk.setRkTime(rkTime);
            }
            //更新数据转换
            WmsRkMapping.INSTANCE.toEntityForUpdate(wmsRk, request);
        }

        //执行数据wms入库数据状态变更操作以及观察者回调
        wmsSubject.rkState(wmsRkList,nodeState);

        return true;
    }

    @Transactional
    @Override
    public Boolean countUpdate(WmsRkCountUpdateRequest request) {
        WmsRk wmsRk = repositoryFactory.getWmsRkRepository().findById(request.getId());
        ValidationUtil.notNull(wmsRk,"入库单id错误");
        ValidationUtil.isTrue(wmsRk.getNodeState() == SkuNodeStateEnums.DRK,"入库单状态无法修改数量");


        //step_1 sku修改
        WmsRkMapping.INSTANCE.toEntityForUpdate(wmsRk,request);
        SkuCountUpdateRpcRequest rpcRequest = new SkuCountUpdateRpcRequest();
        rpcRequest.setCount(request.getCount());
        rpcRequest.setSkuId(wmsRk.getSkuId());
        skuFacade.countUpdate(rpcRequest);


        //step_2 执行wms数据变更 此时节点状态不变
        wmsSubject.rkState(Collections.singletonList(wmsRk),null);

        return true;
    }
}
