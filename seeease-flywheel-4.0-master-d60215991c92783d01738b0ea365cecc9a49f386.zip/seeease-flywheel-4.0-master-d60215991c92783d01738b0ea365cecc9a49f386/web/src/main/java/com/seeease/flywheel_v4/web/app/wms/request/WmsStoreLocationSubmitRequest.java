package com.seeease.flywheel_v4.web.app.wms.request;


import com.seeease.springframework.RequestValidGroup;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * @ Description   :
 * @ Author        :  西门 游
 * @ CreateDate    :  6/6/24
 * @ Version       :  1.0
 */

@Data
public class WmsStoreLocationSubmitRequest {

    /**
     * 主键id
     */
    @NotNull(message = "id不能为空",groups = {RequestValidGroup.Update.class})
    private Integer id;

    /**
     * 名称
     */
    @NotBlank(message = "库位名称不能为空")
    private String name;
    /**
     * 子库区id
     */
    @NotNull(message = "子库区id不能为空")
    private Integer childAreaId;

    /**
     * 状态
     */
    private Integer state;

    /**
     * spuId
     */
    @NotNull(message = "spuId不能为空")
    private Integer spuId;


}
