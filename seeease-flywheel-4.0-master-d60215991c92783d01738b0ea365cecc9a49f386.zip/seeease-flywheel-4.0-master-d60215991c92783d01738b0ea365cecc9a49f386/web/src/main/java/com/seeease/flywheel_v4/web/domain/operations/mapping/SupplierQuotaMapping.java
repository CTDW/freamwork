package com.seeease.flywheel_v4.web.domain.operations.mapping;


import com.seeease.flywheel_v4.client.enums.BusinessUnitTypeEnums;
import com.seeease.flywheel_v4.web.app.operations.result.SupplierQuotaDetailResult;
import com.seeease.flywheel_v4.web.app.operations.result.SupplierQuotaPageResult;
import com.seeease.flywheel_v4.web.app.operations.result.SupplierQuotaResult;
import com.seeease.flywheel_v4.web.infrastructure.config.EnumMapping;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.SupplierQuota;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.SupplierQuotaDetail;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;

import java.math.BigDecimal;


/**
 * <p>
 * 供应商
 * </p>
 *
 * @author 西门 游
 * @since 2023-10-27
 */
@Mapper(componentModel = "spring",
        builder = @Builder(disableBuilder = true),
        nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS,
        nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE,
        imports = {BusinessUnitTypeEnums.class})
public interface SupplierQuotaMapping extends EnumMapping {

    SupplierQuotaMapping INSTANCE = Mappers.getMapper(SupplierQuotaMapping.class);

    @Mapping(target = "consignmentCredit",source = "item.jsQuota")
    @Mapping(target = "normalCredit",source = "item.normalQuota")
    SupplierQuotaPageResult toPageResult(SupplierQuota item,
                                         String supplierName,
                                         BigDecimal consignmentAmount);

    @Mapping(target = "name",source = "userName")
    SupplierQuotaDetailResult.Item toDetailResult(SupplierQuotaDetail detail);

    @Mapping(target = "consignmentCredit",source = "jsQuota")
    @Mapping(target = "normalCredit",source = "normalQuota")
    SupplierQuotaResult to(SupplierQuota quota);
}
