package com.seeease.flywheel_v4.web.app.fix.result;

import com.seeease.flywheel_v4.web.app.fix.common.*;
import com.seeease.flywheel_v4.web.infrastructure.dao.fix.entity.FixOrder;
import com.seeease.flywheel_v4.web.infrastructure.dao.fix.entity.FixOrderLog;
import com.seeease.flywheel_v4.web.infrastructure.dao.fix.entity.FixOrderPart;
import io.swagger.annotations.ApiModelProperty;
import lombok.Builder;
import lombok.Data;

import java.io.Serializable;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @Description 维修中心-维修管理 详情
 * @Date 2024-10-2 20:20
 * @Author by hk
 */
@Data
@Builder
public class FixOrderDetailResult implements Serializable {

    @ApiModelProperty(value = "id")
    private Long id;

    @ApiModelProperty(value = "基本信息")
    private FixOrderBasicInfoDto basicInfo;

    @ApiModelProperty(value = "客户信息")
    private FixCustomInfoDto customInfo;

    @ApiModelProperty(value = "商品信息")
    private FixGoodsDto goodsInfo;

    @ApiModelProperty(value = "维修信息")
    private FixInfoDto fixInfo;

    @ApiModelProperty(value = "维修报价项")
    private List<FixItemDto> fixItemList;

    @ApiModelProperty(value = "配件")
    private List<FixPartsDto> partList;

    @ApiModelProperty(value = "维修日志")
    private List<FixLogDto> fixLogList;

    public static FixOrderDetailResult fromEntity(FixOrder detail, List<FixOrderLog> orderLogList, List<FixOrderPart> orderPartList) {
        return FixOrderDetailResult.builder()

                .id(detail.getId())

                .basicInfo(FixOrderBasicInfoDto.fromEntity(detail))
                .customInfo(FixCustomInfoDto.fromEntity(detail))
                .goodsInfo(FixGoodsDto.fromEntity(detail))
                .fixInfo(FixInfoDto.fromEntity(detail))

                // 维修报价项
                .fixItemList(detail.getFixItemList())
                // 配件
                .partList(orderPartList.stream().map(FixPartsDto::fromEntity).collect(Collectors.toList()))
                // 维修日志
                .fixLogList(orderLogList.stream().map(FixLogDto::fromEntity).collect(Collectors.toList()))

                .build();
    }

}
