package com.seeease.flywheel_v4.web.infrastructure.config;

import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import java.lang.annotation.*;

/**
 * <p>mapStruct 忽略baseDomain字段</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 11/22/23 4:59 下午
 **/
@Target({ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Mappings(value = {
        @Mapping(target = "id", ignore = true),
        @Mapping(target = "revision", ignore = true),
        @Mapping(target = "createdId", ignore = true),
        @Mapping(target = "createdBy", ignore = true),
        @Mapping(target = "createdTime", ignore = true),
        @Mapping(target = "updatedId", ignore = true),
        @Mapping(target = "updatedBy", ignore = true),
        @Mapping(target = "updatedTime", ignore = true),
        @Mapping(target = "deleted", ignore = true),

})
public @interface MappingIgnore {

}
