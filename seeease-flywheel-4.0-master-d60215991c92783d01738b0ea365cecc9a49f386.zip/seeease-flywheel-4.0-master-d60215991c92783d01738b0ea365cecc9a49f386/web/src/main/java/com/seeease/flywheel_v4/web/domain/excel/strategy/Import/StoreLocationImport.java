package com.seeease.flywheel_v4.web.domain.excel.strategy.Import;

import com.alibaba.cola.extension.Extension;
import com.seeease.flywheel_v4.web.app.excel.request.StoreLocationImportRequest;
import com.seeease.flywheel_v4.web.domain.excel.core.ImportExtPtl;
import com.seeease.flywheel_v4.web.infrastructure.dao.RepositoryFactory;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.WmsStoreLocation;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.WmsStoreLocationLevelTypeEnums;
import com.seeease.goods.rpc.SpuFacade;
import com.seeease.goods.rpc.request.SpuRpcRequest;
import com.seeease.goods.rpc.result.SpuRpcResult;
import com.seeease.seeeaseframework.mybatis.domain.WhetherEnum;
import com.seeease.springframework.context.UserContext;
import com.seeease.springframework.exception.ValidationUtil;
import com.seeease.springframework.utils.MultiUtils;
import org.apache.dubbo.config.annotation.DubboReference;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.*;

/**
 * @author 西门 游
 * @version 1.0
 * @since 9/11/24 1:39 下午
 **/
@Service
@Extension(bizId = "import", useCase = "storeLocation")
public class StoreLocationImport implements ImportExtPtl<StoreLocationImportRequest, Void> {

    @DubboReference(check = false, version = "1.0.0")
    private SpuFacade spuFacade;

    @Resource
    private RepositoryFactory repositoryFactory;

    @Override
    public Class<StoreLocationImportRequest> getRequestClass() {
        return StoreLocationImportRequest.class;
    }

    @Override
    public void validate(List<StoreLocationImportRequest> data) {
    }


    @Override
    public List<Void> handle(List<StoreLocationImportRequest> data) {
        //step_1 查询spu
        Set<String> goodsCodes = MultiUtils.toSet(data, StoreLocationImportRequest::getGoodsCode);
        SpuRpcRequest rpcRequest = new SpuRpcRequest();
        rpcRequest.setGoodsCodes(goodsCodes);
        List<SpuRpcResult> spuList = spuFacade.list(rpcRequest);
        Map<String, SpuRpcResult> spuMap = MultiUtils.toMap(
                spuList,
                SpuRpcResult::getGoodsCode
        );


        //step_2 根据名称查找子库区
        Integer storeId = UserContext.getUser().getStore().getId();
        Set<String> areaNams = MultiUtils.toSet(data, StoreLocationImportRequest::getChildAreaName);
        List<WmsStoreLocation> areaList = repositoryFactory.getWmsStoreLocationRepository()
                .listChildArea(storeId, areaNams);
        Map<String, WmsStoreLocation> areaMap = MultiUtils.toMap(
                areaList,
                WmsStoreLocation::getName
        );

        //根据子库区查找库位
        Set<Integer> pids = MultiUtils.toSet(areaList, WmsStoreLocation::getId);
        Set<Integer> spuIds = MultiUtils.toSet(spuList, SpuRpcResult::getId);
        Map<Integer, WmsStoreLocation> locationMap = MultiUtils.toMap(
                repositoryFactory.getWmsStoreLocationRepository().listLocation(pids, spuIds),
                WmsStoreLocation::getSpuId
        );


        ArrayList<WmsStoreLocation> insertList = new ArrayList<>();
        for (StoreLocationImportRequest item : data) {
            SpuRpcResult spu = spuMap.get(item.getGoodsCode());
            ValidationUtil.notNull(spu, "商品编码:" + item.getGoodsCode() + "不存在对应spu");
            WmsStoreLocation storeLocation = areaMap.get(item.getChildAreaName());
            ValidationUtil.notNull(storeLocation, "子库区名称:" + item.getChildAreaName() + "不存在");


            WmsStoreLocation location = locationMap.get(spu.getId());
            if (location == null) {
                location = new WmsStoreLocation();
                location.setStoreId(storeId);
                location.setName(item.getLocationName());
                location.setLevel(WmsStoreLocationLevelTypeEnums.LOCATION);
                location.setPid(storeLocation.getId());
                location.setSpuId(spu.getId());
                location.setState(WhetherEnum.YES);
                insertList.add(location);
            } else {
                location.setName(item.getLocationName());
                insertList.add(location);
            }
        }
        repositoryFactory.getWmsStoreLocationRepository().submitBatch(insertList);


        return Collections.emptyList();
    }
}
