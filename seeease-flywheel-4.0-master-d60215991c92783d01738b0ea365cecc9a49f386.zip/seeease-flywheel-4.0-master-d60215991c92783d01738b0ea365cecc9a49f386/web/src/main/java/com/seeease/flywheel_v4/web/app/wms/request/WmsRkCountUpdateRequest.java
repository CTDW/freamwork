package com.seeease.flywheel_v4.web.app.wms.request;


import com.seeease.springframework.PageRequest;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

/**
 * @ Description   :
 * @ Author        :  西门 游
 * @ CreateDate    :  6/6/24
 * @ Version       :  1.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class WmsRkCountUpdateRequest extends PageRequest {

    /**
     * 入库单主键id
     */
    @NotNull(message = "入库单主键id不能为空")
    private Integer id;

    /**
     * 入库时实际的收货数量
     */
    @NotNull(message = "数量不能为空")
    @Min(value = 0,message = "入库时实际的收货数量错误")
    private Integer count;




}
