package com.seeease.flywheel_v4.web.app.purchase.service.impl;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.seeease.flywheel_v4.web.app.purchase.request.PurchaseDemandCancelRequest;
import com.seeease.flywheel_v4.web.app.purchase.request.PurchaseDemandDetailRequest;
import com.seeease.flywheel_v4.web.app.purchase.request.PurchaseDemandPageRequest;
import com.seeease.flywheel_v4.web.app.purchase.request.PurchaseDemandSubmitRequest;
import com.seeease.flywheel_v4.web.app.purchase.result.PurchaseDemandDetailResult;
import com.seeease.flywheel_v4.web.app.purchase.result.PurchaseDemandPageResult;
import com.seeease.flywheel_v4.web.app.purchase.service.PurchaseDemandService;
import com.seeease.flywheel_v4.web.domain.purchase.mapping.PurchaseDemandMapping;
import com.seeease.flywheel_v4.web.infrastructure.dao.RepositoryFactory;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.entity.PurchaseDemand;
import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.entity.SysBusinessUnit;
import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.entity.SysUser;
import com.seeease.flywheel_v4.client.enums.BusinessUnitTypeEnums;
import com.seeease.flywheel_v4.web.util.SerialNoGenerator;
import com.seeease.goods.rpc.SpuFacade;
import com.seeease.goods.rpc.request.SpuRpcRequest;
import com.seeease.goods.rpc.result.SpuRpcResult;
import com.seeease.springframework.PageResult;
import com.seeease.springframework.exception.ValidationUtil;
import com.seeease.springframework.utils.MultiUtils;
import com.seeease.springframework.utils.StringUtils;
import org.apache.dubbo.config.annotation.DubboReference;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.*;
import java.util.function.Function;

/**
 * <p>采购需求</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/5/24 1:58 下午
 **/
@Service
public class PurchaseDemandServiceImpl implements PurchaseDemandService {

    @DubboReference(check = false, version = "1.0.0")
    private SpuFacade spuFacade;

    @Resource
    private RepositoryFactory repositoryFactory;


    @Override
    public Boolean create(PurchaseDemandSubmitRequest request) {
        SpuRpcRequest rpcRequest = new SpuRpcRequest();
        rpcRequest.setIdList(Collections.singleton(request.getSpuId()));
        List<SpuRpcResult> spuList = spuFacade.list(rpcRequest);
        ValidationUtil.isTrue(spuList.size() > 0, "spu不存在");

        SysBusinessUnit bu = repositoryFactory.getBusinessUnitRepository()
                .findById(request.getMerchantId());
        ValidationUtil.notNull(bu, "商家不存在");
        ValidationUtil.isTrue(bu.getType() == BusinessUnitTypeEnums.MERCHANT, "商家类型错误");


        PurchaseDemand e = PurchaseDemandMapping.INSTANCE.toEntity(request);
        e.setSerialNo(SerialNoGenerator.generalSerial(SerialNoGenerator.Type.CG_XQ));
        return repositoryFactory.getPurchaseDemandRepository()
                .submit(e);
    }

    @Override
    public PageResult<PurchaseDemandPageResult> page(PurchaseDemandPageRequest request) {
        //spu列表
        List<SpuRpcResult> spuList = null;


        //spu数据搜索
        if (null != request.getCategoryId()) {
            SpuRpcRequest rpcRequest = new SpuRpcRequest();
            rpcRequest.setCategoryId(request.getCategoryId());
            spuList = spuFacade.list(rpcRequest);

            Set<Integer> skuIdList = MultiUtils.toSet(spuList, SpuRpcResult::getId);

            if (skuIdList.isEmpty()){
                return PageResult.buildEmpty();
            }

            request.setSpuIdList(skuIdList);
        }

        //主表查询
        Page<PurchaseDemand> page = repositoryFactory.getPurchaseDemandRepository().page(request);

        if (page.getRecords().isEmpty()){
            return PageResult.buildEmpty();
        }

        if (null == spuList) {
            Set<Integer> spuIdList = MultiUtils.toSet(page.getRecords(), PurchaseDemand::getSpuId);
            SpuRpcRequest rpcRequest = new SpuRpcRequest();
            rpcRequest.setIdList(spuIdList);
            spuList = spuFacade.list(rpcRequest);
        }

        //组合结果
        //spu数据
        Map<Integer, SpuRpcResult> spuMap = MultiUtils.toMap(
                spuList,
                SpuRpcResult::getId,
                Function.identity()
        );

        //商家数据
        Set<Integer> merchantIdList = MultiUtils.toSet(page.getRecords(), PurchaseDemand::getMerchantId);
        Map<Integer, String> merchantMap = MultiUtils.toMap(
                repositoryFactory.getBusinessUnitRepository().listByIds(merchantIdList),
                SysBusinessUnit::getId,
                SysBusinessUnit::getName
        );
        //用户数据
        Set<Integer> useridList = MultiUtils.toSet(page.getRecords(), PurchaseDemand::getAssignedId);
        Map<Integer, String> userMap = MultiUtils.toMap(
                repositoryFactory.getUserRepository().listByIds(useridList),
                SysUser::getId,
                SysUser::getName
        );

        List<PurchaseDemandPageResult> ret = MultiUtils.toList(
                page.getRecords(),
                v -> PurchaseDemandMapping.INSTANCE.toPageResult(
                        v,
                        spuMap.get(v.getSpuId()),
                        merchantMap.get(v.getMerchantId()),
                        userMap.get(v.getAssignedId())
                )
        );

        return PageResult.<PurchaseDemandPageResult>builder()
                .result(ret)
                .totalCount(page.getTotal())
                .totalPage(page.getPages())
                .build();
    }


    @Transactional
    @Override
    public Boolean cancel(PurchaseDemandCancelRequest request) {
        Date cancelTime = new Date();
        List<PurchaseDemand> list = MultiUtils.toList(
                request.getIdList(),
                v -> PurchaseDemandMapping.INSTANCE.toEntityForCancel(v, cancelTime)
        );

        return repositoryFactory.getPurchaseDemandRepository()
                .submitBatchByState(list);
    }


    @Override
    public PurchaseDemandDetailResult details(PurchaseDemandDetailRequest request) {
        ValidationUtil.isTrue(
                null != request.getId() || StringUtils.isNotEmpty(request.getSerialNo()),
                "参数异常"
        );

        PurchaseDemand demand = repositoryFactory.getPurchaseDemandRepository()
                .findByIdOrSerial(
                        request.getId(),
                        request.getSerialNo()
                );
        ValidationUtil.notNull(demand, "未查找到对应数据");

        //spu
        SpuRpcRequest rpcRequest = new SpuRpcRequest();
        rpcRequest.setIdList(Collections.singleton(demand.getSpuId()));
        SpuRpcResult spu = spuFacade.list(rpcRequest).get(0);

        //商家
        SysBusinessUnit merchantUnit = repositoryFactory.getBusinessUnitRepository()
                .findById(demand.getMerchantId());

        //指定采购人
        SysUser assigned = repositoryFactory.getUserRepository()
                .findById(demand.getAssignedId());


        return PurchaseDemandMapping.INSTANCE.toDetailResult(
                demand,
                spu,
                null == merchantUnit ? null : merchantUnit.getName(),
                null == assigned ? null : assigned.getName());
    }


}
