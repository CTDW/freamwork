package com.seeease.flywheel_v4.web.domain.wms.observer;

import com.seeease.flywheel_v4.web.domain.operations.mapping.PricingMapping;
import com.seeease.flywheel_v4.web.domain.wms.observer.base.MerchantWmsObserver;
import com.seeease.flywheel_v4.web.domain.wms.observer.base.WmsRkObserver;
import com.seeease.flywheel_v4.web.infrastructure.dao.RepositoryFactory;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.Pricing;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.entity.PurchaseOrder;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.entity.PurchaseOrderLine;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.MerchantWms;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.MerchantWmsLine;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.WmsRk;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.MerchantWmsModelEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.MerchantWmsTypeEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.WmsRkTypeEnums;
import com.seeease.flywheel_v4.web.infrastructure.listener.purchase.FinishStateListener;
import com.seeease.goods.rpc.SkuFacade;
import com.seeease.goods.rpc.enums.SkuNodeStateEnums;
import com.seeease.goods.rpc.request.PurchaseSkuFinishRpcRequest;
import com.seeease.seeeaseframework.mybatis.domain.WhetherEnum;
import com.seeease.springframework.exception.ValidationUtil;
import com.seeease.springframework.utils.MultiUtils;
import org.apache.dubbo.config.annotation.DubboReference;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.*;

/**
 * <p
 *   采购入库观察者
 * </p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/21/24 2:46下午
 **/
@Component
public class PurchaseRkObserver extends PurchaseBaseObserver
        implements WmsRkObserver, MerchantWmsObserver {

    @Resource
    private RepositoryFactory repositoryFactory;
    @Resource
    private FinishStateListener listener;


    @DubboReference(version = "1.0.0", check = false)
    private SkuFacade skuFacade;





    //----------------------------------------仓库wms观察者实现-----------------------------------//


    @Override
    public List<WmsRkTypeEnums> getWatchDataType() {
        return wmsRkWatchTypeList;
    }


    @Override
    public void update(List<WmsRk> rkList, SkuNodeStateEnums nodeState,String serialNo) {


        //查询采购单
        PurchaseOrder order = repositoryFactory.getPurchaseOrderRepository()
                .findByIdOrSerialNo(null, serialNo);

        //查询采购单行
        Set<Integer> skuIdList = MultiUtils.toSet(rkList, WmsRk::getSkuId);
        List<PurchaseOrderLine> lineList = repositoryFactory.getPurchaseOrderLineRepository()
                .findByPurchaseIdAndSkuIds(order.getId(), skuIdList);



        switch (nodeState){

            case YRK:
                doYrk(order,lineList);
                break;
            default:
                Set<Integer> lineIds = MultiUtils.toSet(lineList, PurchaseOrderLine::getId);
                repositoryFactory.getPurchaseOrderLineRepository().updateStateByIds(
                        lineIds,
                        nodeState,
                        null
                );
                break;
        }



    }

    @Override
    public void updateWithoutState(List<WmsRk> rkList,String serialNo) {
        /**
         * 这里wms的入库单据不对状态修改时，业务上会存在可能修改实际收货数量，
         * 并且如果是修改了实际收货数量的话 rkList只能存在一个元素即只能单条数据修改
         */
        if (rkList.size() == 1) {
            WmsRk wmsRk = rkList.get(0);
            //查询采购单
            PurchaseOrder order = repositoryFactory.getPurchaseOrderRepository()
                    .findByIdOrSerialNo(null, serialNo);

            PurchaseOrderLine line = repositoryFactory.getPurchaseOrderLineRepository()
                    .findByPurchaseIdAndSkuId(order.getId(), wmsRk.getSkuId());

            if (!Objects.equals(line.getCount(), wmsRk.getCount())) {
                line.setActualCount(wmsRk.getCount());
                ValidationUtil.isTrue(
                        repositoryFactory.getPurchaseOrderLineRepository().submit(line),
                        "采购单行绑定实际收货数量失败"
                );
            }


        }
    }


    //----------------------------------------仓库wms观察者实现-----------------------------------//


    //----------------------------------------商家wms观察者实现-----------------------------------//

    @Override
    public MerchantWmsModelEnums model() {
        return MerchantWmsModelEnums.RK;
    }



    @Override
    public List<MerchantWmsTypeEnums> typeList() {
        return merchantWmsRkWatchTypeList;
    }

    @Override
    public void update(MerchantWms main, List<MerchantWmsLine> rkList, SkuNodeStateEnums nodeState) {

        ValidationUtil.isTrue(nodeState != SkuNodeStateEnums.QX,"不支持取消操作");

        //查询采购单
        PurchaseOrder order = repositoryFactory.getPurchaseOrderRepository()
                .findByIdOrSerialNo(null, main.getSerialNo());

        //更新采购单行
        Set<Integer> skuIdList = MultiUtils.toSet(rkList, MerchantWmsLine::getSkuId);
        List<PurchaseOrderLine> lineList = repositoryFactory.getPurchaseOrderLineRepository()
                .findByPurchaseIdAndSkuIds(order.getId(), skuIdList);


        switch (nodeState){
            case YRK:
                doYrk(order,lineList);
                break;

        }
    }



    //----------------------------------------商家wms观察者实现-----------------------------------//




    /**
     * 执行已入库操作
     * @param order
     * @param lineList
     */
    private void doYrk(PurchaseOrder order,List<PurchaseOrderLine> lineList){

        ArrayList<Pricing> insertPricing = new ArrayList<>();
        Set<Integer> lineIds = new HashSet<>();
        for (PurchaseOrderLine l : lineList){
            lineIds.add(l.getId());

            //创建定价任务
            Pricing pricing = PricingMapping.INSTANCE.toEntity(order, l);
            insertPricing.add(pricing);
        }

        //step_1 创建定价任务
        repositoryFactory.getPricingRepository().submitBatch(insertPricing);

        //step_2 批量更新采购单行数据
        repositoryFactory.getPurchaseOrderLineRepository().updateStateByIds(
                lineIds,
                SkuNodeStateEnums.YRK,
                WhetherEnum.YES
        );


        //step_2采购订单节点变更事件推送
        listener.onEvent(new FinishStateListener.Event(this, order.getId()));


        //stpe_3 sku状态变更处理
        PurchaseSkuFinishRpcRequest rpcRequest = new PurchaseSkuFinishRpcRequest();
        Set<Integer> skuIdList = MultiUtils.toSet(lineList, PurchaseOrderLine::getSkuId);
        rpcRequest.setSkuIdList(skuIdList);
        rpcRequest.setSerialNo(order.getSerialNo());
        skuFacade.finish(rpcRequest);

    }


}
