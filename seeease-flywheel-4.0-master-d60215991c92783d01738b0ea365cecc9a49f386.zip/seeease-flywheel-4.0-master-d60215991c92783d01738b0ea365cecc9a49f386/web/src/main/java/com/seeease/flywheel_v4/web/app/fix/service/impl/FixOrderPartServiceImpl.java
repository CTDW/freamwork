package com.seeease.flywheel_v4.web.app.fix.service.impl;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.seeease.flywheel_v4.web.app.fix.request.*;
import com.seeease.flywheel_v4.web.app.fix.result.FixOrderPartPageResult;
import com.seeease.flywheel_v4.web.app.fix.service.FixOrderPartService;
import com.seeease.flywheel_v4.web.infrastructure.dao.RepositoryFactory;
import com.seeease.flywheel_v4.web.infrastructure.dao.fix.entity.FixOrderPart;
import com.seeease.springframework.PageResult;
import com.seeease.springframework.utils.StringUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.stream.Collectors;

/**
 * @Description 维修单-配件
 * @Date 2024-10-2 21:12
 * @Author by hk
 */
@Service
public class FixOrderPartServiceImpl implements FixOrderPartService {

    @Resource
    private RepositoryFactory repositoryFactory;


    @Override
    public PageResult<FixOrderPartPageResult> page(FixOrderPartPageRequest request) {

        //主表查询
        Page<FixOrderPart> page = repositoryFactory.getFixOrderPartRepository().page(request);
        if (StringUtils.isEmpty(page.getRecords())) {
            return PageResult.buildEmpty();
        }

        return PageResult.<FixOrderPartPageResult>builder()
                .result(page.getRecords().stream()
                        .map(FixOrderPartPageResult::fromEntity)
                        .collect(Collectors.toList()))
                .totalCount(page.getTotal())
                .totalPage(page.getPages())
                .build();
    }
}
