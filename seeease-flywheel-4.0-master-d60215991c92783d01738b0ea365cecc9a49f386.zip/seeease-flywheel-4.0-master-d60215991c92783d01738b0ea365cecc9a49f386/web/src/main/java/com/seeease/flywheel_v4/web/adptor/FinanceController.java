package com.seeease.flywheel_v4.web.adptor;


import com.seeease.flywheel_v4.web.app.finance.request.PaymentSlipDetailRequest;
import com.seeease.flywheel_v4.web.app.finance.request.PaymentSlipPageRequest;
import com.seeease.flywheel_v4.web.app.finance.request.PaymentSlipSubmitRequest;
import com.seeease.flywheel_v4.web.app.finance.request.PaymentSlipUploadPayedImgRequest;
import com.seeease.flywheel_v4.web.app.finance.result.PaymentSlipDetailResult;
import com.seeease.flywheel_v4.web.app.finance.result.PaymentSlipPageResult;
import com.seeease.flywheel_v4.web.app.finance.service.FinancePaymentSlipService;
import com.seeease.flywheel_v4.web.app.operations.request.*;
import com.seeease.flywheel_v4.web.app.operations.result.*;
import com.seeease.flywheel_v4.web.app.operations.service.SupplierQuotaAuditService;
import com.seeease.flywheel_v4.web.app.operations.service.SupplierQuotaService;
import com.seeease.flywheel_v4.web.infrastructure.config.IdentifyLogPrinter;
import com.seeease.springframework.PageResult;
import com.seeease.springframework.RequestValidGroup;
import com.seeease.springframework.SingleResponse;
import com.seeease.springframework.log.annotation.LogPrinter;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.validation.groups.Default;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 5/30/24 5:35 下午
 **/
@RestController
@RequestMapping("finance")
public class FinanceController {

    @Resource
    private FinancePaymentSlipService financePaymentSlipService;
    @Resource
    private SupplierQuotaAuditService supplierQuotaAuditService;
    @Resource
    private SupplierQuotaService supplierQuotaService;


    /**
     * 财务-供应商余额查询
     *
     * @return 结果
     */
    @PostMapping("supplier/quota")
    @LogPrinter(scenario = "财务-供应商余额查询", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<SupplierQuotaResult> supplierQuota(
            @Validated @RequestBody SupplierQuotaRequest request
    ) {
        return SingleResponse.of(supplierQuotaService.findOne(request));
    }


    /**
     * 财务-供应商余额列表
     *
     * @return 列表结果
     */
    @PostMapping("supplier/quota/page")
    @LogPrinter(scenario = "财务-供应商余额列表", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<PageResult<SupplierQuotaPageResult>> supplierQuotaPage(
            @RequestBody SupplierQuotaPageRequest request
    ) {
        return SingleResponse.of(supplierQuotaService.page(request));
    }


    /**
     * 财务-供应商余额详情
     *
     * @return 详情结果
     */
    @PostMapping("supplier/quota/detail")
    @LogPrinter(scenario = "财务-供应商余额详情", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<SupplierQuotaDetailResult> supplierQuotaDetail(
            @Validated @RequestBody SupplierQuotaDetailRequest request
    ) {
        return SingleResponse.of(supplierQuotaService.detail(request));
    }

    /**
     * 财务-供应商余额退款
     *
     * @return 退款结果
     */
    @PostMapping("supplier/quota/return")
    @LogPrinter(scenario = "财务-供应商余额退款", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<Boolean> supplierQuotaReturn(
            @Validated @RequestBody SupplierQuotaReturnRequest request
    ) {
        return SingleResponse.of(supplierQuotaService.returnAmount(request));
    }


    /**
     * 财务-供应商保证金充值
     *
     * @return 创建结果
     */
    @PostMapping("supplier/quota/topUp")
    @LogPrinter(scenario = "财务-供应商保证金充值", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<Boolean> supplierQuotaTopUp(
            @Validated @RequestBody SupplierQuotaTopUpRequest request
    ) {
        return SingleResponse.of(supplierQuotaAuditService.create(request));
    }

    /**
     * 财务-供应商保证金充值记录审核
     *
     * @return 审核结果
     */
    @PostMapping("supplier/quota/audit")
    @LogPrinter(scenario = "财务-供应商保证金充值记录审核", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<Boolean> supplierQuotaAudit(
            @Validated @RequestBody SupplierQuotaAuditRequest request
    ) {
        return SingleResponse.of(supplierQuotaAuditService.audit(request));
    }

    /**
     * 财务-供应商保证金充值记录分页
     *
     * @return 分页结果
     */
    @PostMapping("supplier/quota/audit/page")
    @LogPrinter(scenario = "财务-供应商保证金充值记录分页", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<PageResult<SupplierQuotaAuditPageResult>> supplierQuotaLogPage(
            @RequestBody SupplierQuotaAuditPageRequest request
    ) {
        return SingleResponse.of(supplierQuotaAuditService.page(request));
    }


    /**
     * 财务-供应商保证金充值记录详情
     *
     * @return 详情
     */
    @PostMapping("supplier/quota/audit/detail")
    @LogPrinter(scenario = "财务-供应商保证金充值记录详情", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<SupplierQuotaAuditDetailResult> supplierQuotaLogDetail(
            @RequestBody SupplierQuotaAuditDetailRequest request
    ) {
        return SingleResponse.of(supplierQuotaAuditService.detail(request));
    }



    /**
     * 财务-申请打款单创建
     * @param request
     * @return 创建结果
     */
    @PostMapping("paymentSlip/create")
    @LogPrinter(scenario = "财务-申请打款单创建", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<Boolean> paymentSlipCreate(
            @Validated(RequestValidGroup.Create.class)
            @RequestBody PaymentSlipSubmitRequest request){

        return SingleResponse.of(financePaymentSlipService.create(request));
    }


    /**
     * 申请打款单更新
     * @param request
     * @return 更新结果
     */
    @PostMapping("paymentSlip/update")
    @LogPrinter(scenario = "财务-申请打款单更新", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<Boolean> paymentSlipUpdate(
            @Validated({RequestValidGroup.Update.class, Default.class})
            @RequestBody PaymentSlipSubmitRequest request){

        return SingleResponse.of(financePaymentSlipService.update(request));
    }


    /**
     * 申请打款单分页查询
     * @param request
     * @return 分页结果
     */
    @PostMapping("paymentSlip/page")
    @LogPrinter(scenario = "财务-申请打款单分页查询", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<PageResult<PaymentSlipPageResult>> paymentSlipPage(
            @RequestBody PaymentSlipPageRequest request){

        return SingleResponse.of(financePaymentSlipService.page(request));
    }



    /**
     * 申请打款单详情查询
     * @param request
     * @return 详情结果
     */
    @PostMapping("paymentSlip/details")
    @LogPrinter(scenario = "财务-申请打款单详情查询", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<PaymentSlipDetailResult> paymentSlipDetails(
            @RequestBody PaymentSlipDetailRequest request){

        return SingleResponse.of(financePaymentSlipService.details(request));
    }


    /**
     * 申请打款单上传打款凭证
     * @param request
     * @return 操作结果
     */
    @PostMapping("paymentSlip/upload/payedImg")
    @LogPrinter(scenario = "财务-申请打款单上传打款凭证", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<Boolean> paymentSlipUploadPayedImg(
            @Validated @RequestBody PaymentSlipUploadPayedImgRequest request){

        return SingleResponse.of(financePaymentSlipService.uploadPayedImg(request));
    }

    /**
     * 申请打款单 作废 | 驳回操作
     * @param request
     * @return 操作结果
     */
    @PostMapping("paymentSlip/state")
    @LogPrinter(scenario = "财务-申请打款单状态变更", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<Boolean> paymentSlipState(
            @Validated(RequestValidGroup.State.class) @RequestBody PaymentSlipSubmitRequest request){

        return SingleResponse.of(financePaymentSlipService.state(request));
    }







}
