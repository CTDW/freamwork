package com.seeease.flywheel_v4.web.infrastructure.dao.purchase.mapper;

import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.entity.PurchaseDemand;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.Supplier;
import com.seeease.seeeaseframework.mybatis.SeeeaseMapper;

/**
 * @author 西门 游
 * @version 1.0
 * @since 5/31/24 4:53 下午
 **/
public interface PurchaseDemandMapper extends SeeeaseMapper<PurchaseDemand> {
}
