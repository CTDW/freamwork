package com.seeease.flywheel_v4.web.app.purchase.request;


import com.fasterxml.jackson.annotation.JsonFormat;
import com.seeease.springframework.PageRequest;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Date;
import java.util.Set;


@EqualsAndHashCode(callSuper = true)
@Data
public class PurchaseAftersalePageRequest extends PageRequest  {
    /**
     * ids
     */
    private Set<Integer> ids;
    /**
     * 关联单据号
     */
    private String serialNo;
    /**
     * 类型
     */
    private Integer type;
    /**
     * 状态
     */
    private Integer state;
    /**
     * sku编码
     */
    private String skuCode;
    /**
     * 快递单号
     */
    private String expressNo;
    /**
     * 是否查看自己
     */
    private Boolean mine = false;

    /**
     * 开始时间
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date startTime;
    /**
     * 结束时间
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date endTime;

    /**
     * 当前请求业务部门id 用于数据隔离
     */
    private Integer buId;

}
