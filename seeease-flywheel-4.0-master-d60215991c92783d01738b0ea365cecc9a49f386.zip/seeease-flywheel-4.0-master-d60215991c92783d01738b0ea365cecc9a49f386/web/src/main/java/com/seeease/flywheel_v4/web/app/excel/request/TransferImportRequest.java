package com.seeease.flywheel_v4.web.app.excel.request;


import com.alibaba.excel.annotation.ExcelProperty;
import lombok.Data;



@Data
public class TransferImportRequest  {

    @ExcelProperty(value = "唯一码")
    private String skuCode;
}
