package com.seeease.flywheel_v4.web.app.fix.result;

import com.seeease.flywheel_v4.web.infrastructure.dao.fix.entity.FixItem;
import io.swagger.annotations.ApiModelProperty;
import lombok.Builder;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * @Description 维修项目 返回值
 * @Date 2024-10-2 20:25
 * @Author by hk
 */
@Data
@Builder
public class FixItemPageResult implements Serializable {

    @ApiModelProperty(name = "id")
    private Long id;

    @ApiModelProperty(name = "维修项目名称")
    private String itemName;

    @ApiModelProperty(name = "默认维修价")
    private BigDecimal defaultFixPrice;

    @ApiModelProperty(name = "创建人")
    private String createdBy;

    @ApiModelProperty(name = "创建时间")
    private Date createdTime;

    public static FixItemPageResult fromEntity(FixItem fixItem) {
        return FixItemPageResult.builder()
                .itemName(fixItem.getItemName())
                .defaultFixPrice(fixItem.getDefaultFixPrice())
                .id(fixItem.getId())
                .createdBy(fixItem.getCreatedBy())
                .createdTime(fixItem.getCreatedTime())
                .build();
    }

}
