package com.seeease.flywheel_v4.web.infrastructure.dao.sale.repo;


import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.seeease.flywheel_v4.web.app.sale.request.ToBSaleOrderPageRequest;
import com.seeease.flywheel_v4.web.app.sale.request.ToCSaleOrderPageRequest;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.entity.SaleOrder;

import java.util.List;
import java.util.Set;

/**
 *
 * @author 西门 游
 * @version 1.0
 * @since 5/31/24 4:55 下午
 **/
public interface SaleOrderRepository {

    /**
     * 提交
     * @param saleOrder
     */
    Boolean submit(SaleOrder saleOrder);

    /**
     * 查询
     * @param id
     * @param serialNo
     * @return
     */
    SaleOrder findByIdOrSerialNo(Integer id, String serialNo);

    /**
     * 查询
     * @param request
     * @param orderIdList
     * @param buyerIdList
     * @return
     */
    Page<SaleOrder> pageForC(ToCSaleOrderPageRequest request, Set<Integer> orderIdList, Set<Integer> buyerIdList);

    /**
     * 查找
     * @param serialNos
     * @return
     */
    List<SaleOrder> listBySerialNos(Set<String> serialNos);

    /**
     * 查找
     * @param scType
     * @param buyerIdList
     * @param serialNo
     * @return
     */
    List<SaleOrder> listForSaleReturn(Integer scType,
                                      Set<Integer> buyerIdList,
                                      String serialNo,
                                      Integer sellType

);

    /**
     * 查找
     * @param ids
     * @return
     */
    List<SaleOrder> listByIds(Set<Integer> ids);

    /**
     * 查找
     * @param
     * @return
     */
    List<SaleOrder> listByThirdPartNo(String thirdPartNo);

    /**
     * 查找
     * @param orderIds
     * @return
     */
    boolean existOrderId(Set<String> orderIds);

    /**
     * 查找
     * @param mergedId
     * @return
     */
    SaleOrder findByMergedId(String mergedId);
    /**
     * 查询
     * @param request
     * @param orderIdList
     * @param buyerIdList
     * @return
     */
    Page<SaleOrder> pageForB(ToBSaleOrderPageRequest request, Set<Integer> orderIdList, Set<Integer> buyerIdList);
}
