package com.seeease.flywheel_v4.web.infrastructure.dao.common.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.seeease.flywheel_v4.web.infrastructure.dao.common.entity.Area;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 7/25/24 12:02 下午
 **/
public interface AreaMapper extends BaseMapper<Area> {
}
