package com.seeease.flywheel_v4.web.domain.operations.mapping;


import com.seeease.flywheel_v4.client.result.SupplierContactsRpcResult;
import com.seeease.flywheel_v4.web.app.finance.request.PaymentSlipSubmitRequest;
import com.seeease.flywheel_v4.web.app.operations.request.SupplierContactSubmitRequest;
import com.seeease.flywheel_v4.web.app.operations.result.SupplierContactListResult;
import com.seeease.flywheel_v4.web.infrastructure.config.SimpleMapping;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.Supplier;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.SupplierContacts;
import com.seeease.flywheel_v4.client.enums.BusinessUnitTypeEnums;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;


/**
 * <p>
 * 供应商联系人
 * </p>
 *
 * @author 西门 游
 * @since 2023-10-27
 */
@Mapper(componentModel = "spring",
        builder = @Builder(disableBuilder = true),
        nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS,
        nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE,
        imports = {BusinessUnitTypeEnums.class})
public interface SupplierContactsMapping extends SimpleMapping<SupplierContactSubmitRequest,SupplierContacts> {

    SupplierContactsMapping INSTANCE = Mappers.getMapper(SupplierContactsMapping.class);


    SupplierContactListResult toListResult(SupplierContacts supplierContacts);

    @Mapping(target = "supplierName",source = "supplier.name")
    @Mapping(target = "name",source = "supplierContacts.name")
    @Mapping(target = "createdBy",source = "supplierContacts.createdBy")
    @Mapping(target = "id",source = "supplierContacts.id")
    @Mapping(target = "supplierType",source = "supplier.type")
    @Mapping(target = "supplierAddress",expression = "java(null == supplier ? null : supplier.getCompleteAddress())")
    SupplierContactListResult toListResult(SupplierContacts supplierContacts, Supplier supplier);

    @Mapping(target = "name",source = "request.contactName")
    @Mapping(target = "id",ignore = true)
    void toEntityForUpdate(@MappingTarget SupplierContacts contacts,
                           PaymentSlipSubmitRequest request);

    SupplierContactsRpcResult toRpcResult(SupplierContacts contacts);
}
