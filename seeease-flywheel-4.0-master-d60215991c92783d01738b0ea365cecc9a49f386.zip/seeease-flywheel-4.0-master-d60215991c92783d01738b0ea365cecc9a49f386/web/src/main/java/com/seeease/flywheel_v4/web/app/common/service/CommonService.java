package com.seeease.flywheel_v4.web.app.common.service;

import com.seeease.flywheel_v4.web.app.common.request.AreaListRequest;
import com.seeease.flywheel_v4.web.app.common.result.AreaListResult;

import java.util.List;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 7/25/24 1:36 下午
 **/
public interface CommonService {
    List<AreaListResult> areaList(AreaListRequest request);
}
