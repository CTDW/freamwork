package com.seeease.flywheel_v4.web.app.finance.result;


import lombok.Data;
import java.math.BigDecimal;
import java.util.Date;

/**
 * @ Description   :
 * @ Author        :  西门 游
 * @ CreateDate    :  6/6/24
 * @ Version       :  1.0
 */


@Data
public class PaymentSlipPageResult {
    /**
     * 打款单id
     */
    private Integer id;
    /**
     * 采购单号
     */
    private String purchaseSerialNo;
    /**
     * 申请打款单号
     */
    private String serialNo;
    /**
     * 打款金额
     */
    private BigDecimal amount;
    /**
     * 实际打款金额
     */
    private BigDecimal payAmount;
    /**
     * 打款时间
     */
    private Date payTime;

    /**
     * 供应商名称
     */
    private String  supplierName;
    /**
     * 打款单状态
     */
    private Integer state;
    /**
     * 采购类型
     */
    private Integer purchaseType;
    /**
     * 核销状态
     */
    private Integer verifyState;
    /**
     * 支付方式
     */
    private Integer payType;
    /**
     * 数量
     */
    private Integer count;
    /**
     * 采购主体名称
     */
    private String purchaseSubjectName;
    /**
     * 创建人
     */
    private String createdBy;
    /**
     * 创建时间
     */
    private Date createdTime;
}
