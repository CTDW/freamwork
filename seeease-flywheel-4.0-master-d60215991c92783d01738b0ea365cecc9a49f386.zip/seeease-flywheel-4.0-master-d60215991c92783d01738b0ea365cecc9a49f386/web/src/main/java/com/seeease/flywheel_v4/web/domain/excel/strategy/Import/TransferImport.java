package com.seeease.flywheel_v4.web.domain.excel.strategy.Import;

import com.alibaba.cola.extension.Extension;
import com.seeease.flywheel_v4.web.app.excel.request.TransferImportRequest;
import com.seeease.flywheel_v4.web.app.excel.result.TransferSkuImportResult;
import com.seeease.flywheel_v4.web.domain.excel.core.ImportExtPtl;
import com.seeease.flywheel_v4.web.domain.transfer.mapping.TransferOrderMapping;
import com.seeease.goods.rpc.SkuFacade;
import com.seeease.goods.rpc.enums.SkuStateEnums;
import com.seeease.goods.rpc.request.SkuRpcRequest;
import com.seeease.goods.rpc.result.SkuRpcResult;
import com.seeease.springframework.exception.ValidationUtil;
import com.seeease.springframework.utils.MultiUtils;
import org.apache.dubbo.config.annotation.DubboReference;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Set;

/**
 *
 * @author 西门 游
 * @version 1.0
 * @since 9/11/24 1:39 下午
 **/
@Service
@Extension(bizId = "import", useCase = "transfer")
public class TransferImport implements ImportExtPtl<TransferImportRequest, TransferSkuImportResult> {

    @DubboReference(check = false,version = "1.0.0")
    private SkuFacade skuFacade;

    @Override
    public Class<TransferImportRequest> getRequestClass() {
        return TransferImportRequest.class;
    }

    @Override
    public void validate(List<TransferImportRequest> data) {}

    @Override
    public List<TransferSkuImportResult> handle(List<TransferImportRequest> items) {

        Set<String> skuCodes = MultiUtils.toSet(items, TransferImportRequest::getSkuCode);
        SkuRpcRequest rpcRequest = new SkuRpcRequest();
        rpcRequest.setSkuCodes(skuCodes);
        rpcRequest.setState(SkuStateEnums.SALEABLE);
        List<SkuRpcResult> skuList = skuFacade.list(rpcRequest);
        ValidationUtil.isTrue(!skuList.isEmpty(),"导入数据为查询到对应sku，无法调拨");
        return MultiUtils.toList(skuList, TransferOrderMapping.INSTANCE::toImportResult);
    }


}
