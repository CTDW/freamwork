package com.seeease.flywheel_v4.web.app.operations.request;

import com.seeease.springframework.PageRequest;
import lombok.Data;
import lombok.EqualsAndHashCode;


@EqualsAndHashCode(callSuper = true)
@Data
public class SupplierPageRequest extends PageRequest {


    /**
     * 供应商名称
     */
    private String name;
    /**
     * 供应商类型
     */
    private Integer type;
    /**
     * 联系人电话
     */
    private String contactPhone;
    /**
     * 联系人姓名
     */
    private String contactName;
    /**
     * 状态
     */
    private Integer state;
}
