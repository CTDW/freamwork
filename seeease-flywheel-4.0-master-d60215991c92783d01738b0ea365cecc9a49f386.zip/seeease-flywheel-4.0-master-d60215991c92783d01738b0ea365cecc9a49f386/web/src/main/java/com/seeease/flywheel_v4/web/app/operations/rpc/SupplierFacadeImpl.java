package com.seeease.flywheel_v4.web.app.operations.rpc;

import com.seeease.flywheel_v4.client.result.SupplierContactsRpcResult;
import com.seeease.flywheel_v4.client.result.SupplierRpcResult;
import com.seeease.flywheel_v4.client.rpc.SupplierFacade;
import com.seeease.flywheel_v4.web.domain.operations.mapping.SupplierContactsMapping;
import com.seeease.flywheel_v4.web.domain.operations.mapping.SupplierMapping;
import com.seeease.flywheel_v4.web.infrastructure.dao.RepositoryFactory;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.Supplier;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.SupplierContacts;
import com.seeease.springframework.utils.MultiUtils;
import org.apache.dubbo.config.annotation.DubboService;

import javax.annotation.Resource;
import java.util.List;
import java.util.Set;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/17/24 4:23 下午
 **/
@DubboService(version = "1.0.0")
public class SupplierFacadeImpl implements SupplierFacade {
    @Resource
    private RepositoryFactory repositoryFactory;

    @Override
    public SupplierRpcResult findById(Integer id) {
        Supplier ret = repositoryFactory.getSupplierRepository().findById(id);
        return SupplierMapping.INSTANCE.toRpcResult(ret);
    }

    @Override
    public List<SupplierRpcResult> listByIds(Set<Integer> ids) {

        return MultiUtils.toList(
                repositoryFactory.getSupplierRepository().listByIds(ids),
                SupplierMapping.INSTANCE::toRpcResult
        );

    }

    @Override
    public SupplierContactsRpcResult findContactById(Integer id) {
        SupplierContacts contacts = repositoryFactory.getSupplierContactsRepository().findById(id);
        return SupplierContactsMapping.INSTANCE.toRpcResult(contacts);
    }

    @Override
    public List<SupplierContactsRpcResult> listContactByIds(Set<Integer> ids) {
        return MultiUtils.toList(
                repositoryFactory.getSupplierContactsRepository().listByIds(ids),
                SupplierContactsMapping.INSTANCE::toRpcResult
        );
    }
}
