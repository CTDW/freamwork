package com.seeease.flywheel_v4.web.infrastructure.dao.sale.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.seeease.goods.rpc.enums.SkuNodeStateEnums;
import com.seeease.seeeaseframework.mybatis.domain.BaseDomain;
import com.seeease.seeeaseframework.mybatis.domain.WhetherEnum;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;

/**
 * 销售退货订单行
 */
@EqualsAndHashCode(callSuper = true)
@TableName(value = "v4_sale_return_order_line", autoResultMap = true)
@Data
public class SaleReturnOrderLine extends BaseDomain {
    @TableId(type = IdType.AUTO)
    private Integer id;
    /**
     * 退货单id
     */
    private Integer returnId;
    /**
     * 销售id
     */
    private Integer saleId;
    /**
     * 销售行id
     */
    private Integer saleLineId;
    /**
     * skuId
     */
    private Integer skuId;
    /**
     * 数量
     */
    private Integer count;
    /**
     * 退款金额
     */
    private BigDecimal returnAmount;
    /**
     * b价
     */
    private BigDecimal tobPrice;
    /**
     * c价
     */
    private BigDecimal tocPrice;
    /**
     * 经营权
     */
    private Integer sellerId;
    /**
     * 商品所在
     */
    private Integer storeId;
    /**
     * 最新结算价
     */
    private BigDecimal newSettlePrice;
    /**
     * gmvc
     */
    private BigDecimal gmvc;

    /**
     * sku节点状态
     */
    private SkuNodeStateEnums nodeState;

    /**
     * 是否为终态
     */
    private WhetherEnum endState;








}