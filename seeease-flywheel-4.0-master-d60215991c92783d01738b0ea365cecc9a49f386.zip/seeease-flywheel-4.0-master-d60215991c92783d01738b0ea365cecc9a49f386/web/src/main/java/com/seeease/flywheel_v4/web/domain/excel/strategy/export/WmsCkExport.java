package com.seeease.flywheel_v4.web.domain.excel.strategy.export;

import com.alibaba.cola.extension.Extension;
import com.seeease.flywheel_v4.web.app.excel.result.WmsCkExportResult;
import com.seeease.flywheel_v4.web.app.wms.request.WmsCkPageRequest;
import com.seeease.flywheel_v4.web.app.wms.result.WmsCkPageResult;
import com.seeease.flywheel_v4.web.app.wms.service.WmsCkService;
import com.seeease.flywheel_v4.web.domain.excel.ExcelDomain;
import com.seeease.flywheel_v4.web.domain.excel.core.ExportExtPtl;
import com.seeease.flywheel_v4.web.domain.wms.mapping.WmsCkMapping;
import com.seeease.flywheel_v4.web.infrastructure.dao.RepositoryFactory;
import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.enums.SaleChannelTypeEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.WmsCkTypeEnums;
import com.seeease.goods.rpc.SkuFacade;
import com.seeease.goods.rpc.enums.SkuNodeStateEnums;
import com.seeease.seeeaseframework.mybatis.utils.EnumUtils;
import com.seeease.springframework.utils.MultiUtils;
import org.apache.dubbo.config.annotation.DubboReference;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 9/12/24 10:42 上午
 **/
@Service
@Extension(bizId = "export", useCase = "wmsCk")
public class WmsCkExport implements ExportExtPtl<WmsCkPageRequest, WmsCkExportResult> {

    @Resource
    private RepositoryFactory repositoryFactory;

    @DubboReference(version = "1.0.0", check = false)
    private SkuFacade skuFacade;

    @Resource
    private WmsCkService wmsCkService;

    @Resource
    private ExcelDomain excelDomain;


    @Override
    public Class<WmsCkPageRequest> getRequestClass() {
        return WmsCkPageRequest.class;
    }

    @Override
    public Class<WmsCkExportResult> getResultClass() {
        return WmsCkExportResult.class;
    }

    @Override
    public String getFileName() {
        return "wms出库导出";
    }

    @Override
    public List<WmsCkExportResult> handle(WmsCkPageRequest request) {
        //step_1 调用wms出库分页接口
        request.setLimit(Integer.MAX_VALUE);
        List<WmsCkPageResult> list = wmsCkService.page(request).getResult();
        if (list.isEmpty()) {
            return Collections.emptyList();
        }

        //step_2 数据转换
        return MultiUtils.toList(
                list,
                item -> {

                    String type = EnumUtils.of(WmsCkTypeEnums.class, item.getType()).getDesc();
                    String scType = null == item.getScType() ? null :
                            EnumUtils.of(SaleChannelTypeEnums.class, item.getScType()).getDesc() ;



                    return MultiUtils.toList(item.getSkuList(), sku -> {
                        String nodeState = EnumUtils.of(SkuNodeStateEnums.class, sku.getNodeState()).getDesc();
                        String param = excelDomain.joinParam(sku.getSkuParams());
                        String annexe = excelDomain.joinAnnexe(sku.getAnnexe());

                        return WmsCkMapping.INSTANCE.toExportResult(
                                item,
                                type,
                                scType,
                                sku,
                                nodeState,
                                param,
                                annexe
                        );
                    });

                }
        ).stream().flatMap(Collection::stream).collect(Collectors.toList());
    }
}
