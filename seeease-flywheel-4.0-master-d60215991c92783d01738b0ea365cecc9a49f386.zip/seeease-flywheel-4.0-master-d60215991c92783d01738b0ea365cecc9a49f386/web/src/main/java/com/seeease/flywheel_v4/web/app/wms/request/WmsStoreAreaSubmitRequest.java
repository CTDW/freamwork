package com.seeease.flywheel_v4.web.app.wms.request;


import com.seeease.springframework.RequestValidGroup;
import lombok.Data;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * @ Description   :
 * @ Author        :  西门 游
 * @ CreateDate    :  6/6/24
 * @ Version       :  1.0
 */

@Data
public class WmsStoreAreaSubmitRequest {

    /**
     * 主键id
     */
    @NotNull(message = "id不能为空",groups = {RequestValidGroup.Update.class, RequestValidGroup.Deleted.class})
    private Integer id;
    /**
     * 名称
     */
    @NotBlank(message = "名称不能为空")
    private String name;

    /**
     * 仓库id
     */
    @NotNull(message = "仓库id不能为空",groups =  RequestValidGroup.Create.class)
    private Integer storeId;

    /**
     * 父库位id
     */
    @NotNull(message = "父库位id不能为空",groups =  RequestValidGroup.Create.class)
    @Min(value = 0,message = "父库位id错误")
    private Integer pid;




}
