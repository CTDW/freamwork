package com.seeease.flywheel_v4.web.app.purchase.result;

import com.seeease.goods.rpc.request.SkuAnnexeRpcResult;
import com.seeease.goods.rpc.result.ProductParamRpcResult;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/4/24 6:00 下午
 **/
@Data
public class PurchaseAftersaleDetailResult {
    /**
     * id
     */
    private Integer id;
    /**
     * 编号
     */
    private String serialNo;
    /**
     * 关联单号
     */
    private String originSerialNo;
    /**
     * 快递单号
     */
    private String expressNo;

    /**
     * 类型
     */
    private Integer type;
    /**
     * 状态
     */
    private Integer state;
    /**
     * 金额
     */
    private BigDecimal amount;
    /**
     * 总数量
     */
    private Integer totalCount;
    /**
     * 来源
     */
    private String originName;
    /**
     * 创建人
     */
    private String createdBy;
    /**
     * 创建时间
     */
    private Date createdTime;
    /**
     * 发货时间
     */
    private Date spTime;
    /**
     * 取消时间
     */
    private Date cancelTime;

    /**
     * 供应商名称
     */
    private String supplierName;
    /**
     * 供应商类型
     */
    private Integer supplierType;
    /**
     * 联系人名称
     */
    private String contactName;
    /**
     * 联系人电话
     */
    private String contactPhone;
    /**
     * 地址
     */
    private String address;
    /**
     * sku列表数据
     */
    private List<Sku> skuList;


    @Data
    public static class Sku{
        /**
         * 采购业务单据行id
         */
        private Integer lineId;
        /**
         * skuId
         */
        private Integer skuId;
        /**
         * 商品名称
         */
        private String goodsName;
        /**
         * 类目
         */
        private String categoryName;
        /**
         * 品牌
         */
        private String brandName;
        /**
         * 节点状态
         */
        private Integer nodeState;
        /**
         * 价格
         */
        private BigDecimal price;
        /**
         * 数量
         */
        private Integer count;
        /**
         * sku参数列表
         */
        private List<ProductParamRpcResult> skuParams;
        /**
         * 附件
         */
        private List<SkuAnnexeRpcResult> annexe;
        /**
         * 唯一码
         */
        private String skuCode;

        /**
         * 图片
         */
        private String spuImage;
        /**
         * 类目id
         */
        private Integer categoryId;
    }
}
