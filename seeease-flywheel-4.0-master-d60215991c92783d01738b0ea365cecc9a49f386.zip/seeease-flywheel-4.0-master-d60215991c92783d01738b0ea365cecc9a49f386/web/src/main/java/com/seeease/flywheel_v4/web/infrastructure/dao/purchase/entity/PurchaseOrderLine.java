package com.seeease.flywheel_v4.web.infrastructure.dao.purchase.entity;

import com.alibaba.fastjson.TypeReference;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.seeease.goods.rpc.enums.SkuNodeStateEnums;
import com.seeease.goods.rpc.request.SkuAnnexeRpcResult;
import com.seeease.seeeaseframework.mybatis.domain.BaseDomain;
import com.seeease.seeeaseframework.mybatis.domain.WhetherEnum;
import com.seeease.seeeaseframework.mybatis.type.JsonArrayTypeHandler;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;
import java.util.List;

/**
 * 采购订单行
 */
@EqualsAndHashCode(callSuper = true)
@TableName(value = "v4_purchase_order_line", autoResultMap = true)
@Data
public class PurchaseOrderLine extends BaseDomain {
    @TableId(type = IdType.AUTO)
    private Integer id;
    /**
     * 采购单id
     */
    private Integer purchaseId;
    /**
     * skuId
     */
    private Integer skuId;
    /**
     * 数量
     */
    private Integer count;

    /**
     * 附件快照
     */
    @TableField(typeHandler = SkuAnnexeTypeHandler.class)
    private List<SkuAnnexeRpcResult> snapAnnexe;

    /**
     * sku唯一码快照
     */
    private String snapSkuCode;

    /**
     * 异常原因
     */
    private String reason;
    /**
     * 入库时实际的收货数量
     */
    private Integer actualCount;
    /**
     * 收货价
     */
    private BigDecimal receiptPrice;
    /**
     * 采购价
     */
    private BigDecimal purchasePrice;
    /**
     * 回购价
     */
    private BigDecimal buybackPrice;
    /**
     * 表带根换费
     */
    private BigDecimal strapPrice;
    /**
     * 维修价格
     */
    private BigDecimal repairPrice;

    /**
     * sku节点状态
     */
    private SkuNodeStateEnums nodeState;

    /**
     * 是否为终态
     */
    private WhetherEnum endState;






















    public static class SkuAnnexeTypeHandler extends JsonArrayTypeHandler<SkuAnnexeRpcResult> {

        public SkuAnnexeTypeHandler(Class<List<SkuAnnexeRpcResult>> clazz) {
            super(clazz);
        }

        @Override
        protected TypeReference<List<SkuAnnexeRpcResult>> specificType() {
            return new TypeReference<List<SkuAnnexeRpcResult>>() {
            };

        }
    }

}