package com.seeease.flywheel_v4.web.infrastructure.dao.operations.repo;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.seeease.flywheel_v4.web.app.operations.request.SupplierQuotaPageRequest;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.SupplierQuota;

import java.util.Set;

/**
 *
 * @author 西门 游
 * @version 1.0
 * @since 5/31/24 4:55 下午
 **/
public interface SupplierQuotaRepository {



    /**
     * 提交
     * @param supplierQuota
     */
    Boolean submit(SupplierQuota supplierQuota);

    /**
     * 查找
     * @param supplierId
     * @return
     */
    SupplierQuota findBySupplierId(Integer supplierId);

    /**
     * 分页
     * @param supplierIds
     * @param request
     * @return
     */
    Page<SupplierQuota> page(Set<Integer> supplierIds, SupplierQuotaPageRequest request);

    /**
     * 查找
     * @param id
     * @return
     */
    SupplierQuota findById(Integer id);

}
