package com.seeease.flywheel_v4.web.app.purchase.service;

import com.seeease.flywheel_v4.web.app.purchase.request.PurchaseDemandCancelRequest;
import com.seeease.flywheel_v4.web.app.purchase.request.PurchaseDemandDetailRequest;
import com.seeease.flywheel_v4.web.app.purchase.request.PurchaseDemandPageRequest;
import com.seeease.flywheel_v4.web.app.purchase.request.PurchaseDemandSubmitRequest;
import com.seeease.flywheel_v4.web.app.purchase.result.PurchaseDemandDetailResult;
import com.seeease.flywheel_v4.web.app.purchase.result.PurchaseDemandPageResult;
import com.seeease.springframework.PageResult;

/**
 * <p>采购需求</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/5/24 1:58 下午
 **/
public interface PurchaseDemandService {
    /**
     * 采购需求创建
     *
     * @return 创建结果
     */
    Boolean create(PurchaseDemandSubmitRequest request);


    /**
     * 采购需求分页
     *
     * @return 分页结果
     */
    PageResult<PurchaseDemandPageResult> page(PurchaseDemandPageRequest request);

    /**
     * 采购需求取消
     *
     * @return 取消结果
     */
    Boolean cancel(PurchaseDemandCancelRequest request);
    /**
     * 采购需求详情
     *
     * @return 详情结果
     */
    PurchaseDemandDetailResult details(PurchaseDemandDetailRequest request);
}
