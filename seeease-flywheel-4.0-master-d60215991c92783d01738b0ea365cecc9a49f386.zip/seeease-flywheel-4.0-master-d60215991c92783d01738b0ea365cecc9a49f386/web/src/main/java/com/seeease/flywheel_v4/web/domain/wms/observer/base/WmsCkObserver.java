package com.seeease.flywheel_v4.web.domain.wms.observer.base;

import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.WmsCk;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.WmsCkTypeEnums;

import java.util.Map;
import java.util.Set;

/**
 * <p
 * wms出库事件观察者
 * </p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/21/24 2:46下午
 **/
public interface WmsCkObserver extends WmsObserver<WmsCkTypeEnums, WmsCk> {


    /**
     * 获取拓展字段
     * @param serialNo
     * @return
     */
    Map<String,Ext> getExt(Set<String> serialNo);



}
