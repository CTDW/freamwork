package com.seeease.flywheel_v4.web.domain.operations.mapping;


import com.seeease.flywheel_v4.web.app.operations.request.TransferQuotaSubmitRequest;
import com.seeease.flywheel_v4.web.app.operations.result.TransferQuotaLineListResult;
import com.seeease.flywheel_v4.web.app.operations.result.TransferQuotaPageResult;
import com.seeease.flywheel_v4.web.infrastructure.config.EnumMapping;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.TransferQuota;
import com.seeease.goods.rpc.enums.SkuRunTypeEnums;
import org.mapstruct.Builder;
import org.mapstruct.Mapper;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;
import org.mapstruct.factory.Mappers;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;


/**
 * <p>
 * </p>
 *
 * @author 西门 游
 * @since 2023-10-27
 */
@Mapper(componentModel = "spring",
        builder = @Builder(disableBuilder = true),
        nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS,
        nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE,
        imports = {SkuRunTypeEnums.class})
public interface TransferQuotaMapping extends EnumMapping {

    TransferQuotaMapping INSTANCE = Mappers.getMapper(TransferQuotaMapping.class);

    TransferQuota toEntity(TransferQuotaSubmitRequest request,
                           BigDecimal osQuota,
                           BigDecimal ctQuota);


    TransferQuotaPageResult toPageResult(TransferQuota transferQuota,
                                         String merchantName,
                                         Map<Integer, String> categoryMap,
                                         Map<Integer, String> brandMap,
                                         String categoryNames,
                                         List<TransferQuotaLineListResult> osQuotas,
                                          List<TransferQuotaLineListResult> ctQuotas
    );




}
