package com.seeease.flywheel_v4.web.domain.excel.strategy.Import;

import com.alibaba.cola.extension.Extension;
import com.seeease.flywheel_v4.web.app.excel.request.SkuPricingImportRequest;
import com.seeease.flywheel_v4.web.domain.excel.core.ImportExtPtl;
import com.seeease.flywheel_v4.web.domain.operations.mapping.PricingMapping;
import com.seeease.flywheel_v4.web.infrastructure.dao.RepositoryFactory;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.Pricing;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.obj.PricingLifeCycleObj;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.enums.PricingStateEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.entity.SysBusinessUnit;
import com.seeease.goods.rpc.SkuFacade;
import com.seeease.goods.rpc.enums.SkuRunTypeEnums;
import com.seeease.goods.rpc.enums.SkuSellWayEnums;
import com.seeease.goods.rpc.request.SkuRpcRequest;
import com.seeease.goods.rpc.result.SkuRpcResult;
import com.seeease.seeeaseframework.mybatis.utils.EnumUtils;
import com.seeease.springframework.utils.MultiUtils;
import org.apache.dubbo.config.annotation.DubboReference;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * @author 西门 游
 * @version 1.0
 * @since 9/11/24 1:39 下午
 **/
@Service
@Extension(bizId = "import", useCase = "skuPricing")
public class SkuPricingImport implements ImportExtPtl<SkuPricingImportRequest, Void> {

    @DubboReference(check = false, version = "1.0.0")
    private SkuFacade skuFacade;

    @Resource
    private RepositoryFactory repositoryFactory;

    @Override
    public Class<SkuPricingImportRequest> getRequestClass() {
        return SkuPricingImportRequest.class;
    }

    @Override
    public void validate(List<SkuPricingImportRequest> data) {

    }

    @Override
    public List<Void> handle(List<SkuPricingImportRequest> items) {

        Map<String, SkuPricingImportRequest> paramMap = MultiUtils.toMap(
                items,
                SkuPricingImportRequest::getSkuCode
        );

        //step_1 sku查询
        Set<String> codes = MultiUtils.toSet(items, SkuPricingImportRequest::getSkuCode);
        SkuRpcRequest rpcRequest = new SkuRpcRequest();
        rpcRequest.setSkuCodes(codes);
        List<SkuRpcResult> skuList = skuFacade.list(rpcRequest);
        Map<Integer, SkuRpcResult> skuMap = MultiUtils.toMap(
                skuList,
                SkuRpcResult::getId
        );

        //step_2 定价列表查询
        Set<Integer> skuIdList = MultiUtils.toSet(skuList, SkuRpcResult::getId);
        List<Pricing> pricings = repositoryFactory.getPricingRepository().listBySkuIds(skuIdList)
                .stream()
                .filter(price -> price.getState() != PricingStateEnums.OK)
                .collect(Collectors.toList());

        //step_3 需求商家查询
        Set<String> merchantNames = MultiUtils.toSet(items, SkuPricingImportRequest::getMerchantName);
        Map<String, Integer> merchantMap = MultiUtils.toMap(
                repositoryFactory.getBusinessUnitRepository().listByNames(merchantNames),
                SysBusinessUnit::getName,
                SysBusinessUnit::getId
        );


        //step_4 数据补充
        for (Pricing pricing : pricings) {
            SkuRpcResult sku = skuMap.get(pricing.getSkuId());
            SkuPricingImportRequest item = paramMap.get(sku.getSkuCode());
            Integer merchantId = merchantMap.get(item.getMerchantName());


            SkuSellWayEnums sellWay = null != item.getSellWay() ?
                    EnumUtils.of(SkuSellWayEnums.class, item.getSellWay()) : null;

            SkuRunTypeEnums runType = null != item.getRunType() ?
                    EnumUtils.of(SkuRunTypeEnums.class, item.getRunType()) : null;


            PricingMapping.INSTANCE.toEntityForUpdate(
                    pricing,
                    item,
                    sellWay,
                    runType,
                    merchantId
            );

            pricing.setState(PricingStateEnums.WAIT_AUDIT);
            List<PricingLifeCycleObj> lifyCycle = PricingMapping.INSTANCE.addLifeCycle(pricing.getLifeCycle(), PricingStateEnums.TransitionEnum.STEP_1);
            pricing.setLifeCycle(lifyCycle);
        }
        repositoryFactory.getPricingRepository().submitBatch(pricings);
        return Collections.emptyList();
    }


}
