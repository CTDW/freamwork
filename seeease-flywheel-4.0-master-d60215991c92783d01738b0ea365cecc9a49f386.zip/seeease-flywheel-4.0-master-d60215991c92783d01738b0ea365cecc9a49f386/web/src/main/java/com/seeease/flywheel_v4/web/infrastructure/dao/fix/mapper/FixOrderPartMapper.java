package com.seeease.flywheel_v4.web.infrastructure.dao.fix.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.seeease.flywheel_v4.web.infrastructure.dao.fix.entity.FixOrderPart;
import org.apache.ibatis.annotations.Select;

import java.util.List;


/**
 * @Description 维修配件
 * @Date 2024-10-2 21:02
 * @Author by hk
 */
public interface FixOrderPartMapper extends BaseMapper<FixOrderPart> {

    @Select("select id from v4_fix_order_part where order_number = #{fixOrderNumber} and deleted=0")
    List<Long> getFixPartIdByNumber(String fixOrderNumber);

}
