package com.seeease.flywheel_v4.web.app.transfer.result;


import com.seeease.goods.rpc.request.SkuAnnexeRpcResult;
import com.seeease.goods.rpc.result.ProductParamRpcResult;

import lombok.Data;

import java.math.BigDecimal;
import java.util.List;

/**
 * @author 西门 游
 * @version 1.0
 * @since 6/3/24 11:26 上午
 **/
@Data
public class TransferTaskPageResult {
    /**
     * 主键id
     */
    private Integer id;

    /**
     * skuId
     */
    private Integer skuId;
    /**
     * 货号
     */
    private String goodsCode;



    /**
     * 采购类型
     */
    private Integer purchaseType;
    /**
     * 蜥蜴编码
     */
    private String xyCode;
    /**
     * 商品名称
     */
    private String goodsName;
    /**
     * 类目名称
     */
    private String categoryName;
    /**
     * 图片
     */
    private String spuImage;
    /**
     * 品牌名称
     */
    private String brandName;
    /**
     * sku节点状态
     */
    private Integer skuState;

    /**
     * 数量
     */
    private Integer count;

    /**
     * sku参数列表
     */
    private List<ProductParamRpcResult> skuParams;
    /**
     * 附件
     */
    private List<SkuAnnexeRpcResult> annexe;
    /**
     * 唯一码
     */
    private String skuCode;
    /**
     * 商品所在
     */
    private String belongName;
    /**
     * 调入方
     */
    private String toName;
    /**
     * 调入方id
     */
    private Integer toId;
    /**
     * 公价
     */
    private BigDecimal pubPrice;

    /**
     * 总库龄
     */
    private Integer storeAge;

    /**
     * 商家库龄
     */
    private Integer merchantStoreAge;

}
