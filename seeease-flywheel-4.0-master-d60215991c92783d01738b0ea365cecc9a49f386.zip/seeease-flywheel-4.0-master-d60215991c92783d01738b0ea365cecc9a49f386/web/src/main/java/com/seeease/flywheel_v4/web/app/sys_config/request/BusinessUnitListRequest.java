package com.seeease.flywheel_v4.web.app.sys_config.request;


import lombok.Data;

/**
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/3/24 11:26 上午
 **/
@Data
public class BusinessUnitListRequest{


    /**
     * 业务单元类型
     */
    private Integer type;


}
