package com.seeease.flywheel_v4.web.app.transfer.service;

import com.seeease.flywheel_v4.web.app.transfer.request.TransferTaskCreateRequest;
import com.seeease.flywheel_v4.web.app.transfer.request.TransferTaskPageRequest;
import com.seeease.flywheel_v4.web.app.transfer.result.TransferTaskPageResult;
import com.seeease.springframework.PageResult;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 7/2/24 4:36 下午
 **/
public interface TransferTaskService {
    /**
     * 调拨-调拨任务创建
     *
     * @return 更新结果
     */
    Boolean create(TransferTaskCreateRequest request);

    /**
     * 调拨-调拨任务创建
     *
     * @return 更新结果
     */
    PageResult<TransferTaskPageResult> page(TransferTaskPageRequest request);


    /**
     * 调拨-调拨任务删除
     *
     * @return 删除结果
     */
    Boolean del(Integer id);
}
