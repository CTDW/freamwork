package com.seeease.flywheel_v4.web.infrastructure.dao;


import com.seeease.flywheel_v4.web.infrastructure.dao.common.repo.AreaRepository;
import com.seeease.flywheel_v4.web.infrastructure.dao.finance.repo.FinancePaymentSlipRepository;
import com.seeease.flywheel_v4.web.infrastructure.dao.fix.repo.FixItemRepository;
import com.seeease.flywheel_v4.web.infrastructure.dao.fix.repo.FixOrderLogRepository;
import com.seeease.flywheel_v4.web.infrastructure.dao.fix.repo.FixOrderPartRepository;
import com.seeease.flywheel_v4.web.infrastructure.dao.fix.repo.FixOrderRepository;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.repo.*;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.repo.*;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.repo.*;
import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.repo.BusinessUnitRepository;
import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.repo.SaleChannelRepository;
import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.repo.UserRepository;
import com.seeease.flywheel_v4.web.infrastructure.dao.transfer.repo.TransferOrderLineRepository;
import com.seeease.flywheel_v4.web.infrastructure.dao.transfer.repo.TransferOrderRepository;
import com.seeease.flywheel_v4.web.infrastructure.dao.transfer.repo.TransferTaskRepository;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.repo.*;
import lombok.Getter;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;

/**
 * <p>db调用中心</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 1/31/24 11:12 上午
 **/
@Repository
@Getter
public class RepositoryFactory {

    /**
     * 通用
     */
    @Resource
    private AreaRepository areaRepository;


    /**
     * 系统配置
     */
    @Resource
    private BusinessUnitRepository businessUnitRepository;
    @Resource
    private SaleChannelRepository saleChannelRepository;
    @Resource
    private UserRepository userRepository;


    /**
     * 系统运营
     */
    @Resource
    private SupplierRepository supplierRepository;
    @Resource
    private SupplierContactsRepository supplierContactsRepository;
    @Resource
    private SupplierQuotaAuditRepository supplierQuotaAuditRepository;
    @Resource
    private SupplierQuotaRepository supplierQuotaRepository;
    @Resource
    private SupplierQuotaLogRepository supplierQuotaLogRepository;
    @Resource
    private SupplierQuotaDetailRepository supplierQuotaDetailRepository;
    @Resource
    private PricingRepository pricingRepository;
    @Resource
    private TransferQuotaRepository transferQuotaRepository;
    @Resource
    private TransferQuotaLineRepository transferQuotaLineRepository;




    /**
     * 采购
     */
    @Resource
    private PurchaseDemandRepository purchaseDemandRepository;
    @Resource
    private PurchaseOrderRepository purchaseOrderRepository;
    @Resource
    private PurchaseOrderLineRepository purchaseOrderLineRepository;
    @Resource
    private PurchaseAftersaleRepository purchaseAftersaleRepository;
    @Resource
    private PurchaseAftersaleLineRepository purchaseAftersaleLineRepository;




    /**
     * 财务
     */
    @Resource
    private FinancePaymentSlipRepository financePaymentSlipRepository;



    /**
     * wms
     */
    @Resource
    private WmsRkRepository wmsRkRepository;
    @Resource
    private WmsCkRepository wmsCkRepository;
    @Resource
    private WmsPhotoManagementRepository wmsPhotoManagementRepository;
    @Resource
    private WmsStoreLocationRepository  wmsStoreLocationRepository;
    @Resource
    private MerchantWmsRepository merchantWmsRepository;
    @Resource
    private MerchantWmsLineRepository merchantWmsLineRepository;


    /**
     * 调拨
     */
    @Resource
    private TransferTaskRepository transferTaskRepository;
    @Resource
    private TransferOrderRepository transferOrderRepository;
    @Resource
    private TransferOrderLineRepository transferOrderLineRepository;


    /**
     * 销售
     */
    @Resource
    private SaleOrderRepository saleOrderRepository;
    @Resource
    private SaleOrderLineRepository saleOrderLineRepository;
    @Resource
    private SaleReturnOrderRepository saleReturnOrderRepository;
    @Resource
    private SaleReturnOrderLineRepository saleReturnOrderLineRepository;
    @Resource
    private ThirdSaleOrderRepository thirdSaleOrderRepository;
    @Resource
    private ThirdSaleOrderLineRepository thirdSaleOrderLineRepository;


    /**
     * 维修中心
     */
    @Resource
    private FixItemRepository fixItemRepository;
    @Resource
    private FixOrderRepository fixOrderRepository;
    @Resource
    private FixOrderLogRepository fixOrderLogRepository;
    @Resource
    private FixOrderPartRepository fixOrderPartRepository;

}
