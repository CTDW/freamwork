package com.seeease.flywheel_v4.web.domain.finance.strategy.paymentSlip;


import com.google.common.collect.Lists;
import com.seeease.flywheel_v4.web.app.finance.request.PaymentSlipSubmitRequest;
import com.seeease.flywheel_v4.client.enums.PurchaseTypeEnums;
import com.seeease.springframework.exception.ValidationUtil;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 *
 * A类型申请打款单创建类型校验
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/13/24 11:20上午
 **/
@Component
public class PreCreateStrategyA implements PreCreateStrategy{

    List<PurchaseTypeEnums> condition = Lists.newArrayList(
            PurchaseTypeEnums.GR_HS,
            PurchaseTypeEnums.GR_HSZH
    );

    @Override
    public void check(PaymentSlipSubmitRequest request) {
        ValidationUtil.notNull(request.getContractImg(),"转让协议不能为空");
        ValidationUtil.notNull(request.getEvidenceImg(),"回收定价聊天记录不能为空");
        ValidationUtil.notNull(request.getIdBackImg(),"身份证背面不能为空");
        ValidationUtil.notNull(request.getIdFrontImg(),"身份证正面不能为空");
    }

    @Override
    public Boolean match(PurchaseTypeEnums purchaseTypeEnums){
        return condition.contains(purchaseTypeEnums);
    }

}
