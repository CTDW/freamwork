package com.seeease.flywheel_v4.web.app.excel.request;


import com.alibaba.excel.annotation.ExcelProperty;
import lombok.Data;

import java.math.BigDecimal;


@Data
public class SkuPriceUpdateImportRequest {

    @ExcelProperty(value = "唯一码")
    private String skuCode;

    @ExcelProperty(value = "修改原因")
    private String remark;

    @ExcelProperty(value = "采购价")
    private BigDecimal purchasePrice;

    @ExcelProperty(value = "收货价")
    private BigDecimal receiptPrice;

    @ExcelProperty(value = "维修成本")
    private BigDecimal repairPrice;

    @ExcelProperty(value = "同行价")
    private BigDecimal tobPrice;

    @ExcelProperty(value = "零售价")
    private BigDecimal tocPrice;

    @ExcelProperty(value = "结算价")
    private BigDecimal settlePrice;

    @ExcelProperty(value = "最新结算价")
    private BigDecimal newSettlePrice;

    @ExcelProperty(value = "绩效价")
    private BigDecimal perfPrice;
}
