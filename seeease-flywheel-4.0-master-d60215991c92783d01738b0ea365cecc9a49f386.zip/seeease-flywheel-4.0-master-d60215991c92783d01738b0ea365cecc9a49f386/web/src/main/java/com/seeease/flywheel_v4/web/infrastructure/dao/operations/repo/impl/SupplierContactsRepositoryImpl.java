package com.seeease.flywheel_v4.web.infrastructure.dao.operations.repo.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.seeease.springframework.utils.StringUtils;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.SupplierContacts;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.mapper.SupplierContactsMapper;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.repo.SupplierContactsRepository;
import org.springframework.stereotype.Repository;

import java.util.Collections;
import java.util.List;
import java.util.Set;

/**
 * @author 西门 游
 * @version 1.0
 * @since 5/31/24 4:55 下午
 **/
@Repository
public class SupplierContactsRepositoryImpl extends ServiceImpl<SupplierContactsMapper, SupplierContacts>
        implements SupplierContactsRepository {


    @Override
    public boolean submitBatch(List<SupplierContacts> batch) {
        return saveOrUpdateBatch(batch);
    }

    @Override
    public boolean delBySupplierId(Integer supplierId) {
        LambdaQueryWrapper<SupplierContacts> wq = Wrappers.<SupplierContacts>lambdaQuery()
                .eq(SupplierContacts::getSupplierId, supplierId);

        return remove(wq);
    }

    @Override
    public List<SupplierContacts> listByNameAndPhone(String name, String phone) {
        LambdaQueryWrapper<SupplierContacts> wq = Wrappers.<SupplierContacts>lambdaQuery()
                .like(StringUtils.isNotEmpty(name),SupplierContacts::getName, name)
                .like(StringUtils.isNotEmpty(phone),SupplierContacts::getPhone, phone);

        return baseMapper.selectList(wq);
    }

    @Override
    public List<SupplierContacts> listBySupplierIds(Set<Integer> supplierIdList) {
        if (com.seeease.springframework.utils.StringUtils.isEmpty(supplierIdList)){
            return Collections.emptyList();
        }
        LambdaQueryWrapper<SupplierContacts> wq = Wrappers.<SupplierContacts>lambdaQuery()
                .in(SupplierContacts::getSupplierId, supplierIdList);
        return baseMapper.selectList(wq);
    }

    @Override
    public Boolean delById(Integer id) {
        return removeById(id);
    }

    @Override
    public Boolean submit(SupplierContacts contacts) {
        return saveOrUpdate(contacts);
    }

    @Override
    public SupplierContacts findById(Integer id) {
        return baseMapper.selectById(id);
    }

    @Override
    public List<SupplierContacts> listByIds(Set<Integer> buyerIdList) {
        if (StringUtils.isEmpty(buyerIdList)){
            return Collections.emptyList();
        }
        return baseMapper.selectBatchIds(buyerIdList);
    }

    @Override
    public List<SupplierContacts> listByKey(String key) {
        return baseMapper.listByKey(key);
    }
}
