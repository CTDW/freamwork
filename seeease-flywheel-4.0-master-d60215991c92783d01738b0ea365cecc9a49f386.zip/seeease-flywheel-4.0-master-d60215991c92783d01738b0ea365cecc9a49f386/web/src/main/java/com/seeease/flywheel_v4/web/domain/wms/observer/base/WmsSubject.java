package com.seeease.flywheel_v4.web.domain.wms.observer.base;

import com.google.common.collect.Lists;
import com.seeease.flywheel_v4.web.app.purchase.request.PurchaseOrderSubmitRequest;
import com.seeease.flywheel_v4.web.domain.wms.mapping.MerchantWmsMapping;
import com.seeease.flywheel_v4.web.domain.wms.mapping.WmsCkMapping;
import com.seeease.flywheel_v4.web.domain.wms.mapping.WmsPhotoManagementMapping;
import com.seeease.flywheel_v4.web.domain.wms.mapping.WmsRkMapping;
import com.seeease.flywheel_v4.web.domain.wms.observer.PurchaseRkObserver;
import com.seeease.flywheel_v4.web.infrastructure.dao.RepositoryFactory;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.*;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.MerchantWmsModelEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.WmsCkTypeEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.WmsRkTypeEnums;
import com.seeease.flywheel_v4.web.infrastructure.listener.MerchantWmsStateListener;
import com.seeease.flywheel_v4.web.infrastructure.listener.purchase.StartingStateListener;
import com.seeease.goods.rpc.SkuFacade;
import com.seeease.goods.rpc.enums.SkuNodeStateEnums;
import com.seeease.goods.rpc.request.SkuStateEventSubmitRcpRequest;
import com.seeease.seeeaseframework.mybatis.domain.WhetherEnum;
import com.seeease.springframework.exception.ValidationUtil;
import com.seeease.springframework.exception.e.ArgumentException;
import com.seeease.springframework.utils.MultiUtils;
import com.seeease.springframework.utils.StringUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.dubbo.config.annotation.DubboReference;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.*;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * <p>
 * wms出入库管理被观察者，该对象主要业务模式说明如下(以下例子列举采购单入库说明)
 * <p>
 * <p>
 * <以下是采购系统的操作>
 * 1.创建采购单 {@link com.seeease.flywheel_v4.web.adptor.PurchaseController#create(PurchaseOrderSubmitRequest)}
 * 2.当采购单达到入库条件时推送对应的wms入库数据 {@link com.seeease.flywheel_v4.web.infrastructure.listener.purchase.StartingStateListener#onEvent(StartingStateListener.Event)}
 * <p>
 * <以下wms的操作>
 * 3.wms操作质检通过 先保存wms本地状态变更数据 {@link #rkState(List, SkuNodeStateEnums)}
 * 4.wms通过rpc方法统一调用sku修改状态 {@link com.seeease.goods.rpc.SkuFacade#stateEventSubmit(SkuStateEventSubmitRcpRequest)}
 * 5.wms回调变更数据至采购类型的观察者进行自定义模块的数据处理 {@link PurchaseRkObserver#update(List, SkuNodeStateEnums)}
 *
 * </p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/21/24 2:37 下午
 **/
@Slf4j
@Component
public class WmsSubject {

    /**
     * 入库观察者列表
     */
    @Resource
    private List<WmsObserver<WmsRkTypeEnums, WmsRk>> rkObservers;
    /**
     * 出库观察者列表
     */
    @Resource
    private List<WmsObserver<WmsCkTypeEnums, WmsCk>> ckObservers;


    private final Map<MerchantWmsModelEnums, List<MerchantWmsObserver>> merchantWmsObserverMap;

    private final List<SkuNodeStateEnums> ignore = Lists.newArrayList(
            SkuNodeStateEnums.QX,
            SkuNodeStateEnums.YRK
    );

    @Resource
    private RepositoryFactory repositoryFactory;

    @Resource
    private MerchantWmsStateListener stateListener;

    @DubboReference(version = "1.0.0", check = false)
    private SkuFacade skuFacade;


    public WmsSubject(List<MerchantWmsObserver> merchantWmsObservers) {
        merchantWmsObserverMap = merchantWmsObservers.stream()
                .collect(Collectors.groupingBy(MerchantWmsObserver::model));
    }


    /**
     * 入库数据提交
     *
     * @param rkList 入库数据
     */
    public void rkDateSubmit(List<WmsRk> rkList) {
        repositoryFactory.getWmsRkRepository().submitBatch(rkList);
    }

    /**
     * 出库数据提交
     *
     * @param ckList 出库数据
     */
    public void ckDataSubmit(List<WmsCk> ckList) {
        ckList.forEach(ck -> {
            if (StringUtils.isEmpty(ck.getGroup())) {
                ck.setGroup(UUID.randomUUID().toString());
            }
        });
        repositoryFactory.getWmsCkRepository().submitBatch(ckList);

    }

    /**
     * 入库数据状态变动或数据变动提交
     *
     * @param rkList    入库数据
     * @param nodeState 变动的状态
     */
    public void rkState(List<WmsRk> rkList, SkuNodeStateEnums nodeState) {
        state(
                rkList,
                nodeState,
                this::rkDateSubmit,
                WmsRkMapping.INSTANCE::toSkuStateEvent,
                rkObservers,
                WmsRk::getType,
                this::postRkState,
                WmsRk::getSerialNo
        );
    }


    /**
     * wms入库数据变更后置处理
     *
     * @param rkList    变动的数据
     * @param nodeState 变动的状态
     */
    private void postRkState(List<WmsRk> rkList, SkuNodeStateEnums nodeState) {
        if (nodeState == null) {
            return;
        }

        switch (nodeState) {
            //状态变更为待入库
            case DRK:
                //创建拍照任务
                List<WmsPhotoManagement> photoManagementList = MultiUtils.toList(
                        rkList,
                        WmsPhotoManagementMapping.INSTANCE::toEntity
                );
                repositoryFactory.getWmsPhotoManagementRepository().submitBatch(photoManagementList);
                break;
        }
    }


    /**
     * 出库数据状态变动或数据变动提交
     *
     * @param ckList    出库数据
     * @param nodeState 变动的状态
     */
    public void ckState(List<WmsCk> ckList, SkuNodeStateEnums nodeState) {
        state(
                ckList,
                nodeState,
                this::ckDataSubmit,
                WmsCkMapping.INSTANCE::toSkuStateEvent,
                ckObservers,
                WmsCk::getType,
                this::postCkState,
                WmsCk::getSerialNo
        );
    }


    /**
     * wms出库数据变更后置处理
     *
     * @param rkList    变动的数据
     * @param nodeState 变动的状态
     */
    private void postCkState(List<WmsCk> rkList, SkuNodeStateEnums nodeState) {

    }

    /**
     * wms状态变更或数据更新的方法适配已经实际操作
     *
     * @param dataList           变更的wms数据
     * @param nodeState          变更的节点状态
     * @param dataSubmitFun      wms数据提交方法
     * @param skuRpcMapper       sku数据变更的转换器
     * @param observers          wms数据变更对应的观察者列表
     * @param dataTypeClassifier wms数据分组操作
     * @param post               wms后置操作
     * @param <T>                wms类型  入库  | 出库
     * @param <T1>               wms数据类型 {@link WmsRkTypeEnums} || {@link WmsCkTypeEnums}
     */
    private <T, T1> void state(List<T> dataList,
                               SkuNodeStateEnums nodeState,
                               Consumer<List<T>> dataSubmitFun,
                               BiFunction<List<T>, SkuNodeStateEnums, SkuStateEventSubmitRcpRequest> skuRpcMapper,
                               List<WmsObserver<T1, T>> observers,
                               Function<T, T1> dataTypeClassifier,
                               BiConsumer<List<T>, SkuNodeStateEnums> post,
                               Function<T, String> serialNoFun
    ) {


        /**
         * step1: 提交wms自身的变动数据
         */
        dataSubmitFun.accept(dataList);

        /**
         * step2: 查找对应的观察者进行回调
         */

        ArrayList<SkuStateEventSubmitRcpRequest> rpcRequestList = new ArrayList<>();

        Map<T1, List<T>> typeMap = dataList.stream().collect(Collectors.groupingBy(dataTypeClassifier));
        for (Map.Entry<T1, List<T>> entry : typeMap.entrySet()) {
            //通知所有观察者执行wms入库状态变更
            for (WmsObserver<T1, T> observer : observers) {
                //匹配对应的观察者
                if (observer.matchDataType(entry.getKey())) {

                    //根据单号分组
                    Map<String, List<T>> serialNoMap = entry.getValue()
                            .stream()
                            .collect(Collectors.groupingBy(serialNoFun));


                    for (Map.Entry<String, List<T>> sEntry : serialNoMap.entrySet()) {

                        if (null != nodeState) {
                            //通过各自观察者适配的状态去尝试修改sku状态
                            SkuNodeStateEnums newNodeState = observer.adaptSkuNodeState(nodeState, sEntry.getKey());
                            SkuStateEventSubmitRcpRequest rpcRequest;
                            //这里是变动sku节点状态的rpc请求
                            if (!ignore.contains(newNodeState)) {
                                if (null != newNodeState) {
                                    rpcRequest = skuRpcMapper.apply(entry.getValue(), newNodeState);
                                    rpcRequest.setSerialNo(sEntry.getKey());
                                    rpcRequest.setNodeState(newNodeState);
                                }
                                //这里是记录声明周期的请求
                                else {
                                    rpcRequest = skuRpcMapper.apply(entry.getValue(), nodeState);
                                    rpcRequest.setNodeState(nodeState);
                                    rpcRequest.setSerialNo(sEntry.getKey());
                                    rpcRequest.setUpdateNodeState(false);
                                }
                                rpcRequestList.add(rpcRequest);
                            }

                            //存在状态变更通知观察者
                            observer.update(entry.getValue(), nodeState, sEntry.getKey());
                        } else {
                            //无任何状态变更 通知观察者
                            observer.updateWithoutState(entry.getValue(), sEntry.getKey());
                        }
                    }

                    break;
                }
            }
        }



        /**
         * step_3 修改sku状态
         */
        if (StringUtils.isNotEmpty(rpcRequestList)) {

            skuFacade.stateEventSubmitBatch(rpcRequestList);
        }

        /**
         * wms自身后置处理
         */
        post.accept(dataList, nodeState);
    }


    /**
     * 获取出库拓展字段
     * @param wmsCkList
     * @return
     */
    public Map<String, Ext> getCkExt(List<WmsCk> wmsCkList) {
        Map<WmsCkTypeEnums, List<WmsCk>> wmsMap = wmsCkList.stream()
                .collect(Collectors.groupingBy(WmsCk::getType));

        HashMap<String, Ext> ret = new HashMap<>();

        for (Map.Entry<WmsCkTypeEnums, List<WmsCk>> entry : wmsMap.entrySet()) {
            for (WmsObserver<WmsCkTypeEnums, WmsCk> observer : ckObservers) {
                if (observer.matchDataType(entry.getKey())) {

                    WmsCkObserver ckObserver = (WmsCkObserver) observer;

                    Set<String> serialNo = MultiUtils.toSet(entry.getValue(), WmsCk::getSerialNo);
                    Map<String, Ext> part = ckObserver.getExt(serialNo);

                    if (StringUtils.isNotEmpty(part)) {
                        ret.putAll(part);
                    }
                }
            }
        }
        return ret;
    }


    /**
     * 商家wms数据新增
     *
     * @param main     主单数据
     * @param lineList 子单数据
     */
    public void merchantWmsDataCreate(MerchantWms main, List<MerchantWmsLine> lineList) {
        repositoryFactory.getMerchantWmsRepository().submit(main);

        lineList.forEach(l -> l.setMainId(main.getId()));
        repositoryFactory.getMerchantWmsLineRepository().submitBatch(lineList);
    }


    /**
     * 商家wms数据更新
     *
     * @param main     主单数据
     * @param lineList 子单数据
     */
    public void merchantWmsDataSubmit(MerchantWms main, List<MerchantWmsLine> lineList) {

        repositoryFactory.getMerchantWmsLineRepository().submitBatch(lineList);

        if (main != null) {
            ValidationUtil.isTrue(
                    repositoryFactory.getMerchantWmsRepository().submit(main),
                    "商家出入库主表数据更新失败"

            );
            //尝试变动主单状态
            stateListener.onEvent(new MerchantWmsStateListener.Event(this, main.getId()));
        }


    }


    /**
     * 商家wms出入库数据变动
     *
     * @param main      主表
     * @param lineList  字表
     * @param nodeState 变动的状态
     */
    public void merchantWmsState(MerchantWms main, List<MerchantWmsLine> lineList, SkuNodeStateEnums nodeState) {
        //更新数据
        merchantWmsDataSubmit(main, lineList);


        ArrayList<SkuStateEventSubmitRcpRequest> rpcRequestList = new ArrayList<>();
        //通知观察者
        List<MerchantWmsObserver> observers = merchantWmsObserverMap.get(main.getModel());
        for (MerchantWmsObserver observer : observers) {
            if (observer.typeList().contains(main.getType())) {

                if (nodeState != null) {

                    SkuNodeStateEnums newState = observer.adaptSkuNodeState(nodeState, main.getSerialNo());
                    //这里是变动sku节点状态的rpc请求
                    if (!ignore.contains(newState)) {
                        SkuStateEventSubmitRcpRequest rpcRequest;
                        if (null != newState) {
                            rpcRequest = MerchantWmsMapping.INSTANCE.toSkuStateEvent(lineList, main, newState);
                        }
                        //这里是记录声明周期的请求
                        else {
                            rpcRequest = MerchantWmsMapping.INSTANCE.toSkuStateEvent(lineList, main, nodeState);
                            rpcRequest.setUpdateNodeState(false);
                        }
                        rpcRequestList.add(rpcRequest);
                    }
                    observer.update(main, lineList, nodeState);
                }
                break;
            }

        }

        if (StringUtils.isNotEmpty(rpcRequestList)) {
            skuFacade.stateEventSubmitBatch(rpcRequestList);
        }


        //尝试变动主单状态
        stateListener.onEvent(new MerchantWmsStateListener.Event(this, main.getId()));

    }


    /**
     * 给外部调用取消某个wms出库单子，只有集单状态下才支持取消
     *
     * @param serialNo  业务单据
     * @param skuIdList 需要取消的skuId
     * @param force     忽略状态强制取消
     */
    public void cancelWmsCk(String serialNo, Set<Integer> skuIdList,boolean force) {
        List<WmsCk> ckList = repositoryFactory.getWmsCkRepository()
                .listBySerialNoAndSkuIds(serialNo, skuIdList)
                .stream()
                .filter(ck -> force || ck.getNodeState() != SkuNodeStateEnums.YCK)
                .peek(ck -> ck.setNodeState(SkuNodeStateEnums.QX))
                .collect(Collectors.toList());

        ValidationUtil.isTrue(StringUtils.isNotEmpty(ckList), "无可取消的出库单据");

        ckState(ckList, SkuNodeStateEnums.QX);
    }


    /**
     * 给外部调用取消某个wms入库单子
     *
     * @param serialNo  业务单据
     * @param skuIdList 需要取消的skuId

     */
    public void cancelWmsRk(String serialNo, Set<Integer> skuIdList) {

        List<WmsRk> wmsCkList = repositoryFactory.getWmsRkRepository()
                .list(skuIdList, serialNo, null)
                .stream()
                .filter(rk -> skuIdList.contains(rk.getSkuId()))
                .peek(rk -> rk.setNodeState(SkuNodeStateEnums.QX))
                .collect(Collectors.toList());

        rkState(wmsCkList, SkuNodeStateEnums.QX);
    }


    /**
     * 给外部调用取消某个商家wms单子
     *
     * @param serialNo  业务单据
     * @param skuIdList 需要取消的skuId
     * @param force 强制取消
     */
    public void cancelMerchantWms(String serialNo,
                                  Set<Integer> skuIdList,
                                  SkuNodeStateEnums targetNodeState,
                                  Boolean force) {
        //业务单据不存在唯一性所以需要一次次去匹配
        MerchantWms main = null;
        List<MerchantWmsLine> targetLineList = new ArrayList<>();

        List<MerchantWms> wmsList = repositoryFactory.getMerchantWmsRepository().listBySerialNo(serialNo);
        for (MerchantWms wms : wmsList) {

            List<MerchantWmsLine> lineList = repositoryFactory.getMerchantWmsLineRepository()
                    .listByMainId(wms.getId())
                    .stream()
                    .filter(item -> force || item.getNodeState() == targetNodeState)
                    .filter(item -> skuIdList.contains(item.getSkuId()))
                    .collect(Collectors.toList());

            Set<Integer> lineSkuIdList = MultiUtils.toSet(lineList, MerchantWmsLine::getSkuId);
            if (skuIdList.containsAll(lineSkuIdList)) {
                main = wms;
                targetLineList = lineList;
                break;
            }

        }

        if (null == main) {
            return;
        }

        targetLineList.forEach(l -> {
            l.setNodeState(SkuNodeStateEnums.QX);
            l.setEndState(WhetherEnum.YES);
        });


        merchantWmsState(main, targetLineList, SkuNodeStateEnums.QX);

        //尝试变动主单状态
        stateListener.onEvent(new MerchantWmsStateListener.Event(this, main.getId()));

    }


    /**
     * 获取商家出库拓展字段
     * @param main
     * @return
     */
    public Ext getMerchantCkExt(MerchantWms main) {
        List<MerchantWmsObserver> merchantWmsObservers = merchantWmsObserverMap.get(main.getModel());

        for (MerchantWmsObserver observer : merchantWmsObservers) {
            if (observer.typeList().contains(main.getType())) {
                return observer.getCkExt(main.getSerialNo());
            }
        }
        throw new ArgumentException("商家出入库类型错误");
    }



}

