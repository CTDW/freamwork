package com.seeease.flywheel_v4.web.app.sys_config.result;


import lombok.Data;

/**
 * <p>通用业务单元数据提交</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/3/24 11:26 上午
 **/
@Data
public class BusinessUnitListResult {
    /**
     * id
     */
    private Integer id;
    /**
     * 名称
     */
    private String name;
    /**
     * 业务单元类型
     */
    private Integer type;
    /**
     * 负责人
     */
    private String head;
    /**
     * 联系方式
     */
    private String phone;
    /**
     * 省
     */
    private String province;
    /**
     * 市
     */
    private String city;
    /**
     * 区
     */
    private String town;
    /**
     * 地址详细信息
     */
    private String addressDetail;

    /**
     * 是否自主经营
     */
    public Integer isSell ;
    /**
     * 一件代发业务单元id
     */
    private Integer dobId ;

}
