package com.seeease.flywheel_v4.web.app.sale.request;


import lombok.Data;

import javax.validation.constraints.NotNull;
import java.math.BigDecimal;


@Data
public class ToBSaleConsignmentConfirmRequest {


    /**
     * 销售单行id
     */
    @NotNull(message = "销售单行不能为空")
    private Integer lineId;
    /**
     * 成交价
     */
    @NotNull(message = "成交价不能为空")
    private BigDecimal dealPrice;



}
