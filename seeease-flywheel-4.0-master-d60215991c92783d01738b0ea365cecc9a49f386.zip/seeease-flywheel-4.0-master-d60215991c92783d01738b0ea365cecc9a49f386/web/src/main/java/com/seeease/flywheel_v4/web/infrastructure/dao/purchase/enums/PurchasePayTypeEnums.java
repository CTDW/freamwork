package com.seeease.flywheel_v4.web.infrastructure.dao.purchase.enums;

import com.baomidou.mybatisplus.annotation.IEnum;
import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * <p>采购打款方式</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/6/24 3:06 下午
 **/
@Getter
@AllArgsConstructor
public enum PurchasePayTypeEnums implements IEnum<Integer> {
    PART(1,"定金"),
    ALL(2,"全款"),
    CE(3,"差额")

    ;
    private Integer value;
    private String desc;
}
