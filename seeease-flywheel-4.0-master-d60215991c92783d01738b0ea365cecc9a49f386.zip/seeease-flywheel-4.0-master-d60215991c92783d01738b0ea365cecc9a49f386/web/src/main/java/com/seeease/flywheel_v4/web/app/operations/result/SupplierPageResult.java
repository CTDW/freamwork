package com.seeease.flywheel_v4.web.app.operations.result;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

@Data
public class SupplierPageResult implements Serializable {

    /**
     * id
     */
    private Integer id;
    /**
     * 供应商名称
     */
    private String name;
    /**
     * 供应商类型
     */
    private Integer type;
    /**
     * 状态
     */
    private Integer state;
    /**
     * 省
     */
    private String province;
    /**
     * 市
     */
    private String city;
    /**
     * 县区
     */
    private String area;
    /**
     * 详细地址
     */
    private String address;
    /**
     * 省市县区代码
     */
    private List<Integer> areaCodes;
    /**
     * 备注
     */
    private String remark;

    /**
     * 联系人列表
     */
    private List<SupplierContactListResult> contacts;

    /**
     * 修改人
     */
    private String updatedBy;

    /**
     * 修改时间
     */
    private Date updatedTime;


}
