package com.seeease.flywheel_v4.web.infrastructure.dao.purchase.repo.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.seeease.flywheel_v4.web.app.purchase.request.PurchaseOrderLinePageRequest;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.entity.PurchaseOrderLine;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.mapper.PurchaseOrderLineMapper;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.repo.PurchaseOrderLineRepository;
import com.seeease.goods.rpc.enums.SkuNodeStateEnums;
import com.seeease.seeeaseframework.mybatis.domain.WhetherEnum;
import com.seeease.springframework.context.UserContext;
import com.seeease.springframework.utils.StringUtils;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

/**
 * @author 西门 游
 * @version 1.0
 * @since 5/31/24 4:55 下午
 **/
@Repository
public class PurchaseOrderLineRepositoryImpl extends ServiceImpl<PurchaseOrderLineMapper, PurchaseOrderLine>
        implements PurchaseOrderLineRepository {



    @Override
    public void submitBatch(List<PurchaseOrderLine> list) {
        ArrayList<PurchaseOrderLine> upList = new ArrayList<>();
        ArrayList<PurchaseOrderLine> inList = new ArrayList<>();
        for (PurchaseOrderLine line: list
             ) {
            if (null != line.getId()){
                upList.add(line);
            }else {
                inList.add(line);
            }
        }
        if (!upList.isEmpty()){
            baseMapper.updateBatch(upList);
        }
        if (!inList.isEmpty()){
            baseMapper.insertBatchSomeColumn(inList);
        }
    }



    @Override
    public List<PurchaseOrderLine> listByPurchaseId(Integer purchaseId) {
        LambdaQueryWrapper<PurchaseOrderLine> wq = Wrappers.<PurchaseOrderLine>lambdaQuery()
                .eq(null != purchaseId, PurchaseOrderLine::getPurchaseId, purchaseId);
        return baseMapper.selectList(wq);
    }

    @Override
    public List<PurchaseOrderLine> listByIds(Set<Integer> skuIdList) {
        return baseMapper.selectBatchIds(skuIdList);
    }

    @Override
    public List<PurchaseOrderLine> listByNodeState(Integer nodeState) {
        LambdaQueryWrapper<PurchaseOrderLine> wq = Wrappers.<PurchaseOrderLine>lambdaQuery()
                .eq(null != nodeState, PurchaseOrderLine::getNodeState, nodeState);
        return baseMapper.selectList(wq);
    }



    @Override
    public List<PurchaseOrderLine> findByPurchaseIdAndSkuIds(Integer purchaseId, Set<Integer> skuIdList) {
        LambdaQueryWrapper<PurchaseOrderLine> wq = Wrappers.<PurchaseOrderLine>lambdaQuery()
                .eq(null != purchaseId, PurchaseOrderLine::getPurchaseId, purchaseId)
                .in(StringUtils.isNotEmpty(skuIdList),PurchaseOrderLine::getSkuId,skuIdList);
        return baseMapper.selectList(wq);
    }

    @Override
    public PurchaseOrderLine finById(Integer id) {
        return baseMapper.selectById(id);
    }

    @Override
    public Boolean submit(PurchaseOrderLine line) {
        return saveOrUpdate(line);
    }

    @Override
    public PurchaseOrderLine findByPurchaseIdAndSkuId(Integer purchaseId, Integer skuId) {
        LambdaQueryWrapper<PurchaseOrderLine> wq = Wrappers.<PurchaseOrderLine>lambdaQuery()
                .eq(null != purchaseId, PurchaseOrderLine::getPurchaseId, purchaseId)
                .eq(null != skuId, PurchaseOrderLine::getSkuId, skuId);
        return baseMapper.selectOne(wq);
    }

    @Override
    public Page<PurchaseOrderLine> page(Set<Integer> skuIdList,
                                        Set<Integer> orderIdList,
                                        PurchaseOrderLinePageRequest request) {


        LambdaQueryWrapper<PurchaseOrderLine> wq = Wrappers.<PurchaseOrderLine>lambdaQuery()
                .eq(PurchaseOrderLine::getNodeState,request.getNodeState())
                .in(StringUtils.isNotEmpty(skuIdList),PurchaseOrderLine::getSkuId,skuIdList)
                .in(StringUtils.isNotEmpty(orderIdList),PurchaseOrderLine::getPurchaseId,orderIdList)
                .eq(request.getMine(), PurchaseOrderLine::getCreatedId, UserContext.getUser().getId())
                .orderByDesc(PurchaseOrderLine::getCreatedTime);


        Page<PurchaseOrderLine> page = Page.of(request.getPage(), request.getLimit());
        baseMapper.selectPage(page,wq);
        return page;
    }

    @Override
    public List<PurchaseOrderLine> listByPurchaseIds(Set<Integer> purchaseIdList) {
        if (purchaseIdList.isEmpty()){
            return Collections.emptyList();
        }

        LambdaQueryWrapper<PurchaseOrderLine> wq = Wrappers.<PurchaseOrderLine>lambdaQuery()
                .in(PurchaseOrderLine::getPurchaseId,purchaseIdList);

        return baseMapper.selectList(wq);
    }

    @Override
    public List<PurchaseOrderLine> findByIdList(Set<Integer> idList) {
        return baseMapper.selectBatchIds(idList);
    }

    @Override
    public List<PurchaseOrderLine> listByPurchaseIdAndSkuIds(Integer purchaseId, Set<Integer> skuIdList) {
        LambdaQueryWrapper<PurchaseOrderLine> wq = Wrappers.<PurchaseOrderLine>lambdaQuery()
                .eq(PurchaseOrderLine::getPurchaseId,purchaseId)
                .in(PurchaseOrderLine::getSkuId,skuIdList);
        return baseMapper.selectList(wq);
    }

    @Override
    public List<PurchaseOrderLine> listBySkuIds(Set<Integer> skuIdList) {
        if (skuIdList.isEmpty()){
            return Collections.emptyList();
        }

        LambdaQueryWrapper<PurchaseOrderLine> wq = Wrappers.<PurchaseOrderLine>lambdaQuery()
                .in(PurchaseOrderLine::getSkuId,skuIdList);

        return baseMapper.selectList(wq);
    }

    @Override
    public void updateStateByMainId(Integer purchaseId, SkuNodeStateEnums nodeState) {
        LambdaUpdateWrapper<PurchaseOrderLine> wq = Wrappers.<PurchaseOrderLine>lambdaUpdate()
                .eq(PurchaseOrderLine::getPurchaseId, purchaseId)
                .set(PurchaseOrderLine::getNodeState, nodeState);
        baseMapper.update(null,wq);
    }

    @Override
    public void updateStateByIds(Set<Integer> lineIds, SkuNodeStateEnums nodeState, WhetherEnum endState) {
        LambdaUpdateWrapper<PurchaseOrderLine> wq = Wrappers.<PurchaseOrderLine>lambdaUpdate()
                .in(PurchaseOrderLine::getId, lineIds)
                .set(PurchaseOrderLine::getNodeState, nodeState)
                .set(null != endState ,PurchaseOrderLine::getEndState,endState);
        baseMapper.update(null,wq);
    }


}
