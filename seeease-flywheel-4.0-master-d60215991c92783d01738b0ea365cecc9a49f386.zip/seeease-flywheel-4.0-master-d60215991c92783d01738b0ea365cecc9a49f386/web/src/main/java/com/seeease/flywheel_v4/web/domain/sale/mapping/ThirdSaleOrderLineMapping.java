package com.seeease.flywheel_v4.web.domain.sale.mapping;


import com.doudian.open.api.order_orderDetail.data.SkuOrderListItem;
import com.kuaishou.merchant.open.api.domain.order.OrderItemInfo;
import com.seeease.flywheel_v4.client.enums.BusinessUnitTypeEnums;
import com.seeease.flywheel_v4.web.app.sale.request.SaleOrderCreateRequest;
import com.seeease.flywheel_v4.web.app.sale.request.ThirdSaleOrderConfirmRequest;
import com.seeease.flywheel_v4.web.app.sale.result.ThirdSaleOrderMergeResult;
import com.seeease.flywheel_v4.web.infrastructure.config.EnumMapping;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.enums.PurchaseDemandStateEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.entity.ThirdSaleOrderLine;
import com.seeease.flywheel_v4.web.util.SerialNoGenerator;
import com.seeease.goods.rpc.result.SkuRpcResult;
import com.seeease.goods.rpc.result.SpuRpcResult;
import com.seeease.springframework.utils.BigDecimalUtil;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;

import java.math.BigDecimal;


/**
 * <p>
 * </p>
 *
 * @author 西门 游
 * @since 2023-10-27
 */
@Mapper(componentModel = "spring",
        builder = @Builder(disableBuilder = true),
        nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS,
        nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE,
        imports = {BusinessUnitTypeEnums.class,
                PurchaseDemandStateEnums.class,
                PurchaseDemandStateEnums.TransitionEnum.class,
                SerialNoGenerator.class,
                BigDecimalUtil.class})
public interface ThirdSaleOrderLineMapping extends EnumMapping {

    ThirdSaleOrderLineMapping INSTANCE = Mappers.getMapper(ThirdSaleOrderLineMapping.class);


    @Mapping(target = "count",source = "count")
    @Mapping(target = "skuId",ignore = true)
    ThirdSaleOrderLine toEntity(SkuOrderListItem sku,
                                BigDecimal price,
                                Integer spuId,
                                String orderId,
                                Integer count
    );

    @Mapping(target = "lineId",source = "line.id")
    @Mapping(target = "dealPrice",source = "line.price")
    @Mapping(target = "spuId",source = "sku.spuId")
    @Mapping(target = "id",source = "sku.id")
    ThirdSaleOrderMergeResult.Sku toMergeDetail(ThirdSaleOrderLine line, SkuRpcResult sku);

    @Mapping(target = "lineId",source = "line.id")
    @Mapping(target = "dealPrice",source = "line.price")
    @Mapping(target = "spuId",source = "spu.id")
    @Mapping(target = "id",ignore = true)
    ThirdSaleOrderMergeResult.Sku toMergeDetail(ThirdSaleOrderLine line, SpuRpcResult spu);




    @Mapping(target = "sellCount",source = "sellCount")
    SaleOrderCreateRequest.Sku toTocCreateRequest(ThirdSaleOrderConfirmRequest.Sku sku);


    @Mapping(target = "skuId",ignore = true)
    @Mapping(target = "count",source = "orderItemInfo.num",defaultValue = "1")
    @Mapping(target = "price",expression = "java(BigDecimalUtil.centToYuan(String.valueOf(orderItemInfo.getPrice())))")
    ThirdSaleOrderLine toEntity(String orderId,
                                Integer spuId,
                                OrderItemInfo orderItemInfo);
}
