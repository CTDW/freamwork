package com.seeease.flywheel_v4.web.app.fix.request;

import com.seeease.springframework.PageRequest;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;


/**
 * @Description 维修中心-维修单-配件 请求值
 * @Date 2024-10-2 20:20
 * @Author by hk
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class FixOrderPartPageRequest extends PageRequest {

    @ApiModelProperty(name = "维修单号")
    private String orderNumber;

    @ApiModelProperty(name = "商品名称")
    private String goodsName;

    @ApiModelProperty(value = "品牌")
    private String goodsBrand;

    @ApiModelProperty(value = "分类")
    private String classification;

    @ApiModelProperty(value = "货号")
    private String articleNo;

}
