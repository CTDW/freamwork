package com.seeease.flywheel_v4.web.app.operations.request;

import lombok.Data;

import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;


@Data
public class SupplierQuotaTopUpRequest implements Serializable {


    /**
     * 类型
     */
    @NotNull(message = "类型不能为空")
    private Integer type;

    /**
     * 供应商id
     */
    @NotNull(message = "客户id不能为空")
    private Integer supplierId;


    /**
     * 金额
     */
    @NotNull(message = "金额不能为空")
    private BigDecimal amount;
    /**
     * 采购主体
     */
    @NotNull(message = "采购主体不能为空")
    private Integer purchaseSubjectId;

    /**
     * 打款账户
     */
    @NotNull(message = "打款账户不能为空")
    private String account;

    /**
     * 备注
     */
    private String remark;
    /**
     * 图片
     */
    private List<String> images;
}
