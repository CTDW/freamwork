package com.seeease.flywheel_v4.web.app.wms.request;


import com.fasterxml.jackson.annotation.JsonFormat;
import com.seeease.springframework.PageRequest;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Date;

/**
 * @ Description   :
 * @ Author        :  西门 游
 * @ CreateDate    :  6/6/24
 * @ Version       :  1.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class MerchantWmsPageRequest extends PageRequest {

    /**
     * 业务单号
     */
    private String serialNo;
    /**
     * 模型
     */
    private Integer model;
    /**
     * 类型
     */
    private Integer type;
    /**
     * 订单状态
     */
    private Integer state;
    /**
     * 表身号
     */
    private String skuCode;
    /**
     * 快递单号
     */
    private String expressNo;
    /**
     * 仅看自己
     */
    private Boolean mine;
    /**
     * 开始时间
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date startTime;
    /**
     * 结束时间
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date endTime;
    /**
     * 当前登录人业务单元id 用于数据隔离
     */
    private Integer buId;
}
