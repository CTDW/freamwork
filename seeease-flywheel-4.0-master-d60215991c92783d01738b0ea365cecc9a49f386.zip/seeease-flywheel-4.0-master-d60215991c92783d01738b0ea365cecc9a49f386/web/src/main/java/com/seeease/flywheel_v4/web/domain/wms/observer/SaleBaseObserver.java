package com.seeease.flywheel_v4.web.domain.wms.observer;

import com.google.common.collect.Lists;
import com.seeease.flywheel_v4.web.infrastructure.dao.RepositoryFactory;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.MerchantWmsTypeEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.WmsCkTypeEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.WmsRkTypeEnums;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 7/26/24 11:24 上午
 **/
@Component
public class SaleBaseObserver {



    /**
     * 仓库端wms 入库观察者类型
     */
    protected final List<WmsRkTypeEnums> wmsRkWatchTypeList = Lists.newArrayList(
            WmsRkTypeEnums.XS_TH_RK
    );



    /**
     * 商家端wms 出库观察的类型
     */
    protected final List<WmsCkTypeEnums> wmsCkWatchTypeList = Lists.newArrayList(
            WmsCkTypeEnums.XS_CK
    );






    /**
     * 商家端wms 入库观察的类型
     */
    protected final List<MerchantWmsTypeEnums> merchantWmsRkWatchTypeList = Lists.newArrayList(
            MerchantWmsTypeEnums.XS_TH_RK
    );



    /**
     * 商家端wms 出库观察者类型
     */
    protected final List<MerchantWmsTypeEnums> merchantWmsCkWatchTypeList = Lists.newArrayList(
            MerchantWmsTypeEnums.XS_CK
    );




}
