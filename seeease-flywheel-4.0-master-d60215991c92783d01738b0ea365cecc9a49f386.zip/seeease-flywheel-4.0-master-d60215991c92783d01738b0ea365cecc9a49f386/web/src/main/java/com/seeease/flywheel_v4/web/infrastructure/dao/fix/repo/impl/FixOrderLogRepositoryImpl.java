package com.seeease.flywheel_v4.web.infrastructure.dao.fix.repo.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.seeease.flywheel_v4.web.app.fix.request.FixOrderLogSaveRequest;
import com.seeease.flywheel_v4.web.infrastructure.dao.fix.entity.FixOrderLog;
import com.seeease.flywheel_v4.web.infrastructure.dao.fix.mapper.FixOrderLogMapper;
import com.seeease.flywheel_v4.web.infrastructure.dao.fix.repo.FixOrderLogRepository;
import org.springframework.stereotype.Repository;

import java.util.List;


/**
 * @Description 维修日志
 * @Date 2024-10-2 21:05
 * @Author by hk
 */
@Repository
public class FixOrderLogRepositoryImpl extends ServiceImpl<FixOrderLogMapper, FixOrderLog>
        implements FixOrderLogRepository {

    @Override
    public List<FixOrderLog> getFixLogByNumber(String fixOrderNumber) {
        QueryWrapper<FixOrderLog> queryWrapper = new QueryWrapper<>();
        queryWrapper.lambda().eq(FixOrderLog::getOrderNumber, fixOrderNumber);
        return baseMapper.selectList(queryWrapper);
    }

    /**
     * 保存维修日志
     *
     * @param request 请求
     */
    @Override
    public void save(FixOrderLogSaveRequest request){

        FixOrderLog orderLog = request.toEntity();

        baseMapper.insert(orderLog);
    }

    /**
     * 查询最近一次状态 ，用于回退
     * @param fixOrderNumber 维修单号
     * @return 结果
     */
    @Override
    public Integer getPreOrderStatus(String fixOrderNumber,Integer orderStatus) {
        return baseMapper.getPreOrderStatus(fixOrderNumber,orderStatus);
    }
}
