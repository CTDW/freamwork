package com.seeease.flywheel_v4.web.app.operations.request;

import lombok.Data;

import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.math.BigDecimal;


@Data
public class SupplierQuotaReturnRequest implements Serializable {

    /**
     * id
     */
    @NotNull(message = "id不能为空")
    private Integer id;
    /**
     * 金额
     */
    @NotNull(message = "金额不能为空")
    private BigDecimal amount;

}
