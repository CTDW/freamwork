package com.seeease.flywheel_v4.web.app.sale.request;


import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.List;
import java.util.Set;


@Data
public class ThirdSaleOrderConfirmRequest {
    /**
     * 主键id列表
     */
    @NotEmpty(message = "主键id列表不能为空")
    private Set<Integer> ids;

    /**
     * 第一销售人id
     */
    @NotNull(message = "第一销售人id不能为空")
    private Integer sellerAId;

    /**
     * 第二销售人id
     */
    private Integer sellerBId;

    /**
     * 第三销售人id
     */
    private Integer sellerCId;

    /**
     * 备注
     */
    private String remark;

    @Valid
    @NotEmpty(message = "sku列表不能为空")
    private List<Sku> skuList;


    @Data
    public static class Sku {

        /**
         * skuId
         */
        @NotNull(message = "skuId不能为空")
        private Integer id;
        /**
         * 数量
         */
        @NotNull(message = "数量不能为空")
        private Integer sellCount;
        /**
         * 成交价
         */
        @NotNull(message = "成交价不能为空")
        private BigDecimal dealPrice;
    }



}
