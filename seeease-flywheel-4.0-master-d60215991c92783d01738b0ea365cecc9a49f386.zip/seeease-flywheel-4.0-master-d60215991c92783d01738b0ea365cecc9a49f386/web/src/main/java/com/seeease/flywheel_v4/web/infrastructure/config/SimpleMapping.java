package com.seeease.flywheel_v4.web.infrastructure.config;

import java.util.List;
import java.util.stream.Collectors;

public interface SimpleMapping<BO,ENTITY> extends EnumMapping{


    ENTITY toEntity(BO dto);

    default <T>String parseList(List<T> list){
        if (null == list){
            return "";
        }
        return list.stream().map(Object::toString).collect(Collectors.joining(","));
    }
}
