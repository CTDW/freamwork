package com.seeease.flywheel_v4.web.app.wms.service;

import com.seeease.flywheel_v4.web.app.wms.request.WmsStoreAreaListRequest;
import com.seeease.flywheel_v4.web.app.wms.request.WmsStoreAreaSubmitRequest;
import com.seeease.flywheel_v4.web.app.wms.request.WmsStoreLocationPageRequest;
import com.seeease.flywheel_v4.web.app.wms.request.WmsStoreLocationSubmitRequest;
import com.seeease.flywheel_v4.web.app.wms.result.WmsStoreAreaListResult;
import com.seeease.flywheel_v4.web.app.wms.result.WmsStoreAreaTreeResult;
import com.seeease.flywheel_v4.web.app.wms.result.WmsStoreLocationPageResult;
import com.seeease.springframework.PageResult;

import java.util.List;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/20/24 11:46 上午
 **/
public interface WmsStoreLocationService {


    /**
     * wms库区树结构查询
     *
     * @return 库区树查询
     */
    List<WmsStoreAreaTreeResult> areaTree();

    /**
     * wms库区更新
     *
     * @return 库区树查询
     */
    Boolean areaUpdate(WmsStoreAreaSubmitRequest request);

    /**
     * wms库区删除
     *
     * @return 删除结果
     */
    Boolean areaDel(Integer id);

    /**
     * wms库位分页
     *
     * @return 删除结果
     */
    PageResult<WmsStoreLocationPageResult> locationPage(WmsStoreLocationPageRequest request);

    /**
     * wms库区创建
     *
     * @return 创建结果
     */
    Boolean areaCreate(WmsStoreAreaSubmitRequest request);

    /**
     * wms库位新增
     *
     * @return 新增结果
     */
    Boolean locationCreate(WmsStoreLocationSubmitRequest request);

    /**
     * wms库位更新
     *
     * @return 更新结果
     */
    Boolean locationUpdate(WmsStoreLocationSubmitRequest request);


    /**
     * wms库区列表查询
     *
     * @return 列表结果
     */
    List<WmsStoreAreaListResult> areaList(WmsStoreAreaListRequest request);

}
