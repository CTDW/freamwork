package com.seeease.flywheel_v4.web.app.transfer.request;


import lombok.Data;

import javax.validation.constraints.NotNull;

/**
 * @author 西门 游
 * @version 1.0
 * @since 6/3/24 11:26 上午
 **/
@Data
public class TransferUsableQuotaRequest {

    /**
     * 业务单元id
     */
    @NotNull(message = "业务单元id不能为空")
    private Integer id;
}
