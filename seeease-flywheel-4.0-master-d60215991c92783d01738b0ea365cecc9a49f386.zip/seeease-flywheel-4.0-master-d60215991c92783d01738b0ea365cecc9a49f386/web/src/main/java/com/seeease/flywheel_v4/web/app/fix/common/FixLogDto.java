package com.seeease.flywheel_v4.web.app.fix.common;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.seeease.flywheel_v4.web.infrastructure.dao.fix.entity.FixOrder;
import com.seeease.flywheel_v4.web.infrastructure.dao.fix.entity.FixOrderLog;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * @Description 维修单 维修日志
 * @Date 2024-10-4 18:27
 * @Author by hk
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FixLogDto implements Serializable {

    @ApiModelProperty(value = "步骤")
    private String fixStep;

    @ApiModelProperty(value = "维修内容")
    private String fixContent;

    @ApiModelProperty(value = "操作人")
    private String createdBy;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    @ApiModelProperty(value = "创建时间")
    private Date createdTime;


    public static FixLogDto fromEntity(FixOrderLog orderLog) {
        return FixLogDto.builder()
                .fixStep(orderLog.getFixStep())
                .fixContent(orderLog.getFixContent())
                .createdBy(orderLog.getCreatedBy())
                .createdTime(orderLog.getCreatedTime())
                .build();
    }
}
