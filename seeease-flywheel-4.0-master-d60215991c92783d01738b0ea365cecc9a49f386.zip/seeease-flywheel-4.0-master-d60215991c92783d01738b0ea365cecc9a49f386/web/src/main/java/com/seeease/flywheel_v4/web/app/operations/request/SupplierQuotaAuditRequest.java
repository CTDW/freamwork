package com.seeease.flywheel_v4.web.app.operations.request;

import lombok.Data;

import javax.validation.constraints.NotNull;
import java.util.List;


@Data
public class SupplierQuotaAuditRequest {

    /**
     * id
     */
    @NotNull(message = "id不能为空")
    private Integer id;
    /**
     * 状态
     */
    @NotNull(message = "状态不能为空")
    private Integer state;
    /**
     * 打款凭证
     */
    private List<String> images;
    /**
     * 驳回原因
     */
    private String reason;

}
