package com.seeease.flywheel_v4.web.infrastructure.dao.purchase.repo.impl;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.enums.PurchaseDemandStateEnums;
import com.seeease.seeeaseframework.mybatis.transitionstate.UpdateByIdCheckState;
import com.seeease.springframework.utils.DateUtils;
import com.seeease.springframework.utils.StringUtils;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.seeease.flywheel_v4.web.app.purchase.request.PurchaseDemandPageRequest;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.entity.PurchaseDemand;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.mapper.PurchaseDemandMapper;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.repo.PurchaseDemandRepository;
import com.seeease.springframework.context.UserContext;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author 西门 游
 * @version 1.0
 * @since 5/31/24 4:55 下午
 **/
@Repository
public class PurchaseDemandRepositoryImpl extends ServiceImpl<PurchaseDemandMapper, PurchaseDemand>
        implements PurchaseDemandRepository {

    @Override
    public Boolean submit(PurchaseDemand e) {
        return saveOrUpdate(e);
    }

    @Override
    public Page<PurchaseDemand> page(PurchaseDemandPageRequest request) {
        if (null != request.getStartTime() && null != request.getEndTime()) {
            request.setStartTime(DateUtils.getTimesmorning(request.getStartTime()));
            request.setEndTime(DateUtils.getTimesnight(request.getEndTime()));
        }


        LambdaQueryWrapper<PurchaseDemand> wq = Wrappers.<PurchaseDemand>lambdaQuery()
                .in(StringUtils.isNotEmpty(request.getSpuIdList()), PurchaseDemand::getSpuId, request.getSpuIdList())
                .eq(null != request.getState(), PurchaseDemand::getState, request.getState())
                .eq(StringUtils.isNotEmpty(request.getSerialNo()), PurchaseDemand::getSerialNo, request.getSerialNo())
                .eq(null != request.getMine() && request.getMine(), PurchaseDemand::getAssignedId, UserContext.getUser().getId())
                .eq(null != request.getMerchantId(), PurchaseDemand::getMerchantId, request.getMerchantId())
                .eq(StringUtils.isNotEmpty(request.getPurchaseSerialNo()), PurchaseDemand::getPurchaseSerialNo, request.getPurchaseSerialNo())
                .between(null != request.getStartTime() && null != request.getEndTime(),
                        PurchaseDemand::getCreatedTime,
                        request.getStartTime(),
                        request.getEndTime()

                )
                .orderByDesc(PurchaseDemand::getCreatedTime);

        Page<PurchaseDemand> page = new Page<>(request.getPage(), request.getLimit());
        baseMapper.selectPage(page, wq);
        return page;
    }

    @Override
    public Boolean submitBatchByState(List<PurchaseDemand> list) {
        list.forEach(v -> UpdateByIdCheckState.update(baseMapper, v));
        return true;
    }

    @Override
    public PurchaseDemand findByIdOrSerial(Integer id, String serialNo) {
        LambdaQueryWrapper<PurchaseDemand> wq = Wrappers.<PurchaseDemand>lambdaQuery()
                .eq(null != id, PurchaseDemand::getId, id)
                .eq(StringUtils.isNotEmpty(serialNo), PurchaseDemand::getSerialNo, serialNo);
        return baseMapper.selectOne(wq);
    }

    @Override
    public Boolean bindPurchaseOrder(List<Integer> ids, Integer purchaseId, String serialNo) {
        if (StringUtils.isEmpty(ids)) {
            return true;
        }

        Date now = new Date();
        List<PurchaseDemand> collect = ids.stream().map(v -> {
            PurchaseDemand demand = new PurchaseDemand();
            demand.setId(v);
            demand.setPurchaseId(purchaseId);
            demand.setTransitionStateEnum(PurchaseDemandStateEnums.TransitionEnum.STEP_1);
            demand.setPurchaseSerialNo(serialNo);
            demand.setConfirmTime(now);
            return demand;
        }).collect(Collectors.toList());

        return submitBatchByState(collect);
    }

    @Override
    public List<PurchaseDemand> listByPurchaseId(Integer purchaseId) {
        LambdaQueryWrapper<PurchaseDemand> wq = Wrappers.<PurchaseDemand>lambdaQuery()
                .eq( PurchaseDemand::getPurchaseId, purchaseId);
        return baseMapper.selectList(wq);
    }
}
