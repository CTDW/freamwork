package com.seeease.flywheel_v4.web.infrastructure.dao.purchase.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.seeease.goods.rpc.enums.SkuNodeStateEnums;
import com.seeease.seeeaseframework.mybatis.domain.BaseDomain;
import com.seeease.seeeaseframework.mybatis.domain.WhetherEnum;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;

/**
 * 采购订单行
 */
@EqualsAndHashCode(callSuper = true)
@TableName(value = "v4_purchase_aftersale_line", autoResultMap = true)
@Data
public class PurchaseAftersaleLine extends BaseDomain  {
    @TableId(type = IdType.AUTO)
    private Integer id;
    /**
     * 主单id
     */
    private Integer mainId;
    /**
     * skuId
     */
    private Integer skuId;
    /**
     * 数量
     */
    private Integer count;

    /**
     * 采购价
     */
    private BigDecimal price;

    /**
     * sku节点状态
     */
    private SkuNodeStateEnums nodeState;

    /**
     * 是否为终态
     */
    private WhetherEnum endState;




}