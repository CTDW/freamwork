package com.seeease.flywheel_v4.web.infrastructure.dao.sale.enums;

import com.baomidou.mybatisplus.annotation.IEnum;
import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * <p>销售模型</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/6/24 3:06 下午
 **/
@Getter
@AllArgsConstructor
public enum SaleModelEnums implements IEnum<Integer> {
    //tob
    B(1),
    //toc
    C(2),
    ;

    private Integer value;

}
