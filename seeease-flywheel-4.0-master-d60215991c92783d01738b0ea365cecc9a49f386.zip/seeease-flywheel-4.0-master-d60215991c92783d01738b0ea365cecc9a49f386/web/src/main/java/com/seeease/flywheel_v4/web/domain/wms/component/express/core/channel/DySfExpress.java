package com.seeease.flywheel_v4.web.domain.wms.component.express.core.channel;

import com.alibaba.fastjson.JSONObject;
import com.doudian.open.api.logistics_newCreateOrder.LogisticsNewCreateOrderRequest;
import com.doudian.open.api.logistics_newCreateOrder.LogisticsNewCreateOrderResponse;
import com.doudian.open.api.logistics_newCreateOrder.data.ErrInfosItem;
import com.doudian.open.api.logistics_newCreateOrder.param.*;
import com.doudian.open.api.logistics_waybillApply.LogisticsWaybillApplyRequest;
import com.doudian.open.api.logistics_waybillApply.LogisticsWaybillApplyResponse;
import com.doudian.open.api.logistics_waybillApply.param.LogisticsWaybillApplyParam;
import com.doudian.open.api.logistics_waybillApply.param.WaybillAppliesItem;
import com.doudian.open.api.order_orderDetail.OrderOrderDetailRequest;
import com.doudian.open.api.order_orderDetail.OrderOrderDetailResponse;
import com.doudian.open.api.order_orderDetail.param.OrderOrderDetailParam;
import com.doudian.open.core.AccessToken;
import com.doudian.open.core.GlobalConfig;
import com.doudian.open.utils.SignUtil;
import com.google.common.collect.Lists;
import com.seeease.flywheel_v4.web.domain.sale.mapping.ThirdSaleOrderMapping;
import com.seeease.flywheel_v4.web.domain.wms.component.express.core.ExpressChannel;
import com.seeease.flywheel_v4.web.domain.wms.component.express.core.PlaceOrderDto;
import com.seeease.flywheel_v4.web.domain.wms.component.express.core.PlaceOrderResult;
import com.seeease.flywheel_v4.web.domain.wms.component.express.core.PrintResult;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.entity.obj.BuyerInfoObj;
import com.seeease.frameworktiktok.api.TikTokShopApi;
import com.seeease.springframework.utils.StringUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.*;
import java.util.stream.Collectors;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 9/20/24 5:01 下午
 **/
@Component
@Slf4j
public class DySfExpress implements ExpressChannel<PrintResult.DyPrintResult> {

    /**
     * 国家编码（默认CHN，目前只有国内业务）
     */
    private static final String COUNTRY_CODE = "CHN";
    /**
     * 物流服务商编码
     */
    private static final String LOGISTICS_CODE = "shunfeng";

    @Resource
    private TikTokShopApi tikTokShopApi;

    @Override
    public Channel getChannel() {
        return Channel.DY_SF;
    }




    private BuyerInfoObj getAddress(String orderId ,Long shopId){
        //stpe_1 获取token
        AccessToken accessToken = tikTokShopApi.getAccessToken(shopId);
        //step_2 获取订单信息
        OrderOrderDetailRequest request = new OrderOrderDetailRequest();
        OrderOrderDetailParam param = request.getParam();
        param.setShopOrderId(orderId);
        OrderOrderDetailResponse response = request.execute(accessToken);


        //step_3 创建三方订单
        //构造客户数据
        return ThirdSaleOrderMapping.INSTANCE.toTiktokBuyer(
                orderId,
                response.getData().getShopOrderDetail().getEncryptPostTel(),
                response.getData().getShopOrderDetail().getEncryptPostReceiver(),
                response.getData().getShopOrderDetail().getPostAddr(),
                accessToken
        );

    }



    @Override
    public PlaceOrderResult placeOrder(PlaceOrderDto dto) {

        //step_1 构建发货人信息
        Address address = new Address();
        address.setProvinceName(dto.getSpProvince());
        address.setCityName(dto.getSpCity());
        address.setDistrictName(dto.getSpArea());
        address.setStreetName(dto.getSpStreet());
        String[] s = dto.getSpAddress().split(" ");
        address.setDetailAddress(s[s.length - 1]);

        address.setCountryCode(COUNTRY_CODE);
        Contact contact = new Contact();
        contact.setName(dto.getSpName());
        contact.setMobile(dto.getSpPhone());
        SenderInfo senderInfo = new SenderInfo();
        senderInfo.setAddress(address);
        senderInfo.setContact(contact);

        //step_2 构建收货人信息
        Address_4_4 address_4_4 = new Address_4_4();
        Contact contact_4_4 = new Contact();
        long shopId = Long.parseLong(dto.getSaleChannel().getThirdNo());
        BuyerInfoObj buyerInfo = getAddress(dto.getThirdSaleOrder().getOrderId(), shopId);

        address_4_4.setProvinceName(buyerInfo.getProvince());
        address_4_4.setCityName(buyerInfo.getCity());
        address_4_4.setDistrictName(buyerInfo.getTown());
        address_4_4.setStreetName(buyerInfo.getStreet());
        address_4_4.setDetailAddress(buyerInfo.getAddress());
        address_4_4.setCountryCode(COUNTRY_CODE);
        contact_4_4.setName(buyerInfo.getTiktokEncRec());
        contact_4_4.setMobile(buyerInfo.getTiktokEncTel());
        ReceiverInfo receiverInfo = new ReceiverInfo();
        receiverInfo.setAddress(address_4_4);
        receiverInfo.setContact(contact_4_4);

        //step_3 构建订单信息
        OrderInfosItem orderInfosItem = new OrderInfosItem();
        orderInfosItem.setProductType("2"); //顺丰标快是2  特快是1
        orderInfosItem.setOrderId(dto.getThirdSaleOrder().getOrderId());

        //设置收货方信息
        orderInfosItem.setReceiverInfo(receiverInfo);
        //商品信息
        orderInfosItem.setItems(
                dto.getProducts()
                        .stream()
                        .map(t -> {
                            ItemsItem itemsItem = new ItemsItem();
                            itemsItem.setItemName(t.getGoodsName());
                            itemsItem.setItemCount(NumberUtils.INTEGER_ONE);
                            return itemsItem;
                        }).collect(Collectors.toList()));

        //step_4 发送请求

        //构建请求参数
        LogisticsNewCreateOrderRequest logisticsNewCreateOrderRequest = new LogisticsNewCreateOrderRequest();
        LogisticsNewCreateOrderParam param = logisticsNewCreateOrderRequest.getParam();
        //设置发货信息
        param.setSenderInfo(senderInfo);
        //设置订单信息
        param.setOrderInfos(Collections.singletonList(orderInfosItem));
        //物流服务商编码
        param.setLogisticsCode(LOGISTICS_CODE);

        log.info("商家ERP/ISV 向字节电子面单系统获取单号和打印信息:{}", logisticsNewCreateOrderRequest);
        LogisticsNewCreateOrderResponse logisticsNewCreateOrderResponse = logisticsNewCreateOrderRequest.execute(
                tikTokShopApi.getAccessToken(Long.parseLong(dto.getSaleChannel().getThirdNo()))
        );
        log.info("商家ERP/ISV 向字节电子面单系统获取单号和打印信息:{}", logisticsNewCreateOrderResponse.toString());

        if (ObjectUtils.isNotEmpty(logisticsNewCreateOrderResponse) &&
                "10000".equals(logisticsNewCreateOrderResponse.getCode())) {

            if (CollectionUtils.isEmpty(logisticsNewCreateOrderResponse.getData().getEbillInfos())) {
                return PlaceOrderResult.builder()
                        .success(false)
                        .businessNo(dto.getBusinessNo())
                        .errMsg(Optional.ofNullable(logisticsNewCreateOrderResponse.getData().getErrInfos())
                                .map(t -> t.stream()
                                        .map(ErrInfosItem::getErrMsg)
                                        .findFirst()
                                        .orElse(""))
                                .orElse(""))
                        .build();
            }
            return PlaceOrderResult.builder()
                    .success(true)
                    .businessNo(dto.getBusinessNo())
                    .expressNumber(logisticsNewCreateOrderResponse.getData().getEbillInfos().get(0).getTrackNo())
                    .build();
        }

        return PlaceOrderResult.builder()
                .success(false)
                .businessNo(dto.getBusinessNo())
                .errMsg(logisticsNewCreateOrderResponse.getMsg())
                .build();


    }

    @Override
    public PrintResult.DyPrintResult printInfo(PlaceOrderResult placeOrderResult) {
        System.out.println("抖音打印入参数:" + JSONObject.toJSONString(placeOrderResult));
        long shopId = Long.parseLong(placeOrderResult.getDto().getSaleChannel().getThirdNo());
        AccessToken accessToken = tikTokShopApi.getAccessToken(shopId);

        //返回打印信息
        LogisticsWaybillApplyRequest logisticsWaybillApplyRequest = new LogisticsWaybillApplyRequest();
        LogisticsWaybillApplyParam logisticsWaybillApplyRequestParam = logisticsWaybillApplyRequest.getParam();
        WaybillAppliesItem waybillAppliesItem = new WaybillAppliesItem();
        waybillAppliesItem.setLogisticsCode("shunfeng");
        waybillAppliesItem.setTrackNo(placeOrderResult.getExpressNumber());
        logisticsWaybillApplyRequestParam.setWaybillApplies(Collections.singletonList(waybillAppliesItem));

        log.info("获取面单信息请求:{}", logisticsWaybillApplyRequest);
        LogisticsWaybillApplyResponse logisticsWaybillApplyResponse = logisticsWaybillApplyRequest.execute(accessToken);
        log.info("获取面单信息响应:{}", logisticsWaybillApplyResponse.toString());

        String printData = logisticsWaybillApplyResponse.getData()
                .getWaybillInfos()
                .get(0)
                .getPrintData();

        String sign = logisticsWaybillApplyResponse.getData()
                .getWaybillInfos()
                .get(0)
                .getSign();

        Map<String, String> data = new HashMap<>();

        String printProductName = placeOrderResult.getDto()
                .getProducts()
                .stream()
                .map(PlaceOrderDto.Product::getGoodsName)
                .collect(Collectors.joining("\n"));


        String btsCode = placeOrderResult.getDto().getQualityCode();
        data.put("productName", printProductName + "销售备注:" + placeOrderResult.getDto().getSaleRemark());
        data.put("remarks", placeOrderResult.getDto().getSaleRemark());
        data.put("model", "");
        if (org.apache.commons.lang3.StringUtils.isNotBlank(btsCode)) {
            data.put("spotCheckCode", "国检码：" + btsCode);
        }


        //------------senderInfo------------//
        PrintResult.DyPrintResult.SenderInfo senderInfo = new PrintResult.DyPrintResult.SenderInfo();

        PrintResult.DyPrintResult.Address address = new PrintResult.DyPrintResult.Address();
        address.setCityName(placeOrderResult.getDto().getSpCity());
        address.setProvinceName(placeOrderResult.getDto().getSpProvince());
        address.setCountryCode(COUNTRY_CODE);
        address.setDistrictName(placeOrderResult.getDto().getSpArea());
        address.setStreetName(placeOrderResult.getDto().getSpStreet());
        String[] s = placeOrderResult.getDto().getSpAddress().split(" ");
        address.setDetailAddress(s[s.length - 1]);
        senderInfo.setAddress(address);
        PrintResult.DyPrintResult.Contact contact = new PrintResult.DyPrintResult.Contact();
        String phone = StringUtils.replace(
                placeOrderResult.getDto().getSpPhone(),
                3,
                placeOrderResult.getDto().getSpPhone().length() - 4,
                '*'
        );
        contact.setPhone(phone);
        contact.setName(placeOrderResult.getDto().getSpName());
        senderInfo.setContact(contact);

        //------------contentsDTO------------//
        PrintResult.DyPrintResult.ContentsDTO contentsDTO = new PrintResult.DyPrintResult.ContentsDTO();
        contentsDTO.setTemplateURL(placeOrderResult.getDto().getSaleChannel().getExt().getTemplateUrl());

        String params = org.apache.commons.lang3.StringUtils.join(
                Arrays.asList(
                        "access_token=" + accessToken.getAccessToken(),
                        "app_key=" + GlobalConfig.getGlobalConfig().getAppKey(),
                        "method=logistics.getShopKey",
                        "param_json={}",
                        "timestamp=" + System.currentTimeMillis(),
                        "sign=" + SignUtil.sign(
                                GlobalConfig.getGlobalConfig().getAppKey(),
                                GlobalConfig.getGlobalConfig().getAppSecret(),
                                "logistics.getShopKey",
                                String.valueOf(System.currentTimeMillis()),
                                "{}", "2"
                        ),
                        "sign_method=md5", "v=2"
                ),
                "&"
        );
        contentsDTO.setParams(params);
        contentsDTO.setSignature(sign);
        contentsDTO.setEncryptedData(printData);

        HashMap<String, Object> addData = new HashMap<>();
        addData.put("senderInfo", senderInfo);
        contentsDTO.setAddData(addData);

        //------------dataDTO------------//
        PrintResult.DyPrintResult.DataDTO dataDTO = new PrintResult.DyPrintResult.DataDTO();
        dataDTO.setTemplateURL(placeOrderResult.getDto().getSaleChannel().getExt().getCustomTemplateUrl());
        dataDTO.setData(data);


        //------------documentsDTO------------//
        PrintResult.DyPrintResult.DocumentsDTO documentsDTO = new PrintResult.DyPrintResult.DocumentsDTO();
        documentsDTO.setDocNo(placeOrderResult.getExpressNumber());
        documentsDTO.setContents(Lists.newArrayList(contentsDTO, dataDTO));


        //------------task------------//
        PrintResult.DyPrintResult.TaskDTO task = new PrintResult.DyPrintResult.TaskDTO();
        task.setPreview(false);
        task.setDocuments(Collections.singletonList(documentsDTO));


        PrintResult.DyPrintResult ret = new PrintResult.DyPrintResult();
        ret.setCmd("print");
        ret.setVersion("1.0");
        ret.setTask(task);
        return ret;
    }
}
