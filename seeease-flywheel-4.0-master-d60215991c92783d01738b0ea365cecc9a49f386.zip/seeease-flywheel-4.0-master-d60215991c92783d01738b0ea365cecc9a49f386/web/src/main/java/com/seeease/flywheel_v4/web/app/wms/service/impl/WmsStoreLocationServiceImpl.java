package com.seeease.flywheel_v4.web.app.wms.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.seeease.flywheel_v4.client.enums.BusinessUnitTypeEnums;
import com.seeease.flywheel_v4.web.app.wms.request.WmsStoreAreaListRequest;
import com.seeease.flywheel_v4.web.app.wms.request.WmsStoreAreaSubmitRequest;
import com.seeease.flywheel_v4.web.app.wms.request.WmsStoreLocationPageRequest;
import com.seeease.flywheel_v4.web.app.wms.request.WmsStoreLocationSubmitRequest;
import com.seeease.flywheel_v4.web.app.wms.result.WmsStoreAreaListResult;
import com.seeease.flywheel_v4.web.app.wms.result.WmsStoreAreaTreeResult;
import com.seeease.flywheel_v4.web.app.wms.result.WmsStoreLocationPageResult;
import com.seeease.flywheel_v4.web.app.wms.service.WmsStoreLocationService;
import com.seeease.flywheel_v4.web.domain.wms.mapping.WmsStoreLocationMapping;
import com.seeease.flywheel_v4.web.infrastructure.dao.RepositoryFactory;
import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.entity.SysBusinessUnit;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.WmsStoreLocation;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.WmsStoreLocationLevelTypeEnums;
import com.seeease.goods.rpc.SpuFacade;
import com.seeease.goods.rpc.request.SpuRpcRequest;
import com.seeease.goods.rpc.result.SpuRpcResult;
import com.seeease.springframework.PageResult;
import com.seeease.springframework.context.UserContext;
import com.seeease.springframework.exception.ValidationUtil;
import com.seeease.springframework.utils.MultiUtils;
import org.apache.dubbo.config.annotation.DubboReference;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/20/24 11:46 上午
 **/
@Service
public class WmsStoreLocationServiceImpl implements WmsStoreLocationService {
    @Resource
    private RepositoryFactory repositoryFactory;

    @DubboReference(version = "1.0.0", check = false)
    private SpuFacade spuFacade;


    @Override
    public List<WmsStoreAreaTreeResult> areaTree() {
        //查询仓库
        List<SysBusinessUnit> storeList = repositoryFactory.getBusinessUnitRepository()
                .list(BusinessUnitTypeEnums.WAREHOUSE.getValue());

        if (storeList.isEmpty()) {
            return Collections.emptyList();
        }

        //库区查询
        List<WmsStoreAreaTreeResult> ret = MultiUtils.toList(
                repositoryFactory.getWmsStoreLocationRepository().areaList(),
                WmsStoreLocationMapping.INSTANCE::toTreeResult
        );

        List<WmsStoreAreaTreeResult> areaTree = MultiUtils.buildTree(
                ret,
                WmsStoreAreaTreeResult::getId,
                WmsStoreAreaTreeResult::getPid,
                pid -> pid.equals(0),
                WmsStoreAreaTreeResult::setChild
        );

        //将仓库列表转为同类型树结构
        List<WmsStoreAreaTreeResult> storeTree = MultiUtils.toList(
                storeList,
                WmsStoreLocationMapping.INSTANCE::toTreeResult
        );

        //将库区树结构包裹进仓库树结构
        Map<Integer, List<WmsStoreAreaTreeResult>> areaTreeMap = areaTree.stream()
                .collect(Collectors.groupingBy(WmsStoreAreaTreeResult::getStoreId));

        Integer buId = UserContext.getUser().getStore().getId();
       return storeTree.stream()
                .peek(item -> {
                    item.setChild(areaTreeMap.get(item.getId()));
                    item.setStoreId(item.getId());
                    item.setLevel(0);
                })
                .filter(item -> buId.equals(item.getStoreId()))
                .collect(Collectors.toList());

    }

    @Override
    public Boolean areaUpdate(WmsStoreAreaSubmitRequest request) {

        WmsStoreLocation area = repositoryFactory.getWmsStoreLocationRepository()
                .findById(request.getId());

        ValidationUtil.notNull(area, "库区id错误");
        ValidationUtil.isTrue(area.getLevel() != WmsStoreLocationLevelTypeEnums.LOCATION, "类型错误无法修改");

        WmsStoreLocationMapping.INSTANCE.toEntityForUpdate(area, request);

        repositoryFactory.getWmsStoreLocationRepository().submit(area);

        return true;
    }

    @Override
    public Boolean areaDel(Integer id) {
        WmsStoreLocation area = repositoryFactory.getWmsStoreLocationRepository()
                .findById(id);
        ValidationUtil.notNull(area, "库区id错误");
        ValidationUtil.isTrue(area.getLevel() != WmsStoreLocationLevelTypeEnums.LOCATION, "类型错误无法删除");
        ValidationUtil.isTrue(
                !repositoryFactory.getWmsStoreLocationRepository().canDelArea(area.getId()),
                "无法删除被引用的库区"
        );
        ValidationUtil.isTrue(
                repositoryFactory.getWmsStoreLocationRepository().delById(id),
                "库区更新失败"
        );
        return true;
    }

    @Override
    public PageResult<WmsStoreLocationPageResult> locationPage(WmsStoreLocationPageRequest request) {


        Page<WmsStoreLocation> page = repositoryFactory.getWmsStoreLocationRepository()
                .page(request);

        if (page.getRecords().isEmpty()) {
            return PageResult.buildEmpty();
        }

        //查询子区
        Set<Integer> childAreaIdList = MultiUtils.toSet(page.getRecords(), WmsStoreLocation::getPid);
        List<WmsStoreLocation> childAreaList = repositoryFactory.getWmsStoreLocationRepository()
                .listByIds(childAreaIdList);
        Map<Integer, WmsStoreLocation> childAreaMap = MultiUtils.toMap(
                childAreaList,
                WmsStoreLocation::getId,
                Function.identity()
        );


        //查询主区
        Set<Integer> mainAreaIdList = MultiUtils.toSet(childAreaList, WmsStoreLocation::getPid);
        Map<Integer, WmsStoreLocation> mainAreaMap = MultiUtils.toMap(
                repositoryFactory.getWmsStoreLocationRepository().listByIds(mainAreaIdList),
                WmsStoreLocation::getId,
                Function.identity()
        );

        //查询spu
        Set<Integer> spuIdList = MultiUtils.toSet(page.getRecords(), WmsStoreLocation::getSpuId);
        SpuRpcRequest rpcRequest = new SpuRpcRequest();
        rpcRequest.setIdList(spuIdList);
        Map<Integer, SpuRpcResult> spuMap = MultiUtils.toMap(
                spuFacade.list(rpcRequest),
                SpuRpcResult::getId,
                Function.identity()
        );


        //组合
        List<WmsStoreLocationPageResult> ret = MultiUtils.toList(
                page.getRecords(),
                v -> {
                    WmsStoreLocation childArea = childAreaMap.get(v.getPid());
                    WmsStoreLocation mainArea = mainAreaMap.get(childArea.getPid());
                    SpuRpcResult spu = spuMap.get(v.getSpuId());

                    return WmsStoreLocationMapping.INSTANCE.toPageResult(v, childArea, mainArea, spu);
                }
        );

        return PageResult.<WmsStoreLocationPageResult>builder()
                .result(ret)
                .totalCount(page.getTotal())
                .totalPage(page.getPages())
                .build();
    }

    @Override
    public Boolean areaCreate(WmsStoreAreaSubmitRequest request) {
        SysBusinessUnit store = repositoryFactory.getBusinessUnitRepository().findById(request.getStoreId());
        ValidationUtil.notNull(store, "仓库id错误");
        ValidationUtil.isTrue(store.getType() == BusinessUnitTypeEnums.WAREHOUSE, "仓库id错误");

        if (request.getPid() != 0) {
            WmsStoreLocation parentArea = repositoryFactory.getWmsStoreLocationRepository().findById(request.getPid());
            ValidationUtil.notNull(parentArea, "父节点id错误");
            ValidationUtil.isTrue(parentArea.getLevel() == WmsStoreLocationLevelTypeEnums.MAIN_AREA, "父节点id错误");
        }

        WmsStoreLocation area = WmsStoreLocationMapping.INSTANCE.toEntity(request);
        repositoryFactory.getWmsStoreLocationRepository().submit(area);
        return true;
    }

    @Override
    public Boolean locationCreate(WmsStoreLocationSubmitRequest request) {
        WmsStoreLocation childArea = repositoryFactory.getWmsStoreLocationRepository()
                .findById(request.getChildAreaId());
        ValidationUtil.notNull(childArea, "子库区id错误");
        ValidationUtil.isTrue(
                childArea.getLevel() == WmsStoreLocationLevelTypeEnums.CHILD_AREA,
                "子库区id错误"
        );

        SpuRpcRequest rpcRequest = new SpuRpcRequest();
        rpcRequest.setIdList(Collections.singleton(request.getSpuId()));
        ValidationUtil.isTrue(spuFacade.list(rpcRequest).size() != 0, "spuId错误");

        WmsStoreLocation location = WmsStoreLocationMapping.INSTANCE.toEntity(childArea.getStoreId(), request);

        repositoryFactory.getWmsStoreLocationRepository().submit(location);
        return true;
    }

    @Override
    public Boolean locationUpdate(WmsStoreLocationSubmitRequest request) {
        WmsStoreLocation location = repositoryFactory.getWmsStoreLocationRepository().findById(request.getId());
        ValidationUtil.notNull(location, "库位id错误");
        ValidationUtil.isTrue(location.getLevel() == WmsStoreLocationLevelTypeEnums.LOCATION, "库位id错误");

        if (!Objects.equals(location.getPid(), request.getChildAreaId())) {
            WmsStoreLocation childArea = repositoryFactory.getWmsStoreLocationRepository()
                    .findById(request.getChildAreaId());
            ValidationUtil.notNull(childArea, "子库区id错误");
            ValidationUtil.isTrue(
                    childArea.getLevel() == WmsStoreLocationLevelTypeEnums.CHILD_AREA,
                    "子库区id错误"
            );
        }

        if (!Objects.equals(location.getSpuId(), request.getSpuId())) {
            SpuRpcRequest rpcRequest = new SpuRpcRequest();
            rpcRequest.setIdList(Collections.singleton(request.getSpuId()));
            ValidationUtil.isTrue(spuFacade.list(rpcRequest).size() != 0, "spuId错误");

        }

        WmsStoreLocationMapping.INSTANCE.toEntityForUpdate(location, request);
        repositoryFactory.getWmsStoreLocationRepository().submit(location);

        return true;
    }

    @Override
    public List<WmsStoreAreaListResult> areaList(WmsStoreAreaListRequest request) {
        List<WmsStoreLocation> storeLocationList = repositoryFactory.getWmsStoreLocationRepository().list(
                request.getPid(),
                request.getLevel()
        );


        return MultiUtils.toList(
                storeLocationList,
                WmsStoreLocationMapping.INSTANCE::toListResult
        );
    }
}
