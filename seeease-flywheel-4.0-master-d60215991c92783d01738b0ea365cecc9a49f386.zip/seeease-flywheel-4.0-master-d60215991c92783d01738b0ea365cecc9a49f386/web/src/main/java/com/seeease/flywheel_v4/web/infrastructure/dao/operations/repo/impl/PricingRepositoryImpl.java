package com.seeease.flywheel_v4.web.infrastructure.dao.operations.repo.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.google.common.collect.Lists;
import com.seeease.flywheel_v4.web.app.operations.request.PricingPageRequest;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.Pricing;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.enums.PricingStateEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.mapper.PricingMapper;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.repo.PricingRepository;
import com.seeease.seeeaseframework.mybatis.transitionstate.UpdateByIdCheckState;
import com.seeease.springframework.utils.StringUtils;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * @author 西门 游
 * @version 1.0
 * @since 5/31/24 4:55 下午
 **/
@Repository
public class PricingRepositoryImpl extends ServiceImpl<PricingMapper, Pricing>
        implements PricingRepository {


    @Override
    public Boolean submit(Pricing pricing) {
        if (null != pricing.getTransitionStateEnum()){
            UpdateByIdCheckState.update(baseMapper,pricing);
            return true;
        }else {
            return saveOrUpdate(pricing);
        }
    }

    @Override
    public Page<Pricing> page(PricingPageRequest request, Set<Integer> skuIdList) {
        LambdaQueryWrapper<Pricing> wq = Wrappers.<Pricing>lambdaQuery()
                .eq(StringUtils.isNotEmpty(request.getCreatedBy()), Pricing::getCreatedBy, request.getCreatedBy())
                .in(StringUtils.isNotEmpty(skuIdList), Pricing::getSkuId, skuIdList)
                .eq(null != request.getState(),Pricing::getState,request.getState())
                .orderByDesc(Pricing::getUpdatedTime);

        Page<Pricing> page = Page.of(request.getPage(), request.getLimit());

        baseMapper.selectPage(page,wq);

        return page;
    }

    @Override
    public Pricing findById(Integer id) {
        return baseMapper.selectById(id);
    }

    @Override
    public List<Integer> statics(PricingPageRequest request, Set<Integer> skuIdList) {
        LambdaQueryWrapper<Pricing> wq = Wrappers.<Pricing>lambdaQuery()
                .select(Pricing::getState)
                .eq(StringUtils.isNotEmpty(request.getCreatedBy()), Pricing::getCreatedBy, request.getCreatedBy())
                .in(StringUtils.isNotEmpty(skuIdList), Pricing::getSkuId, skuIdList);

        ArrayList<Integer> ret = Lists.newArrayList(0, 0, 0);

        baseMapper.selectList(wq)
                .stream()
                .collect(Collectors.groupingBy(Pricing::getState))
                .forEach((k,v) ->{
                    if (k == PricingStateEnums.WAIT_PRICING){
                        ret.set(0,v.size());
                    }else if (k == PricingStateEnums.WAIT_AUDIT){
                        ret.set(1, v.size());
                    }else {
                        ret.set(2,v.size());
                    }
                });

        return ret;

    }

    @Override
    public void submitBatch(List<Pricing> list) {
        ArrayList<Pricing> upList = new ArrayList<>();
        ArrayList<Pricing> inList = new ArrayList<>();
        for (Pricing line: list
        ) {
            if (null != line.getId()){
                upList.add(line);
            }else {
                inList.add(line);
            }
        }
        if (!upList.isEmpty()){
            baseMapper.updateBatch(upList);
        }
        if (!inList.isEmpty()){
            baseMapper.insertBatchSomeColumn(inList);
        }
    }

    @Override
    public List<Pricing> listBySkuIds(Set<Integer> skuIdList) {
        LambdaQueryWrapper<Pricing> wq = Wrappers.<Pricing>lambdaQuery()
                .in(StringUtils.isNotEmpty(skuIdList), Pricing::getSkuId, skuIdList);
        return baseMapper.selectList(wq);
    }

    @Override
    public List<Pricing> listByIds(Set<Integer> ids) {
        if (ids.isEmpty()){
            return Collections.emptyList();
        }
        return baseMapper.selectBatchIds(ids);
    }


}
