package com.seeease.flywheel_v4.web.app.sale.rpc;

import com.kuaishou.merchant.open.api.client.AccessTokenKsMerchantClient;
import com.kuaishou.merchant.open.api.client.oauth.OauthAccessTokenKsClient;
import com.kuaishou.merchant.open.api.domain.order.OrderAddressInfo;
import com.kuaishou.merchant.open.api.domain.order.OrderDetail;
import com.kuaishou.merchant.open.api.request.order.OpenOrderDetailRequest;
import com.kuaishou.merchant.open.api.response.oauth.KsAccessTokenResponse;
import com.kuaishou.merchant.open.api.response.order.OpenOrderDetailResponse;
import com.seeease.flywheel_v4.web.domain.sale.mapping.ThirdSaleOrderMapping;
import com.seeease.flywheel_v4.web.infrastructure.dao.RepositoryFactory;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.entity.obj.BuyerInfoObj;
import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.entity.SysSaleChannel;
import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.entity.obj.SaleChannelExtObj;
import com.seeease.framework.ks.api.KsShopApi;
import com.seeease.springframework.utils.StringUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 9/24/24 1:46 下午
 **/
@Component
public class KsComponent {

    @Resource
    private RepositoryFactory repositoryFactory;

    /**
     * 获取token
     * @param saleChannel
     * @return
     */
    public synchronized KsShopApi.ParamUserToken getUserToken(SysSaleChannel saleChannel){
        SaleChannelExtObj ext = saleChannel.getExt();
        KsShopApi.ParamUserToken paramToken = new KsShopApi.ParamUserToken();
        paramToken.setAppId(saleChannel.getThirdNo());
        paramToken.setSecret(saleChannel.getSecret());
        paramToken.setToken(ext.getKsToken());
        paramToken.setRefreshToken(ext.getKsRefreshToken());
        paramToken.setExpire(ext.getKsExpire());
        KsShopApi.ParamUserToken newToken = KsShopApi.getUserAccessToken(paramToken);
        //更新token
        if (newToken != paramToken) {
            ext.setKsExpire(newToken.getExpire());
            ext.setKsToken(newToken.getToken());
            ext.setKsRefreshToken(newToken.getRefreshToken());
            saleChannel.setExt(ext);
            repositoryFactory.getSaleChannelRepository().submit(saleChannel);
        }

        return newToken;
    }

    public static void main(String[] args) throws Exception {
        KsShopApi.ParamUserToken paramToken = new KsShopApi.ParamUserToken();
        paramToken.setAppId("ks648518348687547249");
        paramToken.setSecret("JXTPSs5iB-B1IUuUhC4EfQ");
        paramToken.setToken("ChFvYXV0aC5hY2Nlc3NUb2tlbhJwvN_1MLjopFlYB4TbH9TnUnJ6hXkJPrtQ86FHPb_6hRMOGS2nU7bH7YyjB2VmAvuAs2AaE9R21lGzZRZgdQJ7LZvqTmWkVTGznOrlciwUUW72LHt36Meafd5IOe0O9cW4UI08g7iv8WbHXrYQukPvkxoS5s6ZYyz1R2ytQyU2fnDU6SnyIiDuMcnbJJYu2cwchXFJG6-d0KH996I4PseU8ljL7IWxPSgFMAE");
        paramToken.setRefreshToken("ChJvYXV0aC5yZWZyZXNoVG9rZW4SwAGq2NvdpVgo8-MK84OgUxRIwoZyNYUS30YPB7khHJtJyIhmeWhezHyRc5IYIVyLpYDxVQaAaF1EkNiYKrmCVjTRFplL0VkT2YvFaIxoCdLJqiBRp_lxud-w2vYiGYoCpj5yQG4pTQqkrN8zSVsDxkw_qF2oICkIAVSwNcSipN427GPFkcfDRdXlYGSV2bIAHe0cbHT5SojdEVqBwWJRIK7ikZ2YqTKVXmkCYS_97GYw0ffZBJAteCmX9sy6gVBqZV4aEk9qDI0zy-QVWtawmDw8tfQcKSIgPz5pbUZoaAwyrw0IAQgW9Un_ZlPFqpOVrg0DMfPSF1coBTAB");
        paramToken.setExpire(1742976637792L);
        KsShopApi.ParamUserToken newToken = KsShopApi.getUserAccessToken(paramToken);


        OauthAccessTokenKsClient client1 = new OauthAccessTokenKsClient(
                paramToken.getAppId(),
                paramToken.getSecret()
        );
        KsAccessTokenResponse resp = client1.refreshAccessToken(paramToken.getRefreshToken());

        AccessTokenKsMerchantClient client = new AccessTokenKsMerchantClient(
                "ks648518348687547249",
                "e6583abd25d72689e3fcea5a41a37f76"
        );
        OpenOrderDetailRequest request = new OpenOrderDetailRequest();
        request.setAccessToken(paramToken.getToken());
        request.setOid(2427101803554186L);

        OpenOrderDetailResponse response = client.execute(request);
        OrderDetail detail = response.getData();

        OrderAddressInfo orderAddress = detail.getOrderAddress();
        BuyerInfoObj buyer = ThirdSaleOrderMapping.INSTANCE.toKsBuyer(orderAddress);

        //通过客户数据创建合单依据
        String mergedId = StringUtils.encoderByMd5(
                buyer.getKsEncAddr() +
                        buyer.getKsEncRec() +
                        buyer.getKsEncTel()
        );

    }
}
