package com.seeease.flywheel_v4.web.infrastructure.dao.operations.enums;

import com.seeease.seeeaseframework.mybatis.transitionstate.IStateEnum;
import com.seeease.seeeaseframework.mybatis.transitionstate.ITransitionStateEnum;
import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @ Description   :  定价状态
 * @ Author        :  西门 游
 * @ CreateDate    :  6/4/24
 * @ Version       :  1.0
 */
@Getter
@AllArgsConstructor
public enum PricingStateEnums implements IStateEnum<Integer> {

    WAIT_PRICING(1,"待定价"),
    WAIT_AUDIT(2,"待审核"),
    OK(3,"定价通过")
    ;

    private Integer value;
    private String desc;



    @Getter
    @AllArgsConstructor
    public enum TransitionEnum implements ITransitionStateEnum {
        STEP_1(WAIT_PRICING,WAIT_AUDIT,"待审核"),
        STEP_2(WAIT_AUDIT,WAIT_PRICING,"审核驳回"),
        STEP_3(WAIT_AUDIT,OK,"定价通过"),
        STEP_4(OK,WAIT_PRICING,"重新定价"),

        ;
        private PricingStateEnums fromState;
        private PricingStateEnums toState;
        private String desc;

    }
}
