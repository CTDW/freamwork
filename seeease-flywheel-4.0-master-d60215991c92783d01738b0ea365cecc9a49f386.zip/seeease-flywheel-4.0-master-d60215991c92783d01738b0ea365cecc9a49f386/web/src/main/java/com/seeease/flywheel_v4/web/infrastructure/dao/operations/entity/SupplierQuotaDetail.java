package com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.enums.SupplierQuotaAuditTypeEnums;
import com.seeease.seeeaseframework.mybatis.domain.BaseDomain;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;

/**
 * 供应商保证金详情
 */
@EqualsAndHashCode(callSuper = true)
@TableName(value = "v4_ops_supplier_quota_detail", autoResultMap = true)
@Data
public class SupplierQuotaDetail extends BaseDomain {
    @TableId(type = IdType.AUTO)
    private Integer id;
    /**
     * 用户id
     */
    private Integer userid;
    /**
     * 用户名称
     */
    private String userName;

    /**
     * 余额id
     */
    private Integer quotaId;
    /**
     * 金额
     */
    private BigDecimal amount;

    /**
     * 金额类型
     */
    private SupplierQuotaAuditTypeEnums amountType;


}