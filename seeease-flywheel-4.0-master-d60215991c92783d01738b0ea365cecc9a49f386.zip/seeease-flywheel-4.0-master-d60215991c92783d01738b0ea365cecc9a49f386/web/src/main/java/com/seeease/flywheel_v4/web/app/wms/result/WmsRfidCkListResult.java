package com.seeease.flywheel_v4.web.app.wms.result;

import lombok.Data;

import java.util.Date;
import java.util.List;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/4/24 6:00 下午
 **/
@Data
public class WmsRfidCkListResult {
    /**
     * 类型
     */
    private Integer type;

    /**
     * 业务单号
     */
    private String serialNo;

    /**
     * 待出库数量
     */
    private Long waitCount;

    /**
     * 已出库数量
     */
    private Long doneCount;

    /**
     * 快递单号
     */
    private String expressNo;
    /**
     * 创建人
     */
    private String createdBy;
    /**
     * 创建时间
     */
    private Date createdTime;
    /**
     * sku列表
     */
    private List<Sku> skuList;

    @Data
    public static class Sku {
        /**
         * 出库行id
         */
        private Integer id;
        /**
         * 蜥蜴编码
         */
        private String xyCode;
        /**
         * 商品编码
         */
        private String goodsCode;
        /**
         * 管控类型
         */
        private Integer uniqueType;

        /**
         * 商品名称
         */
        private String goodsName;
        /**
         * 唯一码
         */
        private String skuCode;
    }


}
