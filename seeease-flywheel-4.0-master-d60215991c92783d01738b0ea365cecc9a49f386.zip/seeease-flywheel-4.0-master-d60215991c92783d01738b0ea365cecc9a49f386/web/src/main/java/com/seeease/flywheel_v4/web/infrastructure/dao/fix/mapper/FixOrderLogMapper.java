package com.seeease.flywheel_v4.web.infrastructure.dao.fix.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.seeease.flywheel_v4.web.infrastructure.dao.fix.entity.FixOrderLog;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;


/**
 * @Description 维修日志
 * @Date 2024-10-2 21:02
 * @Author by hk
 */
public interface FixOrderLogMapper extends BaseMapper<FixOrderLog> {

    @Select("select order_status from v4_fix_order_log where id < " +
            "(select id from v4_fix_order_log where order_number = #{orderNumber} " +
            "and order_status = #{currentOrderStatus} order by id desc limit 1) " +
            "order by id desc limit 1")
    Integer getPreOrderStatus(@Param("orderNumber") String orderNumber,
                              @Param("currentOrderStatus") Integer currentOrderStatus);

}
