
package com.seeease.flywheel_v4.web.infrastructure.dao.purchase.repo.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.entity.PurchaseAftersaleLine;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.mapper.PurchaseAftersaleLineMapper;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.repo.PurchaseAftersaleLineRepository;
import com.seeease.springframework.utils.StringUtils;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

/**
 * @author 西门 游
 * @version 1.0
 * @since 5/31/24 4:55 下午
 **/
@Repository
public class PurchaseAftersaleLineRepositoryImpl extends ServiceImpl<PurchaseAftersaleLineMapper, PurchaseAftersaleLine>
        implements PurchaseAftersaleLineRepository {


    @Override
    public void submitBatch(List<PurchaseAftersaleLine> list) {
        ArrayList<PurchaseAftersaleLine> upList = new ArrayList<>();
        ArrayList<PurchaseAftersaleLine> inList = new ArrayList<>();
        for (PurchaseAftersaleLine item: list
        ) {
            if (null != item.getId()){
                upList.add(item);
            }else {
                inList.add(item);
            }
        }
        if (!upList.isEmpty()){
            baseMapper.updateBatch(upList);
        }
        if (!inList.isEmpty()){
            baseMapper.insertBatchSomeColumn(inList);
        }
    }

    @Override
    public List<PurchaseAftersaleLine> listByMainIdAndSkuIds(Integer mainId, Set<Integer> skuIdList) {
        LambdaQueryWrapper<PurchaseAftersaleLine> wq = Wrappers.<PurchaseAftersaleLine>lambdaQuery()
                .in(PurchaseAftersaleLine::getSkuId, skuIdList)
                .eq(PurchaseAftersaleLine::getMainId, mainId);
        return baseMapper.selectList(wq);
    }

    @Override
    public List<PurchaseAftersaleLine> listByMainId(Integer mainId) {
        LambdaQueryWrapper<PurchaseAftersaleLine> wq = Wrappers.<PurchaseAftersaleLine>lambdaQuery()
                .eq(PurchaseAftersaleLine::getMainId, mainId);
        return baseMapper.selectList(wq);
    }

    @Override
    public List<PurchaseAftersaleLine> listbySkuIds(Set<Integer> skuIdList) {
        if (StringUtils.isEmpty(skuIdList)){
            return Collections.emptyList();
        }

        LambdaQueryWrapper<PurchaseAftersaleLine> wq = Wrappers.<PurchaseAftersaleLine>lambdaQuery()
                .in(PurchaseAftersaleLine::getSkuId, skuIdList);

        return baseMapper.selectList(wq);
    }

    @Override
    public PurchaseAftersaleLine findById(Integer id) {
        return baseMapper.selectById(id);
    }

    @Override
    public List<PurchaseAftersaleLine> listByMainIds(Set<Integer> afterSaleIds) {
        if (StringUtils.isEmpty(afterSaleIds)){
            return Collections.emptyList();
        }
        LambdaQueryWrapper<PurchaseAftersaleLine> wq = Wrappers.<PurchaseAftersaleLine>lambdaQuery()
                .in(PurchaseAftersaleLine::getMainId, afterSaleIds);
        return baseMapper.selectList(wq);
    }


}
