package com.seeease.flywheel_v4.web.infrastructure.dao.operations.repo;

import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.SupplierContacts;

import java.util.List;
import java.util.Set;

/**
 *
 * @author 西门 游
 * @version 1.0
 * @since 5/31/24 4:55 下午
 **/
public interface SupplierContactsRepository {


    /**
     * 批量提交
     * @param batch
     * @return 提交结果
     */
    boolean submitBatch(List<SupplierContacts> batch);

    /**
     * 批量删除
     * @param supplierId 供应商id
     * @return 删除结果
     */
    boolean delBySupplierId(Integer supplierId);

    /**
     * 列表查询
     * @param name 联系人姓名
     * @param phone 电话
     * @return
     */
    List<SupplierContacts> listByNameAndPhone(String name, String phone);

    /**
     * 列表查询
     * @param supplierIdList 供应商id列表
     * @return 列表数据
     */
    List<SupplierContacts> listBySupplierIds(Set<Integer> supplierIdList);

    /**
     * 删除
     * @param id 主键id
     * @return  删除结果
     */
    Boolean delById(Integer id);

    /**
     * 联系人创建
     *
     * @return 创建结果
     */
    Boolean submit(SupplierContacts contacts);

    /**
     * 查找
     * @param id 主键id
     * @return
     */
    SupplierContacts findById(Integer id);

    /**
     * 查询
     * @param buyerIdList
     * @return
     */
    List<SupplierContacts> listByIds(Set<Integer> buyerIdList);

    /**
     * 查询
     * @param key 姓名或者电话
     * @return
     */
    List<SupplierContacts> listByKey(String key);
}
