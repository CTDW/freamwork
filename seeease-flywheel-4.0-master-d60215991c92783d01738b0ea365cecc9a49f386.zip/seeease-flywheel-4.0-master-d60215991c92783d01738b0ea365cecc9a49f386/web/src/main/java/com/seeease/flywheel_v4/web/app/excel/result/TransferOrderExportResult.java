package com.seeease.flywheel_v4.web.app.excel.result;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.format.DateTimeFormat;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 9/11/24 5:00 下午
 **/
@Data
public class TransferOrderExportResult implements Serializable {


    @ExcelProperty("调拨单号")
    private String serialNo;

    @ExcelProperty("调拨类型")
    private String type;

    @ExcelProperty("状态")
    private String state;

    @ExcelProperty("调入方")
    private String toName;

    @ExcelProperty("调出方")
    private String fromName;

    @ExcelProperty("结算价合计")
    private String totalSettlePrice;


    @ExcelProperty("商品名称")
    private String goodsName;

    @ExcelProperty("品牌")
    private String brandName;

    @ExcelProperty("类目")
    private String categoryName;

    @ExcelProperty("入库参数")
    private String param;

    @ExcelProperty("唯一码")
    private String skuCode;

    @ExcelProperty("数量")
    private Integer count;

    @ExcelProperty("附件")
    private String annexe;

    @ExcelProperty("经营权")
    private String settlePrice;

    @ExcelProperty("调拨价")
    private String transferPrice;

    @ExcelProperty("最新结算价")
    private String newSettlePrice;

    @ExcelProperty("流程节点")
    private String nodeState;


    @ExcelProperty("订单来源")
    private String originName;

    @DateTimeFormat("yyyy-MM-dd HH:mm:ss")
    @ExcelProperty("创建时间")
    private Date createdTime;

    @ExcelProperty("创建人")
    private String createdBy;
}
