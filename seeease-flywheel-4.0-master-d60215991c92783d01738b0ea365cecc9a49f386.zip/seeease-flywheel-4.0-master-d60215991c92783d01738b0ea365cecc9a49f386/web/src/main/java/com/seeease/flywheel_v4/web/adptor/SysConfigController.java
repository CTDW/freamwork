package com.seeease.flywheel_v4.web.adptor;


import com.seeease.flywheel_v4.web.app.sys_config.request.*;
import com.seeease.flywheel_v4.web.app.sys_config.result.*;
import com.seeease.flywheel_v4.web.app.sys_config.service.BusinessUnitService;
import com.seeease.flywheel_v4.web.app.sys_config.service.SaleChannelService;
import com.seeease.flywheel_v4.web.infrastructure.config.IdentifyLogPrinter;
import com.seeease.springframework.PageResult;
import com.seeease.springframework.RequestValidGroup;
import com.seeease.springframework.SingleResponse;
import com.seeease.springframework.log.annotation.LogPrinter;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.validation.groups.Default;
import java.util.List;


/**
 * <p>系统配置</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 5/31/24 4:11下午
 **/
@RestController
@RequestMapping("/sys")
public class SysConfigController {

    @Resource
    private BusinessUnitService businessUnitService;
    @Resource
    private SaleChannelService saleChannelService;



    /**
     * 系统配置-通用类型业务单元创建
     *
     * @return 创建结果
     */
    @PostMapping("businessUnit/create")
    @LogPrinter(scenario = "系统配置-通用类型业务单元创建", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<Boolean> create(@Validated @RequestBody BusinessUnitSubmitRequest request) {

        return SingleResponse.of(businessUnitService.create(request));
    }

    /**
     * 系统配置-通用类型业务单元更新
     *
     * @return 更新结果
     */
    @PostMapping("businessUnit/update")
    @LogPrinter(scenario = "系统配置-通用类型业务单元更新", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<Boolean> update(@Validated({RequestValidGroup.Update.class, Default.class})
                                          @RequestBody BusinessUnitSubmitRequest request) {

        return SingleResponse.of(businessUnitService.update(request));
    }


    /**
     * 系统配置-通用类型业务单元分页查询
     *
     * @return 分页结果
     */
    @PostMapping("businessUnit/page")
    @LogPrinter(scenario = "系统配置-通用类型业务单元分页查询", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<PageResult<BusinessUnitPageResult>> page(
            @Validated @RequestBody BusinessUnitPageRequest request) {

        return SingleResponse.of(businessUnitService.page(request));
    }


    /**
     * 系统配置-业务单元列表查询
     *
     * @return 列表结果
     */
    @PostMapping("businessUnit/list")
    @LogPrinter(scenario = "系统配置-业务单元列表查询", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<List<BusinessUnitListResult>> list(
            @Validated @RequestBody BusinessUnitListRequest request) {

        return SingleResponse.of(businessUnitService.list(request));
    }


    /**
     * 系统配置-采购主体单元创建
     *
     * @return 创建结果
     */
    @PostMapping("purchase/businessUnit/create")
    @LogPrinter(scenario = "系统配置-采购主体单元创建", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<Boolean> purchaseCreate(
            @Validated @RequestBody PurchaseBusinessUnitSubmitRequest request) {

        return SingleResponse.of(businessUnitService.purchaseCreate(request));
    }

    /**
     * 系统配置-采购主体单元更新
     *
     * @return 更新结果
     */
    @PostMapping("purchase/businessUnit/update")
    @LogPrinter(scenario = "系统配置-采购主体单元更新", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<Boolean> purchaseUpdate(
            @Validated({RequestValidGroup.Update.class, Default.class})
            @RequestBody PurchaseBusinessUnitSubmitRequest request) {

        return SingleResponse.of(businessUnitService.purchaseUpdate(request));
    }

    /**
     * 系统配置-采购主体单元分页查询
     *
     * @return 分页结果
     */
    @PostMapping("purchase/businessUnit/page")
    @LogPrinter(scenario = "系统配置-采购主体单元分页查询", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<PageResult<PurchaseBusinessUnitPageResult>> purchasePage(
            @RequestBody PurchaseBusinessUnitPageRequest request) {

        return SingleResponse.of(businessUnitService.purchasePage(request));
    }


    /**
     * 系统配置-销售渠道创建
     *
     * @return 创建结果
     */
    @PostMapping("saleChannel/create")
    @LogPrinter(scenario = "系统配置-销售渠道创建", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<Boolean> saleChannelCreate(
            @RequestBody SaleChannelSubmitRequest request) {

        return SingleResponse.of(saleChannelService.create(request));
    }


    /**
     * 系统配置-销售渠道更新
     *
     * @return 更新结果
     */
    @PostMapping("saleChannel/update")
    @LogPrinter(scenario = "系统配置-销售渠道更新", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<Boolean> saleChannelUpdate(
            @Validated({RequestValidGroup.Update.class, Default.class})
            @RequestBody SaleChannelSubmitRequest request) {

        return SingleResponse.of(saleChannelService.update(request));
    }


    /**
     *系统配置- 销售渠道分页查询
     *
     * @return 分页结果
     */
    @PostMapping("saleChannel/page")
    @LogPrinter(scenario = "系统配置-销售渠道分页查询", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<PageResult<SaleChannelPageResult>> saleChannelPage(
            @RequestBody SaleChannelPageRequest request) {

        return SingleResponse.of(saleChannelService.page(request));
    }



}
