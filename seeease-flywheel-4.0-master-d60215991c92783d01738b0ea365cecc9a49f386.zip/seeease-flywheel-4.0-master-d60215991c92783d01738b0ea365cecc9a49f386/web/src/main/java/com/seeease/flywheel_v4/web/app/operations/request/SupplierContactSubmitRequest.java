package com.seeease.flywheel_v4.web.app.operations.request;

import com.seeease.springframework.RequestValidGroup;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;


@Data
public class SupplierContactSubmitRequest implements Serializable {
    /**
     * id
     */
    @NotNull(message = "id不能为空",groups = {RequestValidGroup.Update.class, RequestValidGroup.Deleted.class})
    private Integer id;
    /**
     * 供应商id
     */
    @NotNull(message = "供应商id不能为空",groups = Create.class)
    private Integer supplierId;
    /**
     * 联系人名称
     */
    @NotBlank(message = "联系人名称不能为空")
    private String name;
    /**
     * 联系人电话
     */
    @NotBlank(message = "联系人电话不能为空")
    private String phone;
    /**
     * 联系人银行
     */
    private String bank;
    /**
     * 联系人银行账号
     */
    private String account;
    /**
     * 联系人开户行
     */
    private String bankName;
    /**
     * 银行转账户名
     */
    private String accountName;



    public interface Create{}
}
