package com.seeease.flywheel_v4.web.app.purchase.result;

import lombok.Data;

import java.util.Date;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/4/24 6:00 下午
 **/
@Data
public class PurchaseDemandPageResult {
    /**
     * id
     */
    private Integer id;
    /**
     * spuId
     */
    private Integer spuId;
    /**
     * 编号
     */
    private String serialNo;
    /**
     * 商家
     */
    private String merchantName;
    /**
     * 状态
     */
    private Integer state;
    /**
     * 商品名称
     */
    private String goodsName;
    /**
     * 品牌
     */
    private String brand;
    /**
     * 类目
     */
    private String categoryName;
    /**
     * 类目id
     */
    private Integer categoryId;
    /**
     * 采购员id
     */
    private Integer assignedId;
    /**
     * 商家id
     */
    private Integer merchantId;
    /**
     * 数量
     */
    private Integer count;
    /**
     * 指定采购员
     */
    private String assignedName;
    /**
     * 备注
     */
    private String remark;
    /**
     * 创建时间
     */
    private Date createdTime;
}
