package com.seeease.flywheel_v4.web.app.purchase.service;

import com.seeease.flywheel_v4.web.app.purchase.request.PurchaseAftersaleCancelRequest;
import com.seeease.flywheel_v4.web.app.purchase.request.PurchaseAftersaleDetailRequest;
import com.seeease.flywheel_v4.web.app.purchase.request.PurchaseAftersalePageRequest;
import com.seeease.flywheel_v4.web.app.purchase.request.PurchaseReturnCreateRequest;
import com.seeease.flywheel_v4.web.app.purchase.result.PurchaseAftersaleDetailResult;
import com.seeease.flywheel_v4.web.app.purchase.result.PurchaseAftersalePageResult;
import com.seeease.springframework.PageResult;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/24/24 5:43 下午
 **/
public interface PurchaseAftersaleService {



    /**
     * 采购售后 -采购售后分页列表
     *
     * @return 分页结果
     */
    PageResult<PurchaseAftersalePageResult> page(PurchaseAftersalePageRequest request);

    /**
     * 采购售后 -采购售后详情
     *
     * @return 详情结果
     */
    PurchaseAftersaleDetailResult detail(PurchaseAftersaleDetailRequest request);

    /**
     * 采购售后 -采购售后取消
     *
     * @return 详情结果
     */
    Boolean cancel(PurchaseAftersaleCancelRequest request);

    /**
     * 退货创建
     * @param request
     * @return
     */
    Integer returnCreate(PurchaseReturnCreateRequest request);
}
