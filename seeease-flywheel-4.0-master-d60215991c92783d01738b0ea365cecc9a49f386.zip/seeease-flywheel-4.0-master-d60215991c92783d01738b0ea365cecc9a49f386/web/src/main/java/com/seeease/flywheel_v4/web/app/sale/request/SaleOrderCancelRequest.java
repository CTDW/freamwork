package com.seeease.flywheel_v4.web.app.sale.request;


import lombok.Data;

import javax.validation.constraints.NotNull;


@Data
public class SaleOrderCancelRequest {

    /**
     * 主键id
     */
    @NotNull(message = "销售单id不能为空")
    private Integer id;


}
