package com.seeease.flywheel_v4.web.app.wms.service;

import com.seeease.flywheel_v4.web.app.wms.request.*;
import com.seeease.flywheel_v4.web.app.wms.result.MerchantWmsDetailResult;
import com.seeease.flywheel_v4.web.app.wms.result.MerchantWmsPageResult;
import com.seeease.flywheel_v4.web.domain.wms.component.express.core.PrintResult;
import com.seeease.springframework.PageResult;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/20/24 11:46 上午
 **/
public interface MerchantWmsService {

    /**
     * 门店wms-出入库管理分页查询
     *
     * @return 分页结果
     */
    PageResult<MerchantWmsPageResult> page(MerchantWmsPageRequest request);

    /**
     * 门店wms-出库管理详情
     *
     * @return 详情结果
     */
    MerchantWmsDetailResult detail(MerchantWmsDetailRequest request);

    /**
     * 门店wms- 取消操作
     *
     * @return 取消结果
     */
    Boolean cancel(MerchantWmsCancelRequest request);
    /**
     * 门店wms-确认
     *
     * @return 操作结果
     */
    Boolean confirm(MerchantWmsConfirmRequest request);


    /**
     * wms-商家出库打印
     *
     * @return 打印结果
     */
    PrintResult merchantCkPrint(WmsMerchantCkPrintRequest request);
}

