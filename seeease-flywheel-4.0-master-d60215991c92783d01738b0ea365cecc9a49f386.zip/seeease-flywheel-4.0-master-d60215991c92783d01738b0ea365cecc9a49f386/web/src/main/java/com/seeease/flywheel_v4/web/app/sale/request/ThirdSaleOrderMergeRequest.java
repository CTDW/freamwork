package com.seeease.flywheel_v4.web.app.sale.request;


import lombok.Data;

import javax.validation.constraints.NotEmpty;
import java.util.Set;


@Data
public class ThirdSaleOrderMergeRequest{

    /**
     * id列表不能为空
     */
    @NotEmpty(message = "id列表不能为空")
    private Set<Integer> ids;

}
