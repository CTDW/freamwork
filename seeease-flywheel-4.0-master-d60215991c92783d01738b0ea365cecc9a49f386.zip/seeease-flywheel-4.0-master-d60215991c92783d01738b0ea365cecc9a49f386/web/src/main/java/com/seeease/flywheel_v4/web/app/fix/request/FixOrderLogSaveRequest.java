package com.seeease.flywheel_v4.web.app.fix.request;

import com.seeease.flywheel_v4.web.infrastructure.dao.fix.entity.FixOrderLog;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * @Description 维修中心-维修-日志 请求值
 * @Date 2024-10-2 20:20
 * @Author by hk
 */
@Data
public class FixOrderLogSaveRequest implements Serializable {

    @ApiModelProperty(value = "维修单号")
    private String orderNumber;

    @ApiModelProperty(value = "步骤")
    private String fixStep;

    @ApiModelProperty(value = "维修内容")
    private String fixContent;

    /**
     * 当前维修单状态 1：维修登记 2：待接修 3：维修中 4：抛光中 5：清洗中 6：师傅组装 7：质检中 " +
     * "8：待维修出库 9：送外维修 10：等配件 11：已完成 12:已取消
     */
    private Integer orderStatus;


    public  FixOrderLog toEntity(){
        FixOrderLog orderLog = new FixOrderLog();
        orderLog.setOrderNumber(orderNumber);
        orderLog.setFixStep(fixStep);
        orderLog.setFixContent(fixContent);
        orderLog.setOrderStatus(orderStatus);

        return orderLog;
    }
}
