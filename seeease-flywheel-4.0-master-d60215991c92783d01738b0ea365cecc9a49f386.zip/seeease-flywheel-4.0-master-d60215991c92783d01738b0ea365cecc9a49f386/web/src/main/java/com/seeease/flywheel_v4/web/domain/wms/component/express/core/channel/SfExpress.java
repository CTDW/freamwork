package com.seeease.flywheel_v4.web.domain.wms.component.express.core.channel;

import com.seeease.flywheel_v4.web.domain.wms.component.express.core.ExpressChannel;
import com.seeease.flywheel_v4.web.domain.wms.component.express.core.PlaceOrderDto;
import com.seeease.flywheel_v4.web.domain.wms.component.express.core.PlaceOrderResult;
import com.seeease.flywheel_v4.web.domain.wms.component.express.core.PrintResult;
import com.seeease.flywheel_v4.web.domain.wms.component.express.core.sf.SFExpressClient;
import com.seeease.flywheel_v4.web.domain.wms.component.express.core.sf.SFExpressConfig;
import com.seeease.flywheel_v4.web.domain.wms.component.express.core.sf.SfExpressCreateOrderRequest;
import com.seeease.flywheel_v4.web.domain.wms.component.express.core.sf.SfExpressCreateOrderResult;
import lombok.AllArgsConstructor;
import lombok.Getter;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

/**
 * <p>普通顺丰下单</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 9/20/24 5:01 下午
 **/
@Component
public class SfExpress implements ExpressChannel<PrintResult.SfPrintResult> {


    @Resource
    private SFExpressClient client;
    @Resource
    private SFExpressConfig sfExpressConfig;

    @Override
    public Channel getChannel() {
        return Channel.SF;
    }

    @Override
    public PlaceOrderResult placeOrder(PlaceOrderDto dto) {
        //step_1 构建收货人和发货人数据
        List<SfExpressCreateOrderRequest.ContactInfoListDTO> contactInfoListDTOList = Arrays.asList(
                SfExpressCreateOrderRequest.ContactInfoListDTO.builder()
                        .company(dto.getSpName())
                        .contactType(ContactType.SENDER.value)
                        .province(dto.getSpProvince())
                        .city(dto.getSpCity())
                        .county(dto.getSpArea())
                        .address(dto.getSpAddress())
                        .contact(dto.getSpName())
                        .mobile(dto.getSpPhone())
                        .build(),
                SfExpressCreateOrderRequest.ContactInfoListDTO.builder()
                        .company(dto.getName())
                        .contactType(ContactType.RECEIVER.value)
                        .province(dto.getProvince())
                        .city(dto.getCity())
                        .county(dto.getArea())
                        .address(dto.getAddress())
                        .contact(dto.getName())
                        .mobile(dto.getPhone())
                        .build());


        SfExpressCreateOrderRequest request = SfExpressCreateOrderRequest.builder()
                .orderId(dto.getBusinessNo())
                .language("zh-CN")
                //订单货物总重量（郑州空港海关必填）， 若为子母件必填， 单位千克， 精确到小数点后3位，如果提供此值， 必须>0 (子母件需>6)
                .totalWeight(2.0)
                //包裹数，一个包裹对应一个运单号；若包裹数大于1，则返回一个母运单号和N-1个子运单号
                .parcelQty(1)
//                //付款方式，支持以下值： 1:寄方付 2:收方付 3:第三方付
//                .payMethod(1)
//                //快件自取，支持以下值： 1：客户同意快件自取 0：客户不同意快件自取
//                .isOneselfPickup(1)
                //扩展属性
                .extraInfoList(Collections.emptyList())
                //2 顺丰标快 快件产品类别， 支持附录 《快件产品类别表》 的产品编码值，仅可使用与顺丰销售约定的快件产品
                .expressTypeId(2)
                .contactInfoList(contactInfoListDTOList)
                .cargoDetails(
                        dto.getProducts().stream()
                                .map(product -> SfExpressCreateOrderRequest.CargoDetailsDTO.builder()
                                        .name(StringUtils.join(product.getGoodsName()))
                                        .build())
                                .collect(Collectors.toList()))
                .build();

        SfExpressCreateOrderResult res;
        try {
            res = client.createOrder(request);
        }catch (Exception e){
            return PlaceOrderResult.builder()
                    .success(false)
                    .errMsg(e.getMessage())
                    .businessNo(dto.getBusinessNo())
                    .build();
        }

        return PlaceOrderResult.builder()
                .success(true)
                .businessNo(dto.getBusinessNo())
                .expressNumber(res.getMsgData().getWaybillNoInfoList().get(0).getWaybillNo())
                .build();
    }

    @Override
    public PrintResult.SfPrintResult printInfo(PlaceOrderResult placeOrderResult) {
        PrintResult.SfPrintResult ret = new PrintResult.SfPrintResult();
        ret.setExpressNoList(Collections.singletonList(placeOrderResult.getExpressNumber()));
        String productName = placeOrderResult.getDto()
                .getProducts()
                .stream()
                .map(PlaceOrderDto.Product::getGoodsName)
                .collect(Collectors.joining("\n"));
        ret.setProductName(productName);
        ret.setRemarks(placeOrderResult.getDto().getBillRemark());
        ret.setAccessToken(sfExpressConfig.getAccessToken().getAccessToken());
        ret.setTemplateCode(sfExpressConfig.getTemplateCode());
        return ret;
    }


    @Getter
    @AllArgsConstructor
    enum ContactType {
        /**
         * 发件方
         */
        SENDER(1),
        /**
         * 收件方
         */
        RECEIVER(2),
        ;
        int value;
    }

}
