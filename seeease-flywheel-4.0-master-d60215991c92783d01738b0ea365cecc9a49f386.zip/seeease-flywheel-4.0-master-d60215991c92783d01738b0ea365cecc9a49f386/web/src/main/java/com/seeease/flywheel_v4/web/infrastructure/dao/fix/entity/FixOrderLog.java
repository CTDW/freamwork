package com.seeease.flywheel_v4.web.infrastructure.dao.fix.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.seeease.seeeaseframework.mybatis.domain.BaseDomain;
import lombok.Data;
import lombok.EqualsAndHashCode;


/**
 * @Description 维修日志表
 * @Date 2024-10-2 20:55
 * @Author by hk
 */
@EqualsAndHashCode(callSuper = true)
@TableName(value = "v4_fix_order_log", autoResultMap = true)
@Data
public class FixOrderLog extends BaseDomain {

    @TableId(type = IdType.AUTO)
    private Long id;

    /**
     * 维修单号
     */
    private String orderNumber;

    /**
     * 当前维修单状态 1：维修登记 2：待接修 3：维修中 4：抛光中 5：清洗中 6：师傅组装 7：质检中 " +
     * "8：待维修出库 9：送外维修 10：等配件 11：已完成 12:已取消
     */
    private Integer orderStatus;

    /**
     * 步骤
     */
    private String fixStep;

    /**
     * 维修内容
     */
    private String fixContent;


}