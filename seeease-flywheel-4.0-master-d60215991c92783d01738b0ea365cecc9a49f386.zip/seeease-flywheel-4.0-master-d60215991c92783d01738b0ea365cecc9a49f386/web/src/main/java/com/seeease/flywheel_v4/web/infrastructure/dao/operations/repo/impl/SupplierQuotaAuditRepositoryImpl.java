package com.seeease.flywheel_v4.web.infrastructure.dao.operations.repo.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.seeease.flywheel_v4.web.app.operations.request.SupplierQuotaAuditPageRequest;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.SupplierQuotaAudit;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.enums.SupplierQuotaAuditStateEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.mapper.SupplierQuotaAuditMapper;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.repo.SupplierQuotaAuditRepository;
import com.seeease.springframework.utils.StringUtils;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Set;

/**
 * @author 西门 游
 * @version 1.0
 * @since 5/31/24 4:55 下午
 **/
@Repository
public class SupplierQuotaAuditRepositoryImpl extends ServiceImpl<SupplierQuotaAuditMapper, SupplierQuotaAudit>
        implements SupplierQuotaAuditRepository {


    @Override
    public Boolean submit(SupplierQuotaAudit log) {
        return saveOrUpdate(log);
    }

    @Override
    public SupplierQuotaAudit finById(Integer id) {
        return baseMapper.selectById(id);
    }

    @Override
    public Page<SupplierQuotaAudit> page(SupplierQuotaAuditPageRequest request, Set<Integer> supplierIds) {
        LambdaQueryWrapper<SupplierQuotaAudit> wq = Wrappers.<SupplierQuotaAudit>lambdaQuery()
                .in(StringUtils.isNotEmpty(supplierIds), SupplierQuotaAudit::getSupplierId, supplierIds)
                .eq(null != request.getState(), SupplierQuotaAudit::getState, request.getState())
                .eq(null != request.getOriginId(), SupplierQuotaAudit::getBuId, request.getOriginId())
                .orderByDesc(SupplierQuotaAudit::getId);

        Page<SupplierQuotaAudit> page = Page.of(request.getPage(), request.getLimit());
        baseMapper.selectPage(page, wq);
        return page;
    }

    @Override
    public List<SupplierQuotaAudit> listByIdAndState(Integer supplierId, SupplierQuotaAuditStateEnums state) {
        LambdaQueryWrapper<SupplierQuotaAudit> wq = Wrappers.<SupplierQuotaAudit>lambdaQuery()
                .eq(SupplierQuotaAudit::getSupplierId, supplierId)
                .eq(SupplierQuotaAudit::getState, state);

        return baseMapper.selectList(wq);
    }
}
