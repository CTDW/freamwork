package com.seeease.flywheel_v4.web.app.sale.request;


import com.fasterxml.jackson.annotation.JsonFormat;
import com.seeease.springframework.PageRequest;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Date;
import java.util.Set;


@EqualsAndHashCode(callSuper = true)
@Data
public class ThirdSaleOrderPageRequest extends PageRequest {
    /**
     * ids
     */
    private Set<Integer> ids;
    /**
     * 三方单号
     */
    private String thirdPartyNo;
    /**
     * 销售渠道类型
     */
    private Integer scType;
    /**
     * 商品名称
     */
    private String goodsName;
    /**
     * 货号
     */
    private String goodsCode;
    /**
     * 买家姓名
     */
    private String buyerName;
    /**
     * 买家电话
     */
    private String buyerPhone;
    /**
     * 状态
     */
    private Integer state;
    /**
     * 开始时间
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date startTime;
    /**
     * 结束时间
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date endTime;
    /**
     * 审核开始时间
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date auditStartTime;
    /**
     * 审核结束时间
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date auditEndTime;


}
