package com.seeease.flywheel_v4.web.app.sale.service;

import com.seeease.flywheel_v4.web.app.sale.request.*;
import com.seeease.flywheel_v4.web.app.sale.result.*;
import com.seeease.springframework.PageResult;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 8/2/24 2:04 下午
 **/
public interface SaleOrderService {
    /**
     * 销售-toc销售单创建
     *
     * @return 创建结果
     */
    Integer tocCreate(SaleOrderCreateRequest request);

    /**
     * 销售-toc销售单分页查询
     *
     * @return 分页结果
     */
    PageResult<ToCSaleOrderPageResult> tocPage(ToCSaleOrderPageRequest request);

    /**
     * 销售-toc销售单详情
     *
     * @return 详情结果
     */
    ToCSaleOrderDetailResult tocDetail(ToCSaleOrderDetailRequest request);

    /**
     * 销售-toB销售单创建
     *
     * @return 创建结果
     */
    Boolean tobCreate(SaleOrderCreateRequest request);
    /**
     * 销售-toB销售单分页查询
     *
     * @return 分页结果
     */
    PageResult<ToBSaleOrderPageResult> tobPage(ToBSaleOrderPageRequest request);

    /**
     * 销售-toB销售单详情
     *
     * @return 详情结果
     */
    ToBSaleOrderDetailResult tobDetail(ToBSaleOrderDetailRequest request);

    /**
     * 销售-toc销售修改回购政策
     *
     * @return 修改结果
     */
    Boolean policyUpdate(ToCSaleOrderLineBuyBackPolicyUpdateRequest request);

    /**
     * 销售-toc销售单取消
     *
     * @return 取消结果
     */
    Boolean tocCancel(SaleOrderCancelRequest request);

    /**
     * 销售-tob销售单取消
     *
     * @return 取消结果
     */
    Boolean tobCancel(SaleOrderCancelRequest request);

    /**
     * 销售-tob销售寄售模式确认寄售
     *
     * @return 操作结果
     */
    Boolean consignmentConfirm(ToBSaleConsignmentConfirmRequest request);
}
