package com.seeease.flywheel_v4.web.app.operations.request;

import com.seeease.springframework.PageRequest;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.validation.constraints.NotNull;


@EqualsAndHashCode(callSuper = true)
@Data
public class SupplierQuotaRequest extends PageRequest {


    /**
     * 联系人id
     */
    @NotNull(message = "联系人id不能为空")
    private Integer id;


}
