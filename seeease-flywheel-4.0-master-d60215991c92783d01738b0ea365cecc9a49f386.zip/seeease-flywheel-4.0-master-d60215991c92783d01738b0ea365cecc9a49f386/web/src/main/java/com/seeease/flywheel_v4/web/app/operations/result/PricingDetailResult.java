package com.seeease.flywheel_v4.web.app.operations.result;

import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.entity.PurchaseOrder;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.entity.PurchaseOrderLine;
import com.seeease.goods.rpc.request.SkuAnnexeRpcResult;
import com.seeease.goods.rpc.result.ProductParamRpcResult;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

@Data
public class PricingDetailResult implements Serializable {
    /**
     * 定价管理id
     */
    private Integer id;

    /**
     * 声明周期
     */
    private List<PricingLifeCycle> lifeCycle;
    /**
     * 供应商名称
     */
    private String supplierName;
    /**
     * 供应商地址
     */
    private String supplierAddress;
    /**
     * 供应商类型
     */
    private Integer supplierType;
    /**
     * 联系人名称
     */
    private String contactName;
    /**
     * 采购单号
     */
    private String serialNo;
    /**
     * 创建人
     */
    private String createdBy;
    /**
     * 这里取sku身上的商家id,因为采购单上的是快照
     */
    private Integer merchantId;
    /**
     * 商家名称
     */
    private String merchantName;
    /**
     * 采购单的打款方式
     * {@link PurchaseOrder#getPayType()}
     */
    private Integer payType;
    /**
     * {@link PurchaseOrder#getPayRatio()}
     */
    private BigDecimal payRatio;
    /**
     * 申请打款单单号
     */
    private String fpsSerialNo;
    /**
     * 创建时间
     */
    private Date createdTime;
    /**
     * 采购单上的图片
     * {@link PurchaseOrder#getImages()}
     */
    private List<String> images;
    /**
     * 采购单上的备注
     */
    private String remark;
    /**
     * 商品名称
     */
    private String goodsName;
    /**
     * 类目
     */
    private String categoryName;
    /**
     * 品牌
     */
    private String brandName;
    /**
     * 采购价
     */
    private BigDecimal purchasePrice;
    /**
     * 公价
     */
    private BigDecimal pubPrice;
    /**
     * 公价
     */
    private BigDecimal newSettlePrice;
    /**
     * 维修价格
     */
    private BigDecimal repairPrice;
    /**
     * 总成本
     * todo 计算方式
     */
    private BigDecimal totalPrice;
    /**
     * 采购单行数量
     * {@link PurchaseOrderLine#getCount()}
     */
    private Integer count;
    /**
     * sku参数列表
     */
    private List<ProductParamRpcResult> skuParams;
    /**
     * 附件
     */
    private List<SkuAnnexeRpcResult> annexe;
    /**
     * 唯一码
     */
    private String skuCode;

    /**
     * 图片
     */
    private String spuImage;

    /**
     * 同行价
     */
    private BigDecimal tobPrice;
    /**
     * 零售价
     */
    private BigDecimal tocPrice;
    /**
     * 结算价
     */
    private BigDecimal settlePrice;
    /**
     * 收货价
     */
    private BigDecimal receiptPrice;

    /**
     * 销售渠道定位
     * {@link com.seeease.goods.rpc.enums.SkuSellWayEnums}
     */
    private Integer sellWay;
    /**
     * 自主经营类型
     * {@link com.seeease.goods.rpc.enums.SkuRunTypeEnums}
     */
    private Integer runType;

    /**
     * 定价单状态
     * {@link com.seeease.flywheel_v4.web.infrastructure.dao.operations.enums.PricingStateEnums}
     */
    private Integer state;

    /**
     * 采购类型
     */
    private Integer purchaseType;

    /**
     * 采购主体
     */
    private String purchaseSubjectName;





    @Data
    public static class PricingLifeCycle {
        /**
         * 创建人
         */
        private String createdBy;
        /**
         * 创建时间
         */
        private Date createdTime;
        /**
         * 描述
         */
        private String desc;


    }


}
