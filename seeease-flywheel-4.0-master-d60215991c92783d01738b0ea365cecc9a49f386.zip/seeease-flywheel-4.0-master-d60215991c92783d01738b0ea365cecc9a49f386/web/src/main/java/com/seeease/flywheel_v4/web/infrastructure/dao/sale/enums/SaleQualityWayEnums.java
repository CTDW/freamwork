package com.seeease.flywheel_v4.web.infrastructure.dao.sale.enums;

import com.baomidou.mybatisplus.annotation.IEnum;
import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * <p>销售是否质检</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/6/24 3:06 下午
 **/
@Getter
@AllArgsConstructor
public enum SaleQualityWayEnums implements IEnum<Integer> {
    BZJ(1,"不质检"),
    XS_ZJ(2,"线上质检"),
    XX_ZJ(3,"线下质检")
    ;

    private Integer value;
    private String desc;

}
