package com.seeease.flywheel_v4.web.app.wms.service;

import com.seeease.flywheel_v4.web.app.wms.request.*;
import com.seeease.flywheel_v4.web.app.wms.result.WmsCkPageResult;
import com.seeease.flywheel_v4.web.app.wms.result.WmsRfidCkListResult;
import com.seeease.flywheel_v4.web.domain.wms.component.express.core.PrintResult;
import com.seeease.springframework.PageResult;

import java.util.List;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/20/24 11:46 上午
 **/
public interface WmsCkService {


    /**
     * wms-出库管理分页查询
     *
     * @return 分页结果
     */
    PageResult<WmsCkPageResult> page(WmsCkPageRequest request);

    /**
     * wms-出库集单操作
     *
     * @return 集单结果
     */
    Boolean jd(WmsJdRequest request);

    /**
     * wms-出库取消
     *
     * @return 取消结果
     */
    Boolean cancel(WmsCkCancelRequest request);

    /**
     * wms-打单回滚到集单状态
     *
     * @return 操作结果
     */
    Boolean rollBack(WmsCkRollbackRequest request);

    /**
     * wms-出库上传快递单号
     *
     * @return 操作结果
     */
    Boolean uploadExpress(WmsCkUploadExpressRequest request);

    /**
     * wms-出库单出库
     *
     * @return 操作结果
     */
    Boolean ck(WmsCkRequest request);


    /**
     * wms-出库管理出库打印
     *
     * @return 打印结果
     */
    PrintResult ckPrint(WmsCkPrintRequest request);


    /**
     * wms-出库换表
     *
     * @return 分页结果
     */
    Boolean ckReplace(WmsCkReplaceRequest request);

    /**
     * wms-rfid待出库列表
     * @return
     */
    List<WmsRfidCkListResult> rfidCkList();
}
