package com.seeease.flywheel_v4.web.app.purchase.service.impl;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.google.common.collect.Sets;
import com.seeease.flywheel_v4.client.enums.BusinessUnitTypeEnums;
import com.seeease.flywheel_v4.web.app.purchase.request.*;
import com.seeease.flywheel_v4.web.app.purchase.result.PurchaseOrderDetailResult;
import com.seeease.flywheel_v4.web.app.purchase.result.PurchaseOrderPageResult;
import com.seeease.flywheel_v4.web.app.purchase.service.PurchaseOrderService;
import com.seeease.flywheel_v4.web.domain.purchase.mapping.PurchaseOrderLineMapping;
import com.seeease.flywheel_v4.web.domain.purchase.mapping.PurchaseOrderMapping;
import com.seeease.flywheel_v4.web.domain.wms.observer.base.WmsSubject;
import com.seeease.flywheel_v4.web.infrastructure.dao.RepositoryFactory;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.Supplier;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.SupplierContacts;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.entity.PurchaseDemand;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.entity.PurchaseOrder;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.entity.PurchaseOrderLine;
import com.seeease.flywheel_v4.client.enums.PurchaseTypeEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.enums.PurchaseOrderStateEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.enums.PurchasePayTypeEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.entity.SaleOrder;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.entity.SaleOrderLine;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.entity.obj.BuyBackPolicyObj;
import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.entity.SysBusinessUnit;
import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.entity.SysUser;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.MerchantWms;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.MerchantWmsLine;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.WmsRk;
import com.seeease.flywheel_v4.web.infrastructure.listener.purchase.FinishStateListener;
import com.seeease.flywheel_v4.web.infrastructure.listener.purchase.StartingStateListener;
import com.seeease.goods.rpc.SkuFacade;
import com.seeease.goods.rpc.enums.SkuNodeStateEnums;
import com.seeease.goods.rpc.request.PurchaseSkuCancelRequest;
import com.seeease.goods.rpc.request.PurchaseSkuCreateRpcRequest;
import com.seeease.goods.rpc.request.SkuRpcRequest;
import com.seeease.goods.rpc.result.SkuCreateRpcResult;
import com.seeease.goods.rpc.result.SkuRpcResult;
import com.seeease.seeeaseframework.mybatis.domain.WhetherEnum;
import com.seeease.springframework.PageResult;
import com.seeease.springframework.context.UserContext;
import com.seeease.springframework.exception.ValidationUtil;
import com.seeease.springframework.utils.MultiUtils;
import com.seeease.springframework.utils.StringUtils;
import io.seata.spring.annotation.GlobalTransactional;
import org.apache.commons.lang.time.DateUtils;
import org.apache.dubbo.config.annotation.DubboReference;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * <p>采购订单</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/6/24 4:05 下午
 **/
@Service
public class PurchaseOrderServiceImpl implements PurchaseOrderService {
    @DubboReference(check = false, version = "1.0.0")
    private SkuFacade skuFacade;
    @Resource
    private RepositoryFactory repositoryFactory;
    @Resource
    private ApplicationEventPublisher publisher;
    @Resource
    private FinishStateListener stateListener;
    @Resource
    private WmsSubject wmsSubject;


    /**
     * 效验采购单创建参数
     */
    private void checkCreateParam(PurchaseOrderSubmitRequest request) {


        Set<Integer> buIdList = Sets.newHashSet(
                request.getStoreId(),
                request.getPurchaseSubjectId(),
                request.getPricerId());
        Map<Integer, BusinessUnitTypeEnums> buMap = MultiUtils.toMap(
                repositoryFactory.getBusinessUnitRepository().listByIds(buIdList),
                SysBusinessUnit::getId,
                SysBusinessUnit::getType
        );
        ValidationUtil.isTrue(
                null != buMap.get(request.getStoreId()) &&
                        buMap.get(request.getStoreId()) == BusinessUnitTypeEnums.WAREHOUSE ||
                        buMap.get(request.getStoreId()) == BusinessUnitTypeEnums.MERCHANT,
                "仓库id非法"
        );
        ValidationUtil.isTrue(
                null != buMap.get(request.getPurchaseSubjectId()) &&
                        buMap.get(request.getPurchaseSubjectId()) == BusinessUnitTypeEnums.PURCHASE,
                "采购主体id非法"
        );
        ValidationUtil.isTrue(
                null != buMap.get(request.getPricerId()) &&
                        buMap.get(request.getPricerId()) == BusinessUnitTypeEnums.PRICING,
                "定价方id非法"
        );

        ArrayList<String> checker = new ArrayList<>();
        for (PurchaseOrderSubmitRequest.Sku sku : request.getSkuList()
        ) {
            if (StringUtils.isNotEmpty(sku.getSkuCode())) {
                String skuCode = sku.getSkuCode();
                ValidationUtil.isTrue(!checker.contains(skuCode), "表身号:" + skuCode + "重复");
                checker.add(skuCode);
            }
        }


    }

    @GlobalTransactional
    @Override
    public Integer create(PurchaseOrderSubmitRequest request) {

        this.checkCreateParam(request);

        BigDecimal diff = null; //差额
        //step_1获取回购销售单号
        String saleSerialNo = null;
        SaleOrder saleOrder = null;
        //回购类型处理
        if (null != request.getSellId()) {
            saleOrder = repositoryFactory.getSaleOrderRepository().findByIdOrSerialNo(request.getSellId(), null);
            saleSerialNo = saleOrder.getSerialNo();
            //回购类型的采购需要做特殊处理
            if (Objects.equals(request.getType(), PurchaseTypeEnums.GR_HG.getValue()) ||
                    Objects.equals(request.getType(), PurchaseTypeEnums.GR_HGZH.getValue())) {

                Map<Integer, PurchaseOrderSubmitRequest.Sku> paramSkuMap = MultiUtils.toMap(
                        request.getSkuList(),
                        PurchaseOrderSubmitRequest.Sku::getLineId
                );

                List<SaleOrderLine> saleLineList = repositoryFactory.getSaleOrderLineRepository()
                        .listByIds(paramSkuMap.keySet());

                Date now = new Date();
                for (SaleOrderLine line : saleLineList) {
                    //step_1 计算采购价 与回购价
                    PurchaseOrderSubmitRequest.Sku paramSku = paramSkuMap.get(line.getId());
                    ValidationUtil.notNull(paramSku.getPolicyIndex(), "回购政策下标不能为空");
                    BuyBackPolicyObj policy = line.getPolicies().get(paramSku.getPolicyIndex());
                    //计算最后的回购日期
                    Date latestDate = DateUtils.addMonths(saleOrder.getFinishTime(), policy.getMonth());
                    ValidationUtil.isTrue(latestDate.after(now), "sku编码:" + paramSku.getSkuCode() + "超出当前选择回购日期");

                    BigDecimal discount = policy.getDiscount().multiply(new BigDecimal("0.1"));
                    //采购价等于销售价 X 折扣 - 维修费 - 表带根换费
                    BigDecimal buyBackPrice = line.getDealPrice().multiply(discount);
                    BigDecimal newPurchasePrice = buyBackPrice.subtract(paramSku.getRepairPrice()).subtract(paramSku.getStrapPrice());

                    paramSku.setBuybackPrice(buyBackPrice);
                    paramSku.setPurchasePrice(newPurchasePrice);

                    //step_2 修改销售单行状态
                    line.setNodeState(SkuNodeStateEnums.YHG);
                }
                repositoryFactory.getSaleOrderLineRepository().submitBatch(saleLineList);
            }
        }

        //step_2 计算采购单金额和数量
        Integer totalCount = 0; //采购单总数量
        BigDecimal totalPrice = BigDecimal.ZERO; //采购单总金额

        for (PurchaseOrderSubmitRequest.Sku sku : request.getSkuList()) {
            totalCount += sku.getCount();
            totalPrice = totalPrice.add(sku.getPurchasePrice().multiply(new BigDecimal(sku.getCount())));
        }

        //step_3 置换销售单号
        String newSaleSerialNo = null;
        SaleOrder newSaleOrder = null;
        if (null != request.getNewSellId()) {
             newSaleOrder = repositoryFactory.getSaleOrderRepository()
                    .findByIdOrSerialNo(request.getNewSellId(), null);
            newSaleSerialNo = newSaleOrder.getSerialNo();
        }


        // step_3.1 计算差额
        if (Objects.equals(request.getType(), PurchaseTypeEnums.GR_HGZH.getValue()) && null != newSaleOrder) {
            if (Objects.equals(request.getPayType(), PurchasePayTypeEnums.CE.getValue())) {
                diff = totalPrice.subtract(newSaleOrder.getTotalAmount());
            } else {
                diff = totalPrice;
            }
        }
        if (Objects.equals(request.getType(), PurchaseTypeEnums.GR_HSZH.getValue()) && null != saleOrder) {
            if (Objects.equals(request.getPayType(), PurchasePayTypeEnums.CE.getValue())) {
                diff = totalPrice.subtract(saleOrder.getTotalAmount());
            } else {
                diff = totalPrice;
            }
        }

        //step 3.2 创建采购单
        PurchaseOrder purchaseOrder = PurchaseOrderMapping.INSTANCE.toEntity(
                request,
                totalCount,
                totalPrice,
                saleSerialNo,
                newSaleSerialNo,
                diff
        );
        repositoryFactory.getPurchaseOrderRepository()
                .submit(purchaseOrder);


        //step_4  sku创建
        PurchaseSkuCreateRpcRequest rpcRequest = PurchaseOrderMapping.INSTANCE.toSkuRpcCreateRequest(
                request,
                purchaseOrder.getBuId(),
                purchaseOrder.getSerialNo(),
                Objects.equals(request.getType(), PurchaseTypeEnums.TH_CG_DJ.getValue()) ? WhetherEnum.YES : WhetherEnum.NO
        );
        List<SkuCreateRpcResult> skuList = skuFacade.create(rpcRequest);


        //step_5 创建采购单行
        List<PurchaseOrderLine> lineList = MultiUtils.toList(
                skuList,
                sku -> PurchaseOrderLineMapping.INSTANCE.toEntity(sku, purchaseOrder.getId())
        );

        repositoryFactory.getPurchaseOrderLineRepository().submitBatch(lineList);

        //step_6 关联采购需求单
        if (StringUtils.isNotEmpty(request.getDemandIdList())) {
            Boolean bindRet = repositoryFactory.getPurchaseDemandRepository()
                    .bindPurchaseOrder(
                            request.getDemandIdList(),
                            purchaseOrder.getId(),
                            purchaseOrder.getSerialNo()
                    );
            ValidationUtil.isTrue(bindRet, "关联采购需求单失败");
        }


        return purchaseOrder.getId();
    }

    @Override
    public PageResult<PurchaseOrderPageResult> page(PurchaseOrderPageRequest request) {
        Set<Integer> purchaseIdList = Sets.newHashSet();
        //采购单行查询
        if (null != request.getNodeState()) {
            List<PurchaseOrderLine> lineList = repositoryFactory.getPurchaseOrderLineRepository()
                    .listByNodeState(request.getNodeState());

            Set<Integer> partPurchaseIdList = MultiUtils.toSet(lineList, PurchaseOrderLine::getPurchaseId);

            if (partPurchaseIdList.isEmpty()) {
                return PageResult.buildEmpty();
            }

            purchaseIdList.addAll(partPurchaseIdList);

        }

        //sku数据查询
        if (StringUtils.isNotEmpty(request.getSkuCode())) {

            SkuRpcRequest skuRpcRequest = new SkuRpcRequest();
            skuRpcRequest.setSkuCode(request.getSkuCode());
            Set<Integer> skuIdList = MultiUtils.toSet(
                    skuFacade.list(skuRpcRequest),
                    SkuRpcResult::getId
            );

            if (skuIdList.isEmpty()) {
                return PageResult.buildEmpty();
            }

            List<PurchaseOrderLine> lineList = repositoryFactory.getPurchaseOrderLineRepository()
                    .listBySkuIds(skuIdList);
            Set<Integer> partPurchaseIdList = MultiUtils.toSet(lineList, PurchaseOrderLine::getPurchaseId);

            if (partPurchaseIdList.isEmpty()) {
                return PageResult.buildEmpty();
            }
            purchaseIdList.addAll(partPurchaseIdList);
        }


        //分页查询主表
        Integer buId = UserContext.getUser().getStore().getId();
        SysBusinessUnit bu = repositoryFactory.getBusinessUnitRepository().findById(buId);
        if (bu.getType() != BusinessUnitTypeEnums.PLATFORM) {
            request.setBuId(UserContext.getUser().getStore().getId());
        }

        Page<PurchaseOrder> page = repositoryFactory.getPurchaseOrderRepository()
                .page(request, purchaseIdList);


        if (page.getRecords().isEmpty()) {
            return PageResult.buildEmpty();
        }


        //供应商
        Set<Integer> supplierIdList = MultiUtils.toSet(page.getRecords(), PurchaseOrder::getSupplierId);
        Map<Integer, String> supplierMap = MultiUtils.toMap(
                repositoryFactory.getSupplierRepository().listByIds(supplierIdList),
                Supplier::getId,
                Supplier::getName
        );


        //实际采购人
        Set<Integer> buyerIds = MultiUtils.toSet(page.getRecords(), PurchaseOrder::getBuyerId);
        Map<Integer, String> buyerMap = MultiUtils.toMap(
                repositoryFactory.getUserRepository().listByIds(buyerIds),
                SysUser::getId,
                SysUser::getName
        );


        //商家名称
        Set<Integer> merchantIds = MultiUtils.toSet(page.getRecords(), PurchaseOrder::getMerchantId);
        Map<Integer, String> merchantMap = MultiUtils.toMap(
                repositoryFactory.getBusinessUnitRepository().listByIds(merchantIds),
                SysBusinessUnit::getId,
                SysBusinessUnit::getName
        );

        //采购主体名称
        Set<Integer> purchaseSubjectIds = MultiUtils.toSet(page.getRecords(), PurchaseOrder::getPurchaseSubjectId);
        Map<Integer, String> purchaseSubjectMap = MultiUtils.toMap(
                repositoryFactory.getBusinessUnitRepository().listByIds(purchaseSubjectIds),
                SysBusinessUnit::getId,
                SysBusinessUnit::getName
        );

        //入库仓库
        Set<Integer> storeIds = MultiUtils.toSet(page.getRecords(), PurchaseOrder::getStoreId);
        Map<Integer, String> storeMap = MultiUtils.toMap(
                repositoryFactory.getBusinessUnitRepository().listByIds(storeIds),
                SysBusinessUnit::getId,
                SysBusinessUnit::getName
        );


        //组合
        List<PurchaseOrderPageResult> ret = MultiUtils.toList(
                page.getRecords(),
                order -> {
                    String supplierName = supplierMap.get(order.getSupplierId());
                    String buyerName = buyerMap.get(order.getBuyerId());
                    String merchantName = merchantMap.get(order.getMerchantId());
                    String purchaseSubjectName = purchaseSubjectMap.get(order.getPurchaseSubjectId());
                    String storeName = storeMap.get(order.getStoreId());

                    return PurchaseOrderMapping.INSTANCE.toPageResult(
                            order,
                            supplierName,
                            buyerName,
                            merchantName,
                            purchaseSubjectName,
                            storeName
                    );
                }
        );

        return PageResult.<PurchaseOrderPageResult>builder()
                .result(ret)
                .totalCount(page.getTotal())
                .totalPage(page.getPages())
                .build();
    }

    @Override
    public PurchaseOrderDetailResult details(PurchaseOrderDetailRequest request) {
        PurchaseOrder purchaseOrder = repositoryFactory.getPurchaseOrderRepository()
                .findByIdOrSerialNo(request.getId(), request.getSerialNo());
        ValidationUtil.notNull(purchaseOrder, "采购单id错误");

        //采购行
        Map<Integer, PurchaseOrderLine> lineMap = MultiUtils.toMap(
                repositoryFactory.getPurchaseOrderLineRepository().listByPurchaseId(purchaseOrder.getId()),
                PurchaseOrderLine::getSkuId,
                Function.identity()
        );
        Set<Integer> skuIdList = MultiUtils.toSet(lineMap.values(), PurchaseOrderLine::getSkuId);
        SkuRpcRequest skuRpcRequest = new SkuRpcRequest();
        skuRpcRequest.setIdList(skuIdList);
        List<SkuRpcResult> rpcSkuList = skuFacade.list(skuRpcRequest);

        //sku数据组
        List<PurchaseOrderDetailResult.Sku> skuList = MultiUtils.toList(
                rpcSkuList,
                sku -> PurchaseOrderLineMapping.INSTANCE.toSkuResult(sku, lineMap.get(sku.getId()))
        );

        //供应商
        Supplier supplier = repositoryFactory.getSupplierRepository()
                .findById(purchaseOrder.getSupplierId());
        //联系人
        SupplierContacts contacts = repositoryFactory.getSupplierContactsRepository()
                .findById(purchaseOrder.getSupplierContactId());

        //业务单元数据
        Set<Integer> buIdList = Sets.newHashSet(
                purchaseOrder.getStoreId(),
                purchaseOrder.getPurchaseSubjectId(),
                purchaseOrder.getMerchantId(),
                purchaseOrder.getPricerId()
        );
        Map<Integer, String> buMap = MultiUtils.toMap(
                repositoryFactory.getBusinessUnitRepository().listByIds(buIdList),
                SysBusinessUnit::getId,
                SysBusinessUnit::getName
        );

        //采购需求单数据
        String demandSerial = repositoryFactory.getPurchaseDemandRepository()
                .listByPurchaseId(purchaseOrder.getId())
                .stream()
                .map(PurchaseDemand::getSerialNo)
                .collect(Collectors.joining(","));


        //采购人数据
        SysUser buyer = repositoryFactory.getUserRepository().findById(purchaseOrder.getBuyerId());


        SysBusinessUnit bu = repositoryFactory.getBusinessUnitRepository().findById(purchaseOrder.getStoreId());
        boolean pushToStore = bu.getType() == BusinessUnitTypeEnums.WAREHOUSE;


        return PurchaseOrderMapping.INSTANCE.toDetailResult(
                purchaseOrder,
                pushToStore,
                supplier,
                contacts,
                buMap.get(purchaseOrder.getStoreId()),
                buMap.get(purchaseOrder.getPurchaseSubjectId()),
                buMap.get(purchaseOrder.getMerchantId()),
                buMap.get(purchaseOrder.getPricerId()),
                demandSerial,
                skuList,
                buyer
        );
    }

    @Transactional
    @Override
    public Boolean uploadExpress(PurchaseOrderExpressUploadRequest request) {
        PurchaseOrder purchaseOrder = repositoryFactory.getPurchaseOrderRepository().findById(request.getId());
        ValidationUtil.notNull(purchaseOrder, "采购id错误");
        purchaseOrder.setExpressNo(request.getExpressNo());

        ValidationUtil.isTrue(
                repositoryFactory.getPurchaseOrderRepository().submit(purchaseOrder),
                "绑定快递单号失败"
        );

        //采购单状态变更推送
        publisher.publishEvent(new StartingStateListener.Event(this, purchaseOrder.getId()));
        return true;
    }


    @GlobalTransactional
    @Override
    public Boolean cancel(PurchaseOrderCancelRequest request) {
        PurchaseOrder order = repositoryFactory.getPurchaseOrderRepository().findById(request.getId());
        ValidationUtil.notNull(order, "订单不存在");


        //只能够取消采购在途状态的行商品
        List<PurchaseOrderLine> lineList = repositoryFactory.getPurchaseOrderLineRepository()
                .listByPurchaseId(order.getId())
                .stream()
                .filter(l -> l.getNodeState() == SkuNodeStateEnums.CG_ZT || l.getNodeState() == SkuNodeStateEnums.DSH)
                .collect(Collectors.toList());

        ValidationUtil.isTrue(!lineList.isEmpty(), "不存在可以取消的sku");


        //step_0 尝试更新回购销售单行状态
        if (StringUtils.isNotEmpty(order.getSaleSerialNo())) {
            SaleOrder saleOrder = repositoryFactory.getSaleOrderRepository().findByIdOrSerialNo(null, order.getSaleSerialNo());
            List<SaleOrderLine> saleLineList = repositoryFactory
                    .getSaleOrderLineRepository()
                    .listByMainId(saleOrder.getId())
                    .stream()
                    .filter(line -> line.getNodeState() == SkuNodeStateEnums.YHG)
                    .peek(line -> line.setNodeState(SkuNodeStateEnums.YCK))
                    .collect(Collectors.toList());

            repositoryFactory.getSaleOrderLineRepository().submitBatch(saleLineList);
        }


        //step_1 更新采购单行状态
        Set<Integer> lineIds = MultiUtils.toSet(lineList, PurchaseOrderLine::getId);
        repositoryFactory.getPurchaseOrderLineRepository().updateStateByIds(
                lineIds,
                SkuNodeStateEnums.QX,
                WhetherEnum.YES
        );

        //step_2 修改wms状态
        Set<Integer> skuIdList = MultiUtils.toSet(lineList, PurchaseOrderLine::getSkuId);
        if (order.getState() != PurchaseOrderStateEnums.WAIT_STAR) {

            SysBusinessUnit bu = repositoryFactory.getBusinessUnitRepository().findById(order.getStoreId());
            boolean pushToStore = bu.getType() == BusinessUnitTypeEnums.WAREHOUSE;
            if (pushToStore) {
                List<WmsRk> wmsCkList = repositoryFactory.getWmsRkRepository()
                        .list(skuIdList, order.getSerialNo(), null)
                        .stream()
                        .filter(rk -> skuIdList.contains(rk.getSkuId()))
                        .peek(rk -> rk.setNodeState(SkuNodeStateEnums.QX)).collect(Collectors.toList());
                wmsSubject.rkDateSubmit(wmsCkList);
            } else {

                MerchantWms merchantWms = repositoryFactory.getMerchantWmsRepository()
                        .listBySerialNo(order.getSerialNo())
                        .get(0);

                List<MerchantWmsLine> ckList = repositoryFactory.getMerchantWmsLineRepository().listByMainId(merchantWms.getId())
                        .stream()
                        .filter(ck -> ck.getNodeState() == SkuNodeStateEnums.DRK)
                        .peek(ck -> {
                            ck.setNodeState(SkuNodeStateEnums.QX);
                            ck.setEndState(WhetherEnum.YES);
                        })
                        .collect(Collectors.toList());

                if (StringUtils.isNotEmpty(ckList)) {
                    wmsSubject.merchantWmsDataSubmit(merchantWms, ckList);
                }
            }
        }


        //step_3 调用sku取消接口
        PurchaseSkuCancelRequest rpcRequest = new PurchaseSkuCancelRequest();
        rpcRequest.setSerialNo(order.getSerialNo());
        rpcRequest.setIdList(skuIdList);
        skuFacade.cancel(rpcRequest);


        //尝试采购单状态变更
        stateListener.onEvent(new FinishStateListener.Event(this, order.getId()));

        return true;
    }
}
