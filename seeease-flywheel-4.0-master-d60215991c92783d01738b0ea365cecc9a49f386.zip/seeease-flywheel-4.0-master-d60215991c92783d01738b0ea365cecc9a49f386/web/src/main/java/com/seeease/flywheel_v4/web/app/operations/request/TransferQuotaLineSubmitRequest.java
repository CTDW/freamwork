package com.seeease.flywheel_v4.web.app.operations.request;

import lombok.Data;

import javax.validation.constraints.NotNull;
import java.math.BigDecimal;


@Data
public class TransferQuotaLineSubmitRequest {
    /**
     * 类目id
     */
    @NotNull(message = "类目id不能为空")
    private Integer categoryId;
    /**
     * 品牌id
     */
    @NotNull(message = "品牌id不能为空")
    private Integer brandId;
    /**
     * 控制的额度
     */
    @NotNull(message = "控制的额度不能为空")
    private BigDecimal quota;

}
