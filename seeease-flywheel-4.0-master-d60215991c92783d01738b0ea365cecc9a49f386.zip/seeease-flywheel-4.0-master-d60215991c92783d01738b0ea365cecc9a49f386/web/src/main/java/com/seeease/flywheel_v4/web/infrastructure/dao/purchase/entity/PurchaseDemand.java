package com.seeease.flywheel_v4.web.infrastructure.dao.purchase.entity;

import com.baomidou.mybatisplus.annotation.*;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.enums.PurchaseDemandStateEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.enums.SupplierTypeEnums;
import com.seeease.seeeaseframework.mybatis.domain.BaseDomain;
import com.seeease.seeeaseframework.mybatis.transitionstate.ITransitionStateEnum;
import com.seeease.seeeaseframework.mybatis.transitionstate.TransitionState;
import com.seeease.seeeaseframework.mybatis.transitionstate.TransitionStateEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Date;

/**
 * 采购需求
 */
@EqualsAndHashCode(callSuper = true)
@TableName(value = "v4_purchase_demand", autoResultMap = true)
@Data
public class PurchaseDemand extends BaseDomain implements TransitionStateEntity {
    @TableId(type = IdType.AUTO)
    private Integer id;
    /**
     * 采购编码
     */
    private String serialNo;
    /**
     * 状态
     */
    @TransitionState
    private PurchaseDemandStateEnums state;
    /**
     * 指定采购人id
     */
    private Integer assignedId;
    /**
     * spuId
     */
    private Integer spuId;
    /**
     * 需求数量
     */
    private Integer count;
    /**
     * 采购单id
     */
    private Integer purchaseId;
    /**
     * 采购单编码
     */
    private String purchaseSerialNo;
    /**
     * 商家单元id
     */
    private Integer merchantId;

    /**
     * 备注说明
     */
    private String remark;

    /**
     * 取消时间
     */
    private Date cancelTime;
    /**
     * 确认时间
     */
    private Date confirmTime;

    @TableField(exist = false)
    private ITransitionStateEnum transitionStateEnum;
}