package com.seeease.flywheel_v4.web.app.wms.result;

import lombok.Data;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/4/24 6:00 下午
 **/
@Data
public class WmsStoreAreaListResult {
    /**
     * id
     */
    private Integer id;
    /**
     * 名称
     */
    private String name;

}
