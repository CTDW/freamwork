package com.seeease.flywheel_v4.web.infrastructure.dao.operations.mapper;

import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.TransferQuota;
import com.seeease.seeeaseframework.mybatis.SeeeaseMapper;

/**
 * @author 西门 游
 * @version 1.0
 * @since 5/31/24 4:53 下午
 **/
public interface TransferQuotaMapper extends SeeeaseMapper<TransferQuota> {
}
