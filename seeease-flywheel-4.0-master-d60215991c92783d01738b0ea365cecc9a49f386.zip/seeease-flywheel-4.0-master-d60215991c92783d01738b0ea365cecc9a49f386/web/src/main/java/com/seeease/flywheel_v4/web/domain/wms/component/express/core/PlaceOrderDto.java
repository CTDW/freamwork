package com.seeease.flywheel_v4.web.domain.wms.component.express.core;

import com.seeease.flywheel_v4.web.infrastructure.dao.sale.entity.ThirdSaleOrder;
import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.entity.SysSaleChannel;
import lombok.Data;

import java.util.List;

/**
 * <p>快递下单入参</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 9/20/24 4:55 下午
 **/
@Data
public class PlaceOrderDto {

    /**
     * 销售渠道配置
     */
    private SysSaleChannel saleChannel;

    /**
     * 三方订单号
     */
    private ThirdSaleOrder thirdSaleOrder;

    /**
     * 面单备注
     */
    private String billRemark;

    /**
     * 销售备注
     */
    private String saleRemark;

    /**
     * 国检码
     */
    private String qualityCode;

    //--------------------------------------以下是顺丰打印基础数据-------------------------------------//


    /**
     * 业务订单号，下单唯一
     */
    private String businessNo;

    /**
     * 商品数据
     */
    private List<Product> products;

    /**
     * 收货人名称
     */
    private String name;
    /**
     * 收货人电话
     */
    private String phone;
    /**
     * 收货人详细地址（该地址经过拼接）
     */
    private String address;
    /**
     * 收货人省
     */
    private String province;
    /**
     * 收货人市
     */
    private String city;
    /**
     * 收货人县
     */
    private String area;
    /**
     * 收货人街道
     */
    private String street;


    /**
     * 发货人名称
     */
    private String spName;
    /**
     * 发货人电话
     */
    private String spPhone;
    /**
     * 发货人详细地址（该地址经过拼接）
     */
    private String spAddress;
    /**
     * 发货人省
     */
    private String spProvince;
    /**
     * 发货人市
     */
    private String spCity;
    /**
     * 发货人县
     */
    private String spArea;
    /**
     * 发货人街道
     */
    private String spStreet;

    /**
     * 商品信息
     */
    @Data
    public static class Product{
        /**
         * 商品名称
         */
        private String goodsName;
        /**
         * 商品编码
         */
        private String xyCode;
    }


}
