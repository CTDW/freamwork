package com.seeease.flywheel_v4.web.app.sys_config.service;

import com.seeease.flywheel_v4.web.app.sys_config.request.*;
import com.seeease.flywheel_v4.web.app.sys_config.result.BusinessUnitListResult;
import com.seeease.flywheel_v4.web.app.sys_config.result.BusinessUnitPageResult;
import com.seeease.flywheel_v4.web.app.sys_config.result.PurchaseBusinessUnitPageResult;
import com.seeease.flywheel_v4.web.app.sys_config.result.SaleChannelPageResult;
import com.seeease.springframework.PageResult;

import java.util.List;

/**
 * <p>系统销售渠道服务</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/3/24 11:19 上午
 **/

public interface SaleChannelService {

    /**
     * 销售渠道创建
     *
     * @return 创建结果
     */
    Boolean create(SaleChannelSubmitRequest request);
    /**
     * 销售渠道更新
     *
     * @return 更新结果
     */
    Boolean update(SaleChannelSubmitRequest request);
    /**
     * 销售渠道分页查询
     *
     * @return 分页结果
     */
    PageResult<SaleChannelPageResult> page(SaleChannelPageRequest request);
}
