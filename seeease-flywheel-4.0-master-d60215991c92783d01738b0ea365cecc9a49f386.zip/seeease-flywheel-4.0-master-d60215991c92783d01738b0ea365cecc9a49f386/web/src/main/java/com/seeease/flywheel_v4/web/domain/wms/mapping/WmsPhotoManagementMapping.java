package com.seeease.flywheel_v4.web.domain.wms.mapping;


import com.seeease.flywheel_v4.web.app.wms.request.WmsPhoneManagementPageRequest;
import com.seeease.flywheel_v4.web.app.wms.request.WmsTakePhotoRequest;
import com.seeease.flywheel_v4.web.app.wms.result.WmsPhotoManagementPageResult;
import com.seeease.flywheel_v4.web.infrastructure.config.EnumMapping;
import com.seeease.flywheel_v4.web.infrastructure.config.MappingIgnore;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.WmsPhotoManagement;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.WmsRk;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.WmsPhotoManagementState;
import com.seeease.goods.rpc.enums.SkuNodeStateEnums;
import com.seeease.goods.rpc.enums.SkuStateEnums;
import com.seeease.goods.rpc.request.SkuRpcRequest;
import com.seeease.goods.rpc.request.SkuUpdateRpcRequest;
import com.seeease.goods.rpc.result.SkuRpcResult;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;


/**
 * <p>
 * 商品附件
 * </p>
 *
 * @author 西门 游
 * @since 2023-10-27
 */
@Mapper(componentModel = "spring",
        builder = @Builder(disableBuilder = true),
        nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS,
        nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE,
        imports = {WmsPhotoManagementState.class,SkuNodeStateEnums.class, SkuStateEnums.TransitionEnum.class,SkuStateEnums.class})
public interface WmsPhotoManagementMapping extends EnumMapping {

    WmsPhotoManagementMapping INSTANCE = Mappers.getMapper(WmsPhotoManagementMapping.class);


    @MappingIgnore
    @Mapping(target = "rkId",source = "wmsRk.id")
    @Mapping(target = "state",expression = "java(WmsPhotoManagementState.WAIT)")
    WmsPhotoManagement toEntity(WmsRk wmsRk);


    @Mapping(target = "state",ignore = true)
    SkuRpcRequest toSKuRpcRequest(WmsPhoneManagementPageRequest request);

    @Mapping(target = "id",source = "photoManagement.id")
    @Mapping(target = "updatedBy",source = "photoManagement.updatedBy")
    @Mapping(target = "createdTime",source = "photoManagement.createdTime")
    @Mapping(target = "updatedTime",source = "photoManagement.updatedTime")
    WmsPhotoManagementPageResult toPageResult(WmsPhotoManagement photoManagement,
                                              WmsRk wmsRk,
                                              SkuRpcResult sku);

    SkuUpdateRpcRequest toSkuUpdateRequest(Integer skuId, WmsTakePhotoRequest request);
}
