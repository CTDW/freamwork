package com.seeease.flywheel_v4.web.domain.operations.mapping;


import com.seeease.flywheel_v4.web.app.excel.request.SkuPricingImportRequest;
import com.seeease.flywheel_v4.web.app.operations.request.PricingPageRequest;
import com.seeease.flywheel_v4.web.app.operations.request.PricingStateRequest;
import com.seeease.flywheel_v4.web.app.operations.result.PricingDetailResult;
import com.seeease.flywheel_v4.web.app.operations.result.PricingPageResult;
import com.seeease.flywheel_v4.web.infrastructure.config.EnumMapping;
import com.seeease.flywheel_v4.web.infrastructure.config.MappingIgnore;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.Pricing;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.Supplier;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.SupplierContacts;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.obj.PricingLifeCycleObj;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.enums.PricingStateEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.entity.PurchaseOrder;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.entity.PurchaseOrderLine;
import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.entity.SysBusinessUnit;
import com.seeease.goods.rpc.enums.SkuRunTypeEnums;
import com.seeease.goods.rpc.enums.SkuSellWayEnums;
import com.seeease.goods.rpc.request.SkuPricingRpcRequest;
import com.seeease.goods.rpc.request.SkuRpcRequest;
import com.seeease.goods.rpc.result.SkuRpcResult;
import com.seeease.springframework.context.UserContext;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;

import java.util.Collections;
import java.util.Date;
import java.util.List;


/**
 * <p>
 * 供应商
 * </p>
 *
 * @author 西门 游
 * @since 2023-10-27
 */
@Mapper(componentModel = "spring",
        builder = @Builder(disableBuilder = true),
        nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS,
        nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE,
        imports = {PricingStateEnums.class, PricingStateEnums.TransitionEnum.class,PricingStateEnums.class})
public interface PricingMapping extends EnumMapping {

    PricingMapping INSTANCE = Mappers.getMapper(PricingMapping.class);

    @MappingIgnore
    @Mapping(target = "state", expression = "java(PricingStateEnums.WAIT_PRICING)")
    @Mapping(target = "purchaseId", source = "order.id")
    @Mapping(target = "lifeCycle", expression = "java(initLifeCycle())")
    Pricing toEntity(PurchaseOrder order, PurchaseOrderLine line);


    default List<PricingLifeCycleObj> initLifeCycle() {
        PricingLifeCycleObj pricingLifeCycleObj = new PricingLifeCycleObj();
        pricingLifeCycleObj.setDesc("创建定价");
        pricingLifeCycleObj.setCreatedBy("系统");
        pricingLifeCycleObj.setCreatedTime(new Date());

        return Collections.singletonList(pricingLifeCycleObj);
    }

    @Mapping(target = "state", ignore = true)
    SkuRpcRequest toSkuRpcRequest(PricingPageRequest request);

    @Mapping(target = "id", source = "pricing.id")
    PricingPageResult toPageResult(Pricing pricing,
                                   SkuRpcResult sku,
                                   Integer count,
                                   String reviewer,
                                   String merchantName);


    @Mapping(target = "supplierName", source = "supplier.name")
    @Mapping(target = "supplierAddress", expression = "java(supplier.getCompleteAddress())")
    @Mapping(target = "supplierType", source = "supplier.type")
    @Mapping(target = "contactName", source = "contacts.name")
    @Mapping(target = "createdBy", source = "pricing.createdBy")
    @Mapping(target = "merchantId", source = "merchant.id")
    @Mapping(target = "merchantName", source = "merchant.name")
    @Mapping(target = "createdTime", source = "pricing.createdTime")
    @Mapping(target = "remark", source = "purchaseOrder.remark")
    @Mapping(target = "purchasePrice", source = "purchaseOrderLine.purchasePrice")
    @Mapping(target = "tobPrice", source = "pricing.tobPrice")
    @Mapping(target = "tocPrice", source = "pricing.tocPrice")
    @Mapping(target = "settlePrice", source = "pricing.settlePrice")
    @Mapping(target = "receiptPrice", source = "pricing.receiptPrice")
    @Mapping(target = "repairPrice", source = "sku.repairPrice")
    @Mapping(target = "state", source = "pricing.state")
    @Mapping(target = "sellWay", source = "pricing.sellWay")
    @Mapping(target = "runType", source = "pricing.runType")
    @Mapping(target = "id", source = "pricing.id")
    @Mapping(target = "purchaseType", source = "purchaseOrder.type")
    @Mapping(target = "purchaseSubjectName", source = "purchaseSubject.name")
    PricingDetailResult toDetailResult(Pricing pricing,
                                       SkuRpcResult sku,
                                       PurchaseOrderLine purchaseOrderLine,
                                       PurchaseOrder purchaseOrder,
                                       SysBusinessUnit merchant,
                                       Supplier supplier,
                                       SupplierContacts contacts,
                                       SysBusinessUnit purchaseSubject);

    PricingDetailResult.PricingLifeCycle toLifeCycle(PricingLifeCycleObj lifeCycleObj);

    List<PricingDetailResult.PricingLifeCycle> toLifeCycle(List<PricingLifeCycleObj> lifeCycleObj);


    @MappingIgnore
    @Mapping(target = "state", ignore = true)
    @Mapping(target = "lifeCycle", expression = "java(addLifeCycle(pricing.getLifeCycle(),transitionStateEnum))")
    void toEntityForUpdate(@MappingTarget Pricing pricing,
                           PricingStateRequest request,
                           PricingStateEnums.TransitionEnum transitionStateEnum);


    default List<PricingLifeCycleObj> addLifeCycle(List<PricingLifeCycleObj> lifeCycle,
                                                   PricingStateEnums.TransitionEnum transitionStateEnum) {
        PricingLifeCycleObj pricingLifeCycleObj = new PricingLifeCycleObj();
        pricingLifeCycleObj.setDesc(transitionStateEnum.getDesc());
        pricingLifeCycleObj.setCreatedBy(UserContext.getUser().getUserName());
        pricingLifeCycleObj.setCreatedTime(new Date());
        lifeCycle.add(0, pricingLifeCycleObj);
        return lifeCycle;
    }


    @Mapping(target = "newSettlePrice",source = "pricing.settlePrice")
    SkuPricingRpcRequest toSkuPriceUpdateRequest(Pricing pricing);


    @Mapping(target = "sellWay",source = "sellWay")
    @Mapping(target = "runType",source = "runType")
    void toEntityForUpdate(@MappingTarget Pricing pricing,
                           SkuPricingImportRequest item,
                           SkuSellWayEnums sellWay,
                           SkuRunTypeEnums runType,
                           Integer merchantId);
}
