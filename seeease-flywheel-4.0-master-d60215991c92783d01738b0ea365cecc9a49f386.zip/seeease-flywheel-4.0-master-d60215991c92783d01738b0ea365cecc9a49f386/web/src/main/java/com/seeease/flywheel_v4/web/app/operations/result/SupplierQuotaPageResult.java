package com.seeease.flywheel_v4.web.app.operations.result;

import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/4/24 6:00 下午
 **/
@Data
public class SupplierQuotaPageResult {
    /**
     * id
     */
    private Integer id;
    /**
     * 客户名称
     */
    private String supplierName;

    /**
     * 寄售货值
     */
    private BigDecimal consignmentAmount;
    /**
     * 寄售余额
     */
    private BigDecimal consignmentCredit;
    /**
     * 正常余额
     */
    private BigDecimal normalCredit;

    /**
     * 更新时间
     */
    private Date updatedTime;

}
