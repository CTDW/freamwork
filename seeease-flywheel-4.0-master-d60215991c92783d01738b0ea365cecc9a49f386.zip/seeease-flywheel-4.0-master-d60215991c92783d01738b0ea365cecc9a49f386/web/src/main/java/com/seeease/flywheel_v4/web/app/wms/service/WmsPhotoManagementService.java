package com.seeease.flywheel_v4.web.app.wms.service;

import com.seeease.flywheel_v4.web.app.wms.request.WmsBatchTakePhotoRequest;
import com.seeease.flywheel_v4.web.app.wms.request.WmsPhoneManagementPageRequest;
import com.seeease.flywheel_v4.web.app.wms.request.WmsTakePhotoRequest;
import com.seeease.flywheel_v4.web.app.wms.result.WmsPhotoManagementPageResult;
import com.seeease.springframework.PageResult;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/20/24 11:46 上午
 **/
public interface WmsPhotoManagementService {

    /**
     * 入库拍照任务分页
     *
     * @return 分页结果
     */
    PageResult<WmsPhotoManagementPageResult> page(WmsPhoneManagementPageRequest request);


    /**
     * 入库拍照
     *
     * @return 拍照结果
     */
    Boolean takePhoto(WmsTakePhotoRequest request);

    /**
     * 批量拍照通过
     * @param request
     * @return
     */
    Boolean batchTakePhoto(WmsBatchTakePhotoRequest request);
}
