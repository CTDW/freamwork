package com.seeease.flywheel_v4.web.app.purchase.request;


import com.fasterxml.jackson.annotation.JsonFormat;
import com.seeease.springframework.PageRequest;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Date;
import java.util.Set;

/**
 * @ Description   :
 * @ Author        :  西门 游
 * @ CreateDate    :  6/6/24
 * @ Version       :  1.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class PurchaseOrderPageRequest extends PageRequest {
    /**
     * ids
     */
    private Set<Integer> ids;
    /**
     * 采购单号
     */
    private String serialNo;
    /**
     * 关联单号
     */
    private String relatedSerialNo;
    /**
     * 采购类型
     */
    private Integer type;
    /**
     * 采购订单状态
     */
    private Integer state;
    /**
     * 节点状态
     */
    private Integer nodeState;
    /**
     * sku编码
     */
    private String skuCode;
    /**
     * 需求商家
     */
    private Integer merchantId;

    /**
     * 快递单号
     */
    private String expressNo;
    /**
     * 是否查看自己创建的采购单
     */
    private Boolean mine = false;
    /**
     * 开始时间
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date startTime;
    /**
     * 结束时间
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date endTime;

    /**
     * 当前请求业务部门id 用于数据隔离
     */
    private Integer buId;

}
