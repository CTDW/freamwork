package com.seeease.flywheel_v4.web.infrastructure.dao.finance.repo;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.seeease.flywheel_v4.web.app.finance.request.PaymentSlipPageRequest;
import com.seeease.flywheel_v4.web.infrastructure.dao.finance.entity.FinancePaymentSlip;

/**
 * @author 西门 游
 * @version 1.0
 * @since 5/31/24 4:53 下午
 **/
public interface FinancePaymentSlipRepository  {
    /**
     * 提交
     * @param paymentSlip
     * @return
     */
    Boolean submit(FinancePaymentSlip paymentSlip);

    /**
     * 查找
     * @param id 主键id
     * @return
     */
    FinancePaymentSlip findById(Integer id);

    /**
     * 分页查询
     * @param request
     * @return
     */
    Page<FinancePaymentSlip> page(PaymentSlipPageRequest request);

    /**
     * 查找
     * @param id 主键id
     * @param serialNo 编码
     * @return
     */
    FinancePaymentSlip findByIdOrSerial(Integer id, String serialNo);

    /**
     * 待状态变更提交
     * @param paymentSlip
     * @return
     */
    Boolean submitWithState(FinancePaymentSlip paymentSlip);

}
