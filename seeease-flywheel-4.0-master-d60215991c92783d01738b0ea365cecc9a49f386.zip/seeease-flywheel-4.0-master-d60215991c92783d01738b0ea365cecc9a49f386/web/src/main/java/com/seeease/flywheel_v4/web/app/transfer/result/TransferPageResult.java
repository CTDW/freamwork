package com.seeease.flywheel_v4.web.app.transfer.result;


import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @author 西门 游
 * @version 1.0
 * @since 6/3/24 11:26 上午
 **/
@Data
public class TransferPageResult {
    /**
     * 主键id
     */
    private Integer id;
    /**
     * 编号
     */
    private String serialNo;
    /**
     * 调拨类型
     */
    private Integer type;
    /**
     * 调出方
     */
    private String fromName;
    /**
     * 调入方
     */
    private String toName;
    /**
     * 调拨单状态
     */
    private Integer state;
    /**
     * 总金额
     */
    private BigDecimal totalSettlePrice;
    /**
     * 备注
     */
    private String remark;
    /**
     * 创建人
     */
    private String createdBy;
    /**
     * 创建时间
     */
    private Date createdTime;

    /**
     * 订单来源
     */
    private String originName;


}
