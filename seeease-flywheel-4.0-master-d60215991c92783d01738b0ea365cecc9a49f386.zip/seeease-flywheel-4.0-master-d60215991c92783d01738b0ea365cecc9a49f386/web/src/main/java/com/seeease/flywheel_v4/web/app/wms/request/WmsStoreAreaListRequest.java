package com.seeease.flywheel_v4.web.app.wms.request;


import lombok.Data;

/**
 * @ Description   :
 * @ Author        :  西门 游
 * @ CreateDate    :  6/6/24
 * @ Version       :  1.0
 */

@Data
public class WmsStoreAreaListRequest {

    /**
     * 父id
     */
    private Integer pid;
    /**
     * 库区级别
     */
    private Integer level;



}
