package com.seeease.flywheel_v4.web.app.operations.result;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class TransferQuotaLineListResult {
    /**
     * 类目id
     */
    private Integer categoryId;
    /**
     * 类目名称
     */
    private String categoryName;
    /**
     * 品牌名称
     */
    private String brandName;

    /**
     * 品牌id
     */
    private Integer brandId;
    /**
     * 控制的额度
     */
    private BigDecimal quota;
    /**
     * 使用的额度
     */
    private BigDecimal usedQuota;
    /**
     * 自主经营类型
     */
    private Integer runType;

}
