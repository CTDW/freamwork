package com.seeease.flywheel_v4.web.app.fix.common;

import com.alibaba.fastjson.JSON;
import com.seeease.flywheel_v4.web.infrastructure.dao.fix.entity.FixOrder;
import com.seeease.springframework.utils.StringUtils;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;

import java.io.Serializable;
import java.util.List;

/**
 * @Description 维修单 -商品信息
 * @Date 2024-10-4 18:19
 * @Author by hk
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FixGoodsDto implements Serializable {

    @ApiModelProperty(value = "唯一码")
    private String goodsUnique;

    @ApiModelProperty(value = "品牌")
    private String brand;

    @ApiModelProperty(value = "表节数")
    private Integer watchNodeCount;

    @ApiModelProperty(value = "可否拆盖")
    private Boolean removeCover;

    @ApiModelProperty(value = "瑕疵图")
    private List<String> defectPictureList;

    @ApiModelProperty(value = "表带类型")
    private String watchBandType;

    @ApiModelProperty(value = "成色")
    private String newnessDegree;

    public static FixGoodsDto fromEntity(FixOrder detail) {
        return FixGoodsDto.builder()
                .goodsUnique(detail.getGoodsUnique())
                .brand(detail.getBrand())
                .watchNodeCount(detail.getWatchNodeCount())
                .removeCover(detail.getRemoveCover())
                .defectPictureList(StringUtils.isEmpty(detail.getDefectPictureList()) ? null :
                        JSON.parseArray(detail.getDefectPictureList(), String.class))
                .watchBandType(detail.getWatchBandType())
                .newnessDegree(detail.getNewnessDegree())
                .build();
    }

    public void toEntity(FixOrder detail) {
        detail.setGoodsUnique(goodsUnique);
        detail.setBrand(brand);
        detail.setWatchNodeCount(watchNodeCount);
        detail.setRemoveCover(removeCover);
        detail.setDefectPictureList(CollectionUtils.isNotEmpty(defectPictureList) ? JSON.toJSONString(defectPictureList) : null);
        detail.setWatchBandType(watchBandType);
        detail.setNewnessDegree(newnessDegree);
    }
}
