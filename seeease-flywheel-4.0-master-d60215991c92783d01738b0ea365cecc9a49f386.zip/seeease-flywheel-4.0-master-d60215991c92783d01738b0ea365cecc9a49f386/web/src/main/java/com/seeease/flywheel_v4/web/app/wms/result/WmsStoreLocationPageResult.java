package com.seeease.flywheel_v4.web.app.wms.result;

import lombok.Data;

import java.util.Date;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/4/24 6:00 下午
 **/
@Data
public class WmsStoreLocationPageResult {
    /**
     * 库位id
     */
    private Integer id;
    /**
     * spuId
     */
    private Integer spuId;
    /**
     * 库位名称
     */
    private String name;
    /**
     * 主库区名称
     */
    private String mainAreaName;
    /**
     * 主库区id
     */
    private Integer mainAreaId;

    /**
     * 子库区名称
     */
    private String childAreaName;

    /**
     * 子库区id
     */
    private Integer childAreaId;
    /**
     *货号
     */
    private String goodsCode;
    /**
     * 库位状态
     */
    private Integer state;
    /**
     * 仓库id
     */
    private Integer storeId;
    /**
     * 创建时间
     */
    private Date createdTime;
}
