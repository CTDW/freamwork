package com.seeease.flywheel_v4.web.domain.excel.core;

import lombok.Data;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 *
 * @param <T>
 */
@Data
public class ImportCmd<T> implements Serializable {

    /**
     * 用例(扩展点使用)
     */
    private String useCase;
    /**
     * 业务id(扩展点使用)
     */
    private String bizCode = "import";

}
