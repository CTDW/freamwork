package com.seeease.flywheel_v4.web.infrastructure.dao.sale.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.enums.SaleModelEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.enums.SaleReturnStateEnums;
import com.seeease.seeeaseframework.mybatis.domain.BaseDomain;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;
import java.util.Date;

/**
 * 销售退货订单
 */
@EqualsAndHashCode(callSuper = true)
@TableName(value = "v4_sale_return_order", autoResultMap = true)
@Data
public class SaleReturnOrder extends BaseDomain {
    @TableId(type = IdType.AUTO)
    private Integer id;
    /**
     * 单号
     */
    private String serialNo;
    /**
     * 主单号
     */
    private String mainSerialNo;
    /**
     * 三方退货id
     */
    private String thirdReturnId;

    /**
     * 销售模型
     */
    private SaleModelEnums saleModel;

    /**
     * 金额
     */
    private BigDecimal totalAmount;
    /**
     * 入库方id
     */
    private Integer storeId;
    /**
     * 总数
     */
    private Integer totalCount;
    /**
     * 快递单号
     */
    private String expressNo;
    /**
     * 创建人业务单元id
     */
    private Integer buId;
    /**
     * 备注
     */
    private String remark;
    /**
     * 状态
     */
    private SaleReturnStateEnums state;
    /**
     * 完成时间
     */
    private Date finishTime;
}