
package com.seeease.flywheel_v4.web.infrastructure.dao.purchase.repo.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.seeease.flywheel_v4.web.app.purchase.request.PurchaseAftersalePageRequest;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.entity.PurchaseAftersale;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.mapper.PurchaseAftersaleMapper;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.repo.PurchaseAftersaleRepository;
import com.seeease.seeeaseframework.mybatis.transitionstate.UpdateByIdCheckState;
import com.seeease.springframework.context.UserContext;
import com.seeease.springframework.utils.DateUtils;
import com.seeease.springframework.utils.StringUtils;
import org.springframework.stereotype.Repository;

import java.util.Collections;
import java.util.List;
import java.util.Set;

/**
 * @author 西门 游
 * @version 1.0
 * @since 5/31/24 4:55 下午
 **/
@Repository
public class PurchaseAftersaleRepositoryImpl extends ServiceImpl<PurchaseAftersaleMapper, PurchaseAftersale>
        implements PurchaseAftersaleRepository {


    @Override
    public Boolean submit(PurchaseAftersale aftersale) {

        if (null != aftersale.getTransitionStateEnum()){
            UpdateByIdCheckState.update(baseMapper,aftersale);
            return true;
        }
        return saveOrUpdate(aftersale);
    }

    @Override
    public List<PurchaseAftersale> listBySerialNos(Set<String> serialNo) {
        if (StringUtils.isEmpty(serialNo)){
            return Collections.emptyList();
        }
        LambdaQueryWrapper<PurchaseAftersale> wq = Wrappers.<PurchaseAftersale>lambdaQuery()
                .in(PurchaseAftersale::getSerialNo, serialNo);

        return baseMapper.selectList(wq);
    }

    @Override
    public PurchaseAftersale findByIdOrSerialNo(Integer id, String serialNo) {
        LambdaQueryWrapper<PurchaseAftersale> wq = Wrappers.<PurchaseAftersale>lambdaQuery()
                .eq(StringUtils.isNotEmpty(serialNo),PurchaseAftersale::getSerialNo, serialNo)
                .eq(null != id ,PurchaseAftersale::getId,id);

        return baseMapper.selectOne(wq);
    }

    @Override
    public Page<PurchaseAftersale> page(PurchaseAftersalePageRequest request, Set<Integer> ids) {

        if (null != request.getStartTime() && null != request.getEndTime()) {
            request.setStartTime(DateUtils.getTimesmorning(DateUtils.getTimesmorning(request.getStartTime())));
            request.setEndTime(DateUtils.getTimesnight(DateUtils.getTimesnight(request.getEndTime())));
        }


        LambdaQueryWrapper<PurchaseAftersale> wq = Wrappers.<PurchaseAftersale>lambdaQuery()
                .eq(null != request.getBuId(),PurchaseAftersale::getBuId,request.getBuId())
                .in(StringUtils.isNotEmpty(ids),PurchaseAftersale::getId, ids)
                .in(StringUtils.isNotEmpty(request.getIds()),PurchaseAftersale::getId,request.getIds())
                .eq(StringUtils.isNotEmpty(request.getSerialNo()) ,PurchaseAftersale::getOriginSerialNo,request.getSerialNo())
                .eq(null != request.getType(),PurchaseAftersale::getType,request.getType())
                .eq(null != request.getState(),PurchaseAftersale::getState,request.getState())
                .eq(StringUtils.isNotEmpty(request.getExpressNo()),PurchaseAftersale::getExpressNo,request.getExpressNo())
                .eq(request.getMine(),PurchaseAftersale::getCreatedId, UserContext.getUser().getId())
                .between(null != request.getStartTime() && null != request.getEndTime(),PurchaseAftersale::getCreatedTime,request.getStartTime(),request.getEndTime())
                .orderByDesc(PurchaseAftersale::getId);

        Page<PurchaseAftersale> page = Page.of(request.getPage(), request.getLimit());
        baseMapper.selectPage(page,wq);

        return page;
    }
}
