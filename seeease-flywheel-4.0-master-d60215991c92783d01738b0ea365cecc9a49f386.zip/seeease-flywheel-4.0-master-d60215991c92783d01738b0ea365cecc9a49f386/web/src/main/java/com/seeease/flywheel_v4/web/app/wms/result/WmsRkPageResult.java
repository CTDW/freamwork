package com.seeease.flywheel_v4.web.app.wms.result;

import com.seeease.goods.rpc.request.SkuAnnexeRpcResult;
import com.seeease.goods.rpc.result.ProductParamRpcResult;
import lombok.Data;

import java.util.Date;
import java.util.List;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/4/24 6:00 下午
 **/
@Data
public class WmsRkPageResult {
    /**
     * id
     */
    private Integer id;

    /**
     * spuId
     */
    private Integer spuId;

    /**
     * skuId
     */
    private Integer skuId;
    /**
     * 业务单号
     */
    private String serialNo;

    /**
     * 商品所在
     */
    private String belongName;

    /**
     * 业务类型
     */
    private Integer type;
    /**
     * 蜥蜴编码
     */
    private String xyCode;
    /**
     * 商品名称
     */
    private String goodsName;
    /**
     * 类目id
     */
    private Integer categoryId;
    /**
     * 类目名称
     */
    private String categoryName;
    /**
     * 图片
     */
    private String spuImage;
    /**
     * 品牌名称
     */
    private String brandName;

    /**
     * 来源名称
     */
    private String originName;

    /**
     * 是否唯一码管控
     */
    private Integer uniqueType;
    /**
     * 节点状态
     */
    private Integer nodeState;

    /**
     * sku参数列表
     */
    private List<ProductParamRpcResult> skuParams;
    /**
     * 附件
     */
    private List<SkuAnnexeRpcResult> annexe;
    /**
     * 唯一码
     */
    private String skuCode;
    /**
     * 快递单号
     */
    private String expressNo;
    /**
     * 入库数量
     */
    private Integer count;
    /**
     * 创建人
     */
    private String createdBy;
    /**
     * 创建时间
     */
    private Date createdTime;
    /**
     * 入库时间
     */
    private Date rkTime;
    /**
     * spu编码
     */
    private String spuCode;
    /**
     * 出入库状态
     */
    private Integer state;
    /**
     * 异常原因
     */
    private String reason;
}
