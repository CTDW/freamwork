package com.seeease.flywheel_v4.web.adptor;

import com.seeease.flywheel_v4.web.app.sale.request.*;
import com.seeease.flywheel_v4.web.app.sale.result.*;
import com.seeease.flywheel_v4.web.app.sale.service.SaleOrderService;
import com.seeease.flywheel_v4.web.app.sale.service.SaleReturnOrderService;
import com.seeease.flywheel_v4.web.app.sale.service.ThirdSaleOrderService;
import com.seeease.flywheel_v4.web.infrastructure.config.IdentifyLogPrinter;
import com.seeease.springframework.PageResult;
import com.seeease.springframework.SingleResponse;
import com.seeease.springframework.log.annotation.LogPrinter;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;


/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 5/30/24 5:35 下午
 **/
@RestController
@RequestMapping("sale")
public class SaleController {

    @Resource
    private SaleOrderService saleOrderService;
    @Resource
    private SaleReturnOrderService saleReturnOrderService;
    @Resource
    private ThirdSaleOrderService thirdSaleOrderService;


    /**
     * 销售-三方销售单审核通过
     *
     * @return 分页结果
     */
    @PostMapping("third/confirm")
    @LogPrinter(scenario = " 销售-三方销售单审核通过", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<Boolean> thirdOrderConfirm(
            @Validated @RequestBody ThirdSaleOrderConfirmRequest request) {
        return SingleResponse.of(thirdSaleOrderService.confirm(request));
    }


    /**
     * 销售-三方销售单合并详情
     */
    @PostMapping("third/merge/detail")
    @LogPrinter(scenario = " 销售-三方销售单合并页面", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<ThirdSaleOrderMergeResult> mergeDetail(
            @RequestBody ThirdSaleOrderMergeRequest request) {
        return SingleResponse.of(thirdSaleOrderService.mergeDetail(request));
    }


    /**
     * 销售-三方销售单分页
     *
     * @return 分页结果
     */
    @PostMapping("third/page")
    @LogPrinter(scenario = " 销售-三方销售单分页", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<PageResult<ThirdSaleOrderPageResult>> thirdOrderPage(
            @RequestBody ThirdSaleOrderPageRequest request) {
        return SingleResponse.of(thirdSaleOrderService.page(request));
    }


    /**
     * 销售-toc销售单创建
     *
     * @return 创建结果
     */
    @PostMapping("toc/create")
    @LogPrinter(scenario = " 销售-toc销售单创建", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<Integer> tocCreate(
            @Validated @RequestBody SaleOrderCreateRequest request) {
        return SingleResponse.of(saleOrderService.tocCreate(request));
    }

    /**
     * 销售退货-toc销售退货单创建
     *
     * @return 创建结果
     */
    @PostMapping("return/toc/create")
    @LogPrinter(scenario = " 销售退货-toc销售退货单创建", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<Integer> tocReturnCreate(
            @Validated @RequestBody ToCSaleReturnOrderCreateRequest request) {

        return SingleResponse.of(saleReturnOrderService.tocReturnCreate(request));
    }


    /**
     * 销售退货-toc退货单取消
     *
     * @return 取消结果
     */
    @PostMapping("return/toc/cancel")
    @LogPrinter(scenario = "销售退货-toc退货单取消", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<Boolean> tocReturnCancel(
            @Validated @RequestBody SaleReturnOrderCancelRequest request) {

        return SingleResponse.of(saleReturnOrderService.tocReturnCancel(request));
    }


    /**
     * 销售-toc销售单分页查询
     *
     * @return 分页结果
     */
    @PostMapping("toc/page")
    @LogPrinter(scenario = " 销售-toc销售单分页查询", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<PageResult<ToCSaleOrderPageResult>> tocPage(
            @RequestBody ToCSaleOrderPageRequest request) {

        return SingleResponse.of(saleOrderService.tocPage(request));
    }

    /**
     * 销售退货-toc销售退货单分页查询
     *
     * @return 分页结果
     */
    @PostMapping("return/toc/page")
    @LogPrinter(scenario = " 销售退货-toc销售退货单分页查询", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<PageResult<ToCSaleReturnOrderPageResult>> tocReturnPage(
            @RequestBody ToCSaleReturnOrderPageRequest request) {

        return SingleResponse.of(saleReturnOrderService.tocReturnPage(request));
    }


    /**
     * 销售-toc销售单详情
     *
     * @return 详情结果
     */
    @PostMapping("toc/detail")
    @LogPrinter(scenario = "销售-toc销售单详情", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<ToCSaleOrderDetailResult> tocDetail(
            @RequestBody ToCSaleOrderDetailRequest request) {

        return SingleResponse.of(saleOrderService.tocDetail(request));
    }

    /**
     * 销售退货-toc退货单详情
     *
     * @return 详情结果
     */
    @PostMapping("return/toc/detail")
    @LogPrinter(scenario = "销售退货-toc退货单详情", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<ToCSaleReturnOrderDetailResult> tocReturnDetail(
            @RequestBody ToCSaleReturnOrderDetailRequest request) {

        return SingleResponse.of(saleReturnOrderService.tocReturnDetail(request));
    }


    /**
     * 销售-toc销售修改回购政策
     *
     * @return 修改结果
     */
    @PostMapping("policy/update")
    @LogPrinter(scenario = "销售-toc销售修改回购政策", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<Boolean> policyUpdate(
            @Validated @RequestBody ToCSaleOrderLineBuyBackPolicyUpdateRequest request) {

        return SingleResponse.of(saleOrderService.policyUpdate(request));
    }


    /**
     * 销售-toc销售单取消
     *
     * @return 取消结果
     */
    @PostMapping("toc/cancel")
    @LogPrinter(scenario = "销售-toc销售单取消", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<Boolean> tocCancel(
            @Validated @RequestBody SaleOrderCancelRequest request) {

        return SingleResponse.of(saleOrderService.tocCancel(request));
    }


    /**
     * 销售-toB销售单创建
     *
     * @return 创建结果
     */
    @PostMapping("tob/create")
    @LogPrinter(scenario = " 销售-tob销售单创建", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<Boolean> tobCreate(
            @Validated @RequestBody SaleOrderCreateRequest request) {

        return SingleResponse.of(saleOrderService.tobCreate(request));
    }


    /**
     * 销售-toB销售单分页查询
     *
     * @return 分页结果
     */
    @PostMapping("tob/page")
    @LogPrinter(scenario = " 销售-tob销售单分页查询", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<PageResult<ToBSaleOrderPageResult>> tobPage(
            @RequestBody ToBSaleOrderPageRequest request) {

        return SingleResponse.of(saleOrderService.tobPage(request));
    }

    /**
     * 销售-toB销售单详情
     *
     * @return 详情结果
     */
    @PostMapping("tob/detail")
    @LogPrinter(scenario = "销售-tob销售单详情", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<ToBSaleOrderDetailResult> tobDetail(
            @RequestBody ToBSaleOrderDetailRequest request) {

        return SingleResponse.of(saleOrderService.tobDetail(request));
    }


    /**
     * 销售-tob销售寄售模式确认寄售
     *
     * @return 操作结果
     */
    @PostMapping("tob/consignment/confirm")
    @LogPrinter(scenario = "销售-tob销售寄售模式确认寄售", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<Boolean> tobDetail(
            @RequestBody ToBSaleConsignmentConfirmRequest request) {

        return SingleResponse.of(saleOrderService.consignmentConfirm(request));
    }


    /**
     * 销售-tob销售单取消
     *
     * @return 取消结果
     */
    @PostMapping("tob/cancel")
    @LogPrinter(scenario = "销售-tob销售单取消", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<Boolean> tobCancel(
            @Validated @RequestBody SaleOrderCancelRequest request) {

        return SingleResponse.of(saleOrderService.tobCancel(request));
    }


    /**
     * 销售-tob销售退货单创建
     *
     * @return 创建结果
     */
    @PostMapping("return/tob/create")
    @LogPrinter(scenario = "销售-tob销售退货单创建", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<Boolean> tobReturnCreate(
            @Validated @RequestBody ToBSaleReturnOrderCreateRequest request) {

        return SingleResponse.of(saleReturnOrderService.tobReturnCreate(request));
    }


    /**
     * 销售-tob销售退货单分页
     *
     * @return 分页结果
     */
    @PostMapping("return/tob/page")
    @LogPrinter(scenario = "销售-tob销售退货单分页", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<PageResult<ToBSaleReturnOrderPageResult>> tobReturnPage(
            @RequestBody ToBSaleReturnOrderPageRequest request) {

        return SingleResponse.of(saleReturnOrderService.tobReturnPage(request));
    }

    /**
     * 销售-tob销售退货单详情
     *
     * @return 详情结果
     */
    @PostMapping("return/tob/detail")
    @LogPrinter(scenario = "销售-tob销售退货单详情", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<ToBSaleReturnOrderDetailResult> tobReturnDetail(
            @RequestBody ToBSaleReturnOrderDetailRequest request) {

        return SingleResponse.of(saleReturnOrderService.tobReturnDetail(request));
    }


    /**
     * 销售退货-tob退货单取消
     *
     * @return 取消结果
     */
    @PostMapping("return/tob/cancel")
    @LogPrinter(scenario = "销售退货-tob退货单取消", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<Boolean> tobReturnCancel(
            @Validated @RequestBody SaleReturnOrderCancelRequest request) {

        return SingleResponse.of(saleReturnOrderService.tobReturnCancel(request));
    }

}
