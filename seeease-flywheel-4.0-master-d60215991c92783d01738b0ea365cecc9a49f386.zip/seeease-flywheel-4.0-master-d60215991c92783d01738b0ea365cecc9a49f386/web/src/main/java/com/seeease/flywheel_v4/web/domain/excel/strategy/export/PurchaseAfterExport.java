package com.seeease.flywheel_v4.web.domain.excel.strategy.export;

import com.alibaba.cola.extension.Extension;
import com.alibaba.fastjson.JSONObject;
import com.seeease.flywheel_v4.web.app.excel.result.PurchaseAftersaleExportResult;
import com.seeease.flywheel_v4.web.app.purchase.request.PurchaseAftersalePageRequest;
import com.seeease.flywheel_v4.web.app.purchase.result.PurchaseAftersalePageResult;
import com.seeease.flywheel_v4.web.app.purchase.service.PurchaseAftersaleService;
import com.seeease.flywheel_v4.web.domain.excel.ExcelDomain;
import com.seeease.flywheel_v4.web.domain.excel.core.ExportExtPtl;
import com.seeease.flywheel_v4.web.domain.purchase.mapping.PurchaseAftersaleMapping;
import com.seeease.flywheel_v4.web.infrastructure.dao.RepositoryFactory;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.Supplier;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.SupplierContacts;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.entity.PurchaseAftersaleLine;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.entity.PurchaseOrder;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.enums.PurchaseAftersaleStateEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.enums.PurchaseAftersaleTypeEnums;
import com.seeease.goods.rpc.SkuFacade;
import com.seeease.goods.rpc.request.SkuRpcRequest;
import com.seeease.goods.rpc.result.SkuRpcResult;
import com.seeease.seeeaseframework.mybatis.utils.EnumUtils;
import com.seeease.springframework.utils.MultiUtils;
import com.seeease.springframework.utils.StringUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.dubbo.config.annotation.DubboReference;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.*;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 9/12/24 10:42 上午
 **/
@Service
@Slf4j
@Extension(bizId = "export", useCase = "purchaseAftersale")
public class PurchaseAfterExport implements ExportExtPtl<PurchaseAftersalePageRequest, PurchaseAftersaleExportResult> {

    @Resource
    private RepositoryFactory repositoryFactory;

    @Resource
    private PurchaseAftersaleService purchaseAftersaleService;

    @DubboReference(version = "1.0.0", check = false)
    private SkuFacade skuFacade;

    @Resource
    private ExcelDomain excelDomain;


    @Override
    public Class<PurchaseAftersalePageRequest> getRequestClass() {
        return PurchaseAftersalePageRequest.class;
    }

    @Override
    public Class<PurchaseAftersaleExportResult> getResultClass() {
        return PurchaseAftersaleExportResult.class;
    }

    @Override
    public String getFileName() {
        return "采购售后导出";
    }


    @Override
    public List<PurchaseAftersaleExportResult> handle(PurchaseAftersalePageRequest request) {

        //step_1 查询售后单据
        request.setLimit(Integer.MAX_VALUE);
        List<PurchaseAftersalePageResult> list = purchaseAftersaleService.page(request).getResult();
        if (list.isEmpty()) {
            return Collections.emptyList();
        }

        Map<Integer, PurchaseAftersalePageResult> aftersaleOrderMap = MultiUtils.toMap(list, PurchaseAftersalePageResult::getId);


        //step_2 查询采购单据
        Set<String> purchaseSerialNos = new HashSet<>();
        for (PurchaseAftersalePageResult item : list) {
            String originSerialNo = item.getOriginSerialNo();
            if (StringUtils.isNotEmpty(originSerialNo)) {
                String[] split = originSerialNo.split(",");
                purchaseSerialNos.addAll(Arrays.asList(split));
            }
        }

        if (StringUtils.isEmpty(purchaseSerialNos)) {
            log.warn("采购售后导出未查询到对应采购单数据，导出未空。请求参数:{}", JSONObject.toJSONString(request));
            return Collections.emptyList();
        }

        //step_3 查询采购售后行
        Set<Integer> afterSaleIds = MultiUtils.toSet(list, PurchaseAftersalePageResult::getId);
        List<PurchaseAftersaleLine> lineList = repositoryFactory.getPurchaseAftersaleLineRepository()
                .listByMainIds(afterSaleIds);


        List<PurchaseOrder> purchaseOrders = repositoryFactory.getPurchaseOrderRepository()
                .listBySerialNos(purchaseSerialNos);

        Map<String, PurchaseOrder> purchaseOrderMap = MultiUtils.toMap(
                purchaseOrders,
                PurchaseOrder::getSerialNo
        );


        //step_3 查询供应商
        Set<Integer> supplierIds = MultiUtils.toSet(purchaseOrders, PurchaseOrder::getSupplierId);
        Map<Integer, Supplier> supplierMap = MultiUtils.toMap(
                repositoryFactory.getSupplierRepository().listByIds(supplierIds),
                Supplier::getId
        );

        Set<Integer> contactIds = MultiUtils.toSet(purchaseOrders, PurchaseOrder::getSupplierContactId);
        Map<Integer, SupplierContacts> contactMap = MultiUtils.toMap(
                repositoryFactory.getSupplierContactsRepository().listByIds(contactIds),
                SupplierContacts::getId
        );


        //step_5 查询sku
        Set<Integer> skuIds = MultiUtils.toSet(lineList, PurchaseAftersaleLine::getSkuId);
        if (StringUtils.isEmpty(skuIds)) {
            log.warn("采购售后导出未查询到对应sku数据，导出未空。请求参数:{}", JSONObject.toJSONString(request));
            return Collections.emptyList();
        }
        SkuRpcRequest rpcRequest = new SkuRpcRequest();
        rpcRequest.setIdList(skuIds);
        Map<Integer, SkuRpcResult> skuMap = MultiUtils.toMap(
                skuFacade.list(rpcRequest),
                SkuRpcResult::getId
        );


        //step_5 组合数据
        return MultiUtils.toList(
                lineList,
                line -> {
                    SkuRpcResult sku = skuMap.get(line.getSkuId());
                    String params = excelDomain.joinParam(sku.getSkuParams());
                    String annex = excelDomain.joinAnnexe(sku.getAnnexe());

                    PurchaseAftersalePageResult afterSaleOrder = aftersaleOrderMap.get(line.getMainId());
                    String type = EnumUtils.of(PurchaseAftersaleTypeEnums.class, afterSaleOrder.getType()).getDesc();
                    String state = EnumUtils.of(PurchaseAftersaleStateEnums.class, afterSaleOrder.getState()).getDesc();


                    Supplier supplier = null;
                    SupplierContacts contacts = null;
                    String originSerialNo = afterSaleOrder.getOriginSerialNo();
                    if (StringUtils.isNotEmpty(originSerialNo)) {
                        String[] split = originSerialNo.split(",");
                        if (StringUtils.isNotEmpty(split)) {
                            String serialNo = split[0];
                            PurchaseOrder purchaseOrder = purchaseOrderMap.get(serialNo);
                            supplier = supplierMap.get(purchaseOrder.getSupplierId());
                            contacts = contactMap.get(purchaseOrder.getSupplierContactId());
                        }
                    }

                    return PurchaseAftersaleMapping.INSTANCE.toExportResult(
                            type,
                            state,
                            sku,
                            params,
                            annex,
                            supplier,
                            contacts,
                            afterSaleOrder
                    );
                }
        );

    }
}
