package com.seeease.flywheel_v4.web.domain.wms.observer;

import com.seeease.flywheel_v4.client.enums.BusinessUnitTypeEnums;
import com.seeease.flywheel_v4.web.domain.transfer.mapping.TransferOrderLineMapping;
import com.seeease.flywheel_v4.web.domain.transfer.mapping.TransferOrderMapping;
import com.seeease.flywheel_v4.web.domain.wms.observer.base.Ext;
import com.seeease.flywheel_v4.web.domain.wms.observer.base.MerchantWmsObserver;
import com.seeease.flywheel_v4.web.domain.wms.observer.base.WmsCkObserver;
import com.seeease.flywheel_v4.web.domain.wms.observer.base.WmsSubject;
import com.seeease.flywheel_v4.web.infrastructure.dao.RepositoryFactory;
import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.entity.SysBusinessUnit;
import com.seeease.flywheel_v4.web.infrastructure.dao.transfer.entity.TransferOrder;
import com.seeease.flywheel_v4.web.infrastructure.dao.transfer.entity.TransferOrderLine;
import com.seeease.flywheel_v4.web.infrastructure.dao.transfer.enums.TransferStateEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.MerchantWms;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.MerchantWmsLine;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.WmsCk;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.WmsRk;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.obj.ContactInfo;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.MerchantWmsModelEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.MerchantWmsTypeEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.WmsCkTypeEnums;
import com.seeease.flywheel_v4.web.infrastructure.listener.TransferOrderStateListener;
import com.seeease.goods.rpc.SkuFacade;
import com.seeease.goods.rpc.enums.SkuNodeStateEnums;
import com.seeease.goods.rpc.request.TransferSkuCancelRequest;
import com.seeease.seeeaseframework.mybatis.domain.WhetherEnum;
import com.seeease.springframework.exception.ValidationUtil;
import com.seeease.springframework.utils.MultiUtils;
import org.apache.dubbo.config.annotation.DubboReference;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;

/**
 * <p
 * 调拨出库wms观察者
 * </p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/21/24 2:46下午
 **/
@Component
public class TransferCkObserver extends TransferBaseObserver implements WmsCkObserver, MerchantWmsObserver {

    @Resource
    private RepositoryFactory repositoryFactory;

    @DubboReference(version = "1.0.0", check = false)
    private SkuFacade skuFacade;

    @Lazy
    @Resource
    private WmsSubject wmsSubject;
    @Resource
    private TransferOrderStateListener stateListener;

    @Override
    public List<WmsCkTypeEnums> getWatchDataType() {
        return wmsCkWatchTypeList;
    }


    @Override
    public SkuNodeStateEnums adaptSkuNodeState(SkuNodeStateEnums state, String serialNo) {

        /**
         * 如果当前传入的状态为调拨已出库 则代表页面上操作了出库按钮
         * 此时需要判断对应的入库方的业务单元类型
         * 如果 属于仓库 即商家调拨至仓库  则此时商品状态以及仓库wms行商品状态均为 待收货
         * 如果 属于商家 则可能为商家调拨商家或者仓库调拨商家  此时商品状态和商家wms航状态均为 待入库
         */
        if (state == SkuNodeStateEnums.YCK) {

            TransferOrder order = repositoryFactory.getTransferOrderRepository().findByIdOrSerialNo(null, serialNo);
            SysBusinessUnit to = repositoryFactory.getBusinessUnitRepository().findById(order.getToId());
            return to.getType() == BusinessUnitTypeEnums.MERCHANT ? SkuNodeStateEnums.DRK : SkuNodeStateEnums.DSH;
        }
        return WmsCkObserver.super.adaptSkuNodeState(state, serialNo);
    }


    //----------------------------------------仓库wms观察者实现-----------------------------------//
    @Override
    public void update(List<WmsCk> wmsCks, SkuNodeStateEnums nodeState, String serialNo) {


        TransferOrder order = repositoryFactory.getTransferOrderRepository()
                .findByIdOrSerialNo(null, serialNo);


        Set<Integer> skuIdList = MultiUtils.toSet(wmsCks, WmsCk::getSkuId);
        List<TransferOrderLine> lineList = repositoryFactory.getTransferOrderLineRepository()
                .listByTransferIdAndSkuIds(order.getId(), skuIdList);

        switch (nodeState) {

            case QX: //取消
                doCancel(lineList, order);
                break;
            case DD: //集单
                //只要一只表集单则 调拨单修改状态为进行中
                if (order.getState() != TransferStateEnums.STARTING) {
                    order.setTransitionStateEnum(TransferStateEnums.TransitionEnum.STEP_1);
                    ValidationUtil.isTrue(
                            repositoryFactory.getTransferOrderRepository().submit(order),
                            "调拨出库单状态变更为进行中失败"
                    );

                }
                break;
            case YCK: //调拨出库
                //根据快递单号分组
                Map<String, List<WmsCk>> wmsMap = wmsCks.stream()
                        .collect(Collectors.groupingBy(WmsCk::getExpressNo));

                HashMap<String, List<TransferOrderLine>> lineMap = new HashMap<>();

                for (Map.Entry<String, List<WmsCk>> e : wmsMap.entrySet()) {
                    Set<Integer> skuIdSet = MultiUtils.toSet(e.getValue(), WmsCk::getSkuId);
                    List<TransferOrderLine> value = lineList.stream().filter(v -> skuIdSet.contains(v.getSkuId())).collect(Collectors.toList());
                    lineMap.put(e.getKey(), value);
                }
                doCk(order, lineMap);
                break;

        }
    }

    @Override
    public void updateWithoutState(List<WmsCk> wmsCks, String serialNo) {
    }


    @Override
    public Map<String, Ext> getExt(Set<String> serialNo) {
        //step_1 查找收货方数据
        List<TransferOrder> transferOrders = repositoryFactory.getTransferOrderRepository().listBySerialNos(serialNo);
        Set<Integer> toIdList = MultiUtils.toSet(transferOrders, TransferOrder::getToId);
        Map<Integer, SysBusinessUnit> toMap = MultiUtils.toMap(
                repositoryFactory.getBusinessUnitRepository().listByIds(toIdList),
                SysBusinessUnit::getId
        );

        //step_2 查找发货方数据
        Set<Integer> fromId = MultiUtils.toSet(transferOrders, TransferOrder::getFromId);
        Map<Integer, SysBusinessUnit> fromMap = MultiUtils.toMap(
                repositoryFactory.getBusinessUnitRepository().listByIds(fromId),
                SysBusinessUnit::getId
        );


        return MultiUtils.toMap(
                transferOrders,
                TransferOrder::getSerialNo,
                order -> {
                    SysBusinessUnit bu = toMap.get(order.getToId());
                    SysBusinessUnit from = fromMap.get(order.getFromId());
                    String remark = order.getRemark();
                    return TransferOrderMapping.INSTANCE.toCkExt(bu, from,remark);
                }
        );
    }


    //----------------------------------------仓库wms观察者实现-----------------------------------//


    //----------------------------------------商家wms观察者实现-----------------------------------//
    @Override
    public Ext getCkExt(String serialNo) {
        //step_1 查找收货方数据
        TransferOrder transferOrder = repositoryFactory.getTransferOrderRepository()
                .findByIdOrSerialNo(null, serialNo);
        SysBusinessUnit to = repositoryFactory.getBusinessUnitRepository().findById(transferOrder.getToId());
        //step_2 查找发货方数据
        SysBusinessUnit from = repositoryFactory.getBusinessUnitRepository().findById(transferOrder.getFromId());
        return TransferOrderMapping.INSTANCE.toCkExt(to, from,transferOrder.getRemark());
    }

    @Override
    public MerchantWmsModelEnums model() {
        return MerchantWmsModelEnums.CK;
    }

    @Override
    public List<MerchantWmsTypeEnums> typeList() {
        return merchantWmsCkWatchTypeList;
    }

    @Override
    public void update(MerchantWms main, List<MerchantWmsLine> lineList, SkuNodeStateEnums nodeState) {

        TransferOrder order = repositoryFactory.getTransferOrderRepository()
                .findByIdOrSerialNo(null, main.getSerialNo());

        Set<Integer> skuIdList = MultiUtils.toSet(lineList, MerchantWmsLine::getSkuId);

        List<TransferOrderLine> tLineList = repositoryFactory.getTransferOrderLineRepository()
                .listByTransferIdAndSkuIds(order.getId(), skuIdList);

        switch (nodeState) {
            case QX: //取消
                doCancel(tLineList, order);
                break;
            case YCK: //调拨出库
                HashMap<String, List<TransferOrderLine>> lineMap = new HashMap<>();
                lineMap.put(main.getExpressNo(), tLineList);
                //修改状态为进行中
                if (order.getState() == TransferStateEnums.WAIT_STAR) {
                    order.setTransitionStateEnum(TransferStateEnums.TransitionEnum.STEP_1);
                }
                doCk(order, lineMap);
                break;
        }


    }

    //----------------------------------------商家wms观察者实现-----------------------------------//


    /**
     * 调拨单行sku取消操作
     *
     * @param lineList 取消的行
     * @param order    订单
     */
    private void doCancel(List<TransferOrderLine> lineList, TransferOrder order) {
        //setp_1修改行状态
        lineList.forEach(line -> {
            line.setNodeState(SkuNodeStateEnums.QX);
            line.setEndState(WhetherEnum.YES);
        });
        repositoryFactory.getTransferOrderLineRepository().submitBatch(lineList);

        //step_2尝试修改调拨单状态
        stateListener.onEvent(new TransferOrderStateListener.Event(this, order.getId()));


        //step_3rpc取消
        Set<Integer> skuIdList = MultiUtils.toSet(lineList, TransferOrderLine::getSkuId);
        TransferSkuCancelRequest rpcRequest = new TransferSkuCancelRequest();
        rpcRequest.setIdList(skuIdList);
        rpcRequest.setSerialNo(order.getSerialNo());
        skuFacade.cancel(rpcRequest);

    }

    /**
     * 调拨单出库
     *
     * @param order   调拨订单
     * @param lineMap 调拨订单行
     */
    private void doCk(TransferOrder order,
                      Map<String, List<TransferOrderLine>> lineMap) {

        //step_1 调拨单赋值出库时间
        Date now = new Date();
        order.setSpTime(now);
        ValidationUtil.isTrue(
                repositoryFactory.getTransferOrderRepository().submit(order),
                "调拨单出库时间修改失败"
        );

        //step_2 修改调拨单行状态为已出库
        List<TransferOrderLine> lineListTemp = lineMap.values()
                .stream()
                .flatMap(Collection::stream).collect(Collectors.toList());

        lineListTemp.forEach(line -> line.setNodeState(SkuNodeStateEnums.YCK));
        repositoryFactory.getTransferOrderLineRepository().submitBatch(lineListTemp);


        //step_3 根据调入方的业务单元类型来判断推送至wms仓库还是商家仓库
        SysBusinessUnit to = repositoryFactory.getBusinessUnitRepository().findById(order.getToId());

        //根据不同快递单号分组创建
        for (Map.Entry<String, List<TransferOrderLine>> entry : lineMap.entrySet()) {
            String expressNo = entry.getKey();
            List<TransferOrderLine> lineList = entry.getValue();

            if (to.getType() == BusinessUnitTypeEnums.WAREHOUSE) { //推送仓库wms
                //生成入库单
                List<WmsRk> rkList = MultiUtils.toList(
                        lineList,
                        line -> TransferOrderMapping.INSTANCE.toWmsRk(
                                order,
                                line,
                                order.getToId(),
                                expressNo
                        )
                );
                wmsSubject.rkDateSubmit(rkList);
            } else { //推送商家wms

                List<MerchantWmsLine> merchantWmsLines = MultiUtils.toList(
                        lineList,
                        v -> TransferOrderLineMapping.INSTANCE.toMerchantWmsLine(v, SkuNodeStateEnums.DRK)
                );

                Integer totalCount = 0;
                BigDecimal amount = BigDecimal.ZERO;

                for (MerchantWmsLine l : merchantWmsLines) {
                    totalCount += l.getCount();
                    amount = amount.add(l.getPrice());
                }

                //推送商家仓库
                SysBusinessUnit from = repositoryFactory.getBusinessUnitRepository().findById(order.getFromId());
                ContactInfo contactInfo = TransferOrderMapping.INSTANCE.toMerchantWmsContactInfo(from);
                MerchantWms merchantWms = TransferOrderMapping.INSTANCE.toMerchantWms(
                        order,
                        contactInfo,
                        MerchantWmsModelEnums.RK,
                        MerchantWmsTypeEnums.DB_RK,
                        null,
                        order.getToId()
                );
                merchantWms.setExpressNo(expressNo);
                merchantWms.setTotalCount(totalCount);
                merchantWms.setAmount(amount);


                wmsSubject.merchantWmsDataCreate(merchantWms, merchantWmsLines);
            }


        }
    }


}
