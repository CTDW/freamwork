package com.seeease.flywheel_v4.web.app.sale.result;


import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;


@Data
public class ThirdSaleOrderDetailResult {


    /**
     * 三方单号
     */
    private String thirdPartyNo;

    /**
     * 销售渠道
     */
    private Integer scType;

    /**
     * 销售渠道名称
     */
    private String scName;

    /**
     * 状态
     */
    private Integer state;
    /**
     * 客户名称
     */
    private String buyerName;
    /**
     * 总金额
     */
    private BigDecimal totalAmount;
    /**
     * 备注
     */
    private String remark;
    /**
     * 创建人
     */
    private Date auditTime;
    /**
     * 创建时间
     */
    private Date createdTime;





}
