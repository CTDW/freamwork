package com.seeease.flywheel_v4.web.app.operations.service;

import com.seeease.flywheel_v4.web.app.operations.request.SupplierContactSubmitRequest;
import com.seeease.flywheel_v4.web.app.operations.result.SupplierContactListResult;

/**
 * <p>供应商客户</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/4/24 4:43 下午
 **/
public interface SupplierContactsService {

    /**
     * 联系人删除更新
     *
     * @return 删除结果
     */
    Boolean del(Integer id);
    /**
     * 联系人创建
     *
     * @return 创建结果
     */
    SupplierContactListResult create(SupplierContactSubmitRequest request);
}
