package com.seeease.flywheel_v4.web.app.transfer.result;


import com.seeease.goods.rpc.request.SkuAnnexeRpcResult;
import com.seeease.goods.rpc.result.ProductParamRpcResult;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * @author 西门 游
 * @version 1.0
 * @since 6/3/24 11:26 上午
 **/
@Data
public class TransferDetailResult {
    /**
     * 主键id
     */
    private Integer id;
    /**
     * 编号
     */
    private String serialNo;
    /**
     * 调拨类型
     */
    private Integer type;
    /**
     * 调出方
     */
    private String fromName;
    /**
     * 调入方
     */
    private String toName;
    /**
     * 调拨单状态
     */
    private Integer state;
    /**
     * 备注
     */
    private String remark;
    /**
     * 创建人
     */
    private String createdBy;
    /**
     * 创建时间
     */
    private Date createdTime;
    /**
     * 收货时间
     */
    private Date recTime;
    /**
     * 发货时间
     */
    private Date spTime;
    /**
     * sku列表
     */
    private List<Sku> skuList;

    /**
     * 总数量
     */
    private Integer totalCount;
    /**
     * 总结算价
     */
    private BigDecimal totalSettlePrice;
    /**
     * 总最新结算价
     */
    private BigDecimal totalNewSettlePrice;
    /**
     * 总利润
     */
    private BigDecimal totalProfit;




    @Data
    public static class Sku{
        /**
         * 调拨业务单据行id
         */
        private Integer lineId;
        /**
         * skuId
         */
        private Integer skuId;
        /**
         * 商品名称
         */
        private String goodsName;
        /**
         * 类目
         */
        private String categoryName;
        /**
         * 品牌
         */
        private String brandName;
        /**
         * 节点状态
         */
        private Integer nodeState;
        /**
         * 结算价
         */
        private BigDecimal settlePrice;
        /**
         * 最新结算价
         */
        private BigDecimal newSettlePrice;
        /**
         * 调拨价
         */
        private BigDecimal transferPrice;
        /**
         * 调拨数量
         */
        private Integer count;
        /**
         * sku参数列表
         */
        private List<ProductParamRpcResult> skuParams;
        /**
         * 附件
         */
        private List<SkuAnnexeRpcResult> annexe;
        /**
         * 唯一码
         */
        private String skuCode;

        /**
         * 图片
         */
        private String spuImage;
        /**
         * 类目id
         */
        private Integer categoryId;

        /**
         * 利润
         */
        private BigDecimal profit;
    }

}
