package com.seeease.flywheel_v4.web.app.operations.service;

import com.seeease.flywheel_v4.web.app.operations.request.SupplierQuotaAuditRequest;
import com.seeease.flywheel_v4.web.app.operations.request.SupplierQuotaAuditDetailRequest;
import com.seeease.flywheel_v4.web.app.operations.request.SupplierQuotaAuditPageRequest;
import com.seeease.flywheel_v4.web.app.operations.request.SupplierQuotaTopUpRequest;
import com.seeease.flywheel_v4.web.app.operations.result.SupplierQuotaAuditDetailResult;
import com.seeease.flywheel_v4.web.app.operations.result.SupplierQuotaAuditPageResult;
import com.seeease.springframework.PageResult;

/**
 * <p>供应商</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/4/24 4:43 下午
 **/
public interface SupplierQuotaAuditService {

    /**
     * 系统运营-供应商保证金充值
     *
     * @return 创建结果
     */
    Boolean create(SupplierQuotaTopUpRequest request);

    /**
     * 系统运营-供应商保证金充值记录审核
     *
     * @return 审核结果
     */
    Boolean audit(SupplierQuotaAuditRequest request);
    /**
     * 系统运营-供应商保证金充值记录分页
     *
     * @return 分页结果
     */
    PageResult<SupplierQuotaAuditPageResult> page(SupplierQuotaAuditPageRequest request);

    /**
     * 系统运营-供应商保证金充值记录详情
     *
     * @return 详情
     */
    SupplierQuotaAuditDetailResult detail(SupplierQuotaAuditDetailRequest request);

}
