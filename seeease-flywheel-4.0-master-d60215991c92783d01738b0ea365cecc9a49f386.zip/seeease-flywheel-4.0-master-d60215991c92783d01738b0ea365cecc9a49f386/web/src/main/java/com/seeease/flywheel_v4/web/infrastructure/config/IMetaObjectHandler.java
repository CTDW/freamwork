package com.seeease.flywheel_v4.web.infrastructure.config;


import com.seeease.seeeaseframework.mybatis.handlers.DefaultMetaObjectHandler;
import com.seeease.springframework.context.LoginStore;
import com.seeease.springframework.context.LoginUser;
import com.seeease.springframework.context.UserContext;
import org.apache.ibatis.reflection.MetaObject;
import org.springframework.context.annotation.Configuration;

import java.util.Date;
import java.util.Optional;

/**
 * 覆盖组件{@link DefaultMetaObjectHandler} 身份标识获取规则
 * @ Author        :  西门 游
 * @ CreateDate    :  10/25/23
 * @ Version       :  1.0
 */
@Configuration
public class IMetaObjectHandler extends DefaultMetaObjectHandler {


    @Override
    public void updateFill(MetaObject metaObject) {
        Identity identity = Optional.ofNullable(getIdentity()).orElse(DEFAULT_IDENTITY);
        this.setFieldValByName( "updatedTime", new Date(),metaObject);
        this.setFieldValByName("updatedId",identity.getId(),metaObject);
        this.setFieldValByName("updatedBy",identity.getName(),metaObject);

    }


    @Override
    public void insertFill(MetaObject metaObject) {
        LoginUser user = UserContext.getUser();
        if (null != user){
            LoginStore store = user.getStore();
            if (store != null){
                this.strictInsertFill(metaObject, "buId", Integer.class, store.getId());
            }

        }
        super.insertFill(metaObject);
    }

}
