package com.seeease.flywheel_v4.web.app.excel.result;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 9/11/24 5:00 下午
 **/
@Data
public class PurchaseSkuImportResult implements Serializable {
    /**
     * 唯一类型
     */
    private Integer uniqueType;
    /**
     * spuId
     */
    private Integer spuId;

    /**
     * 附件
     */
    private List<SkuAnnexe> annexe;
    /**
     * 类目名称
     */
    private String categoryName;
    /**
     * 品牌名称
     */
    private String brandName;
    /**
     * 数量
     */
    private Integer count = 1;
    /**
     * 商品名称
     */
    private String goodsName;
    /**
     * 唯一编码
     */
    private String skuCode;
    /**
     * 采购价
     */
    private BigDecimal purchasePrice;
    /**
     * spu图片
     */
    private String spuImage;
    /**
     * 参数
     */
    private List<SkuParam> skuParams;




    @Data
    public static class SkuParam implements Serializable{
        private String paramName;
        private String paramCode;
        private List<String> paramValue;
    }


    @Data
    public static class SkuAnnexe implements Serializable{
        private String paramName;
        private Integer selectType;
        private boolean selected = true;
        private String value;
    }
}
