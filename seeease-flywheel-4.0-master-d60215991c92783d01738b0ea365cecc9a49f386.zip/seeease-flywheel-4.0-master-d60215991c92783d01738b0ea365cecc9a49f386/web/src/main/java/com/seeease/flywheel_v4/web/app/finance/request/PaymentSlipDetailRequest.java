package com.seeease.flywheel_v4.web.app.finance.request;


import com.seeease.springframework.PageRequest;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @ Description   :
 * @ Author        :  西门 游
 * @ CreateDate    :  6/6/24
 * @ Version       :  1.0
 */

@EqualsAndHashCode(callSuper = true)
@Data
public class PaymentSlipDetailRequest extends PageRequest {
    /**
     * 打款单号
     */
    private String serialNo;
    /**
     * 打款单id
     */
    private Integer id;
}
