package com.seeease.flywheel_v4.web.infrastructure.dao.fix.repo;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.seeease.flywheel_v4.web.app.fix.common.FixPartsDto;
import com.seeease.flywheel_v4.web.app.fix.request.FixOrderPageRequest;
import com.seeease.flywheel_v4.web.app.fix.request.FixOrderPartPageRequest;
import com.seeease.flywheel_v4.web.infrastructure.dao.fix.entity.FixOrder;
import com.seeease.flywheel_v4.web.infrastructure.dao.fix.entity.FixOrderPart;

import java.util.List;

/**
 * @Description 维修日志
 * @Date 2024-10-2 21:04
 * @Author by hk
 */
public interface FixOrderPartRepository {


    /**
     * 分页
     *
     * @param request 请求
     * @return 维修配件
     */
    Page<FixOrderPart> page(FixOrderPartPageRequest request);

    /**
     * 根据维修单号查询 维修配件
     *
     * @param fixOrderNumber 维修单号
     * @return 数据
     */
    List<FixOrderPart> getFixPartByNumber(String fixOrderNumber);

    /**
     * 维修单新增时，同时新增配件信息
     *
     * @param partList       配件
     * @param fixOrderNumber 维修单号
     * @return 结果
     */
    Boolean save(List<FixPartsDto> partList, String fixOrderNumber);

    /**
     * 维修单编辑时，同时编辑配件信息
     *
     * @param partList       配件
     * @param fixOrderNumber 维修单号
     * @return 结果
     */
    Boolean update(List<FixPartsDto> partList, String fixOrderNumber);
}
