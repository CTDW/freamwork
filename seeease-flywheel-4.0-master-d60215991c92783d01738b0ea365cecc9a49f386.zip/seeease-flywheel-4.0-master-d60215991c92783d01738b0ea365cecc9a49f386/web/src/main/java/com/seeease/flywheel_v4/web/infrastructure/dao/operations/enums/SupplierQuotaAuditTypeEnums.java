package com.seeease.flywheel_v4.web.infrastructure.dao.operations.enums;

import com.baomidou.mybatisplus.annotation.IEnum;
import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @ Description   :  供应商类型
 * @ Author        :  西门 游
 * @ CreateDate    :  6/4/24
 * @ Version       :  1.0
 */
@Getter
@AllArgsConstructor
public enum SupplierQuotaAuditTypeEnums implements IEnum<Integer> {
    JS(1,"寄售货值"),
    NORMAL(2,"正常余额")
    ;

    private Integer value;
    private String desc;
}
