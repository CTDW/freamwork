package com.seeease.flywheel_v4.web.infrastructure.dao.operations.repo.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.SupplierQuotaDetail;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.enums.SupplierQuotaAuditTypeEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.mapper.SupplierQuotaDetailMapper;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.repo.SupplierQuotaDetailRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author 西门 游
 * @version 1.0
 * @since 5/31/24 4:55 下午
 **/
@Repository
public class SupplierQuotaDetailRepositoryImpl extends ServiceImpl<SupplierQuotaDetailMapper, SupplierQuotaDetail>
        implements SupplierQuotaDetailRepository {

    @Override
    public SupplierQuotaDetail findOne(Integer quotaId,Integer userid, SupplierQuotaAuditTypeEnums type) {
        LambdaQueryWrapper<SupplierQuotaDetail> wq = Wrappers.<SupplierQuotaDetail>lambdaQuery()
                .eq(SupplierQuotaDetail::getQuotaId, quotaId)
                .eq(SupplierQuotaDetail::getUserid, userid)
                .eq(SupplierQuotaDetail::getAmountType, type);
        return baseMapper.selectOne(wq);
    }

    @Override
    public Boolean submit(SupplierQuotaDetail detail) {
        return saveOrUpdate(detail);
    }

    @Override
    public List<SupplierQuotaDetail> listByMainId(Integer mainId) {
        LambdaQueryWrapper<SupplierQuotaDetail> wq = Wrappers.<SupplierQuotaDetail>lambdaQuery()
                .eq(SupplierQuotaDetail::getQuotaId, mainId);
        return baseMapper.selectList(wq);
    }

    @Override
    public SupplierQuotaDetail findById(Integer id) {
        return baseMapper.selectById(id);
    }
}
