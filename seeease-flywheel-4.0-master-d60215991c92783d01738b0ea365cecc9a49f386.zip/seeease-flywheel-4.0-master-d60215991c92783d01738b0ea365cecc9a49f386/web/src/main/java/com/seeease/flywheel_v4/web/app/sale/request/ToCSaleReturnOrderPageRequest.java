package com.seeease.flywheel_v4.web.app.sale.request;


import com.fasterxml.jackson.annotation.JsonFormat;
import com.seeease.springframework.PageRequest;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Date;
import java.util.Set;


@EqualsAndHashCode(callSuper = true)
@Data
public class ToCSaleReturnOrderPageRequest extends PageRequest {
    /**
     * ids
     */
    private Set<Integer> ids;
    /**
     * 唯一码
     */
    private String skuCode;
    /**
     * 销售单号
     */
    private String saleSerialNo;
    /**
     * 销售渠道
     */
    private Integer scType;

    /**
     * 销售方式
     */
    private Integer sellType;

    /**
     * 客户名称
     */
    private String buyerName;
    /**
     * 商品所在
     */
    private Integer belongId;

    /**
     * 订单来源
     */
    private Integer originId;
    /**
     * 订单状态
     */
    private Integer state;

    /**
     * 退货单号
     */
    private String serialNo;

    /**
     * 快递单号
     */
    private String expressNo;

    /**
     * 开始时间
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date startTime;
    /**
     * 结束时间
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date endTime;

    /**
     * 完成开始时间
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date finishStartTime;
    /**
     * 完成结束时间
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date finishEndTime;

    /**
     * 当前用户部门id 权限控制
     */
    private Integer buId;



}
