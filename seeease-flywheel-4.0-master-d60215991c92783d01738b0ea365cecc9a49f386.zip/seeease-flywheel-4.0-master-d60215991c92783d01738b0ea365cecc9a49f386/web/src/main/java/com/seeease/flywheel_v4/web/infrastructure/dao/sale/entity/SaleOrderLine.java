package com.seeease.flywheel_v4.web.infrastructure.dao.sale.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.entity.obj.BuyBackPolicyObj;
import com.seeease.goods.rpc.enums.SkuNodeStateEnums;
import com.seeease.seeeaseframework.mybatis.domain.BaseDomain;
import com.seeease.seeeaseframework.mybatis.domain.WhetherEnum;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * 销售订单行
 */
@EqualsAndHashCode(callSuper = true)
@TableName(value = "v4_sale_order_line", autoResultMap = true)
@Data
public class SaleOrderLine extends BaseDomain {
    @TableId(type = IdType.AUTO)
    private Integer id;
    /**
     * 采购单id
     */
    private Integer saleId;
    /**
     * skuId
     */
    private Integer skuId;

    /**
     * 数量
     */
    private Integer count;
    /**
     * 寄售价
     */
    private BigDecimal consignmentPrice;
    /**
     * 寄售人
     */
    private String settledBy;
    /**
     * b价
     */
    private BigDecimal tobPrice;
    /**
     * c价
     */
    private BigDecimal tocPrice;
    /**
     * 经营权
     */
    private Integer sellerId;
    /**
     * 商品所在
     */
    private Integer storeId;
    /**
     * tocGmv
     */
    private BigDecimal gmvc;
    /**
     * 成交价
     */
    private BigDecimal dealPrice;
    /**
     * 最新结算价
     */
    private BigDecimal newSettlePrice;

    /**
     * 表带根换费
     */
    private BigDecimal strapPrice;

    /**
     * 绩效价
     */
    private BigDecimal perfPrice;

    /**
     * 表节数
     */
    private Integer strapCount;

    /**
     * sku节点状态
     */
    private SkuNodeStateEnums nodeState;

    /**
     * 是否为终态
     */
    private WhetherEnum endState;

    /**
     * 完成时间
     */
    private Date finishTime;

    /**
     * 回购政策
     */
    @TableField(typeHandler = BuyBackPolicyObj.BuyBackPolicyHandler.class)
    private List<BuyBackPolicyObj> policies;


}