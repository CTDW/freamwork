package com.seeease.flywheel_v4.web.app.fix.result;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * @Description 维修中心-维修单 状态-数量
 * @Date 2024-10-2 20:20
 * @Author by hk
 */
@Data
public class FixStatusCountResult implements Serializable {

    @ApiModelProperty(value = "维修单状态 1：维修登记 2：待接修 3：维修中 4：抛光中 5：清洗中 6：师傅组装 7：质检中 " +
            "8：待维修出库 9：送外维修 10：等配件 11：已完成 12:已取消")
    private Integer orderStatus;

    @ApiModelProperty(value = "数量")
    private Long count;
}
