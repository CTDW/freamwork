package com.seeease.flywheel_v4.web.app.operations.request;

import com.seeease.springframework.PageRequest;
import lombok.Data;
import lombok.EqualsAndHashCode;


@EqualsAndHashCode(callSuper = true)
@Data
public class SupplierQuotaPageRequest extends PageRequest {


    /**
     * 客户名称
     */
    private String supplierName;


}
