package com.seeease.flywheel_v4.web.app.fix.common;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * @Description 维修师 得分
 * @Date 2024-10-4 16:56
 * @Author by hk
 */
@Data
public class FixMasterScoreDto implements Serializable {

    @ApiModelProperty(value = "维修师id")
    private Long fixMasterId;

    @ApiModelProperty(value = "维修师名称")
    private String fixMaster;

    @ApiModelProperty(value = "分数 1-5分")
    private Integer score;
}
