package com.seeease.flywheel_v4.web.app.sale.service;

import com.seeease.flywheel_v4.web.app.sale.request.ThirdSaleOrderConfirmRequest;
import com.seeease.flywheel_v4.web.app.sale.request.ThirdSaleOrderMergeRequest;
import com.seeease.flywheel_v4.web.app.sale.request.ThirdSaleOrderPageRequest;
import com.seeease.flywheel_v4.web.app.sale.result.ThirdSaleOrderMergeResult;
import com.seeease.flywheel_v4.web.app.sale.result.ThirdSaleOrderPageResult;
import com.seeease.springframework.PageResult;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 8/2/24 2:04 下午
 **/
public interface ThirdSaleOrderService {

    /**
     * 销售-三方销售单分页
     *
     * @return 分页结果
     */
    PageResult<ThirdSaleOrderPageResult> page(ThirdSaleOrderPageRequest request);


    /**
     * 销售-三方销售单审核通过
     *
     * @return 分页结果
     */
    Boolean confirm(ThirdSaleOrderConfirmRequest request);


    /**
     销售-三方销售单合并详情
     */
    ThirdSaleOrderMergeResult mergeDetail(ThirdSaleOrderMergeRequest request);
}
