package com.seeease.flywheel_v4.web.app.wms.result;

import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/4/24 6:00 下午
 **/
@Data
public class MerchantWmsPageResult {
    /**
     * id
     */
    private Integer id;
    /**
     * 业务单号
     */
    private String serialNo;
    /**
     * 状态
     */
    private Integer state;
    /**
     * 类型
     */
    private Integer type;
    /**
     * 金额
     */
    private BigDecimal amount;
    /**
     * 总数量
     */
    private Integer totalCount;
    /**
     * 订单来源
     */
    private String originName;
    /**
     * 收货方
     */
    private String toName;
    /**
     * 发货方
     */
    private String fromName;

    /**
     * 备注
     */
    private String remark;
    /**
     * 创建人
     */
    private String createdBy;
    /**
     * 创建时间
     */
    private Date createdTime;
}
