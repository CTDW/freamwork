package com.seeease.flywheel_v4.web.domain.wms.observer;

import com.alibaba.fastjson.JSONObject;
import com.doudian.open.api.order_logisticsAddSinglePack.OrderLogisticsAddSinglePackRequest;
import com.doudian.open.api.order_logisticsAddSinglePack.OrderLogisticsAddSinglePackResponse;
import com.doudian.open.api.order_logisticsAddSinglePack.param.OrderLogisticsAddSinglePackParam;
import com.doudian.open.api.order_logisticsAddSinglePack.param.ShippedOrderInfoItem;
import com.doudian.open.core.AccessToken;
import com.kuaishou.merchant.open.api.KsMerchantApiException;
import com.kuaishou.merchant.open.api.client.AccessTokenKsMerchantClient;
import com.kuaishou.merchant.open.api.request.order.OpenSellerOrderGoodsDeliverRequest;
import com.kuaishou.merchant.open.api.response.order.OpenSellerOrderGoodsDeliverResponse;
import com.seeease.flywheel_v4.web.app.sale.rpc.KsComponent;
import com.seeease.flywheel_v4.web.domain.sale.mapping.SaleOrderLineMapping;
import com.seeease.flywheel_v4.web.domain.sale.mapping.SaleOrderMapping;
import com.seeease.flywheel_v4.web.domain.wms.observer.base.Ext;
import com.seeease.flywheel_v4.web.domain.wms.observer.base.MerchantWmsObserver;
import com.seeease.flywheel_v4.web.domain.wms.observer.base.WmsCkObserver;
import com.seeease.flywheel_v4.web.infrastructure.dao.RepositoryFactory;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.*;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.enums.SupplierQuotaAuditTypeEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.enums.SupplierQuotaLogTypeEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.entity.SaleOrder;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.entity.SaleOrderLine;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.entity.ThirdSaleOrder;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.entity.obj.BuyerInfoObj;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.enums.SaleModelEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.enums.SaleTypeEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.enums.ThirdSaleStateEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.entity.SysBusinessUnit;
import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.entity.SysSaleChannel;
import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.entity.SysUser;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.MerchantWms;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.MerchantWmsLine;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.WmsCk;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.MerchantWmsModelEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.MerchantWmsTypeEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.WmsCkTypeEnums;
import com.seeease.flywheel_v4.web.infrastructure.listener.SaleOrderStateListener;
import com.seeease.frameworktiktok.api.TikTokShopApi;
import com.seeease.goods.rpc.SkuFacade;
import com.seeease.goods.rpc.enums.SkuNodeStateEnums;
import com.seeease.goods.rpc.request.SaleSkuCancelRpcRequest;
import com.seeease.goods.rpc.request.SaleSkuFinishRpcRequest;
import com.seeease.seeeaseframework.mybatis.domain.WhetherEnum;
import com.seeease.springframework.exception.ValidationUtil;
import com.seeease.springframework.utils.MultiUtils;
import com.seeease.springframework.utils.StringUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.dubbo.config.annotation.DubboReference;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;

/**
 * <p
 * 销售出库观察者
 * </p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/21/24 2:46下午
 **/
@Slf4j
@Component
public class SaleCkObserver extends SaleBaseObserver
        implements WmsCkObserver, MerchantWmsObserver {

    @Resource
    private RepositoryFactory repositoryFactory;

    @DubboReference(version = "1.0.0", check = false)
    private SkuFacade skuFacade;

    @Resource
    private SaleOrderStateListener stateListener;

    @Resource
    private TikTokShopApi tikTokShopApi;

    @Resource
    private KsComponent ksComponent;


    @Override
    public SkuNodeStateEnums adaptSkuNodeState(SkuNodeStateEnums state, String serialNo) {
        return null;
    }


    //----------------------------------------仓库wms观察者实现-----------------------------------//


    @Override
    public Map<String, Ext> getExt(Set<String> serialNo) {
        List<SaleOrder> saleOrderList = repositoryFactory.getSaleOrderRepository()
                .listBySerialNos(serialNo);

        Set<Integer> saleOrderIds = MultiUtils.toSet(saleOrderList, SaleOrder::getId);
        Map<Integer, List<SaleOrderLine>> saleOrderLineMap = repositoryFactory.getSaleOrderLineRepository()
                .listByMainIds(saleOrderIds)
                .stream()
                .collect(Collectors.groupingBy(SaleOrderLine::getSaleId));


        Map<Integer, SupplierContacts> contactMap = new HashMap<>();
        Map<Integer, Supplier> supplierMap = new HashMap<>();

        //step_1 内部订单客户
        Set<Integer> contactIds = MultiUtils.toSet(saleOrderList, SaleOrder::getBuyerId);
        if (StringUtils.isNotEmpty(contactIds)) {
            contactMap = MultiUtils.toMap(
                    repositoryFactory.getSupplierContactsRepository().listByIds(contactIds),
                    SupplierContacts::getId
            );

            Set<Integer> supplierIds = MultiUtils.toSet(
                    contactMap.values(),
                    SupplierContacts::getSupplierId
            );
            supplierMap = MultiUtils.toMap(
                    repositoryFactory.getSupplierRepository().listByIds(supplierIds),
                    Supplier::getId
            );
        }

        //step_2 三方订单客户
        Map<String, ThirdSaleOrder> thirdOrderMap = new HashMap<>();
        Set<String> thirdPartNos = MultiUtils.toSet(saleOrderList, SaleOrder::getThirdPartyNo);


        if (StringUtils.isNotEmpty(thirdPartNos)) {
            List<ThirdSaleOrder> thirdSaleOrders = repositoryFactory.getThirdSaleOrderRepository()
                    .listByOrderIds(thirdPartNos);

            thirdOrderMap = MultiUtils.toMap(
                    thirdSaleOrders,
                    ThirdSaleOrder::getOrderId
            );
        }


        //step_3 发货方数据
        Set<Integer> fromIds = MultiUtils.toSet(saleOrderList, SaleOrder::getStoreId);
        Map<Integer, SysBusinessUnit> fromMap = MultiUtils.toMap(
                repositoryFactory.getBusinessUnitRepository().listByIds(fromIds),
                SysBusinessUnit::getId
        );

        //step_4 销售渠道配置获取
        Set<Integer> scIds = MultiUtils.toSet(saleOrderList, SaleOrder::getScId);
        Map<Integer, SysSaleChannel> scMap = MultiUtils.toMap(
                repositoryFactory.getSaleChannelRepository().listByIds(scIds),
                SysSaleChannel::getId
        );

        //step_5 销售员
        Set<Integer> sellerIds = new HashSet<>();
        saleOrderList.forEach(order -> {
            if (null != order.getSellerAId()) {
                sellerIds.add(order.getSellerAId());
            }
            if (null != order.getSellerBId()) {
                sellerIds.add(order.getSellerBId());
            }
            if (null != order.getSellerCId()) {
                sellerIds.add(order.getSellerCId());
            }
        });

        Map<Integer, String> userMap = MultiUtils.toMap(
                repositoryFactory.getUserRepository().listByIds(sellerIds),
                SysUser::getId,
                SysUser::getName
        );


        Map<String, ThirdSaleOrder> finalThirdBuyerMap = thirdOrderMap;
        Map<Integer, SupplierContacts> finalContactMap = contactMap;
        Map<Integer, Supplier> finalSupplierMap = supplierMap;
        return MultiUtils.toMap(
                saleOrderList,
                SaleOrder::getSerialNo,
                order -> {
                    //销售人
                    String seller = "";
                    String userA = userMap.get(order.getSellerAId());
                    if (null != userA) {
                        seller = seller + userA;
                    }
                    String userB = userMap.get(order.getSellerBId());
                    if (null != userB) {
                        seller = seller + "-" + userB;
                    }
                    String userC = userMap.get(order.getSellerCId());
                    if (null != userC) {
                        seller = seller + "-" + userC;
                    }

                    //回购政策
                    List<SaleOrderLine> lineList = saleOrderLineMap.get(order.getId());
                    ArrayList<Ext.SkuExt> skuExts = new ArrayList<>();
                    lineList.forEach(line -> {
                        Ext.SkuExt skuExt = new Ext.SkuExt();
                        skuExt.setSkuId(line.getSkuId());
                        skuExt.setPolicies(line.getPolicies());
                        skuExt.setDealPrice(line.getDealPrice());
                        skuExts.add(skuExt);
                    });


                    String address, phone, name, province, city, area, street;
                    ThirdSaleOrder thirdSaleOrder = null;
                    if (null == order.getBuyerId()) {
                        thirdSaleOrder = finalThirdBuyerMap.get(order.getThirdPartyNo());
                        BuyerInfoObj buyer = thirdSaleOrder.getBuyerInfo();
                        address = buyer.getCompleteAddress();
                        name = buyer.getRec();
                        phone = buyer.getTel();
                        province = buyer.getProvince();
                        city = buyer.getCity();
                        area = buyer.getTown();
                        street = buyer.getStreet();
                    } else {
                        SupplierContacts contact = finalContactMap.get(order.getBuyerId());
                        Supplier supplier = finalSupplierMap.get(contact.getSupplierId());
                        address = supplier.getCompleteAddress();
                        name = contact.getName();
                        phone = contact.getPhone();
                        province = supplier.getProvince();
                        city = supplier.getCity();
                        area = supplier.getArea();
                        street = supplier.getStreet();
                    }
                    SysBusinessUnit from = fromMap.get(order.getStoreId());
                    SysSaleChannel sc = null;
                    if (null != order.getScId()) {
                        sc = scMap.get(order.getScId());
                    }

                    return SaleOrderMapping.INSTANCE.toCkExt(
                            address,
                            phone,
                            name,
                            province,
                            city,
                            area,
                            street,
                            order,
                            from,
                            sc,
                            thirdSaleOrder,
                            skuExts,
                            seller
                    );
                }
        );
    }

    @Override
    public List<WmsCkTypeEnums> getWatchDataType() {
        return wmsCkWatchTypeList;
    }

    @Override
    public void update(List<WmsCk> wmsCks, SkuNodeStateEnums nodeState, String serialNo) {

        SaleOrder order = repositoryFactory.getSaleOrderRepository()
                .findByIdOrSerialNo(null, serialNo);

        Set<Integer> skuIdList = MultiUtils.toSet(wmsCks, WmsCk::getSkuId);

        List<SaleOrderLine> lineList = repositoryFactory.getSaleOrderLineRepository()
                .listBySaleIdAndSkuIds(order.getId(), skuIdList);

        switch (nodeState) {

            case QX: //取消
                doCancel(lineList, order);
                break;
            case YCK: //调拨出库
                WmsCk ck = wmsCks.get(0);
                doCk(lineList, order, ck.getExpressNo());
                break;
            default:
                lineList.forEach(line -> line.setNodeState(nodeState));
                repositoryFactory.getSaleOrderLineRepository().submitBatch(lineList);
        }
    }


    //----------------------------------------仓库wms观察者实现-----------------------------------//


    //----------------------------------------商家wms观察者实现-----------------------------------//

    @Override
    public Ext getCkExt(String serialNo) {
        SaleOrder saleOrder = repositoryFactory.getSaleOrderRepository()
                .findByIdOrSerialNo(null, serialNo);


        String address, phone, name, province, city, area, street;
        ThirdSaleOrder thirdSaleOrder = null;
        if (null != saleOrder.getBuyerId()) {
            SupplierContacts contact = repositoryFactory.getSupplierContactsRepository().findById(saleOrder.getBuyerId());
            Supplier supplier = repositoryFactory.getSupplierRepository().findById(contact.getSupplierId());
            address = supplier.getCompleteAddress();
            name = contact.getName();
            phone = contact.getPhone();
            province = supplier.getProvince();
            city = supplier.getCity();
            area = supplier.getArea();
            street = supplier.getStreet();
        } else {
            thirdSaleOrder = repositoryFactory.getThirdSaleOrderRepository().findByOrderId(saleOrder.getThirdPartyNo());
            BuyerInfoObj buyer = thirdSaleOrder.getBuyerInfo();
            address = buyer.getCompleteAddress();
            name = buyer.getRec();
            phone = buyer.getTel();
            province = buyer.getProvince();
            city = buyer.getCity();
            area = buyer.getTown();
            street = buyer.getStreet();
        }

        //step_3 发货方数据
        SysBusinessUnit from = repositoryFactory.getBusinessUnitRepository().findById(saleOrder.getStoreId());


        //step_4 销售渠道配置获取
        SysSaleChannel saleChannel = null;
        if (null != saleOrder.getScId()) {
            saleChannel = repositoryFactory.getSaleChannelRepository().findById(saleOrder.getScId());
        }


        return SaleOrderMapping.INSTANCE.toCkExt(
                address,
                phone,
                name,
                province,
                city,
                area,
                street,
                saleOrder,
                from,
                saleChannel,
                thirdSaleOrder,
                null,
                null
        );
    }


    @Override
    public MerchantWmsModelEnums model() {
        return MerchantWmsModelEnums.CK;
    }


    @Override
    public List<MerchantWmsTypeEnums> typeList() {
        return merchantWmsCkWatchTypeList;
    }

    @Override
    public void update(MerchantWms main, List<MerchantWmsLine> rkList, SkuNodeStateEnums nodeState) {


        SaleOrder order = repositoryFactory.getSaleOrderRepository()
                .findByIdOrSerialNo(null, main.getSerialNo());

        Set<Integer> skuIdList = MultiUtils.toSet(rkList, MerchantWmsLine::getSkuId);

        List<SaleOrderLine> lineList = repositoryFactory.getSaleOrderLineRepository()
                .listBySaleIdAndSkuIds(order.getId(), skuIdList);

        switch (nodeState) {
            case QX: //取消
                doCancel(lineList, order);
                break;
            case YCK: //调拨出库
                log.info("merchant wms ck data:{}",JSONObject.toJSONString(main));
                doCk(lineList, order, main.getExpressNo());
                break;
        }
    }

    //----------------------------------------商家wms观察者实现-----------------------------------//


    /**
     * 销售取消出库
     *
     * @param lineList 取消的行
     * @param order    订单
     */
    private void doCancel(List<SaleOrderLine> lineList, SaleOrder order) {
        //step_1修改行状态
        lineList.forEach(line -> {
            line.setNodeState(SkuNodeStateEnums.QX);
            line.setEndState(WhetherEnum.YES);
        });

        repositoryFactory.getSaleOrderLineRepository().submitBatch(lineList);

        //step_2尝试修改调拨单状态
        stateListener.onEvent(new SaleOrderStateListener.Event(this, order.getId()));


        //step_3 rpc取消
        SaleSkuCancelRpcRequest rpcRequest = new SaleSkuCancelRpcRequest();
        List<SaleSkuCancelRpcRequest.Sku> skuList = MultiUtils.toList(
                lineList,
                SaleOrderLineMapping.INSTANCE::toRpcCancelSku
        );
        rpcRequest.setSkuList(skuList);
        rpcRequest.setSerialNo(order.getSerialNo());
        skuFacade.cancel(rpcRequest);


        //step_4 尝试取消三方订单
        if (StringUtils.isNotEmpty(order.getThirdPartyNo())) {
            ThirdSaleOrder thirdSaleOrder = repositoryFactory.getThirdSaleOrderRepository().findByOrderId(order.getThirdPartyNo());
            if (null != thirdSaleOrder && thirdSaleOrder.getState() != ThirdSaleStateEnums.CANCEL) {
                thirdSaleOrder.setState(ThirdSaleStateEnums.WAIT);
                repositoryFactory.getThirdSaleOrderRepository().submit(thirdSaleOrder);
            }
        }

        //step_5 如果是同行销售则回滚保证金余额
        if (order.getModel() == SaleModelEnums.B) {

            SupplierQuotaAuditTypeEnums auditType = null;
            if (order.getSellType() == SaleTypeEnums.ZC) {
                auditType = SupplierQuotaAuditTypeEnums.NORMAL;
            } else if (order.getSellType() == SaleTypeEnums.JS) {
                auditType = SupplierQuotaAuditTypeEnums.JS;
            }

            if (null != auditType) {
                BigDecimal totalAmount = lineList.stream()
                        .map(line -> {
                            if (order.getSellType() == SaleTypeEnums.JS) {
                                return new BigDecimal(line.getCount()).multiply(line.getConsignmentPrice());
                            } else {
                                return new BigDecimal(line.getCount()).multiply(line.getDealPrice());
                            }
                        })
                        .reduce(BigDecimal::add)
                        .orElse(BigDecimal.ZERO);

                SupplierContacts contact = repositoryFactory.getSupplierContactsRepository().findById(order.getBuyerId());
                SupplierQuota quota = repositoryFactory.getSupplierQuotaRepository()
                        .findBySupplierId(contact.getSupplierId());

                if (auditType == SupplierQuotaAuditTypeEnums.NORMAL) {
                    quota.setNormalQuota(quota.getNormalQuota().add(totalAmount));
                } else {
                    quota.setJsQuota(quota.getJsQuota().add(totalAmount));
                }

                repositoryFactory.getSupplierQuotaRepository().submit(quota);

                SupplierQuotaDetail detail = repositoryFactory.getSupplierQuotaDetailRepository().findOne(
                        quota.getId(),
                        order.getCreatedId(),
                        auditType
                );
                detail.setAmount(detail.getAmount().add(totalAmount));
                repositoryFactory.getSupplierQuotaDetailRepository().submit(detail);

                //记录日志
                SupplierQuotaLog log = new SupplierQuotaLog();
                log.setAmountType(auditType);
                log.setType(SupplierQuotaLogTypeEnums.CANCEL);
                log.setAmount(totalAmount);
                log.setQuotaId(quota.getId());
                repositoryFactory.getSupplierQuotaLogRepository().submit(log);
            }

        }
    }


    /**
     * 销售单出库
     *
     * @param lineList 取消的行
     * @param order    订单
     */
    private void doCk(List<SaleOrderLine> lineList, SaleOrder order, String expressNo) {

        //step_1 补充快递单号
        order.setExpressNo(expressNo);
        ValidationUtil.isTrue(
                repositoryFactory.getSaleOrderRepository().submit(order),
                "销售单绑定快递单号失败"
        );




        //这里如果是同行销售 并且类型为寄售的走单独逻辑
        if (order.getModel() == SaleModelEnums.B && order.getSellType() == SaleTypeEnums.JS) {
            //step_1 修改行状态
            lineList.forEach(line -> line.setNodeState(SkuNodeStateEnums.JI_SZ));
            repositoryFactory.getSaleOrderLineRepository().submitBatch(lineList);
        } else {
            //step_0 调用三方发货
            if (StringUtils.isNotEmpty(order.getThirdPartyNo())) {
                ThirdSaleOrder thirdSaleOrder = repositoryFactory.getThirdSaleOrderRepository()
                        .findByOrderId(order.getThirdPartyNo());

                if (null != thirdSaleOrder) {
                    List<ThirdSaleOrder> thirdSaleOrders = repositoryFactory.getThirdSaleOrderRepository()
                            .listByMergedIds(Collections.singleton(thirdSaleOrder.getMergedId()));

                    SysSaleChannel saleChannel = repositoryFactory.getSaleChannelRepository()
                            .findById(thirdSaleOrder.getScId());

                    switch (saleChannel.getType()) {
                        case tiktok:
                            tiktokDelivery(thirdSaleOrders, order.getExpressNo(), saleChannel);
                            break;
                        case ks:
                            ksDelivery(thirdSaleOrders, order.getExpressNo(), saleChannel);
                            break;
                    }
                }
            }

            //step_1 修改行状态
            Date now = new Date();
            lineList.forEach(line -> {
                line.setNodeState(SkuNodeStateEnums.YCK);
                line.setEndState(WhetherEnum.YES);
                line.setFinishTime(now);
            });

            repositoryFactory.getSaleOrderLineRepository().submitBatch(lineList);


            //step_2 尝试修改销售单状态
            stateListener.onEvent(new SaleOrderStateListener.Event(this, order.getId()));

            //step_3 rpc调用完成
            SaleSkuFinishRpcRequest rpcRequest = new SaleSkuFinishRpcRequest();
            List<SaleSkuFinishRpcRequest.Sku> skuList = MultiUtils.toList(
                    lineList,
                    SaleOrderLineMapping.INSTANCE::toFinishRequest
            );

            rpcRequest.setBuyerId(order.getBuyerId());
            rpcRequest.setSkuList(skuList);
            rpcRequest.setSerialNo(order.getSerialNo());
            skuFacade.finish(rpcRequest);

        }

    }


    /**
     * 通知抖音发货
     *
     * @param thirdSaleOrders
     * @param saleChannel
     */
    public void tiktokDelivery(List<ThirdSaleOrder> thirdSaleOrders,
                               String expressNo,
                               SysSaleChannel saleChannel) {

        OrderLogisticsAddSinglePackRequest request = new OrderLogisticsAddSinglePackRequest();
        OrderLogisticsAddSinglePackParam param = request.getParam();

        param.setOrderIdList(MultiUtils.toList(thirdSaleOrders, ThirdSaleOrder::getOrderId));
        param.setLogisticsCode(expressNo);
        param.setCompanyCode("shunfeng");
        param.setRequestId(thirdSaleOrders.get(0).getMergedId());
        ArrayList<ShippedOrderInfoItem> items = new ArrayList<>();
        for (ThirdSaleOrder o : thirdSaleOrders) {
            ShippedOrderInfoItem item = new ShippedOrderInfoItem();
            item.setShippedOrderId(o.getOrderId());
            item.setShippedNum(1L);
            items.add(item);

            // 子订单发货
            List<Long> tiktokSid = o.getTiktokSid();
            if (StringUtils.isNotEmpty(tiktokSid)) {
                for (Long sid : tiktokSid) {
                    if (!sid.toString().equals(o.getOrderId())) {
                        ShippedOrderInfoItem item1 = new ShippedOrderInfoItem();
                        item1.setShippedOrderId(sid.toString());
                        item1.setShippedNum(1L);
                        items.add(item1);
                    }
                }
            }
        }
        param.setShippedOrderInfo(items);
        AccessToken accessToken = tikTokShopApi.getAccessToken(Long.parseLong(saleChannel.getThirdNo()));
        log.info("抖音发货参数:{}",JSONObject.toJSONString(request));
        OrderLogisticsAddSinglePackResponse response = request.execute(accessToken);
        log.info("抖音发货结果为:{}", JSONObject.toJSONString(response));
        if (!response.isSuccess()){
            if (!"没有能发货的订单，请修改后重试".equals(response.getSubMsg()) &&
                !"订单已完结，禁止发货".equals(response.getSubMsg()) &&
                !"订单已发货，不允许再次执行发货".equals(response.getSubMsg())){
                ValidationUtil.isTrue(response.isSuccess(), response.getSubMsg());
            }
        }
    }


    /**
     * 通知快手发货
     *
     * @param thirdSaleOrders
     * @param expressNo
     * @param saleChannel
     */
    public void ksDelivery(List<ThirdSaleOrder> thirdSaleOrders,
                           String expressNo,
                           SysSaleChannel saleChannel) {
        AccessTokenKsMerchantClient client = new AccessTokenKsMerchantClient(
                saleChannel.getThirdNo(),
                saleChannel.getExt().getSignSecret()
        );

        for (ThirdSaleOrder thirdSaleOrder : thirdSaleOrders) {
            OpenSellerOrderGoodsDeliverRequest request = new OpenSellerOrderGoodsDeliverRequest();
            String token = ksComponent.getUserToken(saleChannel).getToken();
            request.setAccessToken(token);
            request.setExpressCode(4);

            request.setExpressNo(expressNo);
            request.setOrderId(Long.parseLong(thirdSaleOrder.getOrderId()));

            OpenSellerOrderGoodsDeliverResponse response = null;

            try {
                response = client.execute(request);
            } catch (KsMerchantApiException e) {
                log.error("快手发货异常 :{}", e.getErrorMsg());
            } finally {
                log.info("快手发货参数:{}.发货结果为:{}",
                        JSONObject.toJSONString(request),
                        JSONObject.toJSONString(response)
                );
            }

        }

    }

}
