package com.seeease.flywheel_v4.web.domain.wms.component.express.core;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/4/24 6:00 下午
 **/
@Data
public class PrintResult {
    /**
     * 抖音打单数据
     */
    private List<DyPrintResult> dyList;
    /**
     * 顺丰打单数据
     */
    private List<SfPrintResult> sfList;
    /**
     * 快手打单数据
     */
    private List<KsPrintResult> ksList;

    /**
     * 失败结构
     */
    private List<String> errList;


    @Data
    public static class SfPrintResult implements Serializable {

        private List<String> expressNoList;

        private String requestID = UUID.randomUUID().toString().replace("-", "");

        private String accessToken;

        private String templateCode;

        private String productName;

        private String remarks;

    }


    @Data
    public static class DyPrintResult implements Serializable {

        @JsonProperty("cmd")
        private String cmd;
        @JsonProperty("requestID")
        private String requestID =  UUID.randomUUID().toString().replace("-", "");
        @JsonProperty("version")
        private String version;
        @JsonProperty("task")
        private TaskDTO task;

        @Data
        public static class TaskDTO implements Serializable {
            @JsonProperty("taskID")
            private String taskID = UUID.randomUUID().toString().replace("-", "");
            @JsonProperty("preview")
            private Boolean preview;
            @JsonProperty("printer")
            private String printer;
            @JsonProperty("documents")
            private List<DocumentsDTO> documents;
        }

        @Data
        public static class DocumentsDTO implements Serializable {
            @JsonProperty("documentID")
            private String documentID = UUID.randomUUID().toString().replace("-", "");
            @JsonProperty("docNo")
            private String docNo;
            //ContentsDTO DataDTO
            @JsonProperty("contents")
            private List<Object> contents;
        }

        @Data
        public static class ContentsDTO implements Serializable {
            @JsonProperty("templateURL")
            private String templateURL;
            @JsonProperty("params")
            private String params;
            @JsonProperty("signature")
            private String signature;
            @JsonProperty("encryptedData")
            private String encryptedData;
            @JsonProperty("addData")
            private Map addData;
        }

        @Data
        public static class DataDTO implements Serializable {
            @JsonProperty("templateURL")
            private String templateURL;
            @JsonProperty("data")
            private Map<String, String> data;
        }

        @Data
        public static class Address implements Serializable {

            @JsonProperty("countryCode")
            private String countryCode;
            @JsonProperty("provinceName")
            private String provinceName;
            @JsonProperty("cityName")
            private String cityName;
            @JsonProperty("districtName")
            private String districtName;
            @JsonProperty("streetName")
            private String streetName;
            @JsonProperty("detailAddress")
            private String detailAddress;
        }

        @Data
        public static class Contact implements Serializable {

            @JsonProperty("name")
            private String name;
            @JsonProperty("phone")
            private String phone;
            @JsonProperty("mobile")
            private String mobile;
        }

        @Data
        public static class SenderInfo implements Serializable {
            @JsonProperty("address")
            private Address address;
            @JsonProperty("contact")
            private Contact contact;
        }
    }

    @Data
    public static class KsPrintResult implements Serializable {

        @JsonProperty("cmd")
        private String cmd;
        @JsonProperty("requestID")
        private String requestID = UUID.randomUUID().toString().replace("-", "");
        @JsonProperty("version")
        private String version;
        @JsonProperty("task")
        private TaskDTO task;


        @Data
        public static class TaskDTO implements Serializable {
            @JsonProperty("taskID")
            private String taskID = UUID.randomUUID().toString().replace("-", "");
            @JsonProperty("preview")
            private Boolean preview;
            @JsonProperty("printer")
            private String printer;
            @JsonProperty("documents")
            private List<DocumentsDTO> documents;

            @JsonProperty("firstDocumentNumber")
            private Integer firstDocumentNumber;
            @JsonProperty("totalDocumentCount")
            private Integer totalDocumentCount;
        }

        @Data
        public static class DocumentsDTO implements Serializable {
            @JsonProperty("documentID")
            private String documentID = UUID.randomUUID().toString().replace("-", "");
            @JsonProperty("waybillCode")
            private String waybillCode;
            @JsonProperty("ksOrderFlag")
            private Boolean ksOrderFlag;
            //ContentsDTO DataDTO
            @JsonProperty("contents")
            private List<ContentsDTO> contents;
        }

        @Data
        public static class ContentsDTO implements Serializable {
            @JsonProperty("templateURL")
            private String templateURL;
            @JsonProperty("key")
            private String key;
            @JsonProperty("ver")
            private String ver;

            @JsonProperty("signature")
            private String signature;
            @JsonProperty("encryptedData")
            private String encryptedData;
            @JsonProperty("addData")
            private Map addData;
        }
//
//        @Data
//        public static class DataDTO implements Serializable {
//            @JsonProperty("templateURL")
//            private String templateURL;
//            @JsonProperty("data")
//            private Map<String, String> data;
//        }

        @Data
        public static class Address implements Serializable {

            @JsonProperty("countryCode")
            private String countryCode;
            @JsonProperty("provinceName")
            private String provinceName;
            @JsonProperty("cityName")
            private String cityName;
            @JsonProperty("districtName")
            private String districtName;
            @JsonProperty("streetName")
            private String streetName;
            @JsonProperty("detailAddress")
            private String detailAddress;
        }

        @Data
        public static class Contact implements Serializable {

            @JsonProperty("name")
            private String name;
            @JsonProperty("phone")
            private String phone;
            @JsonProperty("mobile")
            private String mobile;
        }

        @Data
        public static class SenderInfo implements Serializable {

            @JsonProperty("address")
            private Address address;
            @JsonProperty("contact")
            private Contact contact;
        }
    }
}
