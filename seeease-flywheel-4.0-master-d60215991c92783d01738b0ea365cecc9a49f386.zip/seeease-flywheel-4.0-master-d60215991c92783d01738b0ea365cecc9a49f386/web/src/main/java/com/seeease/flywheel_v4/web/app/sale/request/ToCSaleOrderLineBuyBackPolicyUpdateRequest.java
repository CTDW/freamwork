package com.seeease.flywheel_v4.web.app.sale.request;


import com.seeease.flywheel_v4.web.infrastructure.dao.sale.entity.obj.BuyBackPolicyObj;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.util.List;


@Data
public class ToCSaleOrderLineBuyBackPolicyUpdateRequest {
    /**
     * 行id
     */
    @NotNull(message = "lineId 不能为空")
    private Integer lineId;

    /**
     * 回购政策
     */
    private List<BuyBackPolicyObj> policies;


}
