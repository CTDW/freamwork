package com.seeease.flywheel_v4.web.domain.wms.observer;

import com.seeease.flywheel_v4.web.domain.transfer.mapping.TransferOrderLineMapping;
import com.seeease.flywheel_v4.web.domain.transfer.mapping.TransferOrderMapping;
import com.seeease.flywheel_v4.web.domain.wms.observer.base.MerchantWmsObserver;
import com.seeease.flywheel_v4.web.domain.wms.observer.base.WmsRkObserver;
import com.seeease.flywheel_v4.web.domain.wms.observer.base.WmsSubject;
import com.seeease.flywheel_v4.web.infrastructure.dao.RepositoryFactory;
import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.entity.SysBusinessUnit;
import com.seeease.flywheel_v4.web.infrastructure.dao.transfer.entity.TransferOrder;
import com.seeease.flywheel_v4.web.infrastructure.dao.transfer.entity.TransferOrderLine;
import com.seeease.flywheel_v4.web.infrastructure.dao.transfer.enums.TransferTypeEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.MerchantWms;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.MerchantWmsLine;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.WmsRk;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.obj.ContactInfo;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.MerchantWmsModelEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.MerchantWmsTypeEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.WmsRkTypeEnums;
import com.seeease.flywheel_v4.web.infrastructure.listener.TransferOrderStateListener;
import com.seeease.goods.rpc.SkuFacade;
import com.seeease.goods.rpc.enums.SkuNodeStateEnums;
import com.seeease.goods.rpc.request.TransferSkuCancelRequest;
import com.seeease.goods.rpc.request.TransferSkuFinishRpcRequest;
import com.seeease.seeeaseframework.mybatis.domain.WhetherEnum;
import com.seeease.springframework.context.UserContext;
import com.seeease.springframework.exception.ValidationUtil;
import com.seeease.springframework.utils.MultiUtils;
import org.apache.dubbo.config.annotation.DubboReference;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.List;
import java.util.Objects;
import java.util.Set;

/**
 * <p
 * 调拨入库wms观察者
 * </p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/21/24 2:46下午
 **/
@Component
public class TransferRkObserver extends TransferBaseObserver implements WmsRkObserver, MerchantWmsObserver {

    @Resource
    private RepositoryFactory repositoryFactory;
    @Resource
    private TransferOrderStateListener stateListener;

    @Lazy
    @Resource
    private WmsSubject wmsSubject;

    @DubboReference(version = "1.0.0", check = false)
    private SkuFacade skuFacade;






    @Override
    public SkuNodeStateEnums adaptSkuNodeState(SkuNodeStateEnums state, String serialNo) {

        if (state == SkuNodeStateEnums.QX || state == SkuNodeStateEnums.SW_BF) {
            TransferOrder order = repositoryFactory.getTransferOrderRepository().findByIdOrSerialNo(null, serialNo);
            boolean pushToStore = super.pushToStore(order);
            //如果推送至仓库则sku状态适配为待收货  如果是商家则适配为待入库
            return pushToStore ? SkuNodeStateEnums.DSH : SkuNodeStateEnums.DRK;
        }

        return WmsRkObserver.super.adaptSkuNodeState(state, serialNo);
    }


    //----------------------------------------仓库wms观察者实现-----------------------------------//



    @Override
    public List<WmsRkTypeEnums> getWatchDataType() {
        return wmsRkWatchTypeList;
    }

    @Override
    public void update(List<WmsRk> rkList, SkuNodeStateEnums nodeState, String serialNo) {


        ValidationUtil.isTrue(
                storeCondition.contains(nodeState),
                "调拨入库不支持该类型操作"
        );

        TransferOrder order = repositoryFactory.getTransferOrderRepository().findByIdOrSerialNo(null, serialNo);

        Set<Integer> skuIdList = MultiUtils.toSet(rkList, WmsRk::getSkuId);
        List<TransferOrderLine> lineList = repositoryFactory.getTransferOrderLineRepository()
                .listByTransferIdAndSkuIds(order.getId(), skuIdList);

        switch (nodeState) {
            case YRK:
                doRK(order, lineList);
                break;
            case SW_BF: //实物不符
                doCancel(order, lineList);
                break;
        }


    }


    //----------------------------------------仓库wms观察者实现-----------------------------------//


    //----------------------------------------商家wms观察者实现-----------------------------------//





    @Override
    public MerchantWmsModelEnums model() {
        return MerchantWmsModelEnums.RK;
    }


    @Override
    public List<MerchantWmsTypeEnums> typeList() {
        return merchantWmsRkWatchTypeList;
    }

    @Override
    public void update(MerchantWms main, List<MerchantWmsLine> lineList, SkuNodeStateEnums nodeState) {
        ValidationUtil.isTrue(
                merchantCondition.contains(nodeState),
                "调拨入库不支持该类型操作"
        );

        TransferOrder order = repositoryFactory.getTransferOrderRepository()
                .findByIdOrSerialNo(null, main.getSerialNo());

        Set<Integer> skuIdList = MultiUtils.toSet(lineList, MerchantWmsLine::getSkuId);
        List<TransferOrderLine> tLineList = repositoryFactory.getTransferOrderLineRepository()
                .listByTransferIdAndSkuIds(order.getId(), skuIdList);

        switch (nodeState) {
            case YRK: //入库
                doRK(order, tLineList);
                break;
            case QX:
                doCancel(order, tLineList);

        }
    }


    //----------------------------------------商家wms观察者实现-----------------------------------//

    /**
     * 入库操作
     *
     * @param order    入库对应的调拨单
     * @param lineList 入库的行
     */
    public void doRK(TransferOrder order, List<TransferOrderLine> lineList) {

        //step_1 根据当前操作的的业务单元类型和调拨单上的入库方业务单元类型作比较，如果相同则调拨成功否则就算调拨取消
        Integer userBuId = UserContext.getUser().getStore().getId();
        SysBusinessUnit currentBu = repositoryFactory.getBusinessUnitRepository().findById(userBuId);
        SysBusinessUnit to = repositoryFactory.getBusinessUnitRepository().findById(order.getToId());
        boolean transferOk = Objects.equals(to.getId(), currentBu.getId());

        //step1 修改调拨单行状态
        lineList.forEach(line -> {
            line.setEndState(WhetherEnum.YES);
            line.setNodeState(transferOk ? SkuNodeStateEnums.YRK : SkuNodeStateEnums.QX);
        });
        repositoryFactory.getTransferOrderLineRepository().submitBatch(lineList);

        //step2 尝试修改调拨单状态
        stateListener.onEvent(new TransferOrderStateListener.Event(this, order.getId()));


        //step_3 取消调拨或成功调拨
        if (Objects.equals(to.getId(), currentBu.getId())) { //调拨成功
            //调拨成功修改sku
            TransferSkuFinishRpcRequest rpcRequest = new TransferSkuFinishRpcRequest();
            List<TransferSkuFinishRpcRequest.Sku> rpcSkuList = MultiUtils.toList(
                    lineList,
                    TransferOrderLineMapping.INSTANCE::toSkuFinishRequest
            );
            rpcSkuList.forEach(i ->{
                i.setStoreId(order.getToId());
                if (order.getType() != TransferTypeEnums.JH) {
                    i.setSellerId(order.getToId());
                }
            });

            rpcRequest.setSkuList(rpcSkuList);
            rpcRequest.setSerialNo(order.getSerialNo());
            skuFacade.finish(rpcRequest);


        } else { //调拨取消
            //调拨取消方法
            Set<Integer> skuIdList = MultiUtils.toSet(lineList, TransferOrderLine::getSkuId);
            TransferSkuCancelRequest rpcRequest = new TransferSkuCancelRequest();
            rpcRequest.setIdList(skuIdList);
            rpcRequest.setSerialNo(order.getSerialNo());
            skuFacade.cancel(rpcRequest);
        }


    }


    /**
     * 取消
     *
     * @param order    拒收对应的调拨单
     * @param lineList 拒收的行
     */
    public void doCancel(TransferOrder order,
                         List<TransferOrderLine> lineList) {
        //step 1 将调拨单行状态赋值为终态，并将行商品状态赋值为取消
        lineList.forEach(line -> line.setNodeState(SkuNodeStateEnums.SW_BF));

        repositoryFactory.getTransferOrderLineRepository().submitBatch(lineList);

        //step2 尝试修改调拨单状态
        stateListener.onEvent(new TransferOrderStateListener.Event(this, order.getId()));


        //step3 判断推送入库单到门店还是仓库
        boolean pushToStore = super.pushToStore(order);
        Integer buId = UserContext.getUser().getStore().getId();
        Integer toId = Objects.equals(order.getToId(),buId) ? order.getFromId() : order.getToId();

        //推送仓库wms
        if (pushToStore) {
            //生成入库单
            List<WmsRk> rkList = MultiUtils.toList(
                    lineList,
                    line -> {
                        WmsRk rk = TransferOrderMapping.INSTANCE.toWmsRk(
                                order,
                                line,
                                toId,
                                null
                        );
                        rk.setType(WmsRkTypeEnums.DB_JS);
                        return rk;
                    }
            );
            wmsSubject.rkDateSubmit(rkList);
        }
        //推送商家仓库
        else {

            //推送商家仓库
            SysBusinessUnit to = repositoryFactory.getBusinessUnitRepository().findById(order.getToId());

            //构建行信息
            List<MerchantWmsLine> merchantWmsLines = MultiUtils.toList(
                    lineList,
                    line -> TransferOrderLineMapping.INSTANCE.toMerchantWmsLine(line, SkuNodeStateEnums.DRK)
            );
            Integer totalCount = 0;
            BigDecimal amount = BigDecimal.ZERO;

            for (MerchantWmsLine l : merchantWmsLines) {
                totalCount += l.getCount();
                amount = amount.add(l.getPrice());
            }

            //构架客户信息
            ContactInfo contactInfo = TransferOrderMapping.INSTANCE.toMerchantWmsContactInfo(to);

            //构建主单信息
            MerchantWms merchantWms = TransferOrderMapping.INSTANCE.toMerchantWms(
                    order,
                    contactInfo,
                    MerchantWmsModelEnums.RK,
                    MerchantWmsTypeEnums.DB_RK,
                    null,
                    toId
            );
            merchantWms.setType(MerchantWmsTypeEnums.DB_JS);
            merchantWms.setTotalCount(totalCount);
            merchantWms.setAmount(amount);

            wmsSubject.merchantWmsDataCreate(merchantWms, merchantWmsLines);
        }

    }
}
