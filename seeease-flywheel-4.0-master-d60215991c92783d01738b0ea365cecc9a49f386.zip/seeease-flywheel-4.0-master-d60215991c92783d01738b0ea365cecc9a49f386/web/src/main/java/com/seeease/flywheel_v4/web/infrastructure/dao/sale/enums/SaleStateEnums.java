package com.seeease.flywheel_v4.web.infrastructure.dao.sale.enums;


import com.baomidou.mybatisplus.annotation.IEnum;
import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * <p>销售单</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/5/24 1:47 下午
 **/
@AllArgsConstructor
@Getter
public enum SaleStateEnums implements IEnum<Integer> {
    WAIT_STAR(1,"待开始"),
    STARTING(2,"进行中"),
    OVER(3,"已完成"),
    CANCEL(4,"已取消"),
    ;
    private Integer value;
    private String desc;


}
