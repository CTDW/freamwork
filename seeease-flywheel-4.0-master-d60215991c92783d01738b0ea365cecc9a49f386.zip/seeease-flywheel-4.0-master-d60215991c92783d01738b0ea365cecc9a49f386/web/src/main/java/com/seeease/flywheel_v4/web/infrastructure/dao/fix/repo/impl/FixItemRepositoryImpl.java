package com.seeease.flywheel_v4.web.infrastructure.dao.fix.repo.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.seeease.flywheel_v4.web.app.fix.request.FixItemDetailRequest;
import com.seeease.flywheel_v4.web.app.fix.request.FixItemPageRequest;
import com.seeease.flywheel_v4.web.app.fix.request.FixItemSaveRequest;
import com.seeease.flywheel_v4.web.infrastructure.dao.fix.entity.FixItem;
import com.seeease.flywheel_v4.web.infrastructure.dao.fix.mapper.FixItemMapper;
import com.seeease.flywheel_v4.web.infrastructure.dao.fix.repo.FixItemRepository;
import com.seeease.springframework.utils.StringUtils;
import org.springframework.stereotype.Repository;


/**
 * @Description 维修项目
 * @Date 2024-10-2 21:05
 * @Author by hk
 */
@Repository
public class FixItemRepositoryImpl extends ServiceImpl<FixItemMapper, FixItem>
        implements FixItemRepository {

    @Override
    public Page<FixItem> page(FixItemPageRequest request) {
        LambdaQueryWrapper<FixItem> wq = Wrappers.<FixItem>lambdaQuery()
                .like(StringUtils.isNotEmpty(request.getItemName()), FixItem::getItemName, request.getItemName());

        Page<FixItem> page = Page.of(request.getPage(), request.getLimit());
        baseMapper.selectPage(page, wq);
        return page;
    }

    /**
     * 详情
     *
     * @param request 请求
     * @return 返回
     */
    @Override
    public FixItem detail(FixItemDetailRequest request) {
        return getById(request.getId());
    }

    /**
     * 新增
     *
     * @param request 请求
     */
    @Override
    public Boolean save(FixItemSaveRequest request) {
        FixItem fixItem = new FixItem();
        fixItem.setItemName(request.getItemName());
        fixItem.setDefaultFixPrice(request.getDefaultFixPrice());
        int insert = baseMapper.insert(fixItem);
        return insert == 1;
    }

    /**
     * 编辑
     *
     * @param request 请求
     */
    @Override
    public Boolean update(FixItemSaveRequest request) {
        if (request.getId() == null) {
            throw new RuntimeException("维修项目id不能为空");
        }
        UpdateWrapper<FixItem> updateWrapper = new UpdateWrapper<>();
        updateWrapper.eq("id", request.getId())
                .set("item_name", request.getItemName())
                .set("default_fix_price", request.getDefaultFixPrice());
        return update(updateWrapper);
    }

    /**
     * 删除
     *
     * @param request 请求
     */
    @Override
    public Boolean delete(FixItemDetailRequest request) {
        if (request.getId() == null) {
            throw new RuntimeException("维修项目id不能为空");
        }
        FixItem fixItem = new FixItem();
        fixItem.setId(request.getId());
        return removeById(fixItem);
    }
}
