package com.seeease.flywheel_v4.web.domain.wms.observer.base;

import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.MerchantWms;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.MerchantWmsLine;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.MerchantWmsModelEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.MerchantWmsTypeEnums;
import com.seeease.goods.rpc.enums.SkuNodeStateEnums;

import java.util.List;

/**
 * <p
 * 商家wms出入库事件观察者
 * </p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/21/24 2:46下午
 **/
public interface MerchantWmsObserver extends SkuNodeStateAdaptor {


    /**
     * 获取出库拓展数据
     * @param serialNo
     * @return
     */
    default Ext getCkExt(String serialNo){
        return null;
    }

    /**
     * 获取对应观察者模型
     */
    MerchantWmsModelEnums model();

    /**
     * 获取对应观察者观察的类型
     */
    List<MerchantWmsTypeEnums> typeList();

    /**
     * 针对于发生了节点状态变动的wms数据进行回调
     *
     * @param nodeState 变动后的节点状态
     * @param lineList      变动的数据
     * @param main          变动的主数据
     */
    void update(MerchantWms main, List<MerchantWmsLine> lineList, SkuNodeStateEnums nodeState);

}
