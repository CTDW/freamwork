package com.seeease.flywheel_v4.web.app.purchase.service;

import com.seeease.flywheel_v4.web.app.purchase.request.*;
import com.seeease.flywheel_v4.web.app.purchase.result.PurchaseDemandDetailResult;
import com.seeease.flywheel_v4.web.app.purchase.result.PurchaseDemandPageResult;
import com.seeease.flywheel_v4.web.app.purchase.result.PurchaseOrderDetailResult;
import com.seeease.flywheel_v4.web.app.purchase.result.PurchaseOrderPageResult;
import com.seeease.springframework.PageResult;

/**
 * <p>采购订单</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/5/24 1:58 下午
 **/
public interface PurchaseOrderService {

    /**
     * 采购订单创建
     *
     * @return 创建结果
     */
    Integer create(PurchaseOrderSubmitRequest request);

    /**
     * 采购订单分页查询
     *
     * @return 分页结果
     */
    PageResult<PurchaseOrderPageResult> page(PurchaseOrderPageRequest request);

    /**
     * 采购订单详情查询
     *
     * @return 详情结果
     */
    PurchaseOrderDetailResult details(PurchaseOrderDetailRequest request);

    /**
     * 采购上传快递单号
     *
     * @return 上传结果
     */
    Boolean uploadExpress(PurchaseOrderExpressUploadRequest request);

    /**
     * 取消采购单
     *
     * @return 取消结果
     */
    Boolean cancel(PurchaseOrderCancelRequest request);
}
