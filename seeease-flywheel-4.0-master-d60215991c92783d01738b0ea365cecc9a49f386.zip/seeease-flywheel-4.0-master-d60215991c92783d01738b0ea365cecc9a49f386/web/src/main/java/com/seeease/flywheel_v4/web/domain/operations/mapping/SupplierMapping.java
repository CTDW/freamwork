package com.seeease.flywheel_v4.web.domain.operations.mapping;



import com.seeease.flywheel_v4.client.result.SupplierRpcResult;
import com.seeease.flywheel_v4.web.app.operations.request.SupplierSubmitRequest;
import com.seeease.flywheel_v4.web.app.operations.result.SupplierContactListResult;
import com.seeease.flywheel_v4.web.app.operations.result.SupplierPageResult;
import com.seeease.flywheel_v4.web.infrastructure.config.SimpleMapping;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.Supplier;
import com.seeease.flywheel_v4.client.enums.BusinessUnitTypeEnums;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;

import java.util.List;


/**
 * <p>
 * 供应商
 * </p>
 *
 * @author 西门 游
 * @since 2023-10-27
 */
@Mapper(componentModel = "spring",
        builder = @Builder(disableBuilder = true),
        nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS,
        nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE,
        imports = {BusinessUnitTypeEnums.class})
public interface SupplierMapping extends SimpleMapping<SupplierSubmitRequest, Supplier> {

    SupplierMapping INSTANCE = Mappers.getMapper(SupplierMapping.class);

    SupplierPageResult toPageResult(Supplier supplier, List<SupplierContactListResult> contacts);

    SupplierRpcResult toRpcResult(Supplier ret);
}
