package com.seeease.flywheel_v4.web.domain.wms.mapping;


import com.seeease.flywheel_v4.client.enums.BusinessUnitTypeEnums;
import com.seeease.flywheel_v4.web.app.excel.result.WmsRkExportResult;
import com.seeease.flywheel_v4.web.app.wms.request.WmsRkCountUpdateRequest;
import com.seeease.flywheel_v4.web.app.wms.request.WmsRkPageRequest;
import com.seeease.flywheel_v4.web.app.wms.request.WmsRkStateRequest;
import com.seeease.flywheel_v4.web.app.wms.result.WmsRkPageResult;
import com.seeease.flywheel_v4.web.infrastructure.config.EnumMapping;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.WmsRk;
import com.seeease.goods.rpc.enums.SkuNodeStateEnums;
import com.seeease.goods.rpc.enums.SkuStateEnums;
import com.seeease.goods.rpc.request.SkuRpcRequest;
import com.seeease.goods.rpc.request.SkuStateEventSubmitRcpRequest;
import com.seeease.goods.rpc.request.SkuUpdateRpcRequest;
import com.seeease.goods.rpc.result.SkuRpcResult;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;

import java.util.List;


/**
 * <p>
 * 商品附件
 * </p>
 *
 * @author 西门 游
 * @since 2023-10-27
 */
@Mapper(componentModel = "spring",
        builder = @Builder(disableBuilder = true),
        nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS,
        nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE,
        imports = {BusinessUnitTypeEnums.class, SkuNodeStateEnums.class, SkuStateEnums.TransitionEnum.class, SkuStateEnums.class})
public interface WmsRkMapping extends EnumMapping {

    WmsRkMapping INSTANCE = Mappers.getMapper(WmsRkMapping.class);

    SkuRpcRequest toSkuRcpRequest(WmsRkPageRequest request);

    @Mapping(target = "id", source = "rk.id")
    @Mapping(target = "skuId", source = "skuRpcResult.id")
    WmsRkPageResult toPageResult(WmsRk rk, SkuRpcResult skuRpcResult);


    void toEntityForUpdate(@MappingTarget WmsRk wmsRk, WmsRkStateRequest request);


    void toEntityForUpdate(@MappingTarget WmsRk wmsRk, WmsRkCountUpdateRequest request);


    SkuUpdateRpcRequest toSkuRpcUpdateRequest(WmsRk wmsRk, WmsRkStateRequest request);

    @Mapping(target = "skuList", expression = "java(toSkuStateEvent(wmsRkList))")
    SkuStateEventSubmitRcpRequest toSkuStateEvent(List<WmsRk> wmsRkList,
                                                  SkuNodeStateEnums nodeState);






    @Mapping(target = "lifeCyclePlaceholder", expression = "java(new String[]{wmsRk.getReason()})")
    SkuStateEventSubmitRcpRequest.Sku toSkuStateEvent(WmsRk wmsRk);

    List<SkuStateEventSubmitRcpRequest.Sku> toSkuStateEvent(List<WmsRk> wmsRk);



    @Mapping(target = "type", source = "type")
    @Mapping(target = "nodeState", source = "nodeState")
    @Mapping(target = "param", source = "param")
    @Mapping(target = "annexe", source = "annexe")
    WmsRkExportResult toExportResult(WmsRkPageResult item,
                                     String type,
                                     String nodeState,
                                     String annexe,
                                     String param);
}
