package com.seeease.flywheel_v4.web.infrastructure.dao.operations.repo;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.seeease.flywheel_v4.web.app.operations.request.SupplierQuotaAuditPageRequest;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.SupplierQuotaAudit;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.enums.SupplierQuotaAuditStateEnums;

import java.util.List;
import java.util.Set;

/**
 *
 * @author 西门 游
 * @version 1.0
 * @since 5/31/24 4:55 下午
 **/
public interface SupplierQuotaAuditRepository {

    /**
     * 提交
     * @param log
     * @return
     */
    Boolean submit(SupplierQuotaAudit log);

    /**
     * 查询
     * @param id
     * @return
     */
    SupplierQuotaAudit finById(Integer id);

    /**
     * 分页
     * @param request
     * @param supplierIds
     * @return
     */
    Page<SupplierQuotaAudit> page(SupplierQuotaAuditPageRequest request, Set<Integer> supplierIds);

    /**
     * 查询
     * @param supplierId
     * @param state
     * @return
     */
    List<SupplierQuotaAudit> listByIdAndState(Integer supplierId, SupplierQuotaAuditStateEnums state);
}
