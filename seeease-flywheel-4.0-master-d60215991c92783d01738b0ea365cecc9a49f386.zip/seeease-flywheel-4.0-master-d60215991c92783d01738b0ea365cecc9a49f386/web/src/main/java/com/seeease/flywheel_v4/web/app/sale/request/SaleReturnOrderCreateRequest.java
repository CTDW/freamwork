package com.seeease.flywheel_v4.web.app.sale.request;


import lombok.Data;

import java.math.BigDecimal;
import java.util.List;


@Data
public class SaleReturnOrderCreateRequest {

    /**
     * 主单号
     */
    private String mainSerialNo;

    /**
     * 备注
     */
    private String remark;

    /**
     * 三方退货id
     */
    private String thirdReturnId;

    /**
     * sku列表
     */
    private List<Sku> skuList;


    @Data
    public static class Sku {
        /**
         * uuid
         */
        private String uuid;
        /**
         * 采购单行id
         */
        private Integer saleLineId;
        /**
         * gmvc
         */
        private BigDecimal gmvc;
        /**
         * 最新结算价
         */
        private BigDecimal newSettlePrice;

        /**
         * 销售单id
         */
        private Integer saleId;
        /**
         * skuId
         */
        private Integer skuId;
        /**
         * 退款金额
         */
        private BigDecimal returnAmount;
        /**
         * 退款数量
         */
        private Integer returnCount;
    }


}
