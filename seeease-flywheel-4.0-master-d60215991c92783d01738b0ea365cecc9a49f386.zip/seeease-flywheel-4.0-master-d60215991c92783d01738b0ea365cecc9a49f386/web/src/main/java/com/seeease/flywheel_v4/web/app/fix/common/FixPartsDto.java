package com.seeease.flywheel_v4.web.app.fix.common;

import com.seeease.flywheel_v4.web.infrastructure.dao.fix.entity.FixOrderPart;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @Description 维修单 -配件对象
 * @Date 2024-10-4 18:20
 * @Author by hk
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FixPartsDto implements Serializable {

    @ApiModelProperty(value = "id", notes = "编辑时：有id代表编辑，无id代表新增")
    private Long id;

    @ApiModelProperty(name = "商品图片")
    private String goodsPic;

    @ApiModelProperty(name = "商品名称")
    private String goodsName;

    @ApiModelProperty(value = "品牌id")
    private Integer goodsBrandId;

    @ApiModelProperty(value = "类目id")
    private Integer goodsCategoryId;

    @ApiModelProperty(value = "skuCode")
    private String skuCode;

    @ApiModelProperty(value = "品牌")
    private String goodsBrand;

    @ApiModelProperty(value = "类目")
    private String goodsCategory;

    @ApiModelProperty(value = "分类")
    private String classification;

    @ApiModelProperty(value = "货号")
    private String articleNo;

    @ApiModelProperty(name = "尺寸")
    private String size;

    @ApiModelProperty(name = "形状")
    private String shape;

    @ApiModelProperty(value = "机芯号")
    private String machineNumber;

    @ApiModelProperty(value = "数量")
    private Integer count;

    @ApiModelProperty(value = "采购价")
    private BigDecimal price;

    @ApiModelProperty(value = "公价")
    private BigDecimal publicPrice;

    @ApiModelProperty(value = "零售价")
    private BigDecimal salePrice;

    public static FixPartsDto fromEntity(FixOrderPart orderPart) {
        return FixPartsDto.builder()
                .id(orderPart.getId())
                .goodsPic(orderPart.getGoodsPic())
                .goodsBrand(orderPart.getGoodsBrand())
                .goodsBrandId(orderPart.getGoodsBrandId())
                .goodsCategory(orderPart.getGoodsCategory())
                .goodsCategoryId(orderPart.getGoodsCategoryId())
                .goodsName(orderPart.getGoodsName())
                .skuCode(orderPart.getSkuCode())

                .classification(orderPart.getClassification())
                .articleNo(orderPart.getArticleNo())
                .size(orderPart.getSize())
                .shape(orderPart.getShape())
                .machineNumber(orderPart.getMachineNumber())
                .count(orderPart.getCount())

                .price(orderPart.getPrice())
                .salePrice(orderPart.getSalePrice())
                .publicPrice(orderPart.getPublicPrice())

                .build();
    }

    public FixOrderPart toEntity(boolean update,String fixOrderNumber) {
        FixOrderPart orderPart = new FixOrderPart();

        if (update) {
            orderPart.setId(id);
        }

        orderPart.setOrderNumber(fixOrderNumber);

        orderPart.setGoodsPic(goodsPic);
        orderPart.setGoodsBrand(goodsBrand);
        orderPart.setGoodsBrandId(goodsBrandId);
        orderPart.setGoodsCategory(goodsCategory);
        orderPart.setGoodsCategoryId(goodsCategoryId);
        orderPart.setGoodsName(goodsName);
        orderPart.setSkuCode(skuCode);

        orderPart.setClassification(classification);
        orderPart.setArticleNo(articleNo);
        orderPart.setSize(size);
        orderPart.setShape(shape);
        orderPart.setMachineNumber(machineNumber);
        orderPart.setCount(count);

        orderPart.setPrice(price);
        orderPart.setSalePrice(salePrice);
        orderPart.setPublicPrice(publicPrice);

        return orderPart;
    }
}
