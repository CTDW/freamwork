package com.seeease.flywheel_v4.web.domain.finance.mapping;


import com.seeease.flywheel_v4.web.app.excel.result.FinancePaymentExportResult;
import com.seeease.flywheel_v4.web.app.finance.request.PaymentSlipSubmitRequest;
import com.seeease.flywheel_v4.web.app.finance.result.PaymentSlipDetailResult;
import com.seeease.flywheel_v4.web.app.finance.result.PaymentSlipPageResult;
import com.seeease.flywheel_v4.web.infrastructure.config.EnumMapping;
import com.seeease.flywheel_v4.web.infrastructure.config.MappingIgnore;
import com.seeease.flywheel_v4.web.infrastructure.dao.finance.entity.FinancePaymentSlip;
import com.seeease.flywheel_v4.web.infrastructure.dao.finance.entity.obj.ImageGroupObj;
import com.seeease.flywheel_v4.web.infrastructure.dao.finance.enums.PaymentSlipStateEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.entity.PurchaseOrder;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.entity.PurchaseOrderLine;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.Supplier;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.SupplierContacts;
import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.entity.SysBusinessUnit;
import com.seeease.flywheel_v4.web.util.SerialNoGenerator;
import com.seeease.goods.rpc.request.SkuBusinessSubmitRpcRequest;
import com.seeease.goods.rpc.result.SkuRpcResult;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;

import java.util.List;
import java.util.Set;


/**
 * <p>
 * </p>
 *
 * @author 西门 游
 * @since 2023-10-27
 */
@Mapper(componentModel = "spring",
        builder = @Builder(disableBuilder = true),
        nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS,
        nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE
        , imports = {SerialNoGenerator.class, SerialNoGenerator.Type.class, PaymentSlipStateEnums.class,
        PaymentSlipStateEnums.TransitionEnum.class, PaymentSlipStateEnums.class})
public interface FinancePaymentSlipMapping extends EnumMapping {

    FinancePaymentSlipMapping INSTANCE = Mappers.getMapper(FinancePaymentSlipMapping.class);


    @MappingIgnore
    @Mapping(target = "purchaseId", source = "purchaseOrder.id")
    @Mapping(target = "purchaseSerialNo", source = "purchaseOrder.serialNo")
    @Mapping(target = "serialNo", expression = "java(SerialNoGenerator.generalSerial(SerialNoGenerator.Type.SQ_DK))")
    @Mapping(target = "state", expression = "java(PaymentSlipStateEnums.WAIT_CONFIRM)")
    @Mapping(target = "amount", source = "purchaseOrder.totalPrice")
    @Mapping(target = "purchaseType", source = "purchaseOrder.type")
    @Mapping(target = "count", source = "purchaseOrder.totalCount")
    @Mapping(target = "images", source = "request.images")
    @Mapping(target = "transitionStateEnum", ignore = true)
    @Mapping(target = "imageGroup", expression = "java(toImageGroup(request))")
    @Mapping(target = "payAmount", source = "purchaseOrder.totalPrice")
    FinancePaymentSlip toEntity(PurchaseOrder purchaseOrder,
                                PaymentSlipSubmitRequest request);


    ImageGroupObj toImageGroup(PaymentSlipSubmitRequest request);


    @Mapping(target = "imageGroup", expression = "java(toImageGroup(request))")
    @Mapping(target = "state", ignore = true)
    void toEntityForUpdate(@MappingTarget FinancePaymentSlip paymentSlip,
                           PaymentSlipSubmitRequest request);


    PaymentSlipPageResult toPageResult(FinancePaymentSlip slip,
                                       String supplierName,
                                       String purchaseSubjectName);

    @Mapping(target = "id", source = "paymentSlip.id")
    @Mapping(target = "serialNo", source = "paymentSlip.serialNo")
    @Mapping(target = "state", source = "paymentSlip.state")
    @Mapping(target = "payType", source = "purchaseOrder.payType")
    @Mapping(target = "createdBy", source = "paymentSlip.createdBy")
    @Mapping(target = "createdTime", source = "paymentSlip.createdTime")
    @Mapping(target = "images", source = "paymentSlip.images")
    @Mapping(target = "supplierName", source = "supplier.name")
    @Mapping(target = "contactName", source = "contacts.name")
    @Mapping(target = "purchaseSubjectName", source = "purchaseSubject.name")
    @Mapping(target = "merchantName", source = "merchant.name")
    @Mapping(target = "contractImg", source = "paymentSlip.imageGroup.contractImg")
    @Mapping(target = "evidenceImg", source = "paymentSlip.imageGroup.evidenceImg")
    @Mapping(target = "idFrontImg", source = "paymentSlip.imageGroup.idFrontImg")
    @Mapping(target = "idBackImg", source = "paymentSlip.imageGroup.idBackImg")
    @Mapping(target = "payedImg", source = "paymentSlip.imageGroup.payedImg")
    @Mapping(target = "payedTime", source = "paymentSlip.payTime")
    PaymentSlipDetailResult toDetailResult(FinancePaymentSlip paymentSlip,
                                           PurchaseOrder purchaseOrder,
                                           List<PaymentSlipDetailResult.Sku> skuList,
                                           SysBusinessUnit purchaseSubject,
                                           Supplier supplier,
                                           SupplierContacts contacts,
                                           SysBusinessUnit merchant);


    SkuBusinessSubmitRpcRequest toSkuBusiness(Set<Integer> skuIdList,
                                              String payoutSerialNo,
                                              PaymentSlipStateEnums payoutState,
                                              Boolean settled);

    @Mapping(target = "purchasePrice", source = "line.purchasePrice")
    @Mapping(target = "skuParams", source = "skuRpcResult.skuParams")
    @Mapping(target = "nodeState", source = "line.nodeState")
    @Mapping(target = "skuId", source = "skuRpcResult.id")
    PaymentSlipDetailResult.Sku toSkuResult(SkuRpcResult skuRpcResult, PurchaseOrderLine line);

    @Mapping(target = "purchaseType", source = "purchaseType")
    @Mapping(target = "payType", source = "payType")
    @Mapping(target = "state", source = "state")
    @Mapping(target = "verifyState", source = "verifyState")
    FinancePaymentExportResult toExportResult(String purchaseType,
                                              String payType,
                                              String state,
                                              String verifyState,
                                              PaymentSlipPageResult item);
}
