package com.seeease.flywheel_v4.web.app.fix.common;

import com.seeease.flywheel_v4.web.infrastructure.dao.fix.entity.FixOrder;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

/**
 * @Description 维修单 -维修信息
 * @Date 2024-10-4 18:25
 * @Author by hk
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FixInfoDto implements Serializable {

    @ApiModelProperty(value = "维修师")
    private String fixMasters;

    @ApiModelProperty(value = "送外维修费")
    private BigDecimal sendOutFixFee;

    @ApiModelProperty(value = "送修备注")
    private String sendOutRemark;

    @ApiModelProperty(value = "返回备注")
    private String returnRemark;

    @ApiModelProperty(value = "返回快递单号")
    private String returnExpressNumber;


    @ApiModelProperty(value = "维修师得分")
    private List<FixMasterScoreDto> masterScoreList;

    public static FixInfoDto fromEntity(FixOrder detail) {
        return FixInfoDto.builder()
                .fixMasters(detail.getFixMaster())
                .sendOutFixFee(detail.getSendOutFixFee())
                .sendOutRemark(detail.getSendOutRemark())

                .returnExpressNumber(detail.getReturnExpressNumber())
                .returnRemark(detail.getReturnRemark())

                .masterScoreList(detail.getFixMasterScoreList())
                .build();
    }

}
