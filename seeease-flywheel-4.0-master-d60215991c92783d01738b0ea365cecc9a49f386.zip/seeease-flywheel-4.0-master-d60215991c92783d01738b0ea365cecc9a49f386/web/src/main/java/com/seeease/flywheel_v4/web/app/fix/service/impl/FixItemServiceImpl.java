package com.seeease.flywheel_v4.web.app.fix.service.impl;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.seeease.flywheel_v4.web.app.fix.request.FixItemDetailRequest;
import com.seeease.flywheel_v4.web.app.fix.request.FixItemPageRequest;
import com.seeease.flywheel_v4.web.app.fix.request.FixItemSaveRequest;
import com.seeease.flywheel_v4.web.app.fix.result.FixItemPageResult;
import com.seeease.flywheel_v4.web.app.fix.service.FixItemService;
import com.seeease.flywheel_v4.web.infrastructure.dao.RepositoryFactory;
import com.seeease.flywheel_v4.web.infrastructure.dao.fix.entity.FixItem;
import com.seeease.goods.rpc.SkuFacade;
import com.seeease.springframework.PageResult;
import com.seeease.springframework.utils.StringUtils;
import org.apache.dubbo.config.annotation.DubboReference;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.stream.Collectors;

/**
 * @Description 维修项目
 * @Date 2024-10-2 21:12
 * @Author by hk
 */
@Service
public class FixItemServiceImpl implements FixItemService {

    @Resource
    private RepositoryFactory repositoryFactory;

    @DubboReference(version = "1.0.0", check = false)
    private SkuFacade skuFacade;


    @Override
    public PageResult<FixItemPageResult> page(FixItemPageRequest request) {

        //主表查询
        Page<FixItem> page = repositoryFactory.getFixItemRepository().page(request);
        if (StringUtils.isEmpty(page.getRecords())) {
            return PageResult.buildEmpty();
        }

        return PageResult.<FixItemPageResult>builder()
                .result(page.getRecords().stream()
                        .map(FixItemPageResult::fromEntity)
                        .collect(Collectors.toList()))
                .totalCount(page.getTotal())
                .totalPage(page.getPages())
                .build();
    }

    @Override
    public FixItem detail(FixItemDetailRequest request) {
        return repositoryFactory.getFixItemRepository().detail(request);
    }

    @Override
    public Boolean save(FixItemSaveRequest request) {
        return repositoryFactory.getFixItemRepository().save(request);
    }

    @Override
    public Boolean update(FixItemSaveRequest request) {
        return repositoryFactory.getFixItemRepository().update(request);
    }

    @Override
    public Boolean delete(FixItemDetailRequest request) {
        return repositoryFactory.getFixItemRepository().delete(request);
    }
}
