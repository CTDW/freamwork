package com.seeease.flywheel_v4.web.domain.excel.core;


import com.alibaba.cola.extension.ExtensionPointI;
import com.alibaba.excel.EasyExcel;
import com.seeease.springframework.exception.e.ArgumentException;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

/**
 * @author Tiro
 * @date 2023/3/30
 */
public interface ImportExtPtl<T , R> extends ExtensionPointI {
    /**
     * 获取入参class
     *
     * @return
     */
    Class<T> getRequestClass();

    /**
     * 参数校验
     *
     * @param data
     */
    void validate(List<T> data);

    /**
     * 导入处理
     *
     * @param data
     * @return
     */
    List<R> handle(List<T> data);

    /**
     * 参数转换
     */
    default List<T> convert(MultipartFile file) {
        try {
            return EasyExcel.read(file.getInputStream())
                    .head(getRequestClass())    // 行头类型匹配
                    .sheet(0)                // sheet(0)为第一张表位置
                    .doReadSync();

        }catch (Exception e){
            throw new ArgumentException("excel导入异常");
        }

    }
}