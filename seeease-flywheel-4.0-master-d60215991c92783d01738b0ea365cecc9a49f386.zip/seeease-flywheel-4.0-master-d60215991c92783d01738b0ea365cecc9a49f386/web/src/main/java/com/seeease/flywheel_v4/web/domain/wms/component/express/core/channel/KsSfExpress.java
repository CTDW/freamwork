package com.seeease.flywheel_v4.web.domain.wms.component.express.core.channel;

import com.alibaba.fastjson.JSONObject;
import com.kuaishou.merchant.open.api.KsMerchantApiException;
import com.kuaishou.merchant.open.api.client.AccessTokenKsMerchantClient;
import com.kuaishou.merchant.open.api.domain.express.*;
import com.kuaishou.merchant.open.api.request.express.OpenExpressEbillGetRequest;
import com.kuaishou.merchant.open.api.response.express.OpenExpressEbillGetResponse;
import com.seeease.flywheel_v4.web.app.sale.rpc.KsComponent;
import com.seeease.flywheel_v4.web.domain.wms.component.express.core.ExpressChannel;
import com.seeease.flywheel_v4.web.domain.wms.component.express.core.PlaceOrderDto;
import com.seeease.flywheel_v4.web.domain.wms.component.express.core.PlaceOrderResult;
import com.seeease.flywheel_v4.web.domain.wms.component.express.core.PrintResult;
import com.seeease.flywheel_v4.web.infrastructure.dao.RepositoryFactory;
import com.seeease.framework.ks.api.KsShopApi;
import com.seeease.springframework.exception.ValidationUtil;
import com.seeease.springframework.utils.StringUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.HashMap;
import java.util.UUID;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 9/20/24 5:01 下午
 **/
@Slf4j
@Component
public class KsSfExpress implements ExpressChannel<PrintResult.KsPrintResult> {

    /**
     * 国家编码（默认CHN，目前只有国内业务）
     */
    private static final String COUNTRY_CODE = "CHN";
    /**
     * 物流服务商编码
     */
    private static final String LOGISTICS_CODE = "SF";


    private final String ext = JSONObject.toJSONString(new HashMap<String, String>() {
        {
            put("isvClientCode", "XYWLKPnPx_WDKJ");
        }
    });

    @Resource
    private RepositoryFactory repositoryFactory;

    @Resource
    private KsComponent ksComponent;


    @Override
    public Channel getChannel() {
        return Channel.KS_SF;
    }

    @Override
    public PlaceOrderResult placeOrder(PlaceOrderDto dto) {
        //step_1 构建收货人
        Contract rec = new Contract();
        rec.setName(dto.getThirdSaleOrder().getBuyerInfo().getKsEncRec());
        rec.setMobile(dto.getThirdSaleOrder().getBuyerInfo().getKsEncTel());
        AddressDTO recAddr = new AddressDTO();
        recAddr.setProvinceName(dto.getProvince());
        recAddr.setCityName(dto.getCity());
        recAddr.setDistrictName(dto.getArea());
        recAddr.setStreetName(dto.getStreet());
        recAddr.setDetailAddress(dto.getThirdSaleOrder().getBuyerInfo().getKsEncAddr());

        //step_2 构建发货人
        Contract sp = new Contract();
        sp.setName(dto.getSpName());
        sp.setMobile(dto.getSpPhone());
        AddressDTO spAddr = new AddressDTO();
        spAddr.setProvinceName(dto.getSpProvince());
        spAddr.setCityName(dto.getSpCity());
        spAddr.setDistrictName(dto.getSpArea());
        spAddr.setStreetName(dto.getSpStreet());
        spAddr.setDetailAddress(dto.getSpAddress());

        //step_3 构建请求
        OpenExpressEbillGetRequest request = new OpenExpressEbillGetRequest();
        request.setAccessToken(ksComponent.getUserToken(dto.getSaleChannel()).getToken());

        GetEbillOrderRequest getEbillOrderRequest = new GetEbillOrderRequest();
        getEbillOrderRequest.setMerchantCode(dto.getThirdSaleOrder().getKsSellerId());
        getEbillOrderRequest.setMerchantName(dto.getSaleChannel().getName());

        //包裹 == 订单号
        getEbillOrderRequest.setPackageCode(dto.getThirdSaleOrder().getOrderId());
        getEbillOrderRequest.setTotalPackageQuantity(1L);
        ItemDTO itemDTO = new ItemDTO();
        itemDTO.setItemTitle(dto.getThirdSaleOrder().getTitle());
        itemDTO.setItemQuantity(1L);
        getEbillOrderRequest.setItemList(Collections.singletonList(itemDTO));

        getEbillOrderRequest.setReceiverContract(rec);
        getEbillOrderRequest.setReceiverAddress(recAddr);
        getEbillOrderRequest.setSenderContract(sp);
        getEbillOrderRequest.setSenderAddress(spAddr);


        getEbillOrderRequest.setExpressCompanyCode(LOGISTICS_CODE);
        getEbillOrderRequest.setOrderChannel("KUAI_SHOU");
        //https://docs.qingque.cn/d/home/eZQCstmJ4XYNo4WQdS1sPlw9E?identityId=1oEFwmDizx5#section=h.kb2i44jbl6if
        //	○ settleAccount（客户编码）：
        //		■ 必传，和商家订购服务 中的保持一致，本质为月结卡号；
        getEbillOrderRequest.setSettleAccount("5717175232");

        getEbillOrderRequest.setTradeOrderCode(dto.getThirdSaleOrder().getOrderId());

        getEbillOrderRequest.setExtData(ext);

        getEbillOrderRequest.setPayMethod(1);
        getEbillOrderRequest.setExpressProductCode("2");

        getEbillOrderRequest.setRequestId(UUID.randomUUID().toString().replace("-", ""));

        request.setGetEbillOrderRequest(Collections.singletonList(getEbillOrderRequest));
        OpenExpressEbillGetResponse response = null;

        log.info("快手快递下单请求:{}", JSONObject.toJSONString(request.getGetEbillOrderRequest()));


        try {
            AccessTokenKsMerchantClient client = new AccessTokenKsMerchantClient(
                    dto.getSaleChannel().getThirdNo(),
                    dto.getSaleChannel().getExt().getSignSecret()
            );
            response = client.execute(request);
        } catch (KsMerchantApiException e) {
            log.error(e.getErrorMsg(), e);
        }

        ValidationUtil.notNull(response, "顺丰下单失败");
        log.info("快手快递下单结果:{}", JSONObject.toJSONString(response.getData()));

        if (response.getResult() == 1) {
            return PlaceOrderResult.builder()
                    .success(true)
                    .businessNo(dto.getBusinessNo())
                    .expressNumber(response.getData().get(0).getData().get(0).getWaybillCode())
                    .build();
        }

        return PlaceOrderResult.builder()
                .success(false)
                .businessNo(dto.getBusinessNo())
                .errMsg(response.getErrorMsg())
                .build();

    }

    @Override
    public PrintResult.KsPrintResult printInfo(PlaceOrderResult placeOrderResult) {

        //请求下单接口
        OpenExpressEbillGetRequest request = new OpenExpressEbillGetRequest();
        KsShopApi.ParamUserToken userToken = ksComponent.getUserToken(placeOrderResult.getDto().getSaleChannel());
        request.setAccessToken(userToken.getToken());

        GetEbillOrderRequest getEbillOrderRequest = new GetEbillOrderRequest();
        getEbillOrderRequest.setMerchantCode(placeOrderResult.getDto().getThirdSaleOrder().getKsSellerId());
        getEbillOrderRequest.setMerchantName(placeOrderResult.getDto().getSaleChannel().getName());
        //包裹 == 订单号
        getEbillOrderRequest.setPackageCode(placeOrderResult.getDto().getThirdSaleOrder().getOrderId());

        getEbillOrderRequest.setTotalPackageQuantity(1L);

        ItemDTO itemDTO = new ItemDTO();
        //
        itemDTO.setItemTitle(placeOrderResult.getDto().getThirdSaleOrder().getTitle());
        itemDTO.setItemQuantity(1L);

        getEbillOrderRequest.setItemList(Collections.singletonList(itemDTO));

        //收件人
        Contract receiverContract = new Contract();
        receiverContract.setName(placeOrderResult.getDto().getName());
        receiverContract.setMobile(placeOrderResult.getDto().getPhone());
        getEbillOrderRequest.setReceiverContract(receiverContract);

        //收货地址
        AddressDTO receiverAddress = new AddressDTO();
        receiverAddress.setProvinceName(placeOrderResult.getDto().getProvince());
        receiverAddress.setCityName(placeOrderResult.getDto().getCity());
        receiverAddress.setDistrictName(placeOrderResult.getDto().getArea());
        receiverAddress.setStreetCode(placeOrderResult.getDto().getStreet());
        receiverAddress.setDetailAddress(placeOrderResult.getDto().getAddress());
        getEbillOrderRequest.setReceiverAddress(receiverAddress);

        //发件人
        Contract senderContract = new Contract();
        senderContract.setName(placeOrderResult.getDto().getSpName());
        senderContract.setMobile(placeOrderResult.getDto().getSpPhone());
        getEbillOrderRequest.setSenderContract(senderContract);
        //发货地址
        AddressDTO senderAddress = new AddressDTO();
        senderAddress.setProvinceName(placeOrderResult.getDto().getSpProvince());
        senderAddress.setCityName(placeOrderResult.getDto().getSpCity());
        senderAddress.setDistrictName(placeOrderResult.getDto().getSpArea());
        senderAddress.setStreetName(placeOrderResult.getDto().getSpStreet());
        senderAddress.setDetailAddress(placeOrderResult.getDto().getSpAddress());
        getEbillOrderRequest.setSenderAddress(senderAddress);


        getEbillOrderRequest.setExpressCompanyCode("SF");
        getEbillOrderRequest.setOrderChannel("KUAI_SHOU");
        //https://docs.qingque.cn/d/home/eZQCstmJ4XYNo4WQdS1sPlw9E?identityId=1oEFwmDizx5#section=h.kb2i44jbl6if
        //	○ settleAccount（客户编码）：
        //		■ 必传，和商家订购服务 中的保持一致，本质为月结卡号；
        getEbillOrderRequest.setSettleAccount("5717175232");

        getEbillOrderRequest.setTradeOrderCode(placeOrderResult.getDto().getThirdSaleOrder().getOrderId());

        getEbillOrderRequest.setExtData(JSONObject.toJSONString(new HashMap<String, String>() {
            {
                put("isvClientCode", "XYWLKPnPx_WDKJ");
            }
        }));

        getEbillOrderRequest.setPayMethod(1);
        getEbillOrderRequest.setExpressProductCode("2");

        getEbillOrderRequest.setRequestId(UUID.randomUUID().toString().replace("-", ""));

        request.setGetEbillOrderRequest(Collections.singletonList(getEbillOrderRequest));
        OpenExpressEbillGetResponse response = null;

        log.info("快手 打印请求参数:{}", JSONObject.toJSONString(request.getGetEbillOrderRequest()));
        try {
            AccessTokenKsMerchantClient client = new AccessTokenKsMerchantClient(
                    placeOrderResult.getDto().getSaleChannel().getThirdNo(),
                    placeOrderResult.getDto().getSaleChannel().getExt().getSignSecret()
            );

            response = client.execute(request);
        } catch (KsMerchantApiException e) {
            log.error(e.getErrorMsg(), e);
        }

        ValidationUtil.notNull(response, "快手下顺丰单失败");

        log.info("快手 打印结果:{}", JSONObject.toJSONString(response));

        if (response.getResult() != 1) {
            return null;
        }

        GetEbillOrderDTO getEbillOrderDTO = response.getData()
                .get(0)
                .getData()
                .get(0);



        //------------senderInfo------------//
        PrintResult.KsPrintResult.SenderInfo senderInfo = new PrintResult.KsPrintResult.SenderInfo();

        PrintResult.KsPrintResult.Address address = new PrintResult.KsPrintResult.Address();
        address.setCityName(placeOrderResult.getDto().getSpCity());
        address.setProvinceName(placeOrderResult.getDto().getSpProvince());
        address.setCountryCode(COUNTRY_CODE);
        address.setDistrictName(placeOrderResult.getDto().getSpArea());
        address.setStreetName(placeOrderResult.getDto().getSpStreet());
        address.setDetailAddress(placeOrderResult.getDto().getAddress());

        senderInfo.setAddress(address);


        PrintResult.KsPrintResult.Contact contact = new PrintResult.KsPrintResult.Contact();

        String phone = StringUtils.replace(
                placeOrderResult.getDto().getSpPhone(),
                3,
                placeOrderResult.getDto().getSpPhone().length() - 4,
                '*'
        );
        contact.setPhone(phone);
        contact.setName(placeOrderResult.getDto().getSpName());
        senderInfo.setContact(contact);

        //------------contentsDTO------------//
        PrintResult.KsPrintResult.ContentsDTO contentsDTO = new PrintResult.KsPrintResult.ContentsDTO();
        contentsDTO.setTemplateURL(placeOrderResult.getDto().getSaleChannel().getExt().getTemplateUrl());
        contentsDTO.setKey(getEbillOrderDTO.getKey());
        contentsDTO.setVer(getEbillOrderDTO.getVersion());
        contentsDTO.setSignature(getEbillOrderDTO.getSignature());
        contentsDTO.setEncryptedData(getEbillOrderDTO.getPrintData());
        HashMap<String, Object> addData = new HashMap<>();
        addData.put("senderInfo",senderInfo);
        contentsDTO.setAddData(addData);


        //------------documentsDTO------------//
        PrintResult.KsPrintResult.DocumentsDTO documentsDTO = new PrintResult.KsPrintResult.DocumentsDTO();
        documentsDTO.setWaybillCode(documentsDTO.getWaybillCode());
        documentsDTO.setKsOrderFlag(true);
        documentsDTO.setContents(Collections.singletonList(contentsDTO));


        //------------task------------//
        PrintResult.KsPrintResult.TaskDTO task = new PrintResult.KsPrintResult.TaskDTO();
        task.setPreview(false);
        task.setPrinter("");
        task.setFirstDocumentNumber(1);
        task.setTotalDocumentCount(1);
        task.setDocuments(Collections.singletonList(documentsDTO));


        PrintResult.KsPrintResult ret = new PrintResult.KsPrintResult();
        ret.setCmd("print");
        ret.setVersion("1.0");
        ret.setTask(task);
        return ret;
    }

}
