package com.seeease.flywheel_v4.web.app.wms.result;

import com.seeease.flywheel_v4.web.infrastructure.dao.sale.entity.obj.BuyBackPolicyObj;
import com.seeease.goods.rpc.request.SkuAnnexeRpcResult;
import com.seeease.goods.rpc.result.ProductParamRpcResult;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/4/24 6:00 下午
 **/
@Data
public class WmsCkPageResult {
    /**
     * 出库单id
     */
    private Integer id;
    /**
     * 业务单号
     */
    private String serialNo;
    /**
     * 业务类型
     */
    private Integer type;
    /**
     * 快递单号
     */
    private String expressNo;
    /**
     * 销售渠道
     */
    private Integer scType;
    /**
     * 订单来源
     */
    private String originName;
    /**
     * 创建时间
     */
    private Date createdTime;

    /**
     * 收货地址
     */
    private String address;
    /**
     * 质检情况
     */
    private Integer qualityWay;
    /**
     * 三方单号
     */
    private String thirdPartyNo;
    /**
     * 收货名称
      */
    private String name;
    /**
     * 收货电话
     */
    private String phone;
    /**
     * 国检码
     */
    private String qualityCode;
    /**
     * 备注
     */
    private String remark;

    /**
     * sku列表
     */
    private List<Sku> skuList;

    /**
     * 销售人
     */
    private String seller;

    @Data
    public static class Sku {
        /**
         * skuId
         */
        private Integer id;
        /**
         * spuId
         */
        private Integer spuId;

        /**
         * 蜥蜴编码
         */
        private String xyCode;
        /**
         * 商品编码
         */
        private String goodsCode;
        /**
         * 商品名称
         */
        private String goodsName;
        /**
         * 回购政策
         */
        private List<BuyBackPolicyObj> policies;
        /**
         * 类目id
         */
        private Integer categoryId;
        /**
         * 类目名称
         */
        private String categoryName;
        /**
         * 公价
         */
        private BigDecimal pubPrice;
        /**
         * 成交价
         */
        private BigDecimal dealPrice;
        /**
         * 图片
         */
        private String spuImage;
        /**
         * 品牌名称
         */
        private String brandName;
        /**
         * 是否唯一码管控
         */
        private Integer uniqueType;
        /**
         * 节点状态
         */
        private Integer nodeState;

        /**
         * sku参数列表
         */
        private List<ProductParamRpcResult> skuParams;
        /**
         * 附件
         */
        private List<SkuAnnexeRpcResult> annexe;
        /**
         * 唯一码
         */
        private String skuCode;

        /**
         * 出库数量
         */
        private Integer count;
    }


}
