package com.seeease.flywheel_v4.web.app.sys_config.request;



import com.seeease.springframework.PageRequest;
import lombok.Data;
import lombok.EqualsAndHashCode;


/**
 * <p>采购类型业务单元分页查询</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/3/24 11:26上午
 **/
@EqualsAndHashCode(callSuper = true)
@Data
public class PurchaseBusinessUnitPageRequest extends PageRequest {

    /**
     * 采购主体名称
     */
    private String name;
    /**
     * 采购类型
     */
    private Integer type;
    /**
     * 仓库id
     */
    private Integer storeId;


}
