package com.seeease.flywheel_v4.web.app.fix.service;

import com.seeease.flywheel_v4.web.app.fix.request.*;
import com.seeease.flywheel_v4.web.app.fix.result.FixOrderDetailResult;
import com.seeease.flywheel_v4.web.app.fix.result.FixOrderPageResult;
import com.seeease.flywheel_v4.web.app.fix.result.FixOrderPartPageResult;
import com.seeease.flywheel_v4.web.app.fix.result.FixStatusCountResult;
import com.seeease.flywheel_v4.web.infrastructure.dao.fix.entity.FixOrderPart;
import com.seeease.springframework.PageResult;

import java.util.List;

/**
 * @Description 维修单-配件
 * @Date 2024-10-2 21:11
 * @Author by hk
 */
public interface FixOrderPartService {

    /**
     * 维修中心-维修单-配件列表
     *
     * @param request 请求 * @return 列表结果
     */
    PageResult<FixOrderPartPageResult> page(FixOrderPartPageRequest request);

}
