package com.seeease.flywheel_v4.web.infrastructure.dao.purchase.repo;


import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.seeease.flywheel_v4.web.app.purchase.request.PurchaseOrderPageRequest;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.entity.PurchaseOrder;

import java.util.List;
import java.util.Set;

/**
 *
 * @author 西门 游
 * @version 1.0
 * @since 5/31/24 4:55 下午
 **/
public interface PurchaseOrderRepository {
    /**
     * 提交
     * @param purchaseOrder
     * @return 提交结果
     */
    Boolean submit(PurchaseOrder purchaseOrder);

    /**
     * 分页查询
     * @param request
     * @param idList 主键id列表
     * @return
     */
    Page<PurchaseOrder> page(PurchaseOrderPageRequest request, Set<Integer> idList);



    /**
     * 查找
     * @param id 主键id
     * @return
     */
    PurchaseOrder findById(Integer id);

    /**
     * 查找
     * @param id id
     * @param serialNo 编号
     * @return
     */
    PurchaseOrder findByIdOrSerialNo(Integer id, String serialNo);



    /**
     * 列表查询
     * @param serialNo 采购单号
     * @param supplierId 供应商id
     * @return
     */
    List<PurchaseOrder> list(String serialNo, Integer supplierId);



    /**
     * 事务状态变更提交
     * @param order
     * @return
     */
    Boolean submitWithState(PurchaseOrder order);



    /**
     * 查询
     * @param idList 主键id列表
     * @return
     */
    List<PurchaseOrder> listByIds(Set<Integer> idList);

    /**
     * 查询
     * @param serialNo
     * @return
     */
    List<PurchaseOrder> listBySerialNos(Set<String> serialNo);
}
