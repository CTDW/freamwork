package com.seeease.flywheel_v4.web.adptor.fix;

import com.seeease.flywheel_v4.web.app.fix.request.FixOrderPartPageRequest;
import com.seeease.flywheel_v4.web.app.fix.result.FixOrderPartPageResult;
import com.seeease.flywheel_v4.web.app.fix.service.FixOrderPartService;
import com.seeease.flywheel_v4.web.infrastructure.config.IdentifyLogPrinter;
import com.seeease.springframework.PageResult;
import com.seeease.springframework.SingleResponse;
import com.seeease.springframework.log.annotation.LogPrinter;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;


/**
 * @Description 维修 配件
 * @Date 2024-10-2 10:10
 * @Author by hk
 */
@RestController
@RequestMapping("fix")
@Api(tags = "维修配件 控制层")
public class FixPartController {

    @Resource
    private FixOrderPartService fixOrderPartService;

    @ApiOperation(value = "配件使用明细")
    @PostMapping("/fixPart/page")
    @LogPrinter(scenario = "维修中心-库存-配件使用明细分页", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<PageResult<FixOrderPartPageResult>> page(@RequestBody FixOrderPartPageRequest request) {

        return SingleResponse.of(fixOrderPartService.page(request));
    }
}
