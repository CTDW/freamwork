package com.seeease.flywheel_v4.web.app.finance.service.impl;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.seeease.flywheel_v4.client.enums.BusinessUnitTypeEnums;
import com.seeease.flywheel_v4.web.app.finance.request.PaymentSlipDetailRequest;
import com.seeease.flywheel_v4.web.app.finance.request.PaymentSlipPageRequest;
import com.seeease.flywheel_v4.web.app.finance.request.PaymentSlipSubmitRequest;
import com.seeease.flywheel_v4.web.app.finance.request.PaymentSlipUploadPayedImgRequest;
import com.seeease.flywheel_v4.web.app.finance.result.PaymentSlipDetailResult;
import com.seeease.flywheel_v4.web.app.finance.result.PaymentSlipPageResult;
import com.seeease.flywheel_v4.web.app.finance.service.FinancePaymentSlipService;
import com.seeease.flywheel_v4.web.domain.finance.mapping.FinancePaymentSlipMapping;
import com.seeease.flywheel_v4.web.domain.finance.strategy.FinanceStrategyFactory;
import com.seeease.flywheel_v4.web.domain.operations.mapping.SupplierContactsMapping;
import com.seeease.flywheel_v4.web.infrastructure.dao.RepositoryFactory;
import com.seeease.flywheel_v4.web.infrastructure.dao.finance.entity.FinancePaymentSlip;
import com.seeease.flywheel_v4.web.infrastructure.dao.finance.entity.obj.ImageGroupObj;
import com.seeease.flywheel_v4.web.infrastructure.dao.finance.enums.PaymentSlipStateEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.Supplier;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.SupplierContacts;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.entity.PurchaseOrder;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.entity.PurchaseOrderLine;
import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.entity.SysBusinessUnit;
import com.seeease.goods.rpc.SkuFacade;
import com.seeease.goods.rpc.request.SkuBusinessSubmitRpcRequest;
import com.seeease.goods.rpc.request.SkuRpcRequest;
import com.seeease.goods.rpc.result.SkuRpcResult;
import com.seeease.springframework.PageResult;
import com.seeease.springframework.context.UserContext;
import com.seeease.springframework.exception.ValidationUtil;
import com.seeease.springframework.utils.MultiUtils;
import com.seeease.springframework.utils.StringUtils;
import io.seata.spring.annotation.GlobalTransactional;
import lombok.extern.slf4j.Slf4j;
import org.apache.dubbo.config.annotation.DubboReference;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/12/24 9:54 上午
 **/
@Service
@Slf4j
public class FinancePaymentSlipServiceImpl implements FinancePaymentSlipService {
    @Resource
    private RepositoryFactory repositoryFactory;
    @Resource
    private FinanceStrategyFactory strategyFactory;
    @DubboReference(check = false, version = "1.0.0")
    private SkuFacade skuFacade;


    /**
     * 更新 | 创建 申请打款单通用部分代码
     *
     * @param request 创建请求
     */
    @Transactional
    public void submit(PaymentSlipSubmitRequest request) {
        PurchaseOrder purchaseOrder = repositoryFactory.getPurchaseOrderRepository().findById(request.getPurchaseId());
        ValidationUtil.notNull(purchaseOrder, "采购单不存在");

        //执行不同采购类型的前置逻辑校验
        strategyFactory.findPaymentSlipPreStrategyAndDo(request, purchaseOrder.getType());

        //修改供应商信息
        Supplier supplier = repositoryFactory.getSupplierRepository().findById(purchaseOrder.getSupplierId());
        supplier.setName(request.getSupplierName());
        ValidationUtil.isTrue(
                repositoryFactory.getSupplierRepository().submit(supplier),
                "修改供应商失败"
        );

        //修改联系人信息
        SupplierContacts contacts = repositoryFactory.getSupplierContactsRepository()
                .findById(purchaseOrder.getSupplierContactId());
        SupplierContactsMapping.INSTANCE.toEntityForUpdate(contacts, request);
        ValidationUtil.isTrue(
                repositoryFactory.getSupplierContactsRepository().submit(contacts),
                "修改供应商联系人失败"
        );

    }

    @GlobalTransactional
    @Override
    public Boolean create(PaymentSlipSubmitRequest request) {
        PurchaseOrder purchaseOrder = repositoryFactory.getPurchaseOrderRepository()
                .findById(request.getPurchaseId());

        //提交其他表数据
        this.submit(request);

        //创建申请打款单
        FinancePaymentSlip paymentSlip = FinancePaymentSlipMapping.INSTANCE.toEntity(
                purchaseOrder,
                request
        );
        paymentSlip.setBuId(UserContext.getUser().getStore().getId());
        repositoryFactory.getFinancePaymentSlipRepository().submit(paymentSlip);





        //执行不同采购类型的后置处理
        strategyFactory.findPaymentSlipPostStrategyAndDo(request, purchaseOrder.getType(), paymentSlip);


        //rpc -- sku业务数据绑定
        Set<Integer> skuIdList = MultiUtils.toSet(
                repositoryFactory.getPurchaseOrderLineRepository().listByPurchaseId(purchaseOrder.getId()),
                PurchaseOrderLine::getSkuId
        );
        SkuBusinessSubmitRpcRequest skuBusinessSubmitRpcRequest = FinancePaymentSlipMapping.INSTANCE
                .toSkuBusiness(
                        skuIdList,
                        paymentSlip.getSerialNo(),
                        PaymentSlipStateEnums.WAIT_CONFIRM,
                        false
                );
        skuFacade.businessSubmit(skuBusinessSubmitRpcRequest);
        return true;
    }


    @GlobalTransactional
    @Override
    public Boolean update(PaymentSlipSubmitRequest request) {
        FinancePaymentSlip paymentSlip = repositoryFactory.getFinancePaymentSlipRepository().
                findById(request.getId());
        ValidationUtil.notNull(paymentSlip, "id错误");

        //提交其他表数据
        request.setPurchaseId(paymentSlip.getPurchaseId());
        this.submit(request);

        //更新申请打款单
        FinancePaymentSlipMapping.INSTANCE.toEntityForUpdate(paymentSlip, request);
        //将打款金额赋值给实际打款金额
        paymentSlip.setPayAmount(paymentSlip.getAmount());

        if (request.getState().equals(PaymentSlipStateEnums.TURN_DOWN.getValue())) {
            paymentSlip.setTransitionStateEnum(PaymentSlipStateEnums.TransitionEnum.STEP_4);
        } else if (request.getState().equals(PaymentSlipStateEnums.VOID.getValue())) {
            paymentSlip.setTransitionStateEnum(PaymentSlipStateEnums.TransitionEnum.STEP_5);
        } else {
            throw new IllegalArgumentException("申请打款单状态异常无法更新");
        }

        repositoryFactory.getFinancePaymentSlipRepository().submitWithState(paymentSlip);

        //rpc -- sku业务数据绑定
        Set<Integer> skuIdList = MultiUtils.toSet(
                repositoryFactory.getPurchaseOrderLineRepository().listByPurchaseId(paymentSlip.getPurchaseId()),
                PurchaseOrderLine::getSkuId
        );
        SkuBusinessSubmitRpcRequest skuBusinessSubmitRpcRequest = FinancePaymentSlipMapping.INSTANCE
                .toSkuBusiness(
                        skuIdList,
                        paymentSlip.getSerialNo(),
                        PaymentSlipStateEnums.WAIT_CONFIRM,
                        false
                );
        skuFacade.businessSubmit(skuBusinessSubmitRpcRequest);

        return true;
    }


    @Override
    public PageResult<PaymentSlipPageResult> page(PaymentSlipPageRequest request) {


        //搜索-采购订单行查询
        if (StringUtils.isNotEmpty(request.getSkuCode())) {
            SkuRpcRequest skuRpcRequest = new SkuRpcRequest();
            skuRpcRequest.setSkuCode(request.getSkuCode());
            Set<Integer> skuIdList = MultiUtils.toSet(
                    skuFacade.list(skuRpcRequest),
                    SkuRpcResult::getId
            );
            if (StringUtils.isEmpty(skuIdList)) {
                return PageResult.buildEmpty();
            }
            Set<Integer> purchaseIdList = MultiUtils.toSet(
                    repositoryFactory.getPurchaseOrderLineRepository().listBySkuIds(skuIdList),
                    PurchaseOrderLine::getPurchaseId
            );
            if (StringUtils.isEmpty(purchaseIdList)) {
                return PageResult.buildEmpty();
            }
            request.getPurchaseIdList().addAll(purchaseIdList);
        }



        //搜索-供应商搜索
        List<Supplier> supplierList = null;

        if (StringUtils.isNotEmpty(request.getSupplierName())) {

            supplierList = repositoryFactory.getSupplierRepository().listByName(request.getSupplierName());
            Set<Integer> supplierIdList = MultiUtils.toSet(supplierList, Supplier::getId);
            request.setSupplierIdList(supplierIdList);

            if (StringUtils.isEmpty(supplierIdList)) {
                return PageResult.buildEmpty();
            }
        }


        //搜索-主表查询
        Integer buId = UserContext.getUser().getStore().getId();
        SysBusinessUnit bu = repositoryFactory.getBusinessUnitRepository().findById(buId);
        if (bu.getType() == BusinessUnitTypeEnums.MERCHANT) {
            request.setBuId(buId);
        }

        Page<FinancePaymentSlip> page = repositoryFactory.getFinancePaymentSlipRepository()
                .page(request);

        if (page.getRecords().isEmpty()) {
            return PageResult.buildEmpty();
        }

        //组合数据
        //供应商

        if (null == supplierList) {
            Set<Integer> supplierIdList = MultiUtils.toSet(page.getRecords(), FinancePaymentSlip::getSupplierId);
            supplierList = repositoryFactory.getSupplierRepository().listByIds(supplierIdList);
        }

        Map<Integer, String> supplierMap = MultiUtils.toMap(
                supplierList,
                Supplier::getId,
                Supplier::getName
        );


        //采购主体
        Set<Integer> purchaseSubjectIdList = MultiUtils.toSet(page.getRecords(), FinancePaymentSlip::getPurchaseSubjectId);
        Map<Integer, String> purchaseSubjectMap = MultiUtils.toMap(
                repositoryFactory.getBusinessUnitRepository().listByIds(purchaseSubjectIdList),
                SysBusinessUnit::getId,
                SysBusinessUnit::getName
        );


        List<PaymentSlipPageResult> ret = MultiUtils.toList(
                page.getRecords(),
                v -> FinancePaymentSlipMapping.INSTANCE.toPageResult(
                        v,
                        supplierMap.get(v.getSupplierId()),
                        purchaseSubjectMap.get(v.getPurchaseSubjectId()))
        );


        return PageResult.<PaymentSlipPageResult>builder()
                .result(ret)
                .totalCount(page.getTotal())
                .totalPage(page.getPages())
                .build();
    }

    @Override
    public PaymentSlipDetailResult details(PaymentSlipDetailRequest request) {
        //申请打款单
        FinancePaymentSlip paymentSlip = repositoryFactory.getFinancePaymentSlipRepository()
                .findByIdOrSerial(request.getId(), request.getSerialNo());
        ValidationUtil.notNull(paymentSlip, "未查询到对应打款单");
        //采购单
        PurchaseOrder purchaseOrder = repositoryFactory.getPurchaseOrderRepository()
                .findById(paymentSlip.getPurchaseId());

        //采购单sku
        Map<Integer, PurchaseOrderLine> lineMap = MultiUtils.toMap(
                repositoryFactory.getPurchaseOrderLineRepository().listByPurchaseId(purchaseOrder.getId()),
                PurchaseOrderLine::getSkuId,
                Function.identity()
        );
        SkuRpcRequest skuRpcRequest = new SkuRpcRequest();
        skuRpcRequest.setIdList(lineMap.keySet());
        List<PaymentSlipDetailResult.Sku> skuList = MultiUtils.toList(
                skuFacade.list(skuRpcRequest),
                v -> FinancePaymentSlipMapping.INSTANCE.toSkuResult(v, lineMap.get(v.getId()))
        );

        //采购主体
        SysBusinessUnit purchaseSubject = repositoryFactory.getBusinessUnitRepository()
                .findById(purchaseOrder.getPurchaseSubjectId());

        //商家
        SysBusinessUnit merchant = repositoryFactory.getBusinessUnitRepository()
                .findById(purchaseOrder.getMerchantId());

        //供应商
        Supplier supplier = repositoryFactory.getSupplierRepository()
                .findById(purchaseOrder.getSupplierId());

        // 联系人
        SupplierContacts contacts = repositoryFactory.getSupplierContactsRepository()
                .findById(purchaseOrder.getSupplierContactId());


        //组合数据
        return FinancePaymentSlipMapping.INSTANCE.toDetailResult(
                paymentSlip,
                purchaseOrder,
                skuList,
                purchaseSubject,
                supplier,
                contacts,
                merchant
        );
    }

    @GlobalTransactional
    @Override
    public Boolean uploadPayedImg(PaymentSlipUploadPayedImgRequest request) {
        FinancePaymentSlip paymentSlip = repositoryFactory.getFinancePaymentSlipRepository()
                .findById(request.getId());
        ValidationUtil.notNull(paymentSlip, "id错误");

        paymentSlip.setPayTime(new Date());
        paymentSlip.setTransitionStateEnum(PaymentSlipStateEnums.TransitionEnum.STEP_1);
        ImageGroupObj imageGroup = paymentSlip.getImageGroup();
        if (null == imageGroup) {
            imageGroup = new ImageGroupObj();
        }
        imageGroup.setPayedImg(request.getPayedImg());

        ValidationUtil.isTrue(
                repositoryFactory.getFinancePaymentSlipRepository().submitWithState(paymentSlip),
                "上传打款凭证失败"
        );


        //rpc -- sku业务数据绑定
        Set<Integer> skuIdList = MultiUtils.toSet(
                repositoryFactory.getPurchaseOrderLineRepository().listByPurchaseId(paymentSlip.getPurchaseId()),
                PurchaseOrderLine::getSkuId
        );
        SkuBusinessSubmitRpcRequest skuBusinessSubmitRpcRequest = FinancePaymentSlipMapping.INSTANCE
                .toSkuBusiness(
                        skuIdList,
                        paymentSlip.getSerialNo(),
                        PaymentSlipStateEnums.CONFIRMED,
                        true
                );
        skuFacade.businessSubmit(skuBusinessSubmitRpcRequest);

        return true;
    }


    @GlobalTransactional
    @Override
    public Boolean state(PaymentSlipSubmitRequest request) {
        FinancePaymentSlip paymentSlip = repositoryFactory.getFinancePaymentSlipRepository()
                .findById(request.getId());
        ValidationUtil.notNull(paymentSlip, "id错误");

        if (request.getState().equals(PaymentSlipStateEnums.TURN_DOWN.getValue())) {
            paymentSlip.setTransitionStateEnum(PaymentSlipStateEnums.TransitionEnum.STEP_2);
        } else if (request.getState().equals(PaymentSlipStateEnums.VOID.getValue())) {
            paymentSlip.setTransitionStateEnum(PaymentSlipStateEnums.TransitionEnum.STEP_3);
        } else {
            return true;
        }
        ValidationUtil.isTrue(
                repositoryFactory.getFinancePaymentSlipRepository().submitWithState(paymentSlip),
                "作废或驳回失败"
        );

        //rpc -- sku业务数据绑定
        Set<Integer> skuIdList = MultiUtils.toSet(
                repositoryFactory.getPurchaseOrderLineRepository().listByPurchaseId(paymentSlip.getPurchaseId()),
                PurchaseOrderLine::getSkuId
        );
        SkuBusinessSubmitRpcRequest skuBusinessSubmitRpcRequest = FinancePaymentSlipMapping.INSTANCE
                .toSkuBusiness(
                        skuIdList,
                        paymentSlip.getSerialNo(),
                        (PaymentSlipStateEnums) paymentSlip.getTransitionStateEnum().getToState(),
                        false
                );
        skuFacade.businessSubmit(skuBusinessSubmitRpcRequest);

        return true;
    }


}
