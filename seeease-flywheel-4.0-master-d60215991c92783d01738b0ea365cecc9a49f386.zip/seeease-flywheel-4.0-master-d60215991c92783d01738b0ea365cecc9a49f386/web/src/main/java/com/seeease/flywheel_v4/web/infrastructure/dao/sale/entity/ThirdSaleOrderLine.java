package com.seeease.flywheel_v4.web.infrastructure.dao.sale.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.seeease.seeeaseframework.mybatis.domain.BaseDomain;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;

/**
 * 三方销售订单
 */
@EqualsAndHashCode(callSuper = true)
@TableName(value = "v4_third_sale_order_line", autoResultMap = true)
@Data
public class ThirdSaleOrderLine extends BaseDomain {
    @TableId(type = IdType.AUTO)
    private Integer id;

    /**
     * 三方订单id
     */
    private String orderId;
    /**
     * spuId
     */
    private Integer spuId;
    /**
     * skuId
     */
    private Integer skuId;
    /**
     * 金额
     */
    private BigDecimal price;
    /**
     * 数量
     */
    private Integer count;

}