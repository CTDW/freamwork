package com.seeease.flywheel_v4.web.app.wms.request;


import lombok.Data;

import javax.validation.constraints.NotEmpty;
import java.util.Set;

/**
 * @ Description   :
 * @ Author        :  西门 游
 * @ CreateDate    :  6/6/24
 * @ Version       :  1.0
 */

@Data
public class WmsCkCancelRequest  {
    /**
     * id列表
     */
    @NotEmpty(message = "id数组不能为空")
    private Set<Integer> idList;
}
