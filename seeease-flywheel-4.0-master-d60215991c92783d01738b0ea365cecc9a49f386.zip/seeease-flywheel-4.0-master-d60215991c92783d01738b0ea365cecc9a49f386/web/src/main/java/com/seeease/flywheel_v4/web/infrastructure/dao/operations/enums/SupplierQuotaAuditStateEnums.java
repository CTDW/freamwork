package com.seeease.flywheel_v4.web.infrastructure.dao.operations.enums;

import com.baomidou.mybatisplus.annotation.IEnum;
import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @ Description   :  供应商类型
 * @ Author        :  西门 游
 * @ CreateDate    :  6/4/24
 * @ Version       :  1.0
 */
@Getter
@AllArgsConstructor
public enum SupplierQuotaAuditStateEnums implements IEnum<Integer> {
    WAIT(1,"待审核"),
    PASS(2,"通过"),
    FAIL(3,"驳回"),
    CANCEL(4,"取消")
    ;

    private Integer value;
    private String desc;
}
