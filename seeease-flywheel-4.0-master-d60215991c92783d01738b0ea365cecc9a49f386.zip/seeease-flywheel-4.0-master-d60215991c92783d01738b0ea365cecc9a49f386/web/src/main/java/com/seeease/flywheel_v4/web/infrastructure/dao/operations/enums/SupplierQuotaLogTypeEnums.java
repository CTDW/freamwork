package com.seeease.flywheel_v4.web.infrastructure.dao.operations.enums;

import com.baomidou.mybatisplus.annotation.IEnum;
import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @ Description   :  供应商类型
 * @ Author        :  西门 游
 * @ CreateDate    :  6/4/24
 * @ Version       :  1.0
 */
@Getter
@AllArgsConstructor
public enum SupplierQuotaLogTypeEnums implements IEnum<Integer> {
    SPENT(1,"消费"),
    RETURN(2,"退款"),
    TOP_UP(3,"充值"),
    CANCEL(4,"销售取消"),
    ;

    private Integer value;
    private String desc;
}
