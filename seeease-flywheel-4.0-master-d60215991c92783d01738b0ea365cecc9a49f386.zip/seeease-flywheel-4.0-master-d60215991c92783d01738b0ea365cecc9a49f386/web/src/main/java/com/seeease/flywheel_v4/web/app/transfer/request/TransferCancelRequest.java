package com.seeease.flywheel_v4.web.app.transfer.request;


import lombok.Data;

/**
 * @author 西门 游
 * @version 1.0
 * @since 6/3/24 11:26 上午
 **/
@Data
public class TransferCancelRequest {

    /**
     * 调拨单主单id
     */
    private Integer id;

    /**
     * 行id
     */
    private Integer lineId;
}
