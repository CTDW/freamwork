package com.seeease.flywheel_v4.web.domain.excel.core;

import lombok.Data;

import javax.servlet.http.HttpServletResponse;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 *
 * @param <T>
 */
@Data
public class ExportCmd<T> implements Serializable {

    /**
     * 用例(扩展点使用)
     */
    private String useCase;
    /**
     * 业务id(扩展点使用)
     */
    private String bizCode = "export";
    /**
     * 传递入参
     */
    @NotNull(message = "request不能为空")
    private T request;
    /**
     * 导出响应
     */
    private HttpServletResponse response;
}
