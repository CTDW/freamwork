package com.seeease.flywheel_v4.web.domain.sys_config.mapping;


import com.alibaba.fastjson.JSONObject;
import com.seeease.flywheel_v4.client.enums.BusinessUnitTypeEnums;
import com.seeease.flywheel_v4.client.result.BusinessUnitRpcResult;
import com.seeease.flywheel_v4.web.app.sys_config.request.BusinessUnitSubmitRequest;
import com.seeease.flywheel_v4.web.app.sys_config.request.PurchaseBusinessUnitSubmitRequest;
import com.seeease.flywheel_v4.web.app.sys_config.result.BusinessUnitListResult;
import com.seeease.flywheel_v4.web.app.sys_config.result.BusinessUnitPageResult;
import com.seeease.flywheel_v4.web.app.sys_config.result.PurchaseBusinessUnitPageResult;
import com.seeease.flywheel_v4.web.infrastructure.config.SimpleMapping;
import com.seeease.flywheel_v4.client.enums.PurchaseTypeEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.entity.SysBusinessUnit;
import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.entity.obj.MerchantBusinessUnitExtObj;
import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.entity.obj.PurchaseSubjectBusinessUnitExtObj;
import com.seeease.seeeaseframework.mybatis.utils.EnumUtils;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;

import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;


/**
 * <p>
 * 商品附件
 * </p>
 *
 * @author 西门 游
 * @since 2023-10-27
 */
@Mapper(componentModel = "spring",
        builder = @Builder(disableBuilder = true),
        nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS,
        nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE,
        imports = {BusinessUnitTypeEnums.class})
public interface BusinessUnitMapping extends SimpleMapping<BusinessUnitSubmitRequest, SysBusinessUnit> {

    BusinessUnitMapping INSTANCE = Mappers.getMapper(BusinessUnitMapping.class);


    BusinessUnitPageResult toPageResult(SysBusinessUnit e);

    BusinessUnitListResult toListResult(SysBusinessUnit e);

    @Mapping(target = "type", expression = "java(BusinessUnitTypeEnums.PURCHASE)")
    @Mapping(target = "ext", expression = "java(toPurchaseUnitObj(request))")
    SysBusinessUnit toEntity(PurchaseBusinessUnitSubmitRequest request);

    PurchaseSubjectBusinessUnitExtObj toPurchaseUnitObj(PurchaseBusinessUnitSubmitRequest request);


    default PurchaseSubjectBusinessUnitExtObj toPurchaseUnitObj(Object e) {
        if (null == e) {
            return null;
        }
        return JSONObject.parseObject(JSONObject.toJSONString(e), PurchaseSubjectBusinessUnitExtObj.class);
    }

    @Mapping(target = "typeName", expression = "java(toPurchaseTypeName(ext))")
    @Mapping(target = "storeName", expression = "java(toPurchaseStoreIdList(ext,storeIdMap))")
    PurchaseBusinessUnitPageResult toPurchaseBusinessUnitPageResult(SysBusinessUnit e,
                                                                    Map<Integer, String> storeIdMap,
                                                                    PurchaseSubjectBusinessUnitExtObj ext);

    default String toPurchaseTypeName(PurchaseSubjectBusinessUnitExtObj ext) {
        if (null == ext){
            return "";
        }
        return ext.getTypeList()
                .stream()
                .map(v -> EnumUtils.of(PurchaseTypeEnums.class, v).getDesc())
                .collect(Collectors.joining(","));

    }

    default String toPurchaseStoreIdList(PurchaseSubjectBusinessUnitExtObj ext,
                                         Map<Integer, String> storeIdMap) {
        if (null == ext){
            return "";
        }
        return ext.getStoreIdList()
                .stream()
                .map(storeIdMap::get)
                .filter(Objects::nonNull)
                .collect(Collectors.joining(","));
    }


    BusinessUnitRpcResult toRpcResult(SysBusinessUnit businessUnit);


    MerchantBusinessUnitExtObj toMerchantExt(BusinessUnitSubmitRequest request);

    BusinessUnitListResult toListResult(SysBusinessUnit v, MerchantBusinessUnitExtObj ext);

    BusinessUnitPageResult toPageResult(SysBusinessUnit v, MerchantBusinessUnitExtObj ext);
}
