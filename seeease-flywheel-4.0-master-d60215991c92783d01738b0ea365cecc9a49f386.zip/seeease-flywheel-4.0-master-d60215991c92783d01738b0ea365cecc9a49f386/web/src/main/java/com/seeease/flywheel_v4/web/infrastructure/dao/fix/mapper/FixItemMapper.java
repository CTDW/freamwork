package com.seeease.flywheel_v4.web.infrastructure.dao.fix.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.seeease.flywheel_v4.web.infrastructure.dao.fix.entity.FixItem;

/**
 * @Description 维修项目
 * @Date 2024-10-2 21:02
 * @Author by hk
 */
public interface FixItemMapper extends BaseMapper<FixItem> {
}
