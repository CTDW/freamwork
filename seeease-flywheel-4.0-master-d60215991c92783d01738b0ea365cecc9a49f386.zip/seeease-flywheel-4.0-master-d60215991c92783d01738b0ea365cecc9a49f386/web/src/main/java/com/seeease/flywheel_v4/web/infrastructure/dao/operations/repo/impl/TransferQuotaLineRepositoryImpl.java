package com.seeease.flywheel_v4.web.infrastructure.dao.operations.repo.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.TransferQuotaLine;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.mapper.TransferQuotaLineMapper;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.repo.TransferQuotaLineRepository;
import org.springframework.stereotype.Repository;

import java.util.Collections;
import java.util.List;
import java.util.Set;

/**
 * @author 西门 游
 * @version 1.0
 * @since 5/31/24 4:55 下午
 **/
@Repository
public class TransferQuotaLineRepositoryImpl extends ServiceImpl<TransferQuotaLineMapper, TransferQuotaLine>
        implements TransferQuotaLineRepository {


    @Override
    public Boolean submitBatch(List<TransferQuotaLine> list) {
        return saveOrUpdateBatch(list);
    }

    @Override
    public List<TransferQuotaLine> listByTsqId(Integer tsqId) {
        if (null == tsqId){
            return Collections.emptyList();
        }
        LambdaQueryWrapper<TransferQuotaLine> wq = Wrappers.<TransferQuotaLine>lambdaQuery()
                .eq(TransferQuotaLine::getTsqId, tsqId);

        return baseMapper.selectList(wq);
    }

    @Override
    public Boolean delByIds(Set<Integer> idList) {
        return baseMapper.deleteBatchIds(idList) > 0;
    }

    @Override
    public List<TransferQuotaLine> listByTsqIdList(Set<Integer> tfqIdList) {
        if (tfqIdList.isEmpty()){
            return Collections.emptyList();
        }
        LambdaQueryWrapper<TransferQuotaLine> wq = Wrappers.<TransferQuotaLine>lambdaQuery()
                .in(TransferQuotaLine::getTsqId, tfqIdList);

        return baseMapper.selectList(wq);
    }
}
