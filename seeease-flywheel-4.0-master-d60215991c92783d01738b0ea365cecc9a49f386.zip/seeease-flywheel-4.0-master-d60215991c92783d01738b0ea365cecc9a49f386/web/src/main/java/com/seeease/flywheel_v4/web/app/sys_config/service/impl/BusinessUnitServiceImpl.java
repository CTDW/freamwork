package com.seeease.flywheel_v4.web.app.sys_config.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.seeease.flywheel_v4.web.app.sys_config.request.*;
import com.seeease.flywheel_v4.web.app.sys_config.result.BusinessUnitListResult;
import com.seeease.flywheel_v4.web.app.sys_config.result.BusinessUnitPageResult;
import com.seeease.flywheel_v4.web.app.sys_config.result.PurchaseBusinessUnitPageResult;
import com.seeease.flywheel_v4.web.app.sys_config.service.BusinessUnitService;
import com.seeease.flywheel_v4.web.domain.sys_config.mapping.BusinessUnitMapping;
import com.seeease.flywheel_v4.web.infrastructure.dao.RepositoryFactory;
import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.entity.SysBusinessUnit;
import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.entity.obj.MerchantBusinessUnitExtObj;
import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.entity.obj.PurchaseSubjectBusinessUnitExtObj;
import com.seeease.flywheel_v4.client.enums.BusinessUnitTypeEnums;
import com.seeease.springframework.PageResult;
import com.seeease.springframework.exception.ValidationUtil;
import com.seeease.springframework.utils.MultiUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;


/**
 * <p>系统业务单元服务</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/3/24 11:19 上午
 **/
@Service
public class BusinessUnitServiceImpl implements BusinessUnitService {
    @Resource
    private RepositoryFactory repositoryFactory;


    @Override
    public Boolean create(BusinessUnitSubmitRequest request) {
        SysBusinessUnit e = BusinessUnitMapping.INSTANCE.toEntity(request);

        if (Objects.equals(request.getType(), BusinessUnitTypeEnums.MERCHANT.getValue())) {
            MerchantBusinessUnitExtObj ext = BusinessUnitMapping.INSTANCE.toMerchantExt(request);
            e.setExt(ext);
        }

        return repositoryFactory.getBusinessUnitRepository()
                .submit(e);
    }

    @Override
    public Boolean update(BusinessUnitSubmitRequest request) {
        SysBusinessUnit e = BusinessUnitMapping.INSTANCE.toEntity(request);
        if (Objects.equals(request.getType(), BusinessUnitTypeEnums.MERCHANT.getValue())) {
            MerchantBusinessUnitExtObj ext = BusinessUnitMapping.INSTANCE.toMerchantExt(request);
            e.setExt(ext);
        }
        return repositoryFactory.getBusinessUnitRepository()
                .submit(e);
    }

    @Override
    public PageResult<BusinessUnitPageResult> page(BusinessUnitPageRequest request) {
        Page<SysBusinessUnit> page = repositoryFactory.getBusinessUnitRepository()
                .page(
                        request.getType(),
                        request.getHead(),
                        request.getName(),
                        request
                );

        if (page.getRecords().isEmpty()){
            return PageResult.buildEmpty();
        }

        List<BusinessUnitPageResult> ret = MultiUtils.toList(
                page.getRecords(),
                v -> {
                    if (v.getType() == BusinessUnitTypeEnums.MERCHANT) {
                        MerchantBusinessUnitExtObj ext;
                        if (null != v.getExt()) {
                            ext = JSONObject.parseObject(JSONObject.toJSONString(v.getExt()), MerchantBusinessUnitExtObj.class);
                            return BusinessUnitMapping.INSTANCE.toPageResult(v, ext);
                        }
                    }
                    return BusinessUnitMapping.INSTANCE.toPageResult(v);
                }
        );

        return PageResult.<BusinessUnitPageResult>builder()
                .result(ret)
                .totalCount(page.getTotal())
                .totalPage(page.getPages())
                .build();
    }

    @Override
    public List<BusinessUnitListResult> list(BusinessUnitListRequest request) {
        List<SysBusinessUnit> ret = repositoryFactory.getBusinessUnitRepository()
                .list(request.getType());

        return MultiUtils.toList(
                ret,
                v -> {
                    if (v.getType() == BusinessUnitTypeEnums.MERCHANT) {
                        MerchantBusinessUnitExtObj ext;
                        if (null != v.getExt()) {
                            ext = JSONObject.parseObject(JSONObject.toJSONString(v.getExt()), MerchantBusinessUnitExtObj.class);
                            return BusinessUnitMapping.INSTANCE.toListResult(v, ext);
                        }
                    }
                    return BusinessUnitMapping.INSTANCE.toListResult(v);
                }
        );
    }

    @Override
    public Boolean purchaseCreate(PurchaseBusinessUnitSubmitRequest request) {
        List<Integer> allStoreId = repositoryFactory.getBusinessUnitRepository()
                .list(BusinessUnitTypeEnums.WAREHOUSE.getValue())
                .stream()
                .map(SysBusinessUnit::getId)
                .collect(Collectors.toList());
        ValidationUtil.isTrue(allStoreId.containsAll(request.getStoreIdList()), "仓库id错误");

        SysBusinessUnit e = BusinessUnitMapping.INSTANCE.toEntity(request);

        return repositoryFactory.getBusinessUnitRepository()
                .submit(e);
    }

    @Override
    public Boolean purchaseUpdate(PurchaseBusinessUnitSubmitRequest request) {
        List<Integer> allStoreId = repositoryFactory.getBusinessUnitRepository()
                .list(BusinessUnitTypeEnums.WAREHOUSE.getValue())
                .stream()
                .map(SysBusinessUnit::getId)
                .collect(Collectors.toList());
        ValidationUtil.isTrue(allStoreId.containsAll(request.getStoreIdList()), "仓库id错误");

        SysBusinessUnit businessUnit = repositoryFactory.getBusinessUnitRepository()
                .findById(request.getId());
        ValidationUtil.notNull(businessUnit, "id错误");
        ValidationUtil.isTrue(businessUnit.getType() == BusinessUnitTypeEnums.PURCHASE, "id错误");

        SysBusinessUnit e = BusinessUnitMapping.INSTANCE.toEntity(request);
        return repositoryFactory.getBusinessUnitRepository()
                .submit(e);
    }

    @Override
    public PageResult<PurchaseBusinessUnitPageResult> purchasePage(PurchaseBusinessUnitPageRequest request) {
        Page<SysBusinessUnit> page = repositoryFactory.getBusinessUnitRepository()
                .pageOfPurchase(
                        request.getName(),
                        request.getStoreId(),
                        request.getType(),
                        request
                );


        //获取采购主题对应仓库
        Set<Integer> storeIdList = page.getRecords()
                .stream()
                .map(v -> {
                    PurchaseSubjectBusinessUnitExtObj obj = BusinessUnitMapping.INSTANCE.toPurchaseUnitObj(v.getExt());
                    return obj == null ? null : obj.getStoreIdList();
                })
                .filter(Objects::nonNull)
                .flatMap(List::stream)
                .collect(Collectors.toSet());

        Map<Integer, String> storeIdMap = repositoryFactory.getBusinessUnitRepository()
                .listByIds(storeIdList)
                .stream()
                .collect(Collectors.toMap(SysBusinessUnit::getId, SysBusinessUnit::getName));


        //组合结果
        List<PurchaseBusinessUnitPageResult> ret = MultiUtils.toList(
                page.getRecords(),
                v -> {
                    PurchaseSubjectBusinessUnitExtObj ext = BusinessUnitMapping.INSTANCE.toPurchaseUnitObj(v.getExt());
                    return BusinessUnitMapping.INSTANCE.toPurchaseBusinessUnitPageResult(v, storeIdMap, ext);
                }
        );

        return PageResult.<PurchaseBusinessUnitPageResult>builder()
                .result(ret)
                .totalCount(page.getTotal())
                .totalPage(page.getPages())
                .build();
    }
}
