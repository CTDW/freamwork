package com.seeease.flywheel_v4.web.app.excel.result;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.format.DateTimeFormat;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 9/11/24 5:00 下午
 **/
@Data
public class WmsCkExportResult implements Serializable {

    @ExcelProperty("订单号")
    private String serialNo;

    @ExcelProperty("流程节点")
    private String nodeState;

    @ExcelProperty("类型")
    private String type;

    @ExcelProperty("销售渠道")
    private String scType;

    @ExcelProperty("订单来源")
    private String originName;

    @ExcelProperty("蜥蜴编码")
    private String xyCode;

    @ExcelProperty("商品名称")
    private String goodsName;

    @ExcelProperty("品牌名称")
    private String brandName;

    @ExcelProperty("类目名称")
    private String categoryName;

    @ExcelProperty("入库参数")
    private String param;

    @ExcelProperty("唯一码")
    private String skuCode;

    @ExcelProperty("数量")
    private Integer count;

    @ExcelProperty("附件")
    private String annexe;

    @ExcelProperty("快递单号")
    private String expressNo;

    @ExcelProperty("留言/备注")
    private String remark;

    @ExcelProperty("收货信息")
    private String address;

    @DateTimeFormat("yyyy-MM-dd HH:mm:ss")
    @ExcelProperty("创建时间")
    private Date createdTime;









}
