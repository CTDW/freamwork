package com.seeease.flywheel_v4.web.app.fix.result;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.seeease.flywheel_v4.web.infrastructure.dao.fix.entity.FixOrderPart;
import io.swagger.annotations.ApiModelProperty;
import lombok.Builder;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * @Description 维修中心-维修单-配件 返回值
 * @Date 2024-10-2 20:20
 * @Author by hk
 */
@Data
@Builder
public class FixOrderPartPageResult implements Serializable {

    @ApiModelProperty(value = "维修单号")
    private String orderNumber;

    @ApiModelProperty(value = "商品图片")
    private String goodsPic;

    @ApiModelProperty(value = "商品名称")
    private String goodsName;

    @ApiModelProperty(value = "品牌")
    private String goodsBrand;

    @ApiModelProperty(value = "类目")
    private String goodsCategory;

    @ApiModelProperty(value = "分类")
    private String classification;

    @ApiModelProperty(value = "货号")
    private String articleNo;

    @ApiModelProperty(value = "尺寸")
    private String size;

    @ApiModelProperty(value = "形状")
    private String shape;

    @ApiModelProperty(value = "机芯号")
    private String machineNumber;

    @ApiModelProperty(value = "数量")
    private Integer count;

    @ApiModelProperty(value = "采购价")
    private BigDecimal price;

    @ApiModelProperty(value = "公价")
    private BigDecimal publicPrice;

    @ApiModelProperty(value = "零售价")
    private BigDecimal salePrice;

    @ApiModelProperty(value = "创建人")
    private String createdBy;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    @ApiModelProperty(value = "创建时间")
    private Date createdTime;


    public static FixOrderPartPageResult fromEntity(FixOrderPart orderPart) {
        return FixOrderPartPageResult.builder()
                .orderNumber(orderPart.getOrderNumber())
                .goodsName(orderPart.getGoodsName())
                .goodsPic(orderPart.getGoodsPic())
                .goodsBrand(orderPart.getGoodsBrand())
                .goodsCategory(orderPart.getGoodsCategory())

                .classification(orderPart.getClassification())
                .articleNo(orderPart.getArticleNo())
                .size(orderPart.getSize())
                .shape(orderPart.getShape())
                .machineNumber(orderPart.getMachineNumber())

                .count(orderPart.getCount())
                .price(orderPart.getPrice())
                .publicPrice(orderPart.getPublicPrice())
                .salePrice(orderPart.getSalePrice())

                .createdBy(orderPart.getCreatedBy())
                .createdTime(orderPart.getCreatedTime())
                .build();
    }
}
