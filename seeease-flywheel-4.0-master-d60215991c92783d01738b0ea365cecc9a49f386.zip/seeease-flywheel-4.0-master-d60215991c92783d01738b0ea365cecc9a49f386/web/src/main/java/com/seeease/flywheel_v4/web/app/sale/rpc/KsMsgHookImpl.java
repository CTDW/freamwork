package com.seeease.flywheel_v4.web.app.sale.rpc;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.kuaishou.merchant.open.api.client.AccessTokenKsMerchantClient;
import com.kuaishou.merchant.open.api.common.utils.PlatformEventSecurityUtil;
import com.kuaishou.merchant.open.api.domain.order.OrderAddressInfo;
import com.kuaishou.merchant.open.api.domain.order.OrderDetail;
import com.kuaishou.merchant.open.api.request.order.OpenOrderDetailRequest;
import com.kuaishou.merchant.open.api.response.order.OpenOrderDetailResponse;
import com.seeease.flywheel_v4.web.app.sale.request.SaleOrderCancelRequest;
import com.seeease.flywheel_v4.web.app.sale.request.ToCSaleReturnOrderCreateRequest;
import com.seeease.flywheel_v4.web.app.sale.service.SaleOrderService;
import com.seeease.flywheel_v4.web.app.sale.service.SaleReturnOrderService;
import com.seeease.flywheel_v4.web.domain.sale.mapping.ThirdSaleOrderLineMapping;
import com.seeease.flywheel_v4.web.domain.sale.mapping.ThirdSaleOrderMapping;
import com.seeease.flywheel_v4.web.infrastructure.dao.RepositoryFactory;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.entity.SaleOrder;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.entity.SaleOrderLine;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.entity.ThirdSaleOrder;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.entity.ThirdSaleOrderLine;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.entity.obj.BuyerInfoObj;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.enums.SaleStateEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.enums.ThirdSaleStateEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.entity.SysSaleChannel;
import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.entity.obj.SaleChannelExtObj;
import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.enums.SaleChannelTypeEnums;
import com.seeease.framework.ks.api.KsShopApi;
import com.seeease.goods.rpc.SpuFacade;
import com.seeease.goods.rpc.request.SpuRpcRequest;
import com.seeease.goods.rpc.result.SpuRpcResult;
import com.seeease.outsideapi.facade.rpc.KsMsgHook;
import com.seeease.outsideapi.facade.rpc.request.KsMessageRequest;
import com.seeease.outsideapi.facade.rpc.result.KsMsgBodyResult;
import com.seeease.springframework.context.LoginStore;
import com.seeease.springframework.context.LoginUser;
import com.seeease.springframework.context.UserContext;
import com.seeease.springframework.exception.ValidationUtil;
import com.seeease.springframework.utils.MultiUtils;
import com.seeease.springframework.utils.StringUtils;
import io.seata.spring.annotation.GlobalTransactional;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.dubbo.config.annotation.DubboReference;
import org.apache.dubbo.config.annotation.DubboService;

import javax.annotation.Resource;
import java.util.*;

/**
 * <p>快手回调</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 9/3/24 4:39 下午
 **/
@Slf4j
@DubboService(group = "fl4", version = "1.0.0")
public class KsMsgHookImpl implements KsMsgHook {

    @Resource
    private RepositoryFactory repositoryFactory;

    @DubboReference(version = "1.0.0", check = false)
    private SpuFacade spuFacade;

    @Resource
    private SaleOrderService saleOrderService;

    @Resource
    private KsComponent ksComponent;

    @Resource
    private SaleReturnOrderService saleReturnOrderService;

    @SneakyThrows
    @GlobalTransactional
    @Override
    public void hook(KsMessageRequest request) {
        String appKey = request.getAppKey();
        String msg = request.getData();

        //step_1 根据appKey查找配置数据
        SysSaleChannel saleChannel = repositoryFactory.getSaleChannelRepository()
                .findByKeyAndType(appKey, SaleChannelTypeEnums.ks);
        if (null == saleChannel) {
            return;
        }
        //step_2 解密消息
        String aesKey = saleChannel.getExt().getKsEncodingAesKey();
        String decryptString = PlatformEventSecurityUtil.decode(msg, aesKey);

        if (StringUtils.isEmpty(decryptString)) {
            log.error("快手消息解密失败，加密内容:{}", msg);
            ValidationUtil.isTrue(StringUtils.isNotEmpty(decryptString), "快手消息解密失败");
        }
        log.info("快手解密信息:{}", decryptString);
        KsMsgBodyResult body = JSON.parseObject(decryptString, KsMsgBodyResult.class);
        if (Optional.ofNullable(body.getTest()).orElse(false)) {
            return;
        }

        //step_3 分发消息处理
        JSONObject infoJson = JSON.parseObject(body.getInfo());
        switch (body.getEvent()) {
            /**
             * 订单支付成功
             * <a href="https://open.kwaixiaodian.com/zone/new/docs/msg?name=kwaishop_order_orderSuccess&version=1">
             *     文档地址
             * </a>
             */
            case "kwaishop_order_paySuccess":
                if (infoJson.getInteger("status") == 30) {
                    createOrder(body, saleChannel);
                }
                break;
            /**
             * 订单取消
              */
            case "kwaishop_order_orderFail":
                if (infoJson.getInteger("status") == 80) {
                    cancelOrder(body);
                }
                break;
            /**
             * 新增售后单据
              */
            case "kwaishop_aftersales_addRefund":
                JSONObject info = JSONObject.parseObject(body.getInfo());
                // 退款方式，枚举： [1, "退货退款"] [10, "仅退款"] [3, "换货"][4, "补寄"][5, "维修"]
                if (Arrays.asList(1, 10).contains(info.getInteger("handlingWay"))) {
                    refundOrder(body);
                }
                break;

        }
    }


    /**
     * 售后订单处理
     */
    private void refundOrder(KsMsgBodyResult body) {
        //step_1 获取对应三方销售单
        JSONObject infoJson = JSONObject.parseObject(String.valueOf(body.getInfo()));
        String orderId = infoJson.getString("orderId");
        ThirdSaleOrder thirdOrder = repositoryFactory.getThirdSaleOrderRepository().findByOrderId(orderId);
        if (thirdOrder == null){
            return;
        }
        //step_2 获取对应关联销售单
        SaleOrder saleOrder = repositoryFactory.getSaleOrderRepository().findByMergedId(thirdOrder.getMergedId());
        if (null == saleOrder){
            if (thirdOrder.getState() != ThirdSaleStateEnums.CANCEL){
                thirdOrder.setState(ThirdSaleStateEnums.CANCEL);
                repositoryFactory.getThirdSaleOrderRepository().submit(thirdOrder);
            }
            return;
        }

        //step_3 根据销售单状态判断是否生成退货单据
        if (saleOrder.getState() != SaleStateEnums.OVER){
            SaleOrderCancelRequest request = new SaleOrderCancelRequest();
            request.setId(saleOrder.getId());
            saleOrderService.tocCancel(request);
        }else {

            Long refundId = infoJson.getLong("refundId");
            ToCSaleReturnOrderCreateRequest returnRequest = new ToCSaleReturnOrderCreateRequest();
            returnRequest.setSaleId(saleOrder.getId());


            List<SaleOrderLine> saleLine = repositoryFactory.getSaleOrderLineRepository()
                    .listByMainId(saleOrder.getId());

            List<ToCSaleReturnOrderCreateRequest.Sku> skuList = MultiUtils.toList(
                    saleLine,
                    line -> {
                        ToCSaleReturnOrderCreateRequest.Sku sku = new ToCSaleReturnOrderCreateRequest.Sku();
                        sku.setSkuId(line.getSkuId());
                        sku.setLineId(line.getId());
                        sku.setCount(line.getCount());
                        sku.setReturnAmount(line.getDealPrice());
                        return sku;
                    }
            );
            LoginUser user = new LoginUser();
            user.setId(saleOrder.getCreatedId());
            user.setUserName(saleOrder.getCreatedBy());
            LoginStore store = new LoginStore();
            store.setId(saleOrder.getBuId());
            user.setStore(store);
            UserContext.setUser(user);

            returnRequest.setSkuList(skuList);
            saleReturnOrderService.tocReturnCreate(returnRequest);
        }

    }




    /**
     * 取消订单
     * @param body
     */
    private void cancelOrder(KsMsgBodyResult body){
        JSONObject infoJson = JSONObject.parseObject(body.getInfo());
        String orderId = infoJson.getString("oid");

        ThirdSaleOrder saleOrder = repositoryFactory.getThirdSaleOrderRepository()
                .findByOrderId(String.valueOf(orderId));

        if (null != saleOrder){
            saleOrder.setState(ThirdSaleStateEnums.CANCEL);
            repositoryFactory.getThirdSaleOrderRepository().submit(saleOrder);
        }
    }




    /**
     * 创建订单
     *
     * @param body
     */
    private void createOrder(KsMsgBodyResult body, SysSaleChannel saleChannel) throws Exception {
        //幂等控制
        JSONObject infoJson = JSONObject.parseObject(body.getInfo());
        Long orderId = infoJson.getLong("oid");
        ThirdSaleOrder thirdSaleOrder = repositoryFactory.getThirdSaleOrderRepository().findByOrderId(orderId.toString());
        if (null != thirdSaleOrder) {
            return;
        }


        //step_1 获取订单信息
        KsShopApi.ParamUserToken token = ksComponent.getUserToken(saleChannel);
        SaleChannelExtObj ext = saleChannel.getExt();

        AccessTokenKsMerchantClient client = new AccessTokenKsMerchantClient(
                saleChannel.getThirdNo(),
                ext.getSignSecret()
        );
        OpenOrderDetailRequest request = new OpenOrderDetailRequest();
        request.setAccessToken(token.getToken());
        request.setOid(orderId);

        OpenOrderDetailResponse response = client.execute(request);
        OrderDetail detail = response.getData();
        log.info("快手获取订单请求参数:{} \n 获取快手创建订单订详情信息:{} \n，销售渠道:{}",
                JSONObject.toJSONString(request),
                JSONObject.toJSONString(response),
                JSONObject.toJSONString(saleChannel)
        );

        //step_2 创建三方订单

        //构造客户数据
        OrderAddressInfo orderAddress = detail.getOrderAddress();
        BuyerInfoObj buyer = ThirdSaleOrderMapping.INSTANCE.toKsBuyer(orderAddress);
        log.info("快手解密订单客户数据:{}",JSONObject.toJSONString(buyer));
        //通过客户数据创建合单依据
        String mergeId = StringUtils.encoderByMd5(
                buyer.getKsEncAddr() +
                        buyer.getKsEncRec() +
                        buyer.getKsEncTel()
        );


        //构建订单数据
        thirdSaleOrder = ThirdSaleOrderMapping.INSTANCE.toEntity(
                detail,
                saleChannel.getId(),
                buyer,
                orderAddress,
                mergeId,
                UUID.randomUUID().toString()
        );
        repositoryFactory.getThirdSaleOrderRepository().submit(thirdSaleOrder);


        //step_3 新增订单行
        Integer spuId = null;
        SpuRpcRequest spuRequest = new SpuRpcRequest();
        Set<String> spuCodes = Collections.singleton(detail.getOrderItemInfo().getSkuNick());
        spuRequest.setSpuCodes(spuCodes);
        List<SpuRpcResult> spuList = spuFacade.list(spuRequest);
        if (!spuList.isEmpty()){
            spuId = spuList.get(0).getId();
        }

        ThirdSaleOrderLine line = ThirdSaleOrderLineMapping.INSTANCE.toEntity(
                thirdSaleOrder.getOrderId(),
                spuId,
                detail.getOrderItemInfo()
        );
        repositoryFactory.getThirdSaleOrderLineRepository().submitBatch(Collections.singletonList(line));
    }


}
