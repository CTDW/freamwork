package com.seeease.flywheel_v4.web.domain.purchase.mapping;


import com.seeease.flywheel_v4.client.enums.BusinessUnitTypeEnums;
import com.seeease.flywheel_v4.web.app.purchase.request.PurchaseDemandSubmitRequest;
import com.seeease.flywheel_v4.web.app.purchase.request.PurchaseReturnCreateRequest;
import com.seeease.flywheel_v4.web.app.purchase.result.PurchaseAftersaleDetailResult;
import com.seeease.flywheel_v4.web.infrastructure.config.MappingIgnore;
import com.seeease.flywheel_v4.web.infrastructure.config.SimpleMapping;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.entity.PurchaseAftersale;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.entity.PurchaseAftersaleLine;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.entity.PurchaseDemand;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.entity.PurchaseOrderLine;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.enums.PurchaseDemandStateEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.MerchantWmsLine;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.WmsCk;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.WmsRk;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.WmsCkTypeEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.WmsRkTypeEnums;
import com.seeease.flywheel_v4.web.util.SerialNoGenerator;
import com.seeease.goods.rpc.enums.SkuNodeStateEnums;
import com.seeease.goods.rpc.request.PurchaseReturnSkuCancelRequest;
import com.seeease.goods.rpc.request.PurchaseReturnSkuCreateRpcRequest;
import com.seeease.goods.rpc.request.PurchaseReturnSkuFinishRpcRequest;
import com.seeease.goods.rpc.result.SkuCreateRpcResult;
import com.seeease.goods.rpc.result.SkuRpcResult;
import com.seeease.seeeaseframework.mybatis.domain.WhetherEnum;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;


/**
 * <p>
 * </p>
 *
 * @author 西门 游
 * @since 2023-10-27
 */
@Mapper(componentModel = "spring",
        builder = @Builder(disableBuilder = true),
        nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS,
        nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE,
        imports = {BusinessUnitTypeEnums.class,
                PurchaseDemandStateEnums.class,
                PurchaseDemandStateEnums.TransitionEnum.class,
                SerialNoGenerator.class,
                WhetherEnum.class})
public interface PurchaseAftersaleLineMapping extends SimpleMapping<PurchaseDemandSubmitRequest, PurchaseDemand> {

    PurchaseAftersaleLineMapping INSTANCE = Mappers.getMapper(PurchaseAftersaleLineMapping.class);


    @MappingIgnore
    @Mapping(target = "nodeState",source = "nodeState")
    @Mapping(target = "endState",expression = "java(WhetherEnum.NO)")
    @Mapping(target = "price",source = "line.purchasePrice")
    PurchaseAftersaleLine toEntity(PurchaseOrderLine line,
                                   Integer mainId,
                                   SkuNodeStateEnums nodeState);
    @MappingIgnore
    @Mapping(target = "endState",expression = "java(WhetherEnum.NO)")
    @Mapping(target = "nodeState",source = "nodeState")
    @Mapping(target = "price",source = "line.purchasePrice")
    MerchantWmsLine toMerchantWmsLine(PurchaseOrderLine line,
                                      SkuNodeStateEnums nodeState);

    @MappingIgnore
    @Mapping(target = "endState",expression = "java(WhetherEnum.NO)")
    @Mapping(target = "nodeState",source = "nodeState")
    MerchantWmsLine toMerchantWmsLine(PurchaseAftersaleLine line,
                                      SkuNodeStateEnums nodeState);


    @MappingIgnore
    @Mapping(target = "type",source = "type")
    @Mapping(target = "originId",source = "aftersale.buId")
    @Mapping(target = "nodeState",source = "nodeState")
    @Mapping(target = "count",source = "line.count")
    @Mapping(target = "storeId",source = "aftersale.storeId")
    WmsCk toWmsCk(PurchaseAftersale aftersale,
                  PurchaseOrderLine line,
                  SkuNodeStateEnums nodeState,
                  WmsCkTypeEnums type);



    @MappingIgnore
    @Mapping(target = "type",source = "type")
    @Mapping(target = "originId",source = "aftersale.buId")
    @Mapping(target = "nodeState",source = "nodeState")
    @Mapping(target = "count",source = "line.count")
    @Mapping(target = "storeId",source = "aftersale.storeId")
    WmsCk toWmsCk(PurchaseAftersale aftersale,
                  PurchaseAftersaleLine line,
                  SkuNodeStateEnums nodeState,
                  WmsCkTypeEnums type);



    @MappingIgnore
    @Mapping(target = "serialNo",source = "order.serialNo")
    @Mapping(target = "type",source = "type")
    @Mapping(target = "nodeState",expression = "java(SkuNodeStateEnums.DSH)")
    WmsRk toWmsRk(PurchaseAftersaleLine line,
                  PurchaseAftersale order,
                  WmsRkTypeEnums type);

    @Mapping(target = "price",source = "line.price")
    @Mapping(target = "skuParams",source = "skuRpcResult.skuParams")
    @Mapping(target = "nodeState",source = "line.nodeState")
    @Mapping(target = "skuId",source = "skuRpcResult.id")
    @Mapping(target = "lineId",source = "line.id")
    PurchaseAftersaleDetailResult.Sku toSkuResult(SkuRpcResult skuRpcResult,
                                                  PurchaseAftersaleLine line);

    PurchaseReturnSkuCancelRequest.Sku toCancelRpcRequest(PurchaseAftersaleLine l);


    PurchaseReturnSkuFinishRpcRequest.Sku toPurchaseReturnFinishRequest(PurchaseAftersaleLine l);

    @Mapping(target = "skuId",source = "sku.id")
    @Mapping(target = "returnPrice",source = "sku.amount")
    PurchaseReturnSkuCreateRpcRequest.Sku toSkuRpcCreateRequest(PurchaseReturnCreateRequest.Sku sku);

    @MappingIgnore
    @Mapping(target = "price",source = "sku.purchasePrice")
    @Mapping(target = "skuId",source = "sku.id")
    @Mapping(target = "endState",expression = "java(WhetherEnum.NO)")
    @Mapping(target = "nodeState",source = "nodeState")
    PurchaseAftersaleLine toEntity(SkuCreateRpcResult sku, Integer mainId, SkuNodeStateEnums nodeState);
}
