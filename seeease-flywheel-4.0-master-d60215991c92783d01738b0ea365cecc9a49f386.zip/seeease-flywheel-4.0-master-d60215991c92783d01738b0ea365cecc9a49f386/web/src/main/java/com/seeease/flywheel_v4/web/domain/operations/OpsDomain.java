package com.seeease.flywheel_v4.web.domain.operations;

import com.seeease.flywheel_v4.web.app.transfer.result.TransferUsableQuotaResult;
import com.seeease.flywheel_v4.web.infrastructure.dao.RepositoryFactory;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.TransferQuota;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.TransferQuotaLine;
import com.seeease.goods.rpc.SkuFacade;
import com.seeease.goods.rpc.enums.SkuRunTypeEnums;
import com.seeease.goods.rpc.enums.SkuStateEnums;
import com.seeease.goods.rpc.request.SkuRpcRequest;
import com.seeease.goods.rpc.result.SkuRpcResult;
import com.seeease.seeeaseframework.mybatis.domain.WhetherEnum;
import com.seeease.springframework.exception.ValidationUtil;
import com.seeease.springframework.utils.MultiUtils;
import com.seeease.springframework.utils.StringUtils;
import lombok.Data;
import org.apache.dubbo.config.annotation.DubboReference;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 7/4/24 2:09 下午
 **/
@Component
public class OpsDomain {

    @Resource
    private RepositoryFactory repositoryFactory;

    @DubboReference(version = "1.0.0", check = false)
    private SkuFacade skuFacade;

    /**
     * 计算调拨配货额度中当前时间段可用额度
     *
     * @param merchantId 商家id
     * @return
     */
    public TransferUsableQuotaResult claTransferUsableQuota(Integer merchantId) {

        TransferUsableQuotaResult ret = new TransferUsableQuotaResult();

        //step_1 查询主表
        List<TransferQuota> transferQuotaList = repositoryFactory.getTransferQuotaRepository()
                .listByMerchantId(merchantId);


        if (transferQuotaList.isEmpty()) {
            return ret;
        }

        //查询字表
        Set<Integer> quotaIds = MultiUtils.toSet(transferQuotaList, TransferQuota::getId);
        List<TransferQuotaLine> lineList = repositoryFactory.getTransferQuotaLineRepository().listByTsqIdList(quotaIds);

        Map<Integer, TransferUsedQuotaDto> usedQuotaMap = MultiUtils.toMap(
                this.calTransferUsedQuota(transferQuotaList, lineList),
                TransferUsedQuotaDto::getId
        );


        Date now = new Date();
        for (TransferQuota transferQuota : transferQuotaList) {
            if (now.after(transferQuota.getStartDate()) && now.before(transferQuota.getEndDate())) {

                TransferUsedQuotaDto usedQuota = usedQuotaMap.get(transferQuota.getId());

                ret.setUsableOsQuota(transferQuota.getOsQuota().subtract(usedQuota.getUsedOsQuota()));
                ret.setUsableCtQuota(transferQuota.getCtQuota().subtract(usedQuota.getUsedCtQuota()));
                ret.setDetailUsedQuota(usedQuota.getItems());
                ret.setIsCtl(transferQuota.getIsCtl().getValue());
                ret.setId(transferQuota.getId());
                return ret;
            }
        }
        return ret;
    }

    @Data
    public static class SkuTransferCheckParam {
        /**
         * skuId
         */
        private Integer skuId;
        /**
         * 调拨价
         */
        private BigDecimal transferPrice;
        /**
         * 自主经营类型
         */
        private Integer runType;
        /**
         * 品牌id
         */
        private Integer brandId;
        /**
         * 类目id
         */
        private Integer categoryId;
    }


    @Data
    public static class TransferUsedQuotaDto {
        /**
         * 主表id
         */
        private Integer id;
        /**
         * 已使用压货总额度
         */
        private BigDecimal usedOsQuota;
        /**
         * 已使用代销总额度
         */
        private BigDecimal usedCtQuota;
        /**
         * 详情使用明细
         */
        private List<Item> items;

        @Data
        public static class Item {
            private Integer lineId;
            private BigDecimal usedQuota;
        }
    }


    /**
     * 计算商家配货已使用额度
     *
     * @param quotas
     * @param lines
     * @return
     */
    public List<TransferUsedQuotaDto> calTransferUsedQuota(List<TransferQuota> quotas,
                                                   List<TransferQuotaLine> lines) {

        if (StringUtils.isEmpty(quotas)) {
            return Collections.emptyList();
        }

        ArrayList<TransferUsedQuotaDto> ret = new ArrayList<>();

        Map<Integer, List<TransferQuotaLine>> lineMap = lines.stream()
                .collect(Collectors.groupingBy(TransferQuotaLine::getTsqId));

        Set<Integer> merchantIds = MultiUtils.toSet(quotas, TransferQuota::getMerchantId);
        List<Integer> brandIds = MultiUtils.toList(lines, TransferQuotaLine::getBrandId);

        SkuRpcRequest skuRpcRequest = new SkuRpcRequest();
        skuRpcRequest.setSellerIds(merchantIds);
        skuRpcRequest.setState(SkuStateEnums.SALEABLE);
        skuRpcRequest.setBrandIds(brandIds);
        List<SkuRpcResult> skus = skuFacade.list(skuRpcRequest)
                .stream()
                .filter(sku -> null != sku.getRunType())
                .collect(Collectors.toList());

        for (TransferQuota quota : quotas) {
            //step_1 过滤出经营等于该商家的数据
            List<SkuRpcResult> mainSkuList = skus.stream()
                    .filter(sku -> sku.getSellerId().equals(quota.getMerchantId()))
                    .collect(Collectors.toList());

            TransferUsedQuotaDto item = new TransferUsedQuotaDto();
            List<TransferUsedQuotaDto.Item> detailItems = new ArrayList<>();

            BigDecimal usedOsQuota = BigDecimal.ZERO;
            BigDecimal usedCtQuota = BigDecimal.ZERO;

            //stpe_2 获取详情数据
            List<TransferQuotaLine> lineList = lineMap.get(quota.getId());

            for (TransferQuotaLine line : lineList) {
                BigDecimal usedQuota = mainSkuList.stream()
                        .filter(sku -> sku.getRunType().equals(line.getType()) && sku.getBrandId().equals(line.getBrandId()))
                        .map(SkuRpcResult::getNewSettlePrice)
                        .reduce(BigDecimal::add)
                        .orElse(BigDecimal.ZERO);

                TransferUsedQuotaDto.Item detailItem = new TransferUsedQuotaDto.Item();
                detailItem.setLineId(line.getId());
                detailItem.setUsedQuota(usedQuota);

                if (line.getType() == SkuRunTypeEnums.YH){
                    usedOsQuota = usedOsQuota.add(usedQuota);
                }else {
                    usedCtQuota = usedCtQuota.add(usedCtQuota);
                }
                detailItems.add(detailItem);
            }

            item.setId(quota.getId());
            item.setItems(detailItems);
            item.setUsedCtQuota(usedCtQuota);
            item.setUsedOsQuota(usedOsQuota);
            ret.add(item);
        }

        return ret;
    }


    /**
     * 调拨额度使用的校验，如果校验不通过抛出异常
     *
     * @param params     检测的参数
     * @param merchantId 商家id
     */
    public void transferQuotaCheck(List<SkuTransferCheckParam> params, Integer merchantId) {

        if (params.isEmpty()) {
            return;
        }
        //调拨额度控制校验
        TransferUsableQuotaResult usableQuota = this.claTransferUsableQuota(merchantId);
        if (Objects.equals(usableQuota.getIsCtl(), WhetherEnum.NO.getValue())) {
            return;
        }


        //step1.从配置中获取 相同的经营类型的同类目同品牌 可用金额剩余多少
        Map<Integer, TransferUsedQuotaDto.Item> detailUsedQuotaMap = MultiUtils.toMap(
                usableQuota.getDetailUsedQuota(),
                TransferUsedQuotaDto.Item::getLineId
        );
        Map<String, BigDecimal> usableQuotaMap = MultiUtils.toMap(
                repositoryFactory.getTransferQuotaLineRepository().listByTsqId(usableQuota.getId()),
                quota -> quota.getType().getValue() + ":" + quota.getCategoryId() + ":" + quota.getBrandId(),
                quota -> quota.getQuota().subtract(detailUsedQuotaMap.get(quota.getId()).getUsedQuota())
        );


        //step2.同样根据条件聚合本次调拨需要使用到的各类型金额
        Map<String, BigDecimal> usedQuotaMap = new HashMap<>();
        BigDecimal totalUsedOsQuota = BigDecimal.ZERO;
        BigDecimal totalUsedCtQuota = BigDecimal.ZERO;

        for (SkuTransferCheckParam param : params) {
            if (null == param.getRunType()) {
                continue;
            }
            if (param.getRunType().equals(SkuRunTypeEnums.DX.getValue())) {
                totalUsedCtQuota = totalUsedCtQuota.add(param.getTransferPrice());
            } else {
                totalUsedOsQuota = totalUsedOsQuota.add(param.getTransferPrice());
            }

            String key = param.getRunType() + ":" + param.getCategoryId() + ":" + param.getBrandId();
            BigDecimal usedQuota = usedQuotaMap.get(key);
            if (null == usedQuota) {
                //初始化
                usableQuotaMap.put(key, param.getTransferPrice());
            } else {
                usedQuota = usedQuota.add(param.getTransferPrice());
                usedQuotaMap.replace(key, usedQuota);
            }
        }

        ValidationUtil.isTrue(totalUsedCtQuota.compareTo(usableQuota.getUsableCtQuota()) < 1, "代销金额超时已使用金额");
        ValidationUtil.isTrue(totalUsedOsQuota.compareTo(usableQuota.getUsableOsQuota()) < 1, "压货金额超时已使用金额");


        for (Map.Entry<String, BigDecimal> e : usedQuotaMap.entrySet()) {
            if (usableQuotaMap.containsKey(e.getKey())) {
                //获取同品牌同类目同类型的可用额度
                BigDecimal temp = usableQuotaMap.get(e.getKey());
                ValidationUtil.isTrue(e.getValue().compareTo(temp) < 1, "类型,类目，品牌为:" + e.getKey() + "超出使用范围");
            }
        }
    }
}
