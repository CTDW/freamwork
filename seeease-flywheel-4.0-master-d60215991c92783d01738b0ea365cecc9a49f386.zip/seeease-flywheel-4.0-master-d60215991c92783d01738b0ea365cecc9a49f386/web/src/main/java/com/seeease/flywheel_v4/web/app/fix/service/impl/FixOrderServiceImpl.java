package com.seeease.flywheel_v4.web.app.fix.service.impl;

import com.baomidou.mybatisplus.core.toolkit.CollectionUtils;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.seeease.flywheel_v4.web.app.fix.request.*;
import com.seeease.flywheel_v4.web.app.fix.result.FixOrderDetailResult;
import com.seeease.flywheel_v4.web.app.fix.result.FixOrderPageResult;
import com.seeease.flywheel_v4.web.app.fix.result.FixStatusCountResult;
import com.seeease.flywheel_v4.web.app.fix.service.FixOrderService;
import com.seeease.flywheel_v4.web.infrastructure.dao.RepositoryFactory;
import com.seeease.flywheel_v4.web.infrastructure.dao.fix.entity.FixOrder;
import com.seeease.flywheel_v4.web.infrastructure.dao.fix.entity.FixOrderLog;
import com.seeease.flywheel_v4.web.infrastructure.dao.fix.entity.FixOrderPart;
import com.seeease.flywheel_v4.web.infrastructure.dao.fix.enums.FixOrderStatusEnum;
import com.seeease.springframework.PageResult;
import com.seeease.springframework.exception.e.ArgumentException;
import com.seeease.springframework.utils.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @Description 维修单
 * @Date 2024-10-2 21:12
 * @Author by hk
 */
@Service
public class FixOrderServiceImpl implements FixOrderService {

    @Resource
    private RepositoryFactory repositoryFactory;


    @Override
    public PageResult<FixOrderPageResult> page(FixOrderPageRequest request) {

        //主表查询
        Page<FixOrder> page = repositoryFactory.getFixOrderRepository().page(request);
        if (StringUtils.isEmpty(page.getRecords())) {
            return PageResult.buildEmpty();
        }

        return PageResult.<FixOrderPageResult>builder()
                .result(page.getRecords().stream()
                        .map(FixOrderPageResult::fromEntity)
                        .collect(Collectors.toList()))
                .totalCount(page.getTotal())
                .totalPage(page.getPages())
                .build();
    }

    /**
     * 维修中心-维修单-状态-数量
     *
     * @param request 请求 * @return 列表结果
     */
    @Override
    public List<FixStatusCountResult> getStatusCount(FixOrderPageRequest request) {
        return repositoryFactory.getFixOrderRepository().getStatusCount(request);
    }

    /**
     * 分配 维修师
     *
     * @param request 请求
     * @return 结果
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public Boolean distribute(FixOrderDistributeRequest request) {

        FixOrder fixOrder = getFixOrder(request.getId());

        if (!FixOrderStatusEnum.REGISTER.getValue().equals(fixOrder.getOrderStatus())) {
            throw new ArgumentException("当前状态不是" + FixOrderStatusEnum.REGISTER.getName() + "，无法分配");
        }

        // 分配维修师
        repositoryFactory.getFixOrderRepository().updateMasterAndOrderStatusToWaitFix(request);

        // 保存日志
        FixOrderLogSaveRequest orderLogSaveRequest = new FixOrderLogSaveRequest();
        orderLogSaveRequest.setOrderNumber(fixOrder.getOrderNumber());
        orderLogSaveRequest.setFixStep("维修分配");
        orderLogSaveRequest.setFixContent("维修师:" + request.getFixMaster());
        orderLogSaveRequest.setOrderStatus(FixOrderStatusEnum.WAIT_REPAIR.getValue());
        repositoryFactory.getFixOrderLogRepository().save(orderLogSaveRequest);

        return true;
    }

    /**
     * 重新分配 维修师
     *
     * @param request 请求
     * @return 结果
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public Boolean reDistribute(FixOrderDistributeRequest request) {

        FixOrder fixOrder = getFixOrder(request.getId());

        if (!FixOrderStatusEnum.WAIT_REPAIR.getValue().equals(fixOrder.getOrderStatus())) {
            throw new ArgumentException("当前状态不是" + FixOrderStatusEnum.WAIT_REPAIR.getName() + "，无法重新分配");
        }

        // 重新分配维修师
        repositoryFactory.getFixOrderRepository().updateMasterAndOrderStatusToWaitFix(request);

        // 保存日志
        FixOrderLogSaveRequest orderLogSaveRequest = new FixOrderLogSaveRequest();
        orderLogSaveRequest.setOrderNumber(fixOrder.getOrderNumber());
        orderLogSaveRequest.setFixStep("重新维修分配");
        orderLogSaveRequest.setFixContent("维修师由:" + fixOrder.getFixMaster() + " 变更为:" + request.getFixMaster());
        orderLogSaveRequest.setOrderStatus(FixOrderStatusEnum.WAIT_REPAIR.getValue());
        repositoryFactory.getFixOrderLogRepository().save(orderLogSaveRequest);

        return true;
    }

    /**
     * 取消 维修
     *
     * @param request 请求
     * @return 结果
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public Boolean cancel(FixOrderDetailRequest request) {

        FixOrder fixOrder = getFixOrder(request.getId());

        // 取消维修
        repositoryFactory.getFixOrderRepository().updateOrderStatusToCancel(request.getId());

        // 保存日志
        FixOrderLogSaveRequest orderLogSaveRequest = new FixOrderLogSaveRequest();
        orderLogSaveRequest.setOrderNumber(fixOrder.getOrderNumber());
        orderLogSaveRequest.setFixStep("取消维修");
        orderLogSaveRequest.setFixContent("当前状态:" + FixOrderStatusEnum.parse(fixOrder.getOrderStatus()).getName());
        orderLogSaveRequest.setOrderStatus(FixOrderStatusEnum.HAS_CHANCEL.getValue());
        repositoryFactory.getFixOrderLogRepository().save(orderLogSaveRequest);

        return true;
    }

    /**
     * 送外 维修
     *
     * @param request 请求
     * @return 结果
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public Boolean sendOut(FixOrderSendOutRequest request) {

        FixOrder fixOrder = getFixOrder(request.getId());

        // 送外 维修
        repositoryFactory.getFixOrderRepository().updateOrderStatusToSendOut(request, fixOrder);

        // 保存日志
        FixOrderLogSaveRequest orderLogSaveRequest = new FixOrderLogSaveRequest();
        orderLogSaveRequest.setOrderNumber(fixOrder.getOrderNumber());
        orderLogSaveRequest.setFixStep("送外维修中");
        orderLogSaveRequest.setFixContent("送修备注:" + request.getSendOutRemark());
        orderLogSaveRequest.setOrderStatus(FixOrderStatusEnum.SEND_OUT_FIX.getValue());
        repositoryFactory.getFixOrderLogRepository().save(orderLogSaveRequest);

        return true;
    }

    /**
     * 维修完成
     *
     * @param request 请求
     * @return 结果
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public Boolean complete(FixOrderCompleteRequest request) {

        FixOrder fixOrder = getFixOrder(request.getId());

        // 维修完成
        repositoryFactory.getFixOrderRepository().complete(request);

        // 保存日志
        FixOrderLogSaveRequest orderLogSaveRequest = new FixOrderLogSaveRequest();
        orderLogSaveRequest.setOrderNumber(fixOrder.getOrderNumber());
        orderLogSaveRequest.setFixStep("已完成");
        orderLogSaveRequest.setFixContent("确认维修完成:" + request.getSendOutRemark());
        orderLogSaveRequest.setOrderStatus(FixOrderStatusEnum.HAS_COMPLETE.getValue());
        repositoryFactory.getFixOrderLogRepository().save(orderLogSaveRequest);

        return true;
    }

    /**
     * 回退
     *
     * @param request 请求
     * @return 结果
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public Boolean fallback(FixOrderDetailRequest request) {

        FixOrder fixOrder = getFixOrder(request.getId());

        if (FixOrderStatusEnum.canNotFallBack(fixOrder.getOrderStatus())) {
            throw new ArgumentException("当前状态" + FixOrderStatusEnum.parse(fixOrder.getOrderStatus()).getName() + "无法回退");
        }

        Integer newOrderStatus = repositoryFactory.getFixOrderLogRepository().getPreOrderStatus(fixOrder.getOrderNumber(),fixOrder.getOrderStatus());
        if (newOrderStatus == null) {
            throw new ArgumentException("无法回退");
        }

        // 回退
        repositoryFactory.getFixOrderRepository().updateOrderStatusToPreOrderStatus(request.getId(),newOrderStatus);

        // 保存日志
        FixOrderLogSaveRequest orderLogSaveRequest = new FixOrderLogSaveRequest();
        orderLogSaveRequest.setOrderNumber(fixOrder.getOrderNumber());
        orderLogSaveRequest.setFixStep("回退");
        orderLogSaveRequest.setFixContent("状态由:" + FixOrderStatusEnum.parse(fixOrder.getOrderStatus()).getName()
                + " 变更为:" + FixOrderStatusEnum.parse(newOrderStatus).getName());
        repositoryFactory.getFixOrderLogRepository().save(orderLogSaveRequest);

        return true;
    }

    /**
     * 跳过
     *
     * @param request 请求
     * @return 结果
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public Boolean jump(FixOrderJumpRequest request) {

        FixOrder fixOrder = getFixOrder(request.getId());

        if (FixOrderStatusEnum.canNotJump(fixOrder.getOrderStatus())) {
            throw new ArgumentException("当前状态" + FixOrderStatusEnum.parse(fixOrder.getOrderStatus()).getName() + "无法跳过");
        }

        // 跳过
        repositoryFactory.getFixOrderRepository().updateOrderStatusToAppoint(request);

        // 保存日志
        FixOrderLogSaveRequest orderLogSaveRequest = new FixOrderLogSaveRequest();
        orderLogSaveRequest.setOrderNumber(fixOrder.getOrderNumber());
        orderLogSaveRequest.setFixStep("跳过");
        orderLogSaveRequest.setFixContent("状态由:" + FixOrderStatusEnum.parse(fixOrder.getOrderStatus()).getName()
                + " 变更为:" + FixOrderStatusEnum.parse(request.getOrderStatus()).getName());
        orderLogSaveRequest.setOrderStatus(request.getOrderStatus());
        repositoryFactory.getFixOrderLogRepository().save(orderLogSaveRequest);

        return true;
    }

    /**
     * 维修师 扫码领用
     *
     * @param request 请求
     * @return 结果
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public Boolean masterUse(FixOrderMasterUseRequest request) {

        FixOrder fixOrder = getByOrderNoOrGoodsUnique(request.getId());

        // 扫码领用
        repositoryFactory.getFixOrderRepository().masterUpdateOrderStatusToAppoint(fixOrder, request);

        // 保存日志
        FixOrderLogSaveRequest orderLogSaveRequest = new FixOrderLogSaveRequest();
        orderLogSaveRequest.setOrderNumber(fixOrder.getOrderNumber());
        orderLogSaveRequest.setFixStep(FixOrderStatusEnum.parse(request.getOrderStatus()).getName());
        orderLogSaveRequest.setFixContent("维修师:" + request.getFixMaster()
                + "领取:" + FixOrderStatusEnum.parse(request.getOrderStatus()).getTaskName());
        orderLogSaveRequest.setOrderStatus(request.getOrderStatus());
        repositoryFactory.getFixOrderLogRepository().save(orderLogSaveRequest);

        return true;
    }

    /**
     * 查询详情
     *
     * @param request 请求
     * @return 返回
     */
    @Override
    public FixOrderDetailResult detail(FixOrderDetailRequest request) {
        FixOrder detail = getFixOrder(request.getId());
        // 维修日志
        List<FixOrderLog> orderLogList = repositoryFactory.getFixOrderLogRepository().getFixLogByNumber(detail.getOrderNumber());
        // 维修配件
        List<FixOrderPart> orderPartList = repositoryFactory.getFixOrderPartRepository().getFixPartByNumber(detail.getOrderNumber());

        return FixOrderDetailResult.fromEntity(detail, orderLogList, orderPartList);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Boolean save(FixOrderSaveRequest request) {
        FixOrder fixOrder = repositoryFactory.getFixOrderRepository().save(request);

        // 保存配件
        if (CollectionUtils.isNotEmpty(request.getPartList())) {
            repositoryFactory.getFixOrderPartRepository().save(request.getPartList(), fixOrder.getOrderNumber());
        }

        // 保存日志
        FixOrderLogSaveRequest orderLogSaveRequest = new FixOrderLogSaveRequest();
        orderLogSaveRequest.setOrderNumber(fixOrder.getOrderNumber());
        orderLogSaveRequest.setFixStep(FixOrderStatusEnum.REGISTER.getName());
        orderLogSaveRequest.setFixContent("维修单创建");
        orderLogSaveRequest.setOrderStatus(FixOrderStatusEnum.REGISTER.getValue());
        repositoryFactory.getFixOrderLogRepository().save(orderLogSaveRequest);

        return true;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Boolean update(FixOrderSaveRequest request) {
        if (request.getId() == null) {
            throw new ArgumentException("维修单id不能为空");
        }

        FixOrder old = getFixOrder(request.getId());

        repositoryFactory.getFixOrderRepository().update(request);

        // 编辑配件
        if (CollectionUtils.isNotEmpty(request.getPartList())) {
            repositoryFactory.getFixOrderPartRepository().update(request.getPartList(), old.getOrderNumber());
        }

        return true;
    }

    @Override
    public Boolean delete(FixOrderDetailRequest request) {
        return repositoryFactory.getFixOrderRepository().delete(request);
    }

    /**
     * 完成质检
     * @param request 完成质检
     * @return 结果
     */
    @Override
    public Boolean completeQuality(FixOrderDetailRequest request){

        FixOrder fixOrder = getFixOrder(request.getId());

        // 完成质检
        repositoryFactory.getFixOrderRepository().completeQuality(request.getId());

        // 保存日志
        FixOrderLogSaveRequest orderLogSaveRequest = new FixOrderLogSaveRequest();
        orderLogSaveRequest.setOrderNumber(fixOrder.getOrderNumber());
        orderLogSaveRequest.setFixStep("完成质检");
        orderLogSaveRequest.setFixContent("完成质检");
        orderLogSaveRequest.setOrderStatus(FixOrderStatusEnum.WAIT_OUT_STOCK.getValue());
        repositoryFactory.getFixOrderLogRepository().save(orderLogSaveRequest);

        return true;
    }

    private FixOrder getFixOrder(Long id) {
        FixOrder fixOrder = repositoryFactory.getFixOrderRepository().detail(id);
        if (fixOrder == null) {
            throw new ArgumentException("维修单不存在或已被删除");
        }
        return fixOrder;
    }

    private FixOrder getByOrderNoOrGoodsUnique(String orderNo) {
        FixOrder fixOrder = repositoryFactory.getFixOrderRepository().getByOrderNoOrGoodsUnique(orderNo);
        if (fixOrder == null) {
            throw new ArgumentException("维修单不存在或已被删除");
        }
        return fixOrder;
    }
}
