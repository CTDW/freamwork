package com.seeease.flywheel_v4.web.app.purchase.result;

import com.seeease.goods.rpc.request.SkuAnnexeRpcResult;
import com.seeease.goods.rpc.result.ProductParamRpcResult;
import lombok.Data;

import java.util.List;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/4/24 6:00 下午
 **/
@Data
public class PurchaseOrderLinePageResult {
    /**
     * id
     */
    private Integer id;
    /**
     * skuId
     */
    private Integer skuId;
    /**
     * 业务单号
     */
    private String serialNo;

    /**
     * 蜥蜴编码
     */
    private String xyCode;
    /**
     * 商品名称
     */
    private String goodsName;

    /**
     * 类目名称
     */
    private String categoryName;
    /**
     * 类目id
     */
    private Integer categoryId;
    /**
     * 图片
     */
    private String spuImage;
    /**
     * 品牌名称
     */
    private String brandName;

    /**
     * sku参数列表
     */
    private List<ProductParamRpcResult> skuParams;
    /**
     * 附件
     */
    private List<SkuAnnexeRpcResult> annexe;
    /**
     * 唯一码
     */
    private String skuCode;
    /**
     * 数量
     */
    private Integer count;
    /**
     * 创建人
     */
    private String createdBy;

    /**
     * 异常原因
     */
    private String reason;
}
