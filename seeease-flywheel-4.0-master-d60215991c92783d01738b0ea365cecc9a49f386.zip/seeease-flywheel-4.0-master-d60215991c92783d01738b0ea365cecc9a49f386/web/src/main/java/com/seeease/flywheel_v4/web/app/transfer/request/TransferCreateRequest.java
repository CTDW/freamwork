package com.seeease.flywheel_v4.web.app.transfer.request;


import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.List;

/**
 * @author 西门 游
 * @version 1.0
 * @since 6/3/24 11:26 上午
 **/
@Data
public class TransferCreateRequest {

    /**
     * 调拨任务id
     */
    private List<Integer> taskIds;

    /**
     * 调出方id
     */
    @NotNull(message = "调出方id不能为空")
    private Integer fromId;

    /**
     * 调入方id
     */
    @NotNull(message = "调入方id不能为空")
    private Integer toId;
    /**
     * 调拨类型
     */
    @NotNull(message = "调拨类型不能为空")
    private Integer type;
    /**
     * 备注
     */
    private String remark;

    /**
     * sku列表
     */
    @Valid
    @NotEmpty(message = "sku列表不能为空")
    private List<Sku> skuList;


    @Data
    public static class Sku{
        /**
         * uuid
         *
         */
        private String uuid;
        /**
         * skuId
         */
        @NotNull(message = "skuId不能为空")
        private Integer skuId;
        /**
         * 调拨价
         */
        @NotNull(message = "调拨价不能为空")
        private BigDecimal transferPrice;
        /**
         * 调拨数量
         */
        @NotNull(message = "调拨数量不能为空")
        private Integer transferCount;
        /**
         * 自主经营类型
         */
        private Integer runType;
        /**
         * 品牌id
         */
        @NotNull(message = "品牌id不能为空")
        private Integer brandId;
        /**
         * 类目id
         */
        @NotNull(message = "类目id不能为空")
        private Integer categoryId;
    }
}
