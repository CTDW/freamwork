package com.seeease.flywheel_v4.web.domain.wms.observer.base;

import com.seeease.flywheel_v4.web.infrastructure.dao.sale.entity.ThirdSaleOrder;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.entity.obj.BuyBackPolicyObj;
import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.entity.SysSaleChannel;
import lombok.Data;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 9/19/24 4:25 下午
 **/
@Data
public class Ext {


    /**
     * 收货人名称
     */
    private String name;
    /**
     * 收货人电话
     */
    private String phone;
    /**
     * 收货人详细地址（该地址经过拼接）
     */
    private String address;
    /**
     * 收货人省
     */
    private String province;
    /**
     * 收货人市
     */
    private String city;
    /**
     * 收货人县
     */
    private String area;
    /**
     * 收货人街道
     */
    private String street;


    /**
     * 发货人名称
     */
    private String spName;
    /**
     * 发货人电话
     */
    private String spPhone;
    /**
     * 发货人详细地址（该地址经过拼接）
     */
    private String spAddress;
    /**
     * 发货人省
     */
    private String spProvince;
    /**
     * 发货人市
     */
    private String spCity;
    /**
     * 发货人县
     */
    private String spArea;
    /**
     * 发货人街道
     */
    private String spStreet;
    /**
     * 国检码
     */
    private String qualityCode;
    /**
     * 质检情况
     */
    private Integer qualityWay;
    /**
     * 三方单号
     */
    private String thirdPartNo;


    /**
     * 面单备注
     */
    private String billRemark;

    /**
     * 备注
     */
    private String remark;


    /**
     * 销售渠道
     */
    private SysSaleChannel saleChannel;

    /**
     * 三方订单
     */
    private ThirdSaleOrder thirdSaleOrder;

    /**
     * 销售人
     */
    private String seller;

    /**
     * sku拓展字段
     */
    private List<SkuExt> skuExts = new ArrayList<>();


    /**
     * sku拓展字段
     */
    @Data
    public static class SkuExt{
        /**
         * skuId
         */
        private Integer skuId;
        /**
         * 回购政策
         */
        private List<BuyBackPolicyObj> policies;
        /**
         * 成交价
         */
        private BigDecimal dealPrice;

    }

}
