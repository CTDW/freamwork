package com.seeease.flywheel_v4.web.app.purchase.request;


import lombok.Data;

/**
 * @ Description   :
 * @ Author        :  西门 游
 * @ CreateDate    :  6/6/24
 * @ Version       :  1.0
 */

@Data
public class PurchaseOrderDetailRequest  {

    /**
     * id
     */
    private Integer id;
    /**
     * 采购单号
     */
    private String serialNo;

}
