package com.seeease.flywheel_v4.web.app.sale.service;

import com.seeease.flywheel_v4.web.app.sale.request.*;
import com.seeease.flywheel_v4.web.app.sale.result.*;
import com.seeease.springframework.PageResult;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 8/2/24 2:04 下午
 **/
public interface SaleReturnOrderService {
    /**
     * 销售退货-toc销售退货单创建
     *
     * @return 创建结果
     */
    Integer tocReturnCreate(ToCSaleReturnOrderCreateRequest request);

    /**
     * 销售退货-toc销售退货单分页查询
     *
     * @return 分页结果
     */
    PageResult<ToCSaleReturnOrderPageResult> tocReturnPage(ToCSaleReturnOrderPageRequest request);

    /**
     * 销售退货-toc退货单详情
     *
     * @return 详情结果
     */
    ToCSaleReturnOrderDetailResult tocReturnDetail(ToCSaleReturnOrderDetailRequest request);

    /**
     * 销售退货-退货单取消
     *
     * @return 取消结果
     */
    Boolean tocReturnCancel(SaleReturnOrderCancelRequest request);

    /**
     * 销售-tob销售退货单分页
     *
     * @return 分页结果
     */
    PageResult<ToBSaleReturnOrderPageResult> tobReturnPage(ToBSaleReturnOrderPageRequest request);


    /**
     * 销售-tob销售退货单详情
     *
     * @return 详情结果
     */
    ToBSaleReturnOrderDetailResult tobReturnDetail(ToBSaleReturnOrderDetailRequest request);

    /**
     * 销售退货-tob退货单取消
     *
     * @return 取消结果
     */
    Boolean tobReturnCancel(SaleReturnOrderCancelRequest request);


    /**
     * 销售-tob销售退货单创建
     *
     * @return 创建结果
     */
    Boolean tobReturnCreate(ToBSaleReturnOrderCreateRequest request);
}
