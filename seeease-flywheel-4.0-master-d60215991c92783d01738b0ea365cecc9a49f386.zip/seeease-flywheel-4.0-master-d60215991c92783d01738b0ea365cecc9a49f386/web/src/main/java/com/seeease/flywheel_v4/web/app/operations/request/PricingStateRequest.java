package com.seeease.flywheel_v4.web.app.operations.request;

import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.Pricing;
import com.seeease.springframework.PageRequest;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.validation.constraints.NotNull;
import java.math.BigDecimal;


@EqualsAndHashCode(callSuper = true)
@Data
public class PricingStateRequest extends PageRequest {



    /**
     * 定价管理id
     */
    @NotNull(message = "id不能为空")
    private Integer id;
    /**
     * 同行价
     */
    @NotNull(message = "同行价不能为空")
    private BigDecimal tobPrice;
    /**
     * 零售价
     */
    @NotNull(message = "零售价不能为空")
    private BigDecimal tocPrice;
    /**
     * 结算价
     */
    @NotNull(message = "结算价不能为空")
    private BigDecimal settlePrice;
    /**
     * 销售渠道定位
     */
    @NotNull(message = "销售渠道定位不能为空")
    private Integer sellWay;
    /**
     * 自主经营类型
     */
    @NotNull(message = "自主经营类型不能为空")
    private Integer runType;
    /**
     * 商家id
     */
    private Integer merchantId;
    /**
     * 收货价
     */
    private BigDecimal receiptPrice;

    /**
     * 定价单状态
     * {@link Pricing#getState()}
     */
    @NotNull(message = "定价单状态不能为空")
    private Integer state;
}
