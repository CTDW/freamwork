package com.seeease.flywheel_v4.web.infrastructure.dao.operations.repo;

import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.SupplierQuotaDetail;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.enums.SupplierQuotaAuditTypeEnums;

import java.util.List;

/**
 *
 * @author 西门 游
 * @version 1.0
 * @since 5/31/24 4:55 下午
 **/
public interface SupplierQuotaDetailRepository {

    /**
     * 查找
     * @param userid
     * @param type
     * @return
     */
    SupplierQuotaDetail findOne(Integer quotaId ,Integer userid, SupplierQuotaAuditTypeEnums type);

    /**
     * 提交
     * @param detail
     */
    Boolean submit(SupplierQuotaDetail detail);

    /**
     * 查找
     * @param mainId
     * @return
     */
    List<SupplierQuotaDetail> listByMainId(Integer mainId);

    /**
     * 查找
     * @param id
     * @return
     */
    SupplierQuotaDetail findById(Integer id);
}
