package com.seeease.flywheel_v4.web.infrastructure.dao.operations.repo.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.SupplierQuotaLog;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.mapper.SupplierQuotaLogMapper;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.repo.SupplierQuotaLogRepository;
import org.springframework.stereotype.Repository;

/**
 * @author 西门 游
 * @version 1.0
 * @since 5/31/24 4:55 下午
 **/
@Repository
public class SupplierQuotaLogRepositoryImpl extends ServiceImpl<SupplierQuotaLogMapper, SupplierQuotaLog>
        implements SupplierQuotaLogRepository {


    @Override
    public Boolean submit(SupplierQuotaLog log) {
        return saveOrUpdate(log);
    }
}
