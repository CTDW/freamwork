package com.seeease.flywheel_v4.web.infrastructure.dao.operations.repo;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.Supplier;
import com.seeease.springframework.PageRequest;

import java.util.List;
import java.util.Set;

/**
 *
 * @author 西门 游
 * @version 1.0
 * @since 5/31/24 4:55 下午
 **/
public interface SupplierRepository {

    /**
     * 提交
     *
     * @return 提交结果
     */
    boolean submit(Supplier supplier);

    /**
     * 分页查询
     * @param ids  主键id列表
     * @param type  类型
     * @param name  名称
     * @param state 状态
     *
     * @return 分页结果
     */
    Page<Supplier> page(Set<Integer> ids,
                        Integer type,
                        String name,
                        Integer state,
                        PageRequest request);

    /**
     * 查找
     * @param id 主键id
     * @return
     */
    Supplier findById(Integer id);

    /**
     * 列表查询
     * @param ids 主键id列表
     * @return
     */
    List<Supplier> listByIds(Set<Integer> ids);

    /**
     * 列表查询
     * @param name 供应商名称
     * @return
     */
    List<Supplier> listByName(String name);
}
