package com.seeease.flywheel_v4.web.infrastructure.dao.sale.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.entity.obj.BuyerInfoObj;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.enums.SaleQualityWayEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.enums.ThirdSaleStateEnums;
import com.seeease.seeeaseframework.mybatis.domain.BaseDomain;
import com.seeease.seeeaseframework.mybatis.type.JsonTypeHandler;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * 三方销售订单
 */
@EqualsAndHashCode(callSuper = true)
@TableName(value = "v4_third_sale_order", autoResultMap = true)
@Data
public class ThirdSaleOrder extends BaseDomain {
    @TableId(type = IdType.AUTO)
    private Integer id;
    /**
     * 订单id
     */
    private String orderId;
    /**
     * 对应销售渠道里面的配置id
     */
    private Integer scId;
    /**
     * 客户名称 搜索使用
     */
    private String buyerName;
    /**
     * 客户电话 搜索使用
     */
    private String buyerTel;

    /**
     * 商品标题
     */
    private String title;

    /**
     * 状态
     */
    private ThirdSaleStateEnums state;
    /**
     * 客户信息
     */
    private String mergeId;
    /**
     * 客户信息
     */
    @TableField(typeHandler = JsonTypeHandler.class)
    private BuyerInfoObj buyerInfo;
    /**
     * 总数量
     */
    private Integer totalCount;
    /**
     * 总金额
     */
    private BigDecimal totalAmount;

    /**
     * 备注
     */
    private String remark;

    /**
     * 客户备注
     */
    private String billRemark;

    /**
     * 审核时间
     */
    private Date auditTime;

    /**
     * 快手卖家id
     */
    private String ksSellerId;

    /**
     * 合并后id
     */
    private String  mergedId;

    /**
     * 质检方式
     */
    private SaleQualityWayEnums qualityWay;
    /**
     * 国检码
     */
    private String qualityCode;
    /**
     * 抖音子订单id
     */
    @TableField(typeHandler = JsonTypeHandler.class)
    private List<Long> tiktokSid;
}