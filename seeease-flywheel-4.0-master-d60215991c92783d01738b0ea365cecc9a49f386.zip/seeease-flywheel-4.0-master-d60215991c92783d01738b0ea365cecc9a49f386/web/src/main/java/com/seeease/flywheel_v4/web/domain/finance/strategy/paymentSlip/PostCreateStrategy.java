package com.seeease.flywheel_v4.web.domain.finance.strategy.paymentSlip;

import com.seeease.flywheel_v4.web.app.finance.request.PaymentSlipSubmitRequest;
import com.seeease.flywheel_v4.web.infrastructure.dao.finance.entity.FinancePaymentSlip;
import com.seeease.flywheel_v4.client.enums.PurchaseTypeEnums;

/**
 * 
 * 申请打款单创建后置策略
 * @author 西门 游
 * @version 1.0
 * @since 6/13/24 11:20上午
 **/
public interface PostCreateStrategy {

    /**
     * 申请打款单后置处理
     */
    void post(PaymentSlipSubmitRequest request, FinancePaymentSlip paymentSlip);

    /**
     * 匹配对应的后置处理策略
     * @param purchaseTypeEnums 采购类型
     * @return 匹配结果
     */
    default Boolean match(PurchaseTypeEnums purchaseTypeEnums){
        return false;
    }
}
