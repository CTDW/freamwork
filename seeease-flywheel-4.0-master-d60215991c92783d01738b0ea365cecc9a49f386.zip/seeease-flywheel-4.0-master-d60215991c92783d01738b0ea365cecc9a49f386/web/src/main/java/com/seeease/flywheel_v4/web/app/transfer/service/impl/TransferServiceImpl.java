package com.seeease.flywheel_v4.web.app.transfer.service.impl;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.seeease.flywheel_v4.client.enums.BusinessUnitTypeEnums;
import com.seeease.flywheel_v4.web.app.transfer.request.*;
import com.seeease.flywheel_v4.web.app.transfer.result.TransferDetailResult;
import com.seeease.flywheel_v4.web.app.transfer.result.TransferPageResult;
import com.seeease.flywheel_v4.web.app.transfer.result.TransferUsableQuotaResult;
import com.seeease.flywheel_v4.web.app.transfer.service.TransferService;
import com.seeease.flywheel_v4.web.domain.operations.OpsDomain;
import com.seeease.flywheel_v4.web.domain.transfer.mapping.TransferOrderLineMapping;
import com.seeease.flywheel_v4.web.domain.transfer.mapping.TransferOrderMapping;
import com.seeease.flywheel_v4.web.domain.wms.observer.base.WmsSubject;
import com.seeease.flywheel_v4.web.infrastructure.dao.RepositoryFactory;
import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.entity.SysBusinessUnit;
import com.seeease.flywheel_v4.web.infrastructure.dao.transfer.entity.TransferOrder;
import com.seeease.flywheel_v4.web.infrastructure.dao.transfer.entity.TransferOrderLine;
import com.seeease.flywheel_v4.web.infrastructure.dao.transfer.enums.TransferTypeEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.MerchantWms;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.MerchantWmsLine;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.WmsCk;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.obj.ContactInfo;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.MerchantWmsModelEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.MerchantWmsTypeEnums;
import com.seeease.flywheel_v4.web.infrastructure.listener.TransferOrderStateListener;
import com.seeease.goods.rpc.SkuFacade;
import com.seeease.goods.rpc.enums.SkuNodeStateEnums;
import com.seeease.goods.rpc.request.SkuRpcRequest;
import com.seeease.goods.rpc.request.TransferSkuCreateRpcRequest;
import com.seeease.goods.rpc.result.SkuCreateRpcResult;
import com.seeease.goods.rpc.result.SkuRpcResult;
import com.seeease.springframework.PageResult;
import com.seeease.springframework.context.UserContext;
import com.seeease.springframework.exception.ValidationUtil;
import com.seeease.springframework.utils.MultiUtils;
import com.seeease.springframework.utils.StringUtils;
import io.seata.spring.annotation.GlobalTransactional;
import lombok.extern.slf4j.Slf4j;
import org.apache.dubbo.config.annotation.DubboReference;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 7/2/24 4:37 下午
 **/
@Service
@Slf4j
public class TransferServiceImpl implements TransferService {

    @Resource
    private RepositoryFactory repositoryFactory;
    @Resource
    private OpsDomain opsDomain;
    @Resource
    private WmsSubject wmsSubject;
    @Resource
    private TransferOrderStateListener stateListener;

    @DubboReference(version = "1.0.0", check = false)
    private SkuFacade skuFacade;


    @Override
    public TransferUsableQuotaResult usableQuota(TransferUsableQuotaRequest request) {
        SysBusinessUnit buId = repositoryFactory.getBusinessUnitRepository().findById(request.getId());
        ValidationUtil.notNull(buId, "业务单元id错误");
        return opsDomain.claTransferUsableQuota(request.getId());
    }


    /**
     * 调拨单创建参数校验
     */
    private void check(TransferCreateRequest request) {
        ValidationUtil.isTrue(!Objects.equals(request.getFromId(), request.getToId()), "调拨双方id不能为空");
        SysBusinessUnit toUnit = repositoryFactory.getBusinessUnitRepository().findById(request.getToId());
        ValidationUtil.notNull(toUnit, "调入方id错误");

        ValidationUtil.notNull(toUnit, "调出方id错误");


        Map<Integer, List<TransferCreateRequest.Sku>> requestSkuMap = request.getSkuList().stream()
                .collect(Collectors.groupingBy(TransferCreateRequest.Sku::getSkuId));

        for (Map.Entry<Integer, List<TransferCreateRequest.Sku>> entry : requestSkuMap.entrySet()) {
            ValidationUtil.isTrue(entry.getValue().size() == 1, "相同sku无法同时调拨");
        }

//        //额度校验
//        List<OpsDomain.SkuTransferCheckParam> checkParamList = MultiUtils.toList(
//                request.getSkuList(),
//                TransferOrderMapping.INSTANCE::toTransferQuotaCheckParam
//        );
//        opsDomain.transferQuotaCheck(checkParamList, request.getToId());

        //条件校验
//        SysBusinessUnit fromUnit = repositoryFactory.getBusinessUnitRepository().findById(request.getFromId());
//        final List<Integer> condition = Lists.newArrayList(
//                TransferTypeEnums.JS.getValue(),
//                TransferTypeEnums.JS_GH.getValue()
//        );
//        if (fromUnit.getType() == BusinessUnitTypeEnums.WAREHOUSE || toUnit.getType() == BusinessUnitTypeEnums.WAREHOUSE) {
//            ValidationUtil.isTrue(
//                    condition.contains(request.getType()),
//                    "如果调入方跟调出方有一个是仓库主体，那么只能选，寄售、寄售归还"
//            );
//        }

    }


    @GlobalTransactional
    @Override
    public Integer create(TransferCreateRequest request) {
        //stpe_0 校验
        this.check(request);
        //step_1 查询sku数据为了计算金额
        Set<Integer> skuIdList = MultiUtils.toSet(request.getSkuList(), TransferCreateRequest.Sku::getSkuId);
        SkuRpcRequest rpcRequest = new SkuRpcRequest();
        rpcRequest.setIdList(skuIdList);
        List<SkuRpcResult> skuList = skuFacade.list(rpcRequest);

        for (SkuRpcResult sku : skuList){
            if (!sku.getStoreId().equals(sku.getSellerId())){
                ValidationUtil.isTrue(
                        Objects.equals(request.getType(), TransferTypeEnums.JH.getValue()),
                        "商品位置和经营权不相同的商品只能做借货"
                );
            }
        }

        Map<Integer, SkuRpcResult> skuMap = MultiUtils.toMap(
                skuList,
                SkuRpcResult::getId,
                Function.identity()
        );
        //金额计算
        int totalCount = 0;
        BigDecimal totalSettlePrice = BigDecimal.ZERO;
        BigDecimal totalNewSettlePrice = BigDecimal.ZERO;
        BigDecimal totalProfit = BigDecimal.ZERO;

        for (TransferCreateRequest.Sku sku : request.getSkuList()) {
            Integer transferCount = sku.getTransferCount();
            BigDecimal tb = new BigDecimal(transferCount);
            BigDecimal settlePrice = skuMap.get(sku.getSkuId()).getSettlePrice();
            BigDecimal newSettlePrice = skuMap.get(sku.getSkuId()).getNewSettlePrice();
            BigDecimal transferPrice = sku.getTransferPrice();

            totalCount += transferCount;
            totalSettlePrice = totalSettlePrice.add(settlePrice.multiply(tb));
            totalNewSettlePrice = totalNewSettlePrice.add(newSettlePrice.multiply(tb));
            totalProfit = totalProfit.add((transferPrice.subtract(settlePrice)).multiply(tb));
        }
        //step_2 删除调拨任务单据
        if (StringUtils.isNotEmpty(request.getTaskIds())) {
            repositoryFactory.getTransferTaskRepository().delByIds(request.getTaskIds());
        }

        //step_3 创建调拨单
        Integer buId = UserContext.getUser().getStore().getId();
        TransferOrder transferOrder = TransferOrderMapping.INSTANCE.toEntity(
                request,
                totalCount,
                totalSettlePrice,
                totalNewSettlePrice,
                totalProfit,
                buId
        );
        repositoryFactory.getTransferOrderRepository().submit(transferOrder);

        //step_4 sku锁定
        request.getSkuList().forEach(sku -> sku.setUuid(UUID.randomUUID().toString()));
        SysBusinessUnit fromUnit = repositoryFactory.getBusinessUnitRepository().findById(request.getFromId());
        boolean pushToStoreWms = fromUnit.getType() == BusinessUnitTypeEnums.WAREHOUSE;
        SkuNodeStateEnums nodeState = pushToStoreWms ? SkuNodeStateEnums.DB_ZT : SkuNodeStateEnums.DCK;
        TransferSkuCreateRpcRequest rpcRequest1 = TransferOrderMapping.INSTANCE.toTransferSKuCreate(
                request,
                transferOrder.getSerialNo(),
                nodeState
        );
        List<SkuCreateRpcResult> skuCreateList = skuFacade.create(rpcRequest1);
        Map<String, TransferCreateRequest.Sku> paramSkuList = MultiUtils.toMap(
                request.getSkuList(),
                TransferCreateRequest.Sku::getUuid);


        //step_5 调拨单行创建
        List<TransferOrderLine> lineList = MultiUtils.toList(
                skuCreateList,
                sku -> {
                    TransferCreateRequest.Sku paramSku = paramSkuList.get(sku.getUuid());

                    //利润等于调拨价 - 最新结算价 / 数量
                    BigDecimal profit = (paramSku.getTransferPrice().subtract(sku.getNewSettlePrice()))
                            .multiply(new BigDecimal(sku.getCount()));

                    return TransferOrderLineMapping.INSTANCE.toEntity(
                            paramSku,
                            sku,
                            transferOrder.getId(),
                            profit
                    );
                }
        );

        repositoryFactory.getTransferOrderLineRepository().submitBatch(lineList);

        //step_6 wms推送
        if (pushToStoreWms) { //推送仓库
            List<WmsCk> wmsCkList = MultiUtils.toList(
                    lineList,
                    line -> TransferOrderMapping.INSTANCE.toWmsCk(transferOrder, line, buId)
            );
            wmsSubject.ckDataSubmit(wmsCkList);
        } else { //推送商家
            SysBusinessUnit toUnit = repositoryFactory.getBusinessUnitRepository().findById(request.getToId());
            ContactInfo contactInfo = TransferOrderMapping.INSTANCE.toMerchantWmsContactInfo(toUnit);
            MerchantWms merchantWms = TransferOrderMapping.INSTANCE.toMerchantWms(
                    transferOrder,
                    contactInfo,
                    MerchantWmsModelEnums.CK,
                    MerchantWmsTypeEnums.DB_CK,
                    transferOrder.getFromId(),
                    null
            );
            List<MerchantWmsLine> merchantWmsLines = MultiUtils.toList(
                    lineList,
                    line -> TransferOrderLineMapping.INSTANCE.toMerchantWmsLine(line, SkuNodeStateEnums.DCK)
            );
            wmsSubject.merchantWmsDataCreate(merchantWms, merchantWmsLines);
        }

        return transferOrder.getId();
    }

    @Override
    public PageResult<TransferPageResult> page(TransferPageRequest request) {
        //sku查询
        Set<Integer> skuIdList = null;
        if (StringUtils.oneOfNonNull(
                request.getSkuCode(),
                request.getGoodsCode(),
                request.getGoodsName()
        )) {
            SkuRpcRequest rpcRequest = TransferOrderMapping.INSTANCE.toSkuRpcRequest(request);
            List<SkuRpcResult> skuList = skuFacade.list(rpcRequest);

            if (skuList.isEmpty()) {
                return PageResult.buildEmpty();
            }
            skuIdList = MultiUtils.toSet(skuList, SkuRpcResult::getId);
        }

        //调拨行查询
        Set<Integer> transferIdList = null;
        if (StringUtils.isNotEmpty(skuIdList)) {
            transferIdList = MultiUtils.toSet(
                    repositoryFactory.getTransferOrderLineRepository().listBySkuId(skuIdList),
                    TransferOrderLine::getTransferId
            );

            if (transferIdList.isEmpty()) {
                return PageResult.buildEmpty();
            }
        }


        //主表查询
        Integer buId = UserContext.getUser().getStore().getId();
        SysBusinessUnit bu = repositoryFactory.getBusinessUnitRepository().findById(buId);
        if (bu.getType() != BusinessUnitTypeEnums.PLATFORM){
            request.setBuId(buId);
        }

        Page<TransferOrder> page = repositoryFactory.getTransferOrderRepository().page(
                request,
                transferIdList
        );

        if (page.getRecords().isEmpty()) {
            return PageResult.buildEmpty();
        }

        //调入方
        Set<Integer> toIdList = MultiUtils.toSet(page.getRecords(), TransferOrder::getToId);
        Map<Integer, String> toMap = MultiUtils.toMap(
                repositoryFactory.getBusinessUnitRepository().listByIds(toIdList),
                SysBusinessUnit::getId,
                SysBusinessUnit::getName
        );

        //调出方
        Set<Integer> fromIdList = MultiUtils.toSet(page.getRecords(), TransferOrder::getFromId);
        Map<Integer, String> fromMap = MultiUtils.toMap(
                repositoryFactory.getBusinessUnitRepository().listByIds(fromIdList),
                SysBusinessUnit::getId,
                SysBusinessUnit::getName
        );

        //订单来源
        List<Integer> originIds = MultiUtils.toList(page.getRecords(), TransferOrder::getBuId);
        Map<Integer, String> originMap = MultiUtils.toMap(
                repositoryFactory.getBusinessUnitRepository().listByIds(fromIdList),
                SysBusinessUnit::getId,
                SysBusinessUnit::getName
        );



        //数据组合
        List<TransferPageResult> ret = MultiUtils.toList(
                page.getRecords(),
                v -> {
                    String originName = originMap.get(v.getBuId());
                    String toName = toMap.get(v.getToId());
                    String fromName = fromMap.get(v.getFromId());
                    return TransferOrderMapping.INSTANCE.toPageResult(v, toName, fromName,originName);
                }
        );

        return PageResult.<TransferPageResult>builder()
                .result(ret)
                .totalCount(page.getTotal())
                .totalPage(page.getPages())
                .build();
    }

    @Override
    public TransferDetailResult detail(TransferDetailRequest request) {
        //调拨单
        TransferOrder transferOrder = repositoryFactory.getTransferOrderRepository()
                .findByIdOrSerialNo(request.getId(), request.getSerialNo());

        ValidationUtil.notNull(transferOrder, "调拨单id错误");

        //调拨单行
        List<TransferOrderLine> lineList = repositoryFactory.getTransferOrderLineRepository()
                .listByTransferId(transferOrder.getId());
        //sku
        Set<Integer> skuIdList = MultiUtils.toSet(lineList, TransferOrderLine::getSkuId);
        SkuRpcRequest rpcRequest = new SkuRpcRequest();
        rpcRequest.setIdList(skuIdList);
        Map<Integer, SkuRpcResult> skuMap = MultiUtils.toMap(
                skuFacade.list(rpcRequest),
                SkuRpcResult::getId,
                Function.identity()
        );
        //组合sku和调拨单行
        List<TransferDetailResult.Sku> skuList = MultiUtils.toList(
                lineList,
                v -> TransferOrderLineMapping.INSTANCE.toDetailResult(v, skuMap.get(v.getSkuId()))
        );

        //调入方
        SysBusinessUnit to = repositoryFactory.getBusinessUnitRepository().findById(transferOrder.getToId());

        //调出方
        SysBusinessUnit from = repositoryFactory.getBusinessUnitRepository().findById(transferOrder.getFromId());


        //数据组合
        return TransferOrderMapping.INSTANCE.toDetailResult(transferOrder, skuList, to.getName(), from.getName());

    }

    @GlobalTransactional
    @Override
    public Boolean cancel(TransferCancelRequest request) {
        ValidationUtil.isTrue(
                StringUtils.oneOfNonNull(request.getId(), request.getLineId()),
                "参数缺失"
        );
        List<TransferOrderLine> lineList;
        if (null != request.getId()) {
            lineList = repositoryFactory.getTransferOrderLineRepository().listByTransferId(request.getId());
        } else {
            lineList = Collections.singletonList(
                    repositoryFactory.getTransferOrderLineRepository().findById(request.getLineId())
            );
        }


        //step_1 过滤出状态为调拨在途的数据
        lineList = lineList.stream()
                .filter(line -> line.getNodeState() == SkuNodeStateEnums.DB_ZT)
                .collect(Collectors.toList());

        ValidationUtil.isTrue(!lineList.isEmpty(),"无可取消的sku");



        //step_2 调用wms取消
        TransferOrder order = repositoryFactory.getTransferOrderRepository().findByIdOrSerialNo(
                lineList.get(0).getTransferId(),
                null
        );
        Set<Integer> skuIdList = MultiUtils.toSet(lineList, TransferOrderLine::getSkuId);
        SysBusinessUnit fromUnit = repositoryFactory.getBusinessUnitRepository().findById(order.getFromId());

        if (fromUnit.getType() == BusinessUnitTypeEnums.WAREHOUSE){
            wmsSubject.cancelWmsCk(order.getSerialNo(),skuIdList,false);
        }else {
            wmsSubject.cancelMerchantWms(order.getSerialNo(),skuIdList,SkuNodeStateEnums.DCK,false);
        }

        return true;
    }
}
