package com.seeease.flywheel_v4.web.app.wms.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.seeease.flywheel_v4.web.app.wms.request.*;
import com.seeease.flywheel_v4.web.app.wms.result.MerchantWmsDetailResult;
import com.seeease.flywheel_v4.web.app.wms.result.MerchantWmsPageResult;
import com.seeease.flywheel_v4.web.app.wms.service.MerchantWmsService;
import com.seeease.flywheel_v4.web.domain.wms.component.express.core.ExpressChannel;
import com.seeease.flywheel_v4.web.domain.wms.component.express.core.PlaceOrderDto;
import com.seeease.flywheel_v4.web.domain.wms.component.express.core.PlaceOrderResult;
import com.seeease.flywheel_v4.web.domain.wms.component.express.core.PrintResult;
import com.seeease.flywheel_v4.web.domain.wms.component.express.core.sf.PlaceOrderHandler;
import com.seeease.flywheel_v4.web.domain.wms.mapping.MerchantWmsLineMapping;
import com.seeease.flywheel_v4.web.domain.wms.mapping.MerchantWmsMapping;
import com.seeease.flywheel_v4.web.domain.wms.mapping.WmsCkMapping;
import com.seeease.flywheel_v4.web.domain.wms.observer.base.Ext;
import com.seeease.flywheel_v4.web.domain.wms.observer.base.WmsSubject;
import com.seeease.flywheel_v4.web.infrastructure.dao.RepositoryFactory;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.enums.SaleQualityWayEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.entity.SysBusinessUnit;
import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.enums.SaleChannelTypeEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.MerchantWms;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.MerchantWmsLine;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.obj.ContactInfo;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.MerchantWmsModelEnums;
import com.seeease.goods.rpc.SkuFacade;
import com.seeease.goods.rpc.enums.SkuNodeStateEnums;
import com.seeease.goods.rpc.request.SkuRpcRequest;
import com.seeease.goods.rpc.result.SkuRpcResult;
import com.seeease.seeeaseframework.mybatis.domain.WhetherEnum;
import com.seeease.springframework.PageResult;
import com.seeease.springframework.context.UserContext;
import com.seeease.springframework.exception.ValidationUtil;
import com.seeease.springframework.utils.MultiUtils;
import com.seeease.springframework.utils.StringUtils;
import io.seata.spring.annotation.GlobalTransactional;
import lombok.extern.slf4j.Slf4j;
import org.apache.dubbo.config.annotation.DubboReference;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.*;
import java.util.stream.Collectors;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/20/24 11:46 上午
 **/
@Service
@Slf4j
public class MerchantWmsServiceImpl implements MerchantWmsService {
    @Resource
    private RepositoryFactory repositoryFactory;

    @DubboReference(version = "1.0.0", check = false)
    private SkuFacade skuFacade;

    @Resource
    private WmsSubject wmsSubject;
    @Resource
    private PlaceOrderHandler placeOrderHandler;

    @Override
    public PageResult<MerchantWmsPageResult> page(MerchantWmsPageRequest request) {

        //sku查询
        Set<Integer> skuIdList = null;
        if (StringUtils.isNotEmpty(request.getSkuCode())) {
            SkuRpcRequest rpcRequest = new SkuRpcRequest();
            rpcRequest.setSkuCode(request.getSkuCode());
            skuIdList = MultiUtils.toSet(skuFacade.list(rpcRequest), SkuRpcResult::getId);

            if (StringUtils.isEmpty(skuIdList)) {
                return PageResult.buildEmpty();
            }
        }

        //wms行查询
        Set<Integer> mainIdList = null;
        if (null != skuIdList) {
            mainIdList = MultiUtils.toSet(
                    repositoryFactory.getMerchantWmsLineRepository().listBySkuIdList(skuIdList),
                    MerchantWmsLine::getMainId
            );
            if (StringUtils.isEmpty(mainIdList)) {
                return PageResult.buildEmpty();
            }
        }


        //主表查询
        Integer buId = UserContext.getUser().getStore().getId();
        request.setBuId(buId);
        Page<MerchantWms> page = repositoryFactory.getMerchantWmsRepository().page(request, mainIdList);
        if (StringUtils.isEmpty(page.getRecords())) {
            return PageResult.buildEmpty();
        }


        //收货方数据
        Set<Integer> toIdList = MultiUtils.toSet(page.getRecords(), MerchantWms::getToId);
        Map<Integer, String> toMap = MultiUtils.toMap(
                repositoryFactory.getBusinessUnitRepository().listByIds(toIdList),
                SysBusinessUnit::getId,
                SysBusinessUnit::getName
        );


        //发货方数据
        Set<Integer> fromIdList = MultiUtils.toSet(page.getRecords(), MerchantWms::getFromId);
        Map<Integer, String> fromMap = MultiUtils.toMap(
                repositoryFactory.getBusinessUnitRepository().listByIds(fromIdList),
                SysBusinessUnit::getId,
                SysBusinessUnit::getName
        );

        //订单来源
        Set<Integer> originIdList = MultiUtils.toSet(page.getRecords(), MerchantWms::getOriginId);
        Map<Integer, String> originMap = MultiUtils.toMap(
                repositoryFactory.getBusinessUnitRepository().listByIds(originIdList),
                SysBusinessUnit::getId,
                SysBusinessUnit::getName
        );


        //组合数据
        List<MerchantWmsPageResult> ret = MultiUtils.toList(
                page.getRecords(),
                v -> {
                    String originName = originMap.get(v.getOriginId());
                    String toName = toMap.get(v.getToId());
                    String fromName = fromMap.get(v.getFromId());
                    return MerchantWmsMapping.INSTANCE.to(v, toName, fromName, originName);
                }
        );


        return PageResult.<MerchantWmsPageResult>builder()
                .result(ret)
                .totalCount(page.getTotal())
                .totalPage(page.getPages())
                .build();
    }

    @Override
    public MerchantWmsDetailResult detail(MerchantWmsDetailRequest request) {

        MerchantWms main = repositoryFactory.getMerchantWmsRepository().findById(request.getId());

        //收货方数据
        SysBusinessUnit to = repositoryFactory.getBusinessUnitRepository().findById(main.getToId());
        //发货方数据
        SysBusinessUnit from = repositoryFactory.getBusinessUnitRepository().findById(main.getFromId());
        //订单来源
        SysBusinessUnit origin = repositoryFactory.getBusinessUnitRepository().findById(main.getOriginId());
        //客户数据
        ContactInfo contactInfo = main.getContactInfo();
        //行数据
        Map<Integer, MerchantWmsLine> lineMap = MultiUtils.toMap(
                repositoryFactory.getMerchantWmsLineRepository().listByMainId(main.getId()),
                MerchantWmsLine::getSkuId
        );

        //sku数据
        SkuRpcRequest rpcRequest = new SkuRpcRequest();
        rpcRequest.setIdList(lineMap.keySet());
        List<SkuRpcResult> skuList = skuFacade.list(rpcRequest);

        //组合行数据
        List<MerchantWmsDetailResult.Sku> itemList = MultiUtils.toList(
                skuList,
                v -> MerchantWmsLineMapping.INSTANCE.toDetail(v, lineMap.get(v.getId()))
        );


        //组合总数据

        return MerchantWmsMapping.INSTANCE.toDetailResult(
                main,
                to,
                from,
                origin,
                contactInfo,
                itemList
        );
    }


    @GlobalTransactional
    @Override
    public Boolean cancel(MerchantWmsCancelRequest request) {
        MerchantWms main;
        List<MerchantWmsLine> lineList;

        if (null != request.getId()) {
            main = repositoryFactory.getMerchantWmsRepository().findById(request.getId());
            ValidationUtil.notNull(main, "id错误");
            lineList = repositoryFactory.getMerchantWmsLineRepository().listByMainId(main.getId());
        } else {
            MerchantWmsLine line = repositoryFactory.getMerchantWmsLineRepository().findById(request.getLineId());
            ValidationUtil.notNull(line, "lineId 错误");
            lineList = Collections.singletonList(line);
            main = repositoryFactory.getMerchantWmsRepository().findById(line.getMainId());
        }


        SkuNodeStateEnums before = main.getModel() == MerchantWmsModelEnums.RK ?
                SkuNodeStateEnums.DRK : SkuNodeStateEnums.DCK;


        lineList = lineList.stream()
                .filter(l -> l.getNodeState() == before)
                .peek(l -> {
                    l.setNodeState(SkuNodeStateEnums.QX);
                    l.setEndState(WhetherEnum.YES);
                })
                .collect(Collectors.toList());

        ValidationUtil.isTrue(!lineList.isEmpty(), "状态错误无法拒收");


        wmsSubject.merchantWmsState(main, lineList, SkuNodeStateEnums.QX);
        return true;
    }

    @GlobalTransactional
    @Override
    public Boolean confirm(MerchantWmsConfirmRequest request) {
        MerchantWms main = repositoryFactory.getMerchantWmsRepository().findById(request.getId());
        if (StringUtils.isNotEmpty(request.getExpressNo())){
            main.setExpressNo(request.getExpressNo());
        }

        ValidationUtil.notNull(main, "id错误");


        SkuNodeStateEnums before = main.getModel() == MerchantWmsModelEnums.RK ?
                SkuNodeStateEnums.DRK : SkuNodeStateEnums.DCK;

        SkuNodeStateEnums after = main.getModel() == MerchantWmsModelEnums.RK ?
                SkuNodeStateEnums.YRK : SkuNodeStateEnums.YCK;

        List<MerchantWmsLine> lineList = repositoryFactory.getMerchantWmsLineRepository()
                .listByMainId(main.getId())
                .stream()
                .filter(l -> l.getNodeState() == before)
                .peek(l -> {
                    l.setNodeState(after);
                    l.setEndState(WhetherEnum.YES);
                })
                .collect(Collectors.toList());

        if (lineList.isEmpty()) {
            return true;
        }

        wmsSubject.merchantWmsState(main, lineList, after);
        return true;
    }

    @Override
    public PrintResult merchantCkPrint(WmsMerchantCkPrintRequest request) {
        //step_1 先获取订单数据
        MerchantWms main = repositoryFactory.getMerchantWmsRepository().findById(request.getId());
        ValidationUtil.notNull(main,"id参数错误");
        List<MerchantWmsLine> lines = repositoryFactory.getMerchantWmsLineRepository().listByMainId(main.getId());


        //step_2 转换快递数据
        List<PlaceOrderDto> placeOrderDtos = new ArrayList<>();
        ExpressChannel.Channel channel;
        Ext ext = wmsSubject.getMerchantCkExt(main);
        Set<Integer> skuIds = MultiUtils.toSet(lines, MerchantWmsLine::getSkuId);
        SkuRpcRequest rpcRequest = new SkuRpcRequest();
        rpcRequest.setIdList(skuIds);
        List<SkuRpcResult> skus = skuFacade.list(rpcRequest);
        //转换为快递下单数据
        List<PlaceOrderDto.Product> products = MultiUtils.toList(skus, WmsCkMapping.INSTANCE::toPlaceOrderProduct);
        PlaceOrderDto dto = WmsCkMapping.INSTANCE.toPlaceOrderDeo(
                ext,
                products,
                main.getSerialNo()
        );
        //添加进数据集合
        log.info("merchantWms placeOrder Dto:{}", JSONObject.toJSONString(dto));
        if (null != ext.getSaleChannel() && ext.getSaleChannel().getType() == SaleChannelTypeEnums.tiktok) {
            channel = ExpressChannel.Channel.DY_SF;
            placeOrderDtos.add(dto);
        } else if (null != ext.getSaleChannel() && ext.getSaleChannel().getType() == SaleChannelTypeEnums.ks) {
            channel = ExpressChannel.Channel.KS_SF;
            placeOrderDtos.add(dto);
        } else {
            channel = ExpressChannel.Channel.SF;
            if (Objects.equals(ext.getQualityWay(), SaleQualityWayEnums.BZJ.getValue())) {
                placeOrderDtos.add(dto);
            } else {

                //如果是现在质检生成两个面单 公司发给国检中心，国检中心发给客户
                PlaceOrderDto dto_1 = WmsCkMapping.INSTANCE.copy(dto);
                dto_1.setName("国检小葛");
                dto_1.setPhone("18001602507");
                dto_1.setProvince("上海市");
                dto_1.setCity("上海市");
                dto_1.setArea("闵行区");
                dto_1.setStreet("虹桥镇");
                dto_1.setAddress("吴中路1189号525室");
                placeOrderDtos.add(dto_1);

                PlaceOrderDto dto_2 = WmsCkMapping.INSTANCE.copy(dto);
                dto_2.setSpName("国检小葛");
                dto_2.setSpPhone("18001602507");
                dto_2.setSpProvince("上海市");
                dto_2.setSpCity("上海市");
                dto_2.setSpArea("闵行区");
                dto_2.setSpStreet("虹桥镇");
                dto_2.setSpAddress("吴中路1189号525室");
                dto_2.setBusinessNo(dto_2.getBusinessNo() + "_GJ");
                placeOrderDtos.add(dto_2);
            }

        }
        log.info("merchantWms mapping placeOrder Dtos:{}", JSONObject.toJSONString(placeOrderDtos));

        //step_3 判断是补打还是打单
        List<PlaceOrderResult> placeOrderResults;
        boolean firstPrint = StringUtils.isEmpty(main.getExpressNo());
        if (firstPrint) {
            HashMap<ExpressChannel.Channel, List<PlaceOrderDto>> dtoMap = new HashMap<>();
            dtoMap.put(channel, placeOrderDtos);
            placeOrderResults = placeOrderHandler.placeOrder(dtoMap);

            String expressNo = placeOrderResults.stream()
                    .filter(PlaceOrderResult::getSuccess)
                    .map(PlaceOrderResult::getExpressNumber)
                    .collect(Collectors.toList())
                    .stream()
                    .findFirst()
                    .orElse(null);
            if (null != expressNo) {
                main.setExpressNo(expressNo);
                repositoryFactory.getMerchantWmsRepository().submit(main);
            }
        } else {

            placeOrderResults = new ArrayList<>();
            for (PlaceOrderDto var : placeOrderDtos) {
                PlaceOrderResult item = new PlaceOrderResult();
                item.setChannel(channel);
                item.setDto(var);
                item.setBusinessNo(var.getBusinessNo());
                item.setExpressNumber(main.getExpressNo());
                item.setSuccess(true);
                placeOrderResults.add(item);
            }
        }

        //step_6 返回打单数据
        return placeOrderHandler.getPrintInfo(placeOrderResults);
    }
}

