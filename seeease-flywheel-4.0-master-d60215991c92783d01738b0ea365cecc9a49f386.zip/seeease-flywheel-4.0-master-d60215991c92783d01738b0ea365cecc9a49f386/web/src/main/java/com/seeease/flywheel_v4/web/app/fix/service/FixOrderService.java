package com.seeease.flywheel_v4.web.app.fix.service;

import com.seeease.flywheel_v4.web.app.fix.request.*;
import com.seeease.flywheel_v4.web.app.fix.result.FixOrderDetailResult;
import com.seeease.flywheel_v4.web.app.fix.result.FixOrderPageResult;
import com.seeease.flywheel_v4.web.app.fix.result.FixStatusCountResult;
import com.seeease.springframework.PageResult;

import java.util.List;

/**
 * @Description 维修单
 * @Date 2024-10-2 21:11
 * @Author by hk
 */
public interface FixOrderService {

    /**
     * 维修中心-维修单列表
     *
     * @param request 请求 * @return 列表结果
     */
    PageResult<FixOrderPageResult> page(FixOrderPageRequest request);

    /**
     * 维修中心-维修单-查询状态对应数量
     *
     * @param request 请求 * @return 列表结果
     */
    List<FixStatusCountResult> getStatusCount(FixOrderPageRequest request);

    /**
     * 分配 维修师
     *
     * @param request 请求
     * @return 结果
     */
    Boolean distribute(FixOrderDistributeRequest request);

    /**
     * 重新分配 维修师
     *
     * @param request 请求
     * @return 结果
     */
    Boolean reDistribute(FixOrderDistributeRequest request);

    /**
     * 取消 维修
     *
     * @param request 请求
     * @return 结果
     */
    Boolean cancel(FixOrderDetailRequest request);

    /**
     * 送外 维修
     *
     * @param request 请求
     * @return 结果
     */
    Boolean sendOut(FixOrderSendOutRequest request);

    /**
     * 维修完成
     *
     * @param request 请求
     * @return 结果
     */
    Boolean complete(FixOrderCompleteRequest request);

    /**
     * 回退
     *
     * @param request 请求
     * @return 结果
     */
    Boolean fallback(FixOrderDetailRequest request);

    /**
     * 跳过
     *
     * @param request 请求
     * @return 结果
     */
    Boolean jump(FixOrderJumpRequest request);

    /**
     * 维修师 扫码领用
     *
     * @param request 请求
     * @return 结果
     */
    Boolean masterUse(FixOrderMasterUseRequest request);

    /**
     * 详情
     *
     * @param request 请求
     * @return 返回
     */
    FixOrderDetailResult detail(FixOrderDetailRequest request);

    /**
     * 新增
     *
     * @param request 请求
     * @return 结果
     */
    Boolean save(FixOrderSaveRequest request);

    /**
     * 编辑
     *
     * @param request 请求
     * @return 结果
     */
    Boolean update(FixOrderSaveRequest request);

    /**
     * 删除
     *
     * @param request 请求
     * @return 结果
     */
    Boolean delete(FixOrderDetailRequest request);

    /**
     * 完成质检
     * @param request 完成质检
     * @return 结果
     */
    Boolean completeQuality(FixOrderDetailRequest request);
}
