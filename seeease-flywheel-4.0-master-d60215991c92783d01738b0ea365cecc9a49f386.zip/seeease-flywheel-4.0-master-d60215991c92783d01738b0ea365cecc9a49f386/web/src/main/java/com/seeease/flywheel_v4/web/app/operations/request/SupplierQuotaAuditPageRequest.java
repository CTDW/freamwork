package com.seeease.flywheel_v4.web.app.operations.request;

import com.seeease.springframework.PageRequest;
import lombok.Data;
import lombok.EqualsAndHashCode;


@EqualsAndHashCode(callSuper = true)
@Data
public class SupplierQuotaAuditPageRequest extends PageRequest {


    /**
     * 客户名称
     */
    private String supplierName;
    /**
     * 状态
     */
    private Integer state;
    /**
     * 来源id
     */
    private Integer originId;

}
