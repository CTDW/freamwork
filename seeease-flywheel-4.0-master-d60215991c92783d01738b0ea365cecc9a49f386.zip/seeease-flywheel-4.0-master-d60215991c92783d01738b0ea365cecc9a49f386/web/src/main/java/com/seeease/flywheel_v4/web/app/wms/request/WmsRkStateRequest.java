package com.seeease.flywheel_v4.web.app.wms.request;


import com.seeease.springframework.PageRequest;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.util.List;
import java.util.Set;

/**
 * @ Description   :
 * @ Author        :  西门 游
 * @ CreateDate    :  6/6/24
 * @ Version       :  1.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class WmsRkStateRequest extends PageRequest {

    /**
     * rk单id列表
     */
    @NotEmpty(message = "rk单id列表不能为空")
    private Set<Integer> idList;
    /**
     * 变更的节点状态
     */
    @NotNull(message = "变更的节点状态不能为空")
    private Integer nodeState;

    /**
     * 异常原因 当状态变为去维修或者质检不通过时必填
     */
    private String reason;


}
