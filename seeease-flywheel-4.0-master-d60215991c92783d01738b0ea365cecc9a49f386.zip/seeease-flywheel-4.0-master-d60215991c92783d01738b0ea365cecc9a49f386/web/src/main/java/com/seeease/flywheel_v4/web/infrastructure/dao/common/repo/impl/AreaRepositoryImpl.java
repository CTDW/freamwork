package com.seeease.flywheel_v4.web.infrastructure.dao.common.repo.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.seeease.flywheel_v4.web.infrastructure.dao.common.entity.Area;
import com.seeease.flywheel_v4.web.infrastructure.dao.common.mapper.AreaMapper;
import com.seeease.flywheel_v4.web.infrastructure.dao.common.repo.AreaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 7/25/24 12:03 下午
 **/
@Repository
public class AreaRepositoryImpl extends ServiceImpl<AreaMapper, Area> implements AreaRepository {
    @Override
    public List<Area> listByPid(Integer parentId) {
        LambdaQueryWrapper<Area> wq = Wrappers.<Area>lambdaQuery()
                .eq(Area::getParentId, parentId);
        return baseMapper.selectList(wq);
    }
}
