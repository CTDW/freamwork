package com.seeease.flywheel_v4.web.app.operations.request;

import com.seeease.springframework.PageRequest;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.validation.constraints.NotNull;


@EqualsAndHashCode(callSuper = true)
@Data
public class PricingDetailRequest extends PageRequest {
    /**
     * 定价管理id
     */
    @NotNull(message = "id不能为空")
    private Integer id;
}
