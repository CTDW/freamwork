package com.seeease.flywheel_v4.web.infrastructure.dao.sale.repo;


import com.seeease.flywheel_v4.web.infrastructure.dao.sale.entity.SaleOrderLine;
import com.seeease.goods.rpc.enums.SkuNodeStateEnums;

import java.math.BigDecimal;
import java.util.List;
import java.util.Set;

/**
 *
 * @author 西门 游
 * @version 1.0
 * @since 5/31/24 4:55 下午
 **/
public interface SaleOrderLineRepository {

    /**
     * 提交
     * @param list
     */
    void submitBatch(List<SaleOrderLine> list);

    /**
     * 查询
     * @param saleId
     * @return
     */
    List<SaleOrderLine> listByMainId(Integer saleId);

    /**
     * 查询
     * @param skuIdList
     * @return
     */
    List<SaleOrderLine> listBySkuIds(Set<Integer> skuIdList);

    /**
     * 查找
     * @param id
     * @return
     */
    SaleOrderLine findById(Integer id);

    /**
     * 查找
     * @param saleId
     * @param skuIdList
     * @return
     */
    List<SaleOrderLine> listBySaleIdAndSkuIds(Integer saleId, Set<Integer> skuIdList);

    /**
     * 查询
     * @param ids
     * @return
     */
    List<SaleOrderLine> listByIds(Set<Integer> ids);




    /**
     * 提交
     * @param line
     * @return
     */
    Boolean submit(SaleOrderLine line);

    /**
     * 查找最新的数据
     * @param skuIdList
     * @param states
     * @return
     */
    List<SaleOrderLine> findLatest(Set<Integer> skuIdList,  List<SkuNodeStateEnums> states);

    /**
     * 查找
     * @param belongId
     * @return
     */
    List<SaleOrderLine> listByStoreId(Integer belongId);

    /**
     * 查找
     * @param saleOrderIds
     * @return
     */
    List<SaleOrderLine> listByMainIds(Set<Integer> saleOrderIds);

    /**
     * 统计寄售货值
     * @param supplierId
     * @return
     */
    BigDecimal claSaleConsignmentPrice(Integer supplierId);
}
