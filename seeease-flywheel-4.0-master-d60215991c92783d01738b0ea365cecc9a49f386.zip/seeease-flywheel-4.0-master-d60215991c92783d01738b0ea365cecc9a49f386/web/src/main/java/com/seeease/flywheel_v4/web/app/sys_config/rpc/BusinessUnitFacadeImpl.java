package com.seeease.flywheel_v4.web.app.sys_config.rpc;

import com.seeease.flywheel_v4.client.result.BusinessUnitRpcResult;
import com.seeease.flywheel_v4.client.rpc.BusinessUnitFacade;
import com.seeease.flywheel_v4.web.domain.sys_config.mapping.BusinessUnitMapping;
import com.seeease.flywheel_v4.web.infrastructure.dao.RepositoryFactory;
import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.entity.SysBusinessUnit;
import com.seeease.springframework.utils.MultiUtils;
import org.apache.dubbo.config.annotation.DubboService;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.List;
import java.util.Set;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/15/24 3:28 下午
 **/
@DubboService(version = "1.0.0")
public class BusinessUnitFacadeImpl implements BusinessUnitFacade {
    @Resource
    private RepositoryFactory repositoryFactory;

    @Override
    public BusinessUnitRpcResult findById(Integer id) {
        SysBusinessUnit ret = repositoryFactory.getBusinessUnitRepository().findById(id);
        return BusinessUnitMapping.INSTANCE.toRpcResult(ret);
    }

    @Override
    public List<BusinessUnitRpcResult> listByType(Integer type) {
        if (null == type){
            return Collections.emptyList();
        }
        List<SysBusinessUnit> ret = repositoryFactory.getBusinessUnitRepository().list(type);
        return MultiUtils.toList(ret,BusinessUnitMapping.INSTANCE::toRpcResult);
    }

    @Override
    public List<BusinessUnitRpcResult> listByIds(Set<Integer> ids) {
        List<SysBusinessUnit> ret = repositoryFactory.getBusinessUnitRepository().listByIds(ids);
        return MultiUtils.toList(ret,BusinessUnitMapping.INSTANCE::toRpcResult);
    }
}
