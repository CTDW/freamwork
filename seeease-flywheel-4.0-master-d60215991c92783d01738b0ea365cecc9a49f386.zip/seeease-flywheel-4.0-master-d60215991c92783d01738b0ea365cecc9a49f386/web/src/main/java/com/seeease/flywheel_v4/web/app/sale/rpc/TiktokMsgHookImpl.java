package com.seeease.flywheel_v4.web.app.sale.rpc;

import com.alibaba.fastjson.JSONObject;
import com.doudian.open.api.afterSale_Detail.AfterSaleDetailRequest;
import com.doudian.open.api.afterSale_Detail.data.AfterSaleDetailData;
import com.doudian.open.api.afterSale_Detail.param.AfterSaleDetailParam;
import com.doudian.open.api.afterSale_rejectReasonCodeList.AfterSaleRejectReasonCodeListRequest;
import com.doudian.open.api.afterSale_rejectReasonCodeList.AfterSaleRejectReasonCodeListResponse;
import com.doudian.open.api.afterSale_rejectReasonCodeList.data.ItemsItem;
import com.doudian.open.api.afterSale_rejectReasonCodeList.param.AfterSaleRejectReasonCodeListParam;
import com.doudian.open.api.btas_getInspectionOrder.BtasGetInspectionOrderRequest;
import com.doudian.open.api.btas_getInspectionOrder.BtasGetInspectionOrderResponse;
import com.doudian.open.api.btas_getInspectionOrder.data.ProductOrdersItem;
import com.doudian.open.api.btas_getInspectionOrder.param.BtasGetInspectionOrderParam;
import com.doudian.open.api.order_orderDetail.OrderOrderDetailRequest;
import com.doudian.open.api.order_orderDetail.OrderOrderDetailResponse;
import com.doudian.open.api.order_orderDetail.data.PostAddr;
import com.doudian.open.api.order_orderDetail.data.ShopOrderDetail;
import com.doudian.open.api.order_orderDetail.data.SkuOrderListItem;
import com.doudian.open.api.order_orderDetail.param.OrderOrderDetailParam;
import com.doudian.open.core.AccessToken;
import com.doudian.open.core.DoudianOpResponse;
import com.seeease.flywheel_v4.web.app.sale.request.SaleOrderCancelRequest;
import com.seeease.flywheel_v4.web.app.sale.request.SaleReturnOrderCancelRequest;
import com.seeease.flywheel_v4.web.app.sale.request.ToCSaleReturnOrderCreateRequest;
import com.seeease.flywheel_v4.web.app.sale.service.SaleOrderService;
import com.seeease.flywheel_v4.web.app.sale.service.SaleReturnOrderService;
import com.seeease.flywheel_v4.web.domain.sale.mapping.ThirdSaleOrderLineMapping;
import com.seeease.flywheel_v4.web.domain.sale.mapping.ThirdSaleOrderMapping;
import com.seeease.flywheel_v4.web.infrastructure.dao.RepositoryFactory;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.entity.*;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.entity.obj.BuyerInfoObj;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.enums.SaleQualityWayEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.enums.SaleStateEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.enums.ThirdSaleStateEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.entity.SysSaleChannel;
import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.enums.SaleChannelTypeEnums;
import com.seeease.frameworktiktok.api.TikTokShopApi;
import com.seeease.goods.rpc.SpuFacade;
import com.seeease.goods.rpc.request.SpuRpcRequest;
import com.seeease.goods.rpc.result.SpuRpcResult;
import com.seeease.outsideapi.facade.rpc.TiktokMsgHook;
import com.seeease.outsideapi.facade.rpc.request.TikTokMessageRequest;
import com.seeease.outsideapi.facade.rpc.result.TiktokRefundCreatedResult;
import com.seeease.outsideapi.facade.rpc.result.TiktokTradeAddressChangedResult;
import com.seeease.outsideapi.facade.rpc.result.TiktokTradeCancelResult;
import com.seeease.outsideapi.facade.rpc.result.TiktokTradePaidResult;
import com.seeease.springframework.context.LoginStore;
import com.seeease.springframework.context.LoginUser;
import com.seeease.springframework.context.UserContext;
import com.seeease.springframework.utils.BigDecimalUtil;
import com.seeease.springframework.utils.MultiUtils;
import com.seeease.springframework.utils.StringUtils;
import io.seata.spring.annotation.GlobalTransactional;
import lombok.extern.slf4j.Slf4j;
import org.apache.dubbo.config.annotation.DubboReference;
import org.apache.dubbo.config.annotation.DubboService;

import javax.annotation.Resource;
import java.util.*;
import java.util.stream.Collectors;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 8/26/24 4:34 下午
 **/
@DubboService(group = "fl4", version = "1.0.0")
@Slf4j
public class TiktokMsgHookImpl implements TiktokMsgHook {

    @Resource
    private TikTokShopApi tikTokShopApi;
    @Resource
    private RepositoryFactory repositoryFactory;
    @Resource
    private SaleOrderService saleOrderService;
    @Resource
    private SaleReturnOrderService saleReturnOrderService;

    @DubboReference(version = "1.0.0", check = false)
    private SpuFacade spuFacade;


    @GlobalTransactional
    @Override
    public void hook(TikTokMessageRequest request) {
        log.info("收到了抖音订单回调信息:{}", JSONObject.toJSONString(request));

        //过滤系统中存在的销售渠道
        String jsonStr = request.getData();
        JSONObject json = JSONObject.parseObject(jsonStr);
        SysSaleChannel sc = repositoryFactory.getSaleChannelRepository().findByKeyAndType(
                json.getString("shop_id"),
                SaleChannelTypeEnums.tiktok
        );
        if (null == sc) {
            return;
        }

        switch (request.getTag()) {
            case "101":
                doCreate(JSONObject.parseObject(jsonStr, TiktokTradePaidResult.class), sc.getId());
                break;
            case "105":
                doAddressChanged(JSONObject.parseObject(jsonStr, TiktokTradeAddressChangedResult.class));
                break;
            case "106":
                doSaleCancel(JSONObject.parseObject(jsonStr, TiktokTradeCancelResult.class));
                break;
            case "200":
                doReturnCreate(JSONObject.parseObject(jsonStr, TiktokRefundCreatedResult.class));
                break;
            case "202":
                doReturnOrderAddExpress(JSONObject.parseObject(jsonStr, TiktokRefundCreatedResult.class));
                break;
            case "207":
                doReturnCancel(JSONObject.parseObject(jsonStr, TiktokRefundCreatedResult.class));
                break;

        }
    }


    /**
     * 销售取消
     *
     * @param result
     */
    private void doSaleCancel(TiktokTradeCancelResult result) {


        String orderId = result.getP_id().toString();
        ThirdSaleOrder thirdSaleOrder = repositoryFactory.getThirdSaleOrderRepository().findByOrderId(orderId);

        if (null != thirdSaleOrder) {

            if (thirdSaleOrder.getState() != ThirdSaleStateEnums.CANCEL){
                thirdSaleOrder.setState(ThirdSaleStateEnums.CANCEL);
                repositoryFactory.getThirdSaleOrderRepository().submit(thirdSaleOrder);
            }
            if (null != thirdSaleOrder.getMergedId()) {
                SaleOrder saleOrder = repositoryFactory.getSaleOrderRepository().findByMergedId(thirdSaleOrder.getMergedId());


                if (null != saleOrder && saleOrder.getState() != SaleStateEnums.CANCEL) {

                    List<SaleReturnOrderLine> returnLineList = repositoryFactory.getSaleReturnOrderLineRepository()
                            .listBySaleIds(Collections.singleton(saleOrder.getId()));

                    if (returnLineList.isEmpty() && saleOrder.getState() != SaleStateEnums.OVER){
                        //取消销售单
                        SaleOrderCancelRequest request = new SaleOrderCancelRequest();
                        request.setId(saleOrder.getId());
                        saleOrderService.tocCancel(request);
                    }
                }
            }

        }
    }


    /**
     * 抖音支付成功
     *
     * @param result
     */
    private void doCreate(TiktokTradePaidResult result, Integer scId) {
        //stpe_1 获取token
        AccessToken accessToken = tikTokShopApi.getAccessToken(result.getShop_id());
        //step_2 获取订单信息
        OrderOrderDetailRequest request = new OrderOrderDetailRequest();
        OrderOrderDetailParam param = request.getParam();
        param.setShopOrderId(result.getP_id().toString());
        OrderOrderDetailResponse response = request.execute(accessToken);
        ShopOrderDetail tiktokOrder = response.getData().getShopOrderDetail();
        log.info("抖音订单信息{}", JSONObject.toJSONString(response));

        String orderId = tiktokOrder.getOrderId();
        ThirdSaleOrder thirdOrder = repositoryFactory.getThirdSaleOrderRepository()
                .findByOrderId(orderId);
        if (null != thirdOrder) {
            return;
        }

        //step_3 创建三方订单
        //构造客户数据
        BuyerInfoObj buyer = ThirdSaleOrderMapping.INSTANCE.toTiktokBuyer(
                orderId,
                tiktokOrder.getEncryptPostTel(),
                tiktokOrder.getEncryptPostReceiver(),
                tiktokOrder.getPostAddr(),
                accessToken
        );


        //查询质检方式
        BtasGetInspectionOrderRequest inspRequest = new BtasGetInspectionOrderRequest();
        BtasGetInspectionOrderParam inspParam = inspRequest.getParam();
        inspParam.setOrderId(orderId);
        BtasGetInspectionOrderResponse inspResp = inspRequest.execute(accessToken);

        log.info("抖音质检方式查询结果:{}", JSONObject.toJSONString(inspResp.getData()));

        SaleQualityWayEnums qualityWay = SaleQualityWayEnums.BZJ;
        String qualityCode = null;
        if (!inspResp.getData().getProductOrders().isEmpty()) {
            qualityWay = inspResp.getData().getProductOrders()
                    .stream()
                    .findFirst()
                    .map(item -> item.getProductOrderDetails()
                            .stream()
                            .findFirst()
                            .map(item1 -> item1.getInspectionType() == 1 ? SaleQualityWayEnums.XX_ZJ : SaleQualityWayEnums.XS_ZJ)
                            .orElse(SaleQualityWayEnums.BZJ)
                    )
                    .orElse(SaleQualityWayEnums.BZJ);


            qualityCode = inspResp.getData()
                    .getProductOrders()
                    .stream()
                    .map(ProductOrdersItem::getOrderCode)
                    .flatMap(Collection::stream)
                    .filter(StringUtils::isNotEmpty)
                    .collect(Collectors.joining(","));
        }


        ThirdSaleOrder order = ThirdSaleOrderMapping.INSTANCE.toEntity(
                qualityWay,
                buyer,
                1,
                BigDecimalUtil.centToYuan(tiktokOrder.getPayAmount().toString()),
                scId,
                tiktokOrder,
                qualityCode
        );

        order.setTiktokSid(result.getS_ids());

        repositoryFactory.getThirdSaleOrderRepository().submit(order);

        //step_4 新增三方单行
        //spu查询
        Map<String, SpuRpcResult> spuMap = new HashMap<>();
        SpuRpcRequest spuRequest = new SpuRpcRequest();
        Set<String> spuCodes = MultiUtils.toSet(tiktokOrder.getSkuOrderList(), SkuOrderListItem::getCode);
        if (StringUtils.isNotEmpty(spuCodes)) {
            spuRequest.setSpuCodes(spuCodes);
            spuMap = MultiUtils.toMap(
                    spuFacade.list(spuRequest),
                    SpuRpcResult::getSpuCode
            );
        }


        List<ThirdSaleOrderLine> lineList = new ArrayList<>();
        for (SkuOrderListItem item : tiktokOrder.getSkuOrderList()) {
            SpuRpcResult spu = spuMap.get(item.getCode());


            for (int i = 0; i < item.getItemNum(); i++) {

                ThirdSaleOrderLine line = ThirdSaleOrderLineMapping.INSTANCE.toEntity(
                        item,
                        BigDecimalUtil.centToYuan(item.getPayAmount().toString()),
                        null == spu ? null : spu.getId(),
                        orderId,
                        1
                );
                lineList.add(line);
            }
        }

        repositoryFactory.getThirdSaleOrderLineRepository().submitBatch(lineList);

    }

    /**
     * 修改销售地址
     *
     * @param result
     */
    private void doAddressChanged(TiktokTradeAddressChangedResult result) {


        ThirdSaleOrder order = repositoryFactory.getThirdSaleOrderRepository()
                .findByOrderId(result.getP_id().toString());
        if (null == order) {
            return;
        }

        //step_1 因为可能会合单所以 通过合单id查找同时修改所有单据收货人数据
        List<ThirdSaleOrder> orders = repositoryFactory.getThirdSaleOrderRepository()
                .listByMergeId(order.getMergeId());

        PostAddr postAddr = JSONObject.parseObject(result.getReceiver_msg().getAddr(), PostAddr.class);
        AccessToken accessToken = tikTokShopApi.getAccessToken(result.getShop_id());
        BuyerInfoObj buyer = ThirdSaleOrderMapping.INSTANCE.toTiktokBuyer(
                result.getP_id().toString(),
                result.getReceiver_msg().getEncrypt_tel(),
                result.getReceiver_msg().getEncrypt_name(),
                postAddr,
                accessToken
        );

        for (ThirdSaleOrder o : orders
        ) {
            o.setBuyerTel(buyer.getTel());
            o.setBuyerName(buyer.getRec());
            o.setBuyerInfo(buyer);
        }
        repositoryFactory.getThirdSaleOrderRepository().submitBatch(orders);
    }


    /**
     * 创建销售退货单
     *
     * @param result
     */
    private void doReturnCreate(TiktokRefundCreatedResult result) {

        //step_1 判断三方订单是否合并过 如果合并过则不取消
        ThirdSaleOrder thirdOrder = repositoryFactory.getThirdSaleOrderRepository()
                .findByOrderId(result.getP_id().toString());
        if (null == thirdOrder){
            return;
        }
        List<ThirdSaleOrder> mergedList = repositoryFactory.getThirdSaleOrderRepository()
                .listByMergedIds(Collections.singleton(thirdOrder.getMergedId()));
        if (mergedList.size() > 1) {
            return;
        }
        //取消三方订单
        thirdOrder.setState(ThirdSaleStateEnums.CANCEL);
        repositoryFactory.getThirdSaleOrderRepository().submit(thirdOrder);

        // step_2 需要判断业务系统销售单是否完成，如果完成了就创建退货单据 否则就取消销售单
        if (result.getAftersale_type() == 0L || result.getAftersale_type() == 2L) {

            SaleOrder order = repositoryFactory.getSaleOrderRepository().findByMergedId(thirdOrder.getMergedId());


            if (null == order || order.getState() == SaleStateEnums.CANCEL){
                return;
            }

            if (order.getState() != SaleStateEnums.OVER ) {
                //取消销售单
                SaleOrderCancelRequest request = new SaleOrderCancelRequest();
                request.setId(order.getId());
                saleOrderService.tocCancel(request);
                return;
            }


            //获取退货备注
            AfterSaleRejectReasonCodeListRequest request = new AfterSaleRejectReasonCodeListRequest();
            AfterSaleRejectReasonCodeListParam param = request.getParam();
            param.setAftersaleId(result.getAftersale_id());
            AccessToken accessToken = tikTokShopApi.getAccessToken(result.getShop_id());
            AfterSaleRejectReasonCodeListResponse response = request.execute(accessToken);

            String remark = response.getData()
                    .getItems()
                    .stream()
                    .map(ItemsItem::getReason)
                    .collect(Collectors.joining(","));

            //创建退货单
            ToCSaleReturnOrderCreateRequest returnRequest = new ToCSaleReturnOrderCreateRequest();
            returnRequest.setSaleId(order.getId());
            returnRequest.setRemark(remark);

            List<SaleOrderLine> saleLine = repositoryFactory.getSaleOrderLineRepository().listByMainId(order.getId());
            List<ToCSaleReturnOrderCreateRequest.Sku> skuList = MultiUtils.toList(
                    saleLine,
                    line -> {
                        ToCSaleReturnOrderCreateRequest.Sku sku = new ToCSaleReturnOrderCreateRequest.Sku();
                        sku.setSkuId(line.getSkuId());
                        sku.setLineId(line.getId());
                        sku.setReturnAmount(line.getDealPrice());
                        sku.setCount(line.getCount());
                        return sku;
                    }
            );
            LoginUser user = new LoginUser();
            user.setId(order.getCreatedId());
            user.setUserName(order.getCreatedBy());
            LoginStore store = new LoginStore();
            store.setId(order.getBuId());
            user.setStore(store);
            UserContext.setUser(user);

            returnRequest.setThirdReturnId(result.getAftersale_id().toString());
            returnRequest.setSkuList(skuList);
            saleReturnOrderService.tocReturnCreate(returnRequest);

        }
    }

    /**
     * 销售退货单上传快递单号
     *
     * @param result
     */
    private void doReturnOrderAddExpress(TiktokRefundCreatedResult result) {
        //step_1 获取快递单号
        AccessToken accessToken = tikTokShopApi.getAccessToken(result.getShop_id());
        DoudianOpResponse<AfterSaleDetailData> response = new DoudianOpResponse<>();
        AfterSaleDetailRequest request = new AfterSaleDetailRequest();
        AfterSaleDetailParam param = request.getParam();
        param.setAfterSaleId(result.getAftersale_id().toString());
        param.setNeedOperationRecord(true);
        response = request.execute(accessToken);

        String expressNo = response.getData()
                .getProcessInfo()
                .getLogisticsInfo()
                .get_return()
                .getTrackingNo();


        //step_2 退货单据上补充单号
        SaleReturnOrder returnOrder = repositoryFactory.getSaleReturnOrderRepository()
                .findByThirdReturnId(result.getAftersale_id().toString());
        if (null == returnOrder) {
            return;
        }
        returnOrder.setExpressNo(expressNo);
        repositoryFactory.getSaleReturnOrderRepository().submit(returnOrder);

    }

    /**
     * 销售退货单取消
     *
     * @param result
     */
    private void doReturnCancel(TiktokRefundCreatedResult result) {


        SaleReturnOrder returnOrder = repositoryFactory.getSaleReturnOrderRepository()
                .findByThirdReturnId(result.getAftersale_id().toString());
        if (null == returnOrder) {
            return;
        }
        SaleReturnOrderCancelRequest req = new SaleReturnOrderCancelRequest();
        req.setId(returnOrder.getId());
        saleReturnOrderService.tocReturnCancel(req);
    }

}
