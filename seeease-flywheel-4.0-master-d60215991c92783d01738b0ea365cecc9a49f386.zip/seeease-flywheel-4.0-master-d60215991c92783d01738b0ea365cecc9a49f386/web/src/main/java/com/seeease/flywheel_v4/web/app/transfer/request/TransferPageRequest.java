package com.seeease.flywheel_v4.web.app.transfer.request;


import com.fasterxml.jackson.annotation.JsonFormat;
import com.seeease.springframework.PageRequest;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Date;
import java.util.Set;

/**
 * @author 西门 游
 * @version 1.0
 * @since 6/3/24 11:26 上午
 **/
@EqualsAndHashCode(callSuper = true)
@Data
public class TransferPageRequest extends PageRequest {
    /**
     * ids
     */
    private Set<Integer> ids;
    /**
     * 调拨单号
     */
    private String serialNo;
    /**
     * 调拨类型
     */
    private Integer type;
    /**
     * 调拨状态
     */
    private Integer state;
    /**
     * 调出方
     */
    private Integer fromId;
    /**
     * 调入方
     */
    private Integer toId;
    /**
     * sku编码
     */
    private String skuCode;
    /**
     * 商品名称
     */
    private String goodsName;
    /**
     * 货号
     */
    private String goodsCode;
    /**
     * 创建人
     */
    private String createdBy;
    /**
     * 开始时间
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date startTime;
    /**
     * 结束时间
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date endTime;
    /**
     * 当前操作人业务部门id 用于权限控制
     */
    private Integer buId;


}
