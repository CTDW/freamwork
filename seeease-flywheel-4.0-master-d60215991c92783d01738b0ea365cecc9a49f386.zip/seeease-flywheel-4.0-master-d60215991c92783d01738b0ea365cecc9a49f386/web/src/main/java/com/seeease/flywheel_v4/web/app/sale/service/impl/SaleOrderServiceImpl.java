package com.seeease.flywheel_v4.web.app.sale.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.google.common.collect.Sets;
import com.seeease.flywheel_v4.client.enums.BusinessUnitTypeEnums;
import com.seeease.flywheel_v4.web.app.purchase.service.PurchaseOrderService;
import com.seeease.flywheel_v4.web.app.sale.request.*;
import com.seeease.flywheel_v4.web.app.sale.result.ToBSaleOrderDetailResult;
import com.seeease.flywheel_v4.web.app.sale.result.ToBSaleOrderPageResult;
import com.seeease.flywheel_v4.web.app.sale.result.ToCSaleOrderDetailResult;
import com.seeease.flywheel_v4.web.app.sale.result.ToCSaleOrderPageResult;
import com.seeease.flywheel_v4.web.app.sale.service.SaleOrderService;
import com.seeease.flywheel_v4.web.domain.purchase.mapping.PurchaseOrderMapping;
import com.seeease.flywheel_v4.web.domain.sale.mapping.SaleOrderLineMapping;
import com.seeease.flywheel_v4.web.domain.sale.mapping.SaleOrderMapping;
import com.seeease.flywheel_v4.web.domain.wms.observer.base.WmsSubject;
import com.seeease.flywheel_v4.web.infrastructure.dao.RepositoryFactory;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.*;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.enums.SupplierQuotaAuditTypeEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.enums.SupplierQuotaLogTypeEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.entity.SaleOrder;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.entity.SaleOrderLine;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.entity.ThirdSaleOrder;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.entity.obj.BuyBackPolicyObj;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.enums.SaleModelEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.enums.SaleStateEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.enums.SaleTypeEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.entity.SysBusinessUnit;
import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.entity.SysSaleChannel;
import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.entity.SysUser;
import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.entity.obj.MerchantBusinessUnitExtObj;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.MerchantWms;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.MerchantWmsLine;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.WmsCk;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.obj.ContactInfo;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.MerchantWmsModelEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.MerchantWmsTypeEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.WmsCkTypeEnums;
import com.seeease.flywheel_v4.web.infrastructure.listener.SaleOrderStateListener;
import com.seeease.flywheel_v4.web.util.SerialNoGenerator;
import com.seeease.goods.rpc.SkuFacade;
import com.seeease.goods.rpc.enums.SkuNodeStateEnums;
import com.seeease.goods.rpc.enums.SkuStateEnums;
import com.seeease.goods.rpc.request.SaleSkuCreateRpcRequest;
import com.seeease.goods.rpc.request.SaleSkuFinishRpcRequest;
import com.seeease.goods.rpc.request.SkuRpcRequest;
import com.seeease.goods.rpc.result.SkuCreateRpcResult;
import com.seeease.goods.rpc.result.SkuRpcResult;
import com.seeease.seeeaseframework.mybatis.domain.WhetherEnum;
import com.seeease.seeeaseframework.mybatis.utils.EnumUtils;
import com.seeease.springframework.PageResult;
import com.seeease.springframework.context.UserContext;
import com.seeease.springframework.exception.ValidationUtil;
import com.seeease.springframework.utils.MultiUtils;
import com.seeease.springframework.utils.StringUtils;
import io.seata.spring.annotation.GlobalTransactional;
import org.apache.dubbo.config.annotation.DubboReference;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.*;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 8/2/24 2:05 下午
 **/
@Service
public class SaleOrderServiceImpl implements SaleOrderService {

    @Resource
    private RepositoryFactory repositoryFactory;

    @Resource
    private PurchaseOrderService purchaseOrderService;

    @DubboReference(version = "1.0.0", check = false)
    private SkuFacade skuFacade;


    @Resource
    private SaleOrderStateListener stateListener;

    @Resource
    private WmsSubject wmsSubject;


    /**
     * 销售订单创建
     *
     * @param request
     * @param storeId 发货仓库id
     * @return
     */
    private Integer saleOrderCreate(SaleOrderCreateRequest request,
                                    Integer storeId,
                                    ContactInfo buyer) {


        //step_1 判断需要推送的仓库
        SysBusinessUnit store = repositoryFactory.getBusinessUnitRepository().findById(storeId);
        Integer doboId = null;
        if (store.getExt() != null){
            MerchantBusinessUnitExtObj ext = JSONObject.parseObject(
                    JSONObject.toJSONString(store.getExt()),
                    MerchantBusinessUnitExtObj.class
            );
            if (ext.getDobId() != null) {
                storeId = ext.getDobId();
                doboId = storeId;
            }
        }
        SysBusinessUnit newStore = repositoryFactory.getBusinessUnitRepository().findById(storeId);
        boolean pushToStore = newStore.getType() == BusinessUnitTypeEnums.WAREHOUSE;



        //step_2 创建销售单
        Integer totalCount = 0;
        BigDecimal amount = BigDecimal.ZERO;

        for (SaleOrderCreateRequest.Sku sku : request.getSkuList()) {
            totalCount += sku.getSellCount();
            if (Objects.equals(request.getSellType(), SaleTypeEnums.JS.getValue())){
                amount = amount.add(sku.getConsignmentPrice().multiply(new BigDecimal(sku.getSellCount())));
            }else {
                amount = amount.add(sku.getDealPrice().multiply(new BigDecimal(sku.getSellCount())));
            }

        }


        String serialNo;
        if (Objects.equals(request.getModel(), SaleModelEnums.C.getValue())) {
            serialNo = SerialNoGenerator.generalSerial(SerialNoGenerator.Type.TO_C_XS);
        } else {
            serialNo = SerialNoGenerator.generalSerial(SerialNoGenerator.Type.TO_B_XS);
        }


        SaleOrder saleOrder = SaleOrderMapping.INSTANCE.toEntity(
                storeId,
                serialNo,
                UserContext.getUser().getStore().getId(),
                totalCount,
                amount,
                request
        );
        saleOrder.setState(SaleStateEnums.STARTING);
        saleOrder.setDoboId(doboId);
        repositoryFactory.getSaleOrderRepository().submit(saleOrder);

        //step_3 锁定sku
        //因为sku可能分裂所以为它加上一个uuid
        request.getSkuList().forEach(v -> v.setUuid(UUID.randomUUID().toString()));

        List<SaleSkuCreateRpcRequest.Sku> rpcSkuList = MultiUtils.toList(
                request.getSkuList(),
                SaleOrderMapping.INSTANCE::toSaleSkuCreateRpc
        );


        SaleSkuCreateRpcRequest rpcRequest = new SaleSkuCreateRpcRequest();
        rpcRequest.setSkuList(rpcSkuList);
        rpcRequest.setSerialNo(saleOrder.getSerialNo());
        List<SkuCreateRpcResult> rpcRet = skuFacade.create(rpcRequest);


        //step_4 创建销售单行
        SkuNodeStateEnums nodeState = pushToStore ? SkuNodeStateEnums.JD : SkuNodeStateEnums.DCK;
        Map<String, SaleOrderCreateRequest.Sku> paramSkuMap = MultiUtils.toMap(
                request.getSkuList(),
                SaleOrderCreateRequest.Sku::getUuid
        );
        List<SaleOrderLine> lineList = MultiUtils.toList(
                rpcRet,
                sku -> {

                    //sku 创建参数
                    SaleOrderCreateRequest.Sku paramSku = paramSkuMap.get(sku.getUuid());
                    //回购政策
                    List<BuyBackPolicyObj> policies = MultiUtils.toList(
                            sku.getPolicies(),
                            SaleOrderLineMapping.INSTANCE::toPolicy
                    );

                    return SaleOrderLineMapping.INSTANCE.toEntity(
                            sku,
                            paramSku,
                            nodeState,
                            policies,
                            saleOrder.getId()
                    );
                }
        );


        repositoryFactory.getSaleOrderLineRepository().submitBatch(lineList);


        //step_5 推入wms
        Integer finalStoreId = storeId;
        if (pushToStore) {
            List<WmsCk> ckList = MultiUtils.toList(
                    lineList,
                    line -> SaleOrderLineMapping.INSTANCE.toWmsCk(
                            saleOrder,
                            line,
                            SkuNodeStateEnums.JD,
                            WmsCkTypeEnums.XS_CK,
                            finalStoreId
                    )
            );
            wmsSubject.ckDataSubmit(ckList);
        } else {
            //构建wms
            MerchantWms wms = SaleOrderMapping.INSTANCE.toMerchantWms(
                    saleOrder,
                    MerchantWmsTypeEnums.XS_CK,
                    MerchantWmsModelEnums.CK,
                    totalCount,
                    amount,
                    buyer,
                    finalStoreId
            );

            List<MerchantWmsLine> wmsLines = MultiUtils.toList(
                    lineList,
                    line -> SaleOrderLineMapping.INSTANCE.toMerchantWmsLine(line, SkuNodeStateEnums.DCK)
            );
            wmsSubject.merchantWmsDataCreate(wms, wmsLines);
        }

        return saleOrder.getId();

    }


    @GlobalTransactional
    @Override
    public Integer tocCreate(SaleOrderCreateRequest request) {
        //stpe_1参数校验
        if (StringUtils.isEmpty(request.getThirdPartyNo())) {
            SupplierContacts buyer = repositoryFactory.getSupplierContactsRepository().findById(request.getBuyerId());
            ValidationUtil.notNull(buyer, "销售客户不存在");
        }


        //step_2合并相同sku的数量
        Map<Integer, SaleOrderCreateRequest.Sku> skuMap = new HashMap<>();
        for (SaleOrderCreateRequest.Sku paramSku : request.getSkuList()) {
            SaleOrderCreateRequest.Sku sku = skuMap.get(paramSku.getId());
            if (null == sku) {
                skuMap.put(paramSku.getId(), paramSku);
            } else {
                sku.setSellCount(sku.getSellCount() + paramSku.getSellCount());
                skuMap.put(sku.getId(), sku);
            }
        }

        request.setSkuList(new ArrayList<>(skuMap.values()));

        Set<Integer> skuIdList = MultiUtils.toSet(request.getSkuList(), SaleOrderCreateRequest.Sku::getId);
        SkuRpcRequest rpcRequest = new SkuRpcRequest();
        rpcRequest.setIdList(skuIdList);
        rpcRequest.setState(SkuStateEnums.SALEABLE);
        List<SkuRpcResult> skuRpcList = skuFacade.list(rpcRequest);

        //step_3 数据校验
        for (SkuRpcResult sku : skuRpcList){
            SaleOrderCreateRequest.Sku paramSku = skuMap.get(sku.getId());

            if (!Objects.equals(request.getSellType(), SaleTypeEnums.ZP.getValue())){
                if (sku.getBreakSell() == WhetherEnum.NO){
                    String fineness = sku.getSkuParams()
                            .stream()
                            .filter(param -> param.getParamName().equals("成色"))
                            .map(param -> param.getParamValue().stream().findFirst().orElse(""))
                            .findFirst()
                            .orElse("");

                    if (fineness.equals("SA级/98新") || fineness.equals("S级/99新")){
                        ValidationUtil.isTrue(
                                paramSku.getDealPrice().compareTo(sku.getTocPrice()) > -1,
                                "99新 98新 不能低于了零售价"
                        );
                    }

                    if (fineness.equals("AB级/90新") || fineness.equals("A级/95新")){
                        ValidationUtil.isTrue(
                                paramSku.getDealPrice().compareTo(sku.getNewSettlePrice()) > -1,
                                "95新 90新不能低于最新结算价"
                        );
                    }
                }else {
                    ValidationUtil.isTrue(
                            paramSku.getDealPrice().compareTo(sku.getSettlePrice()) > -1,
                            "不能低于结算价售卖"
                    );
                }
            }

        }
        ValidationUtil.isTrue(skuRpcList.size() == request.getSkuList().size(), "存在错误的sku数据");

        Map<Integer, List<SkuRpcResult>> skuStoreMap = skuRpcList.stream()
                .collect(Collectors.groupingBy(SkuRpcResult::getStoreId));
        ValidationUtil.isTrue(skuStoreMap.size() == 1, "不同仓库的sku不能同时间销售");
        Integer storeId = skuRpcList.get(0).getStoreId();


        //构建出库单联系人
        ContactInfo buyer;
        if (null != request.getBuyerId()) {
            SupplierContacts contact = repositoryFactory.getSupplierContactsRepository().findById(request.getBuyerId());
            Supplier supplier = repositoryFactory.getSupplierRepository().findById(contact.getSupplierId());
            buyer = PurchaseOrderMapping.INSTANCE.toMerchantWmsContactInfo(supplier);
        } else { //三方订单去三方订单里面找
            ThirdSaleOrder thirdSaleOrder = repositoryFactory.getThirdSaleOrderRepository().findByOrderId(request.getThirdPartyNo());
            buyer = new ContactInfo();
            buyer.setAddress(thirdSaleOrder.getBuyerInfo().getCompleteAddress());
            buyer.setName(thirdSaleOrder.getBuyerName());
            buyer.setPhone(thirdSaleOrder.getBuyerTel());
        }


        //step_2 创建订单
        request.setModel(SaleModelEnums.C.getValue());
        return saleOrderCreate(request, storeId, buyer);
    }


    @Override
    public PageResult<ToCSaleOrderPageResult> tocPage(ToCSaleOrderPageRequest request) {
        //sku查询
        Set<Integer> orderIdList = null;
        if (StringUtils.isNotEmpty(request.getSkuCode())) {
            SkuRpcRequest rpcRequest = new SkuRpcRequest();
            rpcRequest.setSkuCode(request.getSkuCode());
            Set<Integer> skuIdList = MultiUtils.toSet(skuFacade.list(rpcRequest), SkuRpcResult::getId);

            if (StringUtils.isEmpty(skuIdList)) {
                return PageResult.buildEmpty();
            }

            orderIdList = MultiUtils.toSet(
                    repositoryFactory.getSaleOrderLineRepository().listBySkuIds(skuIdList),
                    SaleOrderLine::getSaleId
            );

            if (StringUtils.isEmpty(orderIdList)) {
                return PageResult.buildEmpty();
            }

        }

        //客户查询
        List<SupplierContacts> buyerList = null;
        Set<Integer> buyerIdList = null;
        if (StringUtils.isNotEmpty(request.getBuyerName())) {
            buyerList = repositoryFactory.getSupplierContactsRepository()
                    .listByNameAndPhone(request.getBuyerName(), null);

            buyerIdList = MultiUtils.toSet(
                    buyerList,
                    SupplierContacts::getId
            );
            if (StringUtils.isEmpty(buyerIdList)) {
                return PageResult.buildEmpty();
            }
        }

        //商品所在查询
        if (null != request.getBelongId()) {
            List<SaleOrderLine> saleOrderLines = repositoryFactory.getSaleOrderLineRepository()
                    .listByStoreId(request.getBelongId());
            if (saleOrderLines.isEmpty()) {
                return PageResult.buildEmpty();
            }

            Set<Integer> partOrderIds = MultiUtils.toSet(saleOrderLines, SaleOrderLine::getSaleId);
            if (orderIdList == null) {
                orderIdList = partOrderIds;
            } else {
                orderIdList.addAll(partOrderIds);
            }
        }


        //主表查询
        Integer buId = UserContext.getUser().getStore().getId();
        SysBusinessUnit bu = repositoryFactory.getBusinessUnitRepository().findById(buId);
        if (bu.getType() != BusinessUnitTypeEnums.PLATFORM) {
            request.setBuId(UserContext.getUser().getStore().getId());
        }
        Page<SaleOrder> page = repositoryFactory.getSaleOrderRepository()
                .pageForC(request, orderIdList, buyerIdList);

        if (StringUtils.isEmpty(page.getRecords())) {
            return PageResult.buildEmpty();
        }


        //联系人
        if (StringUtils.isEmpty(buyerList)) {
            buyerIdList = MultiUtils.toSet(page.getRecords(), SaleOrder::getBuyerId);
            buyerList = repositoryFactory.getSupplierContactsRepository().listByIds(buyerIdList);
        }

        Map<Integer, String> buyerMap = MultiUtils.toMap(
                buyerList,
                SupplierContacts::getId,
                SupplierContacts::getName
        );


        //三方订单联系人
        Set<String> thirdPartNos = MultiUtils.toSet(page.getRecords(), SaleOrder::getThirdPartyNo);
        Map<String, String> thirdBuyerMap = MultiUtils.toMap(
                repositoryFactory.getThirdSaleOrderRepository().listByOrderIds(thirdPartNos),
                ThirdSaleOrder::getOrderId,
                ThirdSaleOrder::getBuyerName
        );


        //渠道名称
        Set<Integer> scIdList = MultiUtils.toSet(page.getRecords(), SaleOrder::getScId);
        Map<Integer, String> scMap = MultiUtils.toMap(
                repositoryFactory.getSaleChannelRepository().listByIds(scIdList),
                SysSaleChannel::getId,
                SysSaleChannel::getName
        );


        //订单来源
        Set<Integer> originIds = MultiUtils.toSet(page.getRecords(), SaleOrder::getBuId);
        Map<Integer, SysBusinessUnit> originMap = MultiUtils.toMap(
                repositoryFactory.getBusinessUnitRepository().listByIds(originIds),
                SysBusinessUnit::getId
        );


        //第一第二第三销售人
        Set<Integer> sellerIds = new HashSet<>();
        for (SaleOrder o : page.getRecords()){
            if (null != o.getSellerAId()){
                sellerIds.add(o.getSellerAId());
            }
            if (null != o.getSellerBId()){
                sellerIds.add(o.getSellerBId());
            }
            if (null != o.getSellerCId()){
                sellerIds.add(o.getSellerCId());
            }
        }
        Map<Integer, String> sellerMap = MultiUtils.toMap(
                repositoryFactory.getUserRepository().listByIds(sellerIds),
                SysUser::getId,
                SysUser::getName
        );


        //组合
        List<ToCSaleOrderPageResult> ret = MultiUtils.toList(
                page.getRecords(),
                saleOrder -> {
                    String buyerName;

                    if (null != saleOrder.getBuyerId()) {
                        buyerName = buyerMap.get(saleOrder.getBuyerId());
                    } else {
                        buyerName = thirdBuyerMap.get(saleOrder.getThirdPartyNo());
                    }

                    String scName = null;
                    if (null != saleOrder.getScId()) {
                        scName = scMap.get(saleOrder.getScId());
                    }

                    SysBusinessUnit origin = originMap.get(saleOrder.getBuId());


                    String sellerA = sellerMap.get(saleOrder.getSellerAId());
                    String sellerB = sellerMap.get(saleOrder.getSellerBId());
                    String sellerC = sellerMap.get(saleOrder.getSellerCId());


                    return SaleOrderMapping.INSTANCE.tocPageResult(
                            saleOrder,
                            buyerName,
                            scName,
                            origin,
                            sellerA,
                            sellerB,
                            sellerC
                    );
                }
        );


        return PageResult.<ToCSaleOrderPageResult>builder()
                .result(ret)
                .totalCount(page.getTotal())
                .totalPage(page.getPages())
                .build();
    }


    @Override
    public ToCSaleOrderDetailResult tocDetail(ToCSaleOrderDetailRequest request) {
        SaleOrder saleOrder = repositoryFactory.getSaleOrderRepository()
                .findByIdOrSerialNo(request.getId(), request.getSerialNo());
        ValidationUtil.notNull(saleOrder, "销售订单不存在");

        //客户
        String buyerName, buyerPhone, buyerAddress;
        if (null == saleOrder.getBuyerId()) {
            ThirdSaleOrder thirdOrder = repositoryFactory.getThirdSaleOrderRepository().findByOrderId(saleOrder.getThirdPartyNo());
            buyerName = thirdOrder.getBuyerName();
            buyerPhone = thirdOrder.getBuyerTel();
            buyerAddress = thirdOrder.getBuyerInfo().getCompleteAddress();
        } else {
            SupplierContacts buyer = repositoryFactory.getSupplierContactsRepository().findById(saleOrder.getBuyerId());
            Supplier supplier = repositoryFactory.getSupplierRepository().findById(buyer.getSupplierId());
            buyerName = buyer.getName();
            buyerPhone = buyer.getPhone();
            buyerAddress = supplier.getCompleteAddress();
        }


        //订单来源
        SysBusinessUnit origin = repositoryFactory.getBusinessUnitRepository().findById(saleOrder.getBuId());
        //销售行
        List<SaleOrderLine> lineList = repositoryFactory.getSaleOrderLineRepository().listByMainId(saleOrder.getId());
        //第一 第二 第三销售员
        HashSet<Integer> sellerIdList = Sets.newHashSet(
                saleOrder.getSellerAId(),
                saleOrder.getSellerBId(),
                saleOrder.getSellerCId()
        );
        Map<Integer, String> orderSellerMap = MultiUtils.toMap(
                repositoryFactory.getUserRepository().listByIds(sellerIdList),
                SysUser::getId,
                SysUser::getName
        );

        //sku
        Set<Integer> skuIdList = MultiUtils.toSet(lineList, SaleOrderLine::getSkuId);
        SkuRpcRequest rpcRequest = new SkuRpcRequest();
        rpcRequest.setIdList(skuIdList);
        List<SkuRpcResult> rpcSkuList = skuFacade.list(rpcRequest);
        Map<Integer, SkuRpcResult> skuMap = MultiUtils.toMap(
                rpcSkuList,
                SkuRpcResult::getId
        );

        //经营权
        Set<Integer> sellIdList = MultiUtils.toSet(lineList, SaleOrderLine::getSellerId);
        Map<Integer, String> sellerMap = MultiUtils.toMap(
                repositoryFactory.getBusinessUnitRepository().listByIds(sellIdList),
                SysBusinessUnit::getId,
                SysBusinessUnit::getName
        );

        //商品所在
        Set<Integer> belongIdList = MultiUtils.toSet(lineList, SaleOrderLine::getStoreId);
        Map<Integer, String> belongMap = MultiUtils.toMap(
                repositoryFactory.getBusinessUnitRepository().listByIds(belongIdList),
                SysBusinessUnit::getId,
                SysBusinessUnit::getName
        );


        List<ToCSaleOrderDetailResult.Sku> skuList = MultiUtils.toList(
                lineList,
                line -> {
                    SkuRpcResult sku = skuMap.get(line.getSkuId());
                    String sellerName = sellerMap.get(line.getSellerId());
                    String belongName = belongMap.get(line.getStoreId());
                    return SaleOrderLineMapping.INSTANCE.tocDetailResult(line, sku, sellerName, belongName);
                }
        );


        //组合数据
        return SaleOrderMapping.INSTANCE.toCDetailResult(
                buyerName,
                buyerPhone,
                buyerAddress,
                origin.getName(),
                skuList,
                saleOrder,
                orderSellerMap.get(saleOrder.getSellerAId()),
                null == saleOrder.getSellerBId() ? null : orderSellerMap.get(saleOrder.getSellerBId()),
                null == saleOrder.getSellerCId() ? null : orderSellerMap.get(saleOrder.getSellerCId())
        );
    }

    @GlobalTransactional
    @Override
    public Boolean tobCreate(SaleOrderCreateRequest request) {
        //step_1 参数校验
        //联系人校验
        SupplierContacts contact = repositoryFactory.getSupplierContactsRepository().findById(request.getBuyerId());
        ValidationUtil.notNull(contact, "销售客户不存在");

        Supplier supplier = repositoryFactory.getSupplierRepository().findById(contact.getSupplierId());
        ContactInfo buyer = PurchaseOrderMapping.INSTANCE.toMerchantWmsContactInfo(supplier);


        //余额校验
        SaleTypeEnums saleType = EnumUtils.of(SaleTypeEnums.class, request.getSellType());
        if (saleType != SaleTypeEnums.FD) {
            SupplierContacts contacts = repositoryFactory.getSupplierContactsRepository().findById(request.getBuyerId());
            SupplierQuota quota = repositoryFactory.getSupplierQuotaRepository().findBySupplierId(contacts.getSupplierId());
            ValidationUtil.notNull(quota, "余额不足请充值");

            BigDecimal totalPrice = request.getSkuList().stream()
                    .map(SaleOrderCreateRequest.Sku::getDealPrice)
                    .reduce(BigDecimal::add)
                    .orElse(BigDecimal.ZERO);

            SupplierQuotaDetail detail = repositoryFactory.getSupplierQuotaDetailRepository().findOne(
                    quota.getId(),
                    UserContext.getUser().getId(),
                    saleType == SaleTypeEnums.JS ? SupplierQuotaAuditTypeEnums.JS : SupplierQuotaAuditTypeEnums.NORMAL
            );

            ValidationUtil.notNull(detail, "余额不足请充值");
            ValidationUtil.isTrue(
                    detail.getAmount().compareTo(totalPrice) >= 0,
                    "余额不足请充值"
            );

            //扣减金额
            detail.setAmount(detail.getAmount().subtract(totalPrice));
            repositoryFactory.getSupplierQuotaDetailRepository().submit(detail);

            SupplierQuotaLog log = new SupplierQuotaLog();
            if (saleType == SaleTypeEnums.JS) {
                quota.setJsQuota(quota.getJsQuota().subtract(totalPrice));
                log.setAmountType(SupplierQuotaAuditTypeEnums.JS);
            } else if (saleType == SaleTypeEnums.ZC) {
                quota.setNormalQuota(quota.getNormalQuota().subtract(totalPrice));
                log.setAmountType(SupplierQuotaAuditTypeEnums.NORMAL);
            }
            repositoryFactory.getSupplierQuotaRepository().submit(quota);

            //扣除金额 并保存日志
            log.setQuotaId(quota.getId());
            log.setAmount(totalPrice);
            log.setType(SupplierQuotaLogTypeEnums.SPENT);
            repositoryFactory.getSupplierQuotaLogRepository().submit(log);

        }

        //step_2 根据不同仓库进行拆单
        String mainSerialNo = SerialNoGenerator.generalSerial(SerialNoGenerator.Type.TO_B_XS);
        request.setMainSerialNo(mainSerialNo);
        request.setModel(SaleModelEnums.B.getValue());
        //sku查询
        Set<Integer> skuIdList = MultiUtils.toSet(request.getSkuList(), SaleOrderCreateRequest.Sku::getId);
        SkuRpcRequest rpcRequest = new SkuRpcRequest();
        rpcRequest.setIdList(skuIdList);
        List<SkuRpcResult> skuRpcList = skuFacade.list(rpcRequest);
        //根据仓库id分组
        Map<Integer, SaleOrderCreateRequest.Sku> paramSkuMap = MultiUtils.toMap(
                request.getSkuList(),
                SaleOrderCreateRequest.Sku::getId
        );

        Map<Integer, List<SaleOrderCreateRequest.Sku>> groupSkus = new HashMap<>();
        for (SkuRpcResult sku : skuRpcList) {
            SaleOrderCreateRequest.Sku paramSku = paramSkuMap.get(sku.getId());
            //非寄售情况 不允许低于b价售卖
            if (Objects.equals(request.getSellType(), SaleTypeEnums.JS.getValue())){
                ValidationUtil.isTrue(
                        paramSku.getDealPrice().compareTo(sku.getTobPrice()) > -1,
                        "不允许低于b价售卖"
                );
            }
            if (groupSkus.containsKey(sku.getStoreId())) {
                List<SaleOrderCreateRequest.Sku> group = groupSkus.get(sku.getStoreId());
                group.add(paramSku);
            } else {
                List<SaleOrderCreateRequest.Sku> item = new ArrayList<>();
                item.add(paramSku);
                groupSkus.put(sku.getStoreId(), item);
            }
        }
        //循环创建销售单
        for (Map.Entry<Integer, List<SaleOrderCreateRequest.Sku>> entry : groupSkus.entrySet()) {
            List<SaleOrderCreateRequest.Sku> skuList = entry.getValue();
            //寄售类型的需要转换一下价格
            if (Objects.equals(request.getSellType(), SaleTypeEnums.JS.getValue())) {
                skuList.forEach(sku -> {
                    sku.setConsignmentPrice(sku.getDealPrice());
                    sku.setDealPrice(BigDecimal.ZERO);
                });
            }
            request.setSkuList(skuList);
            //构建出库单联系人

            saleOrderCreate(request, entry.getKey(), buyer);
        }


        return true;
    }

    @Override
    public PageResult<ToBSaleOrderPageResult> tobPage(ToBSaleOrderPageRequest request) {
        //sku查询
        Set<Integer> orderIdList = null;
        if (StringUtils.isNotEmpty(request.getSkuCode())) {
            SkuRpcRequest rpcRequest = new SkuRpcRequest();
            rpcRequest.setSkuCode(request.getSkuCode());
            Set<Integer> skuIdList = MultiUtils.toSet(skuFacade.list(rpcRequest), SkuRpcResult::getId);

            if (StringUtils.isEmpty(skuIdList)) {
                return PageResult.buildEmpty();
            }

            orderIdList = MultiUtils.toSet(
                    repositoryFactory.getSaleOrderLineRepository().listBySkuIds(skuIdList),
                    SaleOrderLine::getSaleId
            );

            if (StringUtils.isEmpty(orderIdList)) {
                return PageResult.buildEmpty();
            }

        }

        //客户查询
        List<SupplierContacts> buyerList = null;
        Set<Integer> buyerIdList = null;
        if (StringUtils.isNotEmpty(request.getBuyerName())) {
            buyerList = repositoryFactory.getSupplierContactsRepository()
                    .listByNameAndPhone(request.getBuyerName(), null);

            buyerIdList = MultiUtils.toSet(
                    buyerList,
                    SupplierContacts::getId
            );
            if (StringUtils.isEmpty(buyerIdList)) {
                return PageResult.buildEmpty();
            }
        }

        //商品所在查询
        if (null != request.getBelongId()) {
            List<SaleOrderLine> saleOrderLines = repositoryFactory.getSaleOrderLineRepository()
                    .listByStoreId(request.getBelongId());
            if (saleOrderLines.isEmpty()) {
                return PageResult.buildEmpty();
            }

            Set<Integer> partOrderIds = MultiUtils.toSet(saleOrderLines, SaleOrderLine::getSaleId);
            if (orderIdList == null) {
                orderIdList = partOrderIds;
            } else {
                orderIdList.addAll(partOrderIds);
            }
        }


        //主表查询
        Integer buId = UserContext.getUser().getStore().getId();
        SysBusinessUnit bu = repositoryFactory.getBusinessUnitRepository().findById(buId);
        if (bu.getType() != BusinessUnitTypeEnums.PLATFORM) {
            request.setBuId(UserContext.getUser().getStore().getId());
        }
        Page<SaleOrder> page = repositoryFactory.getSaleOrderRepository()
                .pageForB(request, orderIdList, buyerIdList);

        if (StringUtils.isEmpty(page.getRecords())) {
            return PageResult.buildEmpty();
        }


        //联系人
        if (StringUtils.isEmpty(buyerList)) {
            buyerIdList = MultiUtils.toSet(page.getRecords(), SaleOrder::getBuyerId);
            buyerList = repositoryFactory.getSupplierContactsRepository().listByIds(buyerIdList);
        }

        Map<Integer, String> buyerMap = MultiUtils.toMap(
                buyerList,
                SupplierContacts::getId,
                SupplierContacts::getName
        );

        //商品所在
        Set<Integer> belongIds = MultiUtils.toSet(page.getRecords(), SaleOrder::getStoreId);
        Map<Integer, String> belongMap = MultiUtils.toMap(
                repositoryFactory.getBusinessUnitRepository().listByIds(belongIds),
                SysBusinessUnit::getId,
                SysBusinessUnit::getName
        );

        //第一第二第三销售人
        Set<Integer> sellerIds = new HashSet<>();
        for (SaleOrder o : page.getRecords()){
            if (null != o.getSellerAId()){
                sellerIds.add(o.getSellerAId());
            }
            if (null != o.getSellerBId()){
                sellerIds.add(o.getSellerBId());
            }
            if (null != o.getSellerCId()){
                sellerIds.add(o.getSellerCId());
            }
        }
        Map<Integer, String> sellerMap = MultiUtils.toMap(
                repositoryFactory.getUserRepository().listByIds(sellerIds),
                SysUser::getId,
                SysUser::getName
        );



        //组合
        List<ToBSaleOrderPageResult> ret = MultiUtils.toList(
                page.getRecords(),
                saleOrder -> {
                    String buyerName = buyerMap.get(saleOrder.getBuyerId());
                    String belongName = belongMap.get(saleOrder.getStoreId());
                    String sellerA = sellerMap.get(saleOrder.getSellerAId());
                    String sellerB = sellerMap.get(saleOrder.getSellerBId());
                    String sellerC = sellerMap.get(saleOrder.getSellerCId());

                    return SaleOrderMapping.INSTANCE.tobPageResult(
                            saleOrder,
                            buyerName,
                            belongName,
                            sellerA,
                            sellerB,
                            sellerC
                    );
                }
        );


        return PageResult.<ToBSaleOrderPageResult>builder()
                .result(ret)
                .totalCount(page.getTotal())
                .totalPage(page.getPages())
                .build();
    }


    @Override
    public ToBSaleOrderDetailResult tobDetail(ToBSaleOrderDetailRequest request) {

        SaleOrder saleOrder = repositoryFactory.getSaleOrderRepository()
                .findByIdOrSerialNo(request.getId(), request.getSerialNo());
        ValidationUtil.notNull(saleOrder, "销售订单不存在");

        //客户
        SupplierContacts buyer = repositoryFactory.getSupplierContactsRepository().findById(saleOrder.getBuyerId());
        Supplier supplier = repositoryFactory.getSupplierRepository().findById(buyer.getSupplierId());
        String buyerName = buyer.getName();
        String buyerPhone = buyer.getPhone();
        String buyerAddress = supplier.getCompleteAddress();

        //订单来源
        SysBusinessUnit origin = repositoryFactory.getBusinessUnitRepository().findById(saleOrder.getBuId());
        //销售行
        List<SaleOrderLine> lineList = repositoryFactory.getSaleOrderLineRepository().listByMainId(saleOrder.getId());
        //第一 第二 第三销售员
        HashSet<Integer> sellerIdList = Sets.newHashSet(
                saleOrder.getSellerAId(),
                saleOrder.getSellerBId(),
                saleOrder.getSellerCId()
        );
        Map<Integer, String> orderSellerMap = MultiUtils.toMap(
                repositoryFactory.getUserRepository().listByIds(sellerIdList),
                SysUser::getId,
                SysUser::getName
        );



        //sku
        Set<Integer> skuIdList = MultiUtils.toSet(lineList, SaleOrderLine::getSkuId);
        SkuRpcRequest rpcRequest = new SkuRpcRequest();
        rpcRequest.setIdList(skuIdList);
        List<SkuRpcResult> rpcSkuList = skuFacade.list(rpcRequest);
        Map<Integer, SkuRpcResult> skuMap = MultiUtils.toMap(
                rpcSkuList,
                SkuRpcResult::getId
        );

        //经营权
        Set<Integer> sellIdList = MultiUtils.toSet(lineList, SaleOrderLine::getSellerId);
        Map<Integer, String> sellerMap = MultiUtils.toMap(
                repositoryFactory.getBusinessUnitRepository().listByIds(sellIdList),
                SysBusinessUnit::getId,
                SysBusinessUnit::getName
        );

        //商品所在
        Set<Integer> belongIdList = MultiUtils.toSet(lineList, SaleOrderLine::getStoreId);
        Map<Integer, String> belongMap = MultiUtils.toMap(
                repositoryFactory.getBusinessUnitRepository().listByIds(belongIdList),
                SysBusinessUnit::getId,
                SysBusinessUnit::getName
        );

        //组合sku

        AtomicReference<BigDecimal> totalProfit = new AtomicReference<>(BigDecimal.ZERO);
        List<ToBSaleOrderDetailResult.Sku> skuList = MultiUtils.toList(
                lineList,
                line -> {
                    SkuRpcResult sku = skuMap.get(line.getSkuId());
                    //利润等于最新结算价 - 结算价 / 数量
                    BigDecimal profit = (sku.getNewSettlePrice().subtract(sku.getSettlePrice()))
                            .multiply(new BigDecimal(line.getCount()));
                    totalProfit.set(totalProfit.get().add(profit));

                    String sellerName = sellerMap.get(line.getSellerId());
                    String belongName = belongMap.get(line.getStoreId());
                    return SaleOrderLineMapping.INSTANCE.tobDetailResult(
                            line,
                            sku,
                            sellerName,
                            belongName,
                            profit
                    );
                }
        );


        //组合数据
        return SaleOrderMapping.INSTANCE.tobDetailResult(
                totalProfit.get(),
                buyerName,
                buyerPhone,
                buyerAddress,
                origin.getName(),
                skuList,
                saleOrder,
                orderSellerMap.get(saleOrder.getSellerAId()),
                null == saleOrder.getSellerBId() ? null : orderSellerMap.get(saleOrder.getSellerBId()),
                null == saleOrder.getSellerCId() ? null : orderSellerMap.get(saleOrder.getSellerCId())
        );


    }


    @Override
    public Boolean policyUpdate(ToCSaleOrderLineBuyBackPolicyUpdateRequest request) {
        SaleOrderLine line = repositoryFactory.getSaleOrderLineRepository()
                .findById(request.getLineId());
        ValidationUtil.notNull(line, "lineId错误");

        line.setPolicies(request.getPolicies());
        repositoryFactory.getSaleOrderLineRepository().submitBatch(Collections.singletonList(line));

        return true;
    }


    /**
     * 销售订单取消
     *
     * @param request
     * @return
     */
    private Boolean cancel(SaleOrderCancelRequest request) {
        SaleOrder saleOrder = repositoryFactory.getSaleOrderRepository().findByIdOrSerialNo(
                request.getId(), null
        );
        ValidationUtil.notNull(saleOrder, "销售单id错误");

        List<SaleOrderLine> lineList = repositoryFactory.getSaleOrderLineRepository()
                .listByMainId(saleOrder.getId());

        //step_1 过滤状态不符合的数据 非终结状态行均可取消 (三方订单不需要过滤)
        if (StringUtils.isEmpty(saleOrder.getMergedId())) {
            lineList = lineList.stream()
                    .filter(line -> line.getEndState() == WhetherEnum.NO)
                    .collect(Collectors.toList());
        }

        ValidationUtil.isTrue(StringUtils.isNotEmpty(lineList), "无可取消的商品");


        //step_2 调用wms 状态变化
        SysBusinessUnit bu = repositoryFactory.getBusinessUnitRepository().findById(saleOrder.getStoreId());
        boolean pushToStore = bu.getType() == BusinessUnitTypeEnums.WAREHOUSE;
        Set<Integer> skuIdList = MultiUtils.toSet(lineList, SaleOrderLine::getSkuId);
        if (pushToStore) {
            wmsSubject.cancelWmsCk(
                    saleOrder.getSerialNo(),
                    skuIdList,
                    StringUtils.isNotEmpty(saleOrder.getMergedId())
            );
        } else {
            wmsSubject.cancelMerchantWms(
                    saleOrder.getSerialNo(),
                    skuIdList,
                    SkuNodeStateEnums.DCK,
                    StringUtils.isNotEmpty(saleOrder.getMergedId())
            );
        }


        return true;
    }


    @GlobalTransactional
    @Override
    public Boolean tocCancel(SaleOrderCancelRequest request) {
        return cancel(request);
    }

    @GlobalTransactional
    @Override
    public Boolean tobCancel(SaleOrderCancelRequest request) {
        return cancel(request);
    }

    @GlobalTransactional
    @Override
    public Boolean consignmentConfirm(ToBSaleConsignmentConfirmRequest request) {
        //step_1 修改状态 以及补充成交价
        SaleOrderLine line = repositoryFactory.getSaleOrderLineRepository().findById(request.getLineId());
        Date now = new Date();
        line.setFinishTime(now);
        line.setDealPrice(request.getDealPrice());
        line.setNodeState(SkuNodeStateEnums.YCK);
        line.setEndState(WhetherEnum.YES);
        line.setSettledBy(UserContext.getUser().getUserName());


        ValidationUtil.isTrue(
                repositoryFactory.getSaleOrderLineRepository().submit(line),
                "更新销售单行失败"
        );

        //step_3 尝试变动状态
        SaleOrder saleOrder = repositoryFactory.getSaleOrderRepository()
                .findByIdOrSerialNo(line.getSaleId(), null);
        stateListener.onEvent(new SaleOrderStateListener.Event(this, saleOrder.getId()));


        //step_4 调用sku修改状态
        SaleSkuFinishRpcRequest rpcRequest = new SaleSkuFinishRpcRequest();
        SaleSkuFinishRpcRequest.Sku sku = SaleOrderLineMapping.INSTANCE.toFinishRequest(line);
        rpcRequest.setBuyerId(saleOrder.getBuyerId());
        rpcRequest.setSkuList(Collections.singletonList(sku));
        rpcRequest.setSerialNo(saleOrder.getSerialNo());
        skuFacade.finish(rpcRequest);


        //step_5 增加同行保证金

        BigDecimal totalAmount = (line.getConsignmentPrice().subtract(line.getDealPrice()))
                .multiply(new BigDecimal(line.getCount()));


        SupplierContacts contact = repositoryFactory.getSupplierContactsRepository().findById(saleOrder.getBuyerId());
        SupplierQuota quota = repositoryFactory.getSupplierQuotaRepository()
                .findBySupplierId(contact.getSupplierId());

        quota.setJsQuota(quota.getJsQuota().add(totalAmount));

        repositoryFactory.getSupplierQuotaRepository().submit(quota);

        SupplierQuotaDetail detail = repositoryFactory.getSupplierQuotaDetailRepository().findOne(
                quota.getId(),
                saleOrder.getCreatedId(),
                SupplierQuotaAuditTypeEnums.JS
        );
        detail.setAmount(detail.getAmount().add(totalAmount));
        repositoryFactory.getSupplierQuotaDetailRepository().submit(detail);

        //记录日志
        SupplierQuotaLog log = new SupplierQuotaLog();
        log.setAmountType(SupplierQuotaAuditTypeEnums.JS);
        log.setType(SupplierQuotaLogTypeEnums.CANCEL);
        log.setAmount(totalAmount);
        log.setQuotaId(quota.getId());
        repositoryFactory.getSupplierQuotaLogRepository().submit(log);

        return true;
    }


}
