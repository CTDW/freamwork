package com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.obj.PricingLifeCycleObj;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.enums.PricingStateEnums;

import com.seeease.goods.rpc.enums.SkuRunTypeEnums;
import com.seeease.goods.rpc.enums.SkuSellWayEnums;
import com.seeease.seeeaseframework.mybatis.domain.BaseDomain;
import com.seeease.seeeaseframework.mybatis.transitionstate.ITransitionStateEnum;
import com.seeease.seeeaseframework.mybatis.transitionstate.TransitionState;
import com.seeease.seeeaseframework.mybatis.transitionstate.TransitionStateEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;
import java.util.List;

/**
 * 定价管理
 */
@EqualsAndHashCode(callSuper = true)
@TableName(value = "v4_ops_pricing", autoResultMap = true)
@Data
public class Pricing extends BaseDomain implements TransitionStateEntity {
    @TableId(type = IdType.AUTO)
    private Integer id;

    /**
     * skuId
     */
    private Integer skuId;

    @TransitionState
    private PricingStateEnums state;
    /**
     * 采购单id
     */
    private Integer purchaseId;

    /**
     * 同行价
     */
    private BigDecimal tobPrice;
    /**
     * 零售价
     */
    private BigDecimal tocPrice;
    /**
     * 结算价
     */
    private BigDecimal settlePrice;
    /**
     * 收货价
     */
    private BigDecimal receiptPrice;

    /**
     * 销售渠道定位
     */
    private SkuSellWayEnums sellWay;
    /**
     * 自主经营类型
     */
    private SkuRunTypeEnums runType;

    /**
     * 审核人id
     */
    private Integer reviewerId;
    /**
     * 商家id
     */
    private Integer merchantId;

    /**
     * 附件
     */
    @TableField(typeHandler = PricingLifeCycleObj.Handler.class)
    private List<PricingLifeCycleObj> lifeCycle;


    @TableField(exist = false)
    private ITransitionStateEnum transitionStateEnum;
}