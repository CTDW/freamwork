package com.seeease.flywheel_v4.web.app.excel.request;


import com.alibaba.excel.annotation.ExcelProperty;
import lombok.Data;

import java.math.BigDecimal;



@Data
public class PurchaseWatchImportRequest  {

    @ExcelProperty(value = "货号")
    private String goodsCode;

    @ExcelProperty(value = "唯一码")
    private String skuCode;

    @ExcelProperty(value = "采购价")
    private BigDecimal purchasePrice;

    @ExcelProperty(value = "成色")
    private String fineness;

    @ExcelProperty(value = "表带类型")
    private String strapType;

    @ExcelProperty(value = "盒子")
    private String box;

    @ExcelProperty(value = "无附件")
    private String noAnnexe;

    @ExcelProperty(value = "说明书")
    private String manual;

    @ExcelProperty(value = "补充备注")
    private String fillRemark;

    @ExcelProperty(value = "发票")
    private String bill;

    @ExcelProperty(value = "保卡")
    private String card;

    @ExcelProperty(value = "空白保卡")
    private String blankCard;
}
