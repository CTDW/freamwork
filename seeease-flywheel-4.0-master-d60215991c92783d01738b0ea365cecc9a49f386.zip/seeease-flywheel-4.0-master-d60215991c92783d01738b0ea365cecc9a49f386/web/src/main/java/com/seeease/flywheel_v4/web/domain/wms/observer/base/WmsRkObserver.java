package com.seeease.flywheel_v4.web.domain.wms.observer.base;

import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.WmsRk;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.WmsRkTypeEnums;

/**
 * <p
 * wms入库事件变动观察者
 * </p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/21/24 2:46 下午
 **/
public interface WmsRkObserver extends WmsObserver<WmsRkTypeEnums, WmsRk> {


}
