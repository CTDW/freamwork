package com.seeease.flywheel_v4.web.domain.excel.strategy.export;

import com.alibaba.cola.extension.Extension;
import com.seeease.flywheel_v4.web.app.excel.result.WmsRkExportResult;
import com.seeease.flywheel_v4.web.app.wms.request.WmsRkPageRequest;
import com.seeease.flywheel_v4.web.app.wms.result.WmsRkPageResult;
import com.seeease.flywheel_v4.web.app.wms.service.WmsRkService;
import com.seeease.flywheel_v4.web.domain.excel.ExcelDomain;
import com.seeease.flywheel_v4.web.domain.excel.core.ExportExtPtl;
import com.seeease.flywheel_v4.web.domain.wms.mapping.WmsRkMapping;
import com.seeease.flywheel_v4.web.infrastructure.dao.RepositoryFactory;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.WmsRkTypeEnums;
import com.seeease.goods.rpc.SkuFacade;
import com.seeease.goods.rpc.enums.SkuNodeStateEnums;
import com.seeease.seeeaseframework.mybatis.utils.EnumUtils;
import com.seeease.springframework.utils.MultiUtils;
import org.apache.dubbo.config.annotation.DubboReference;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.List;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 9/12/24 10:42 上午
 **/
@Service
@Extension(bizId = "export", useCase = "wmsRk")
public class WmsRkExport implements ExportExtPtl<WmsRkPageRequest, WmsRkExportResult> {

    @Resource
    private RepositoryFactory repositoryFactory;

    @DubboReference(version = "1.0.0",check = false)
    private SkuFacade skuFacade;

    @Resource
    private WmsRkService wmsRkService;

    @Resource
    private ExcelDomain excelDomain;


    @Override
    public Class<WmsRkPageRequest> getRequestClass() {
        return WmsRkPageRequest.class;
    }

    @Override
    public Class<WmsRkExportResult> getResultClass() {
        return WmsRkExportResult.class;
    }

    @Override
    public String getFileName() {
        return "wms入库导出";
    }

    @Override
    public List<WmsRkExportResult> handle(WmsRkPageRequest wmsRkPageRequest) {
        //step_1 调用wmsRK分页接口
        wmsRkPageRequest.setLimit(Integer.MAX_VALUE);
        List<WmsRkPageResult> list = wmsRkService.page(wmsRkPageRequest).getResult();
        if (list.isEmpty()){
            return Collections.emptyList();
        }

        //step_2 参数转化
        return MultiUtils.toList(
                list,
                item ->{
                    String type = EnumUtils.of(WmsRkTypeEnums.class,item.getType()).getDesc();
                    String nodeState = EnumUtils.of(SkuNodeStateEnums.class,item.getNodeState()).getDesc();
                    String annexe = excelDomain.joinAnnexe(item.getAnnexe());
                    String params = excelDomain.joinParam(item.getSkuParams());

                    return WmsRkMapping.INSTANCE.toExportResult(
                            item,
                            type,
                            nodeState,
                            annexe,
                            params
                    );
                }
        );
    }
}
