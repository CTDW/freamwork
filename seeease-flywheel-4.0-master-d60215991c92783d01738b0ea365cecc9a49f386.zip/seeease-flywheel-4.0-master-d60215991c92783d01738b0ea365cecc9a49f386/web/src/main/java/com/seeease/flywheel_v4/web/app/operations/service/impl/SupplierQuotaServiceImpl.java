package com.seeease.flywheel_v4.web.app.operations.service.impl;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.seeease.flywheel_v4.web.app.operations.request.SupplierQuotaDetailRequest;
import com.seeease.flywheel_v4.web.app.operations.request.SupplierQuotaPageRequest;
import com.seeease.flywheel_v4.web.app.operations.request.SupplierQuotaRequest;
import com.seeease.flywheel_v4.web.app.operations.request.SupplierQuotaReturnRequest;
import com.seeease.flywheel_v4.web.app.operations.result.SupplierQuotaDetailResult;
import com.seeease.flywheel_v4.web.app.operations.result.SupplierQuotaPageResult;
import com.seeease.flywheel_v4.web.app.operations.result.SupplierQuotaResult;
import com.seeease.flywheel_v4.web.app.operations.service.SupplierQuotaService;
import com.seeease.flywheel_v4.web.domain.operations.mapping.SupplierQuotaMapping;
import com.seeease.flywheel_v4.web.infrastructure.dao.RepositoryFactory;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.*;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.enums.SupplierQuotaAuditTypeEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.enums.SupplierQuotaLogTypeEnums;
import com.seeease.goods.rpc.SkuFacade;
import com.seeease.springframework.PageResult;
import com.seeease.springframework.exception.ValidationUtil;
import com.seeease.springframework.utils.MultiUtils;
import com.seeease.springframework.utils.StringUtils;
import org.apache.dubbo.config.annotation.DubboReference;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * <p>供应商</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/4/24 4:43 下午
 **/
@Service
public class SupplierQuotaServiceImpl implements SupplierQuotaService {
    @Resource
    private RepositoryFactory repositoryFactory;

    @DubboReference(version = "1.0.0", check = false)
    private SkuFacade skuFacade;


    @Override
    public PageResult<SupplierQuotaPageResult> page(SupplierQuotaPageRequest request) {
        //供应商查询
        Set<Integer> supplierIds = null;
        if (StringUtils.isNotEmpty(request.getSupplierName())) {
            List<Supplier> suppliers = repositoryFactory.getSupplierRepository().listByName(request.getSupplierName());
            if (StringUtils.isEmpty(suppliers)) {
                return PageResult.buildEmpty();
            }
            supplierIds = MultiUtils.toSet(suppliers, Supplier::getId);
        }

        //主表查询
        Page<SupplierQuota> page = repositoryFactory.getSupplierQuotaRepository().page(supplierIds, request);
        if (StringUtils.isEmpty(page.getRecords())) {
            return PageResult.buildEmpty();
        }

        //供应商
        if (supplierIds == null) {
            supplierIds = MultiUtils.toSet(page.getRecords(), SupplierQuota::getSupplierId);
        }
        Map<Integer, String> supplerMap = MultiUtils.toMap(
                repositoryFactory.getSupplierRepository().listByIds(supplierIds),
                Supplier::getId,
                Supplier::getName
        );


        //组合
        List<SupplierQuotaPageResult> ret = MultiUtils.toList(
                page.getRecords(),
                item -> {
                    //寄售货值查询
                    BigDecimal consignmentAmount = repositoryFactory.getSaleOrderLineRepository().claSaleConsignmentPrice(item.getSupplierId());
                    String supplierName = supplerMap.get(item.getSupplierId());
                    return SupplierQuotaMapping.INSTANCE.toPageResult(item, supplierName, consignmentAmount);
                }
        );


        return PageResult.<SupplierQuotaPageResult>builder()
                .result(ret)
                .totalCount(page.getTotal())
                .totalPage(page.getPages())
                .build();
    }

    @Override
    public SupplierQuotaDetailResult detail(SupplierQuotaDetailRequest request) {
        SupplierQuota quota = repositoryFactory.getSupplierQuotaRepository().findById(request.getId());
        ValidationUtil.notNull(quota, "id错误");

        //充值成功记录
        List<SupplierQuotaDetail> details = repositoryFactory.getSupplierQuotaDetailRepository()
                .listByMainId(quota.getId());

        SupplierQuotaDetailResult ret = new SupplierQuotaDetailResult();

        if (details.isEmpty()) {
            return ret;
        }


        //组合
        Map<SupplierQuotaAuditTypeEnums, List<SupplierQuotaDetail>> auditMap = details.stream()
                .collect(Collectors.groupingBy(SupplierQuotaDetail::getAmountType));

        for (Map.Entry<SupplierQuotaAuditTypeEnums, List<SupplierQuotaDetail>> entry : auditMap.entrySet()) {

            List<SupplierQuotaDetailResult.Item> list = MultiUtils.toList(
                    entry.getValue(),
                    SupplierQuotaMapping.INSTANCE::toDetailResult
            );

            switch (entry.getKey()) {
                case NORMAL:
                    ret.setNormalLogs(list);
                    break;
                case JS:
                    ret.setConsignmentLogs(list);
                    break;
            }
        }
        return ret;
    }

    @Transactional
    @Override
    public Boolean returnAmount(SupplierQuotaReturnRequest request) {

        SupplierQuotaDetail detail = repositoryFactory.getSupplierQuotaDetailRepository().findById(request.getId());
        SupplierQuota quota = repositoryFactory.getSupplierQuotaRepository().findById(detail.getQuotaId());


        ValidationUtil.isTrue(detail.getAmount().compareTo(request.getAmount()) > -1,"退款金额超出余额");


        //step_1 扣除金额
        switch (detail.getAmountType()) {
            case NORMAL:
                quota.setNormalQuota(quota.getNormalQuota().subtract(request.getAmount()));
                break;
            case JS:
                quota.setJsQuota(quota.getJsQuota().subtract(request.getAmount()));
                break;
        }
        repositoryFactory.getSupplierQuotaRepository().submit(quota);


        //step_2 扣除详情金额
        detail.setAmount(detail.getAmount().subtract(request.getAmount()));
        repositoryFactory.getSupplierQuotaDetailRepository().submit(detail);



        //新增记录
        SupplierQuotaLog log = new SupplierQuotaLog();
        log.setAmount(request.getAmount());
        log.setQuotaId(quota.getId());
        log.setType(SupplierQuotaLogTypeEnums.RETURN);
        log.setAmountType(detail.getAmountType());
        repositoryFactory.getSupplierQuotaLogRepository().submit(log);

        return true;
    }

    @Override
    public SupplierQuotaResult findOne(SupplierQuotaRequest request) {
        SupplierContacts contact = repositoryFactory.getSupplierContactsRepository().findById(request.getId());
        SupplierQuota quota = repositoryFactory.getSupplierQuotaRepository().findBySupplierId(contact.getSupplierId());
        return SupplierQuotaMapping.INSTANCE.to(quota);
    }
}
