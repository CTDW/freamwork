package com.seeease.flywheel_v4.web.app.wms.request;


import com.fasterxml.jackson.annotation.JsonFormat;
import com.seeease.springframework.PageRequest;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.validation.constraints.NotNull;
import java.util.Date;

/**
 * @ Description   :
 * @ Author        :  西门 游
 * @ CreateDate    :  6/6/24
 * @ Version       :  1.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class WmsPhoneManagementPageRequest extends PageRequest {
    /**
     * 拍照管理状态
     */
    @NotNull(message = "状态不能为空")
    private Integer state;
    /**
     * 业务单号
     */
    private String serialNo;
    /**
     * 业务类型
     */
    private Integer type;
    /**
     * 商品名称
     */
    private String goodsName;
    /**
     * sku编码
     */
    private String skuCode;
    /**
     * 品牌id
     */
    private Integer brandId;
    /**
     * 类目id
     */
    private Integer categoryId;
    /**
     * 蜥蜴编码
     */
    private String xyCode;
    /**
     * 货号
     */
    private String goodsCode;

    /**
     * 创建时间开始
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date startTime;
    /**
     * 创建时间结束
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date endTime;

    /**
     * 业务单元id 用于数据隔离
     */
    private Integer buId;


}
