package com.seeease.flywheel_v4.web.infrastructure.dao.purchase.enums;

import com.baomidou.mybatisplus.annotation.IEnum;
import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * <p>采购打款方式</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/6/24 3:06 下午
 **/
@Getter
@AllArgsConstructor
public enum PurchaseAftersaleTypeEnums implements IEnum<Integer> {
    JS(1,"拒收"),
    FX(2,"返修"),
    HH(3,"换货"),
    TH(4,"退货"),

    ;
    private Integer value;
    private String desc;
}
