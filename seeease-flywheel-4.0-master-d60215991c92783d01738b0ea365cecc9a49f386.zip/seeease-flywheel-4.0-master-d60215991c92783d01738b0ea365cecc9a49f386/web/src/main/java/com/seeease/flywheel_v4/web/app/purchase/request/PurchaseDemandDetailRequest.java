package com.seeease.flywheel_v4.web.app.purchase.request;


import lombok.Data;




@Data
public class PurchaseDemandDetailRequest {
    /**
     * id
     */
    private Integer id;
    /*
     * 编号
     */
    private String serialNo;
}
