package com.seeease.flywheel_v4.web.app.wms.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.google.common.collect.Lists;
import com.seeease.flywheel_v4.web.app.wms.request.*;
import com.seeease.flywheel_v4.web.app.wms.result.WmsCkPageResult;
import com.seeease.flywheel_v4.web.app.wms.result.WmsRfidCkListResult;
import com.seeease.flywheel_v4.web.app.wms.service.WmsCkService;
import com.seeease.flywheel_v4.web.domain.wms.component.express.core.ExpressChannel;
import com.seeease.flywheel_v4.web.domain.wms.component.express.core.PlaceOrderDto;
import com.seeease.flywheel_v4.web.domain.wms.component.express.core.PlaceOrderResult;
import com.seeease.flywheel_v4.web.domain.wms.component.express.core.PrintResult;
import com.seeease.flywheel_v4.web.domain.wms.component.express.core.sf.PlaceOrderHandler;
import com.seeease.flywheel_v4.web.domain.wms.mapping.WmsCkMapping;
import com.seeease.flywheel_v4.web.domain.wms.observer.base.Ext;
import com.seeease.flywheel_v4.web.domain.wms.observer.base.WmsSubject;
import com.seeease.flywheel_v4.web.infrastructure.dao.RepositoryFactory;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.entity.SaleOrder;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.entity.SaleOrderLine;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.enums.SaleQualityWayEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.entity.SysBusinessUnit;
import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.enums.SaleChannelTypeEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.WmsCk;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.WmsCkTypeEnums;
import com.seeease.goods.rpc.SkuFacade;
import com.seeease.goods.rpc.enums.SkuNodeStateEnums;
import com.seeease.goods.rpc.request.SkuCkReplaceRpcRequest;
import com.seeease.goods.rpc.request.SkuRpcRequest;
import com.seeease.goods.rpc.result.SkuCkReplaceRpcResult;
import com.seeease.goods.rpc.result.SkuRpcResult;
import com.seeease.springframework.PageResult;
import com.seeease.springframework.context.UserContext;
import com.seeease.springframework.exception.ValidationUtil;
import com.seeease.springframework.exception.e.ArgumentException;
import com.seeease.springframework.utils.MultiUtils;
import com.seeease.springframework.utils.StringUtils;
import io.seata.spring.annotation.GlobalTransactional;
import lombok.extern.slf4j.Slf4j;
import org.apache.dubbo.config.annotation.DubboReference;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/20/24 11:46 上午
 **/
@Slf4j
@Service
public class WmsCkServiceImpl implements WmsCkService {
    @Resource
    private RepositoryFactory repositoryFactory;
    @DubboReference(version = "1.0.0", check = false)
    private SkuFacade skuFacade;
    @Resource
    private WmsSubject wmsSubject;
    @Resource
    private PlaceOrderHandler placeOrderHandler;


    @Override
    public PageResult<WmsCkPageResult> page(WmsCkPageRequest request) {
        //元素0待集单状态数量 1 待打单状态数量 2待出库状态数量 3其余剩下的数量
        List<Integer> statics = Lists.newArrayList(0, 0, 0, 0);


        //sku查询
        Set<Integer> skuIdList = null;
        List<SkuRpcResult> skuList;
        if (StringUtils.oneOfNonNull(
                request.getSkuCode(),
                request.getBrandId(),
                request.getGoodsName(),
                request.getCategoryId(),
                request.getXyCode()
        )) {
            SkuRpcRequest rpcRequest = WmsCkMapping.INSTANCE.toSkuRpcRequest(request);
            skuList = skuFacade.list(rpcRequest);
            if (skuList.isEmpty()) {
                return PageResult.buildEmpty(statics);
            }
            skuIdList = MultiUtils.toSet(skuList, SkuRpcResult::getId);
        }


        //主表查询
        Integer buId = UserContext.getUser().getStore().getId();
        request.setBuId(buId);
        Page<WmsCk> page = repositoryFactory.getWmsCkRepository().page(request, skuIdList);
        //数据统计查询
        statics = repositoryFactory.getWmsCkRepository().statics(request, skuIdList);
        if (page.getRecords().isEmpty()) {
            return PageResult.buildEmpty(statics);
        }

        //to方地址
        Map<String, Ext> extMap = wmsSubject.getCkExt(page.getRecords());

        //查询组内数据
        Set<String> groupList = MultiUtils.toSet(page.getRecords(), WmsCk::getGroup);
        List<WmsCk> wmsCkGroupList = repositoryFactory.getWmsCkRepository().listByGroups(groupList);
        Map<String, List<WmsCk>> groupMap = wmsCkGroupList.stream()
                .collect(Collectors.groupingBy(WmsCk::getGroup));


        //sku数据
        skuIdList = MultiUtils.toSet(wmsCkGroupList, WmsCk::getSkuId);
        SkuRpcRequest rpcRequest = new SkuRpcRequest();
        rpcRequest.setIdList(skuIdList);
        skuList = skuFacade.list(rpcRequest);
        Map<Integer, SkuRpcResult> skuMap = MultiUtils.toMap(skuList, SkuRpcResult::getId, Function.identity());


        //订单来源
        Set<Integer> originIdList = MultiUtils.toSet(page.getRecords(), WmsCk::getOriginId);
        Map<Integer, String> originMap = MultiUtils.toMap(
                repositoryFactory.getBusinessUnitRepository().listByIds(originIdList),
                SysBusinessUnit::getId,
                SysBusinessUnit::getName
        );


        //组合
        List<WmsCkPageResult> ret = MultiUtils.toList(
                page.getRecords(),
                parent -> {
                    Ext ext = extMap.get(parent.getSerialNo());
                    Map<Integer, Ext.SkuExt> skuExtMap = MultiUtils.toMap(ext.getSkuExts(), Ext.SkuExt::getSkuId);

                    List<WmsCk> childList = groupMap.get(parent.getGroup());
                    List<WmsCkPageResult.Sku> retSkuList = MultiUtils.toList(
                            childList,
                            child -> {
                                SkuRpcResult sku = skuMap.get(child.getSkuId());
                                Ext.SkuExt skuExt = skuExtMap.get(sku.getId());
                                return WmsCkMapping.INSTANCE.toPageSkuListResult(child, sku, skuExt);
                            }
                    );


                    String originName = originMap.get(parent.getOriginId());
                    return WmsCkMapping.INSTANCE.toPageResult(parent, retSkuList, originName, ext);
                }
        );

        return PageResult.<WmsCkPageResult>builder()
                .result(ret)
                .ext(statics)
                .totalCount(page.getTotal())
                .totalPage(page.getPages())
                .build();
    }

    @GlobalTransactional
    @Override
    public Boolean jd(WmsJdRequest request) {
        List<WmsCk> wmsCkList = repositoryFactory.getWmsCkRepository()
                .listByIds(request.getIdList())
                .stream()
                .filter(v -> v.getNodeState() == SkuNodeStateEnums.JD)
                .collect(Collectors.toList());
        ValidationUtil.isTrue(!wmsCkList.isEmpty(), "集单号错误");
        Map<String, List<WmsCk>> wmsMap = wmsCkList.stream().collect(Collectors.groupingBy(WmsCk::getSerialNo));

        ArrayList<WmsCk> updateList = new ArrayList<>();
        for (Map.Entry<String, List<WmsCk>> entry : wmsMap.entrySet()) {
            //根据单号查询是否存在集单的单子 如果存在 则组相同赋值
            String group;
            WmsCk already_jd = repositoryFactory.getWmsCkRepository().listBySerialNo(entry.getKey())
                    .stream()
                    .filter(ck -> ck.getNodeState() == SkuNodeStateEnums.DD)
                    .findFirst()
                    .orElse(null);
            group = null == already_jd ? UUID.randomUUID().toString() : already_jd.getGroup();

            entry.getValue().forEach(ck -> {
                ck.setGroup(group);
                ck.setNodeState(SkuNodeStateEnums.DD);
            });
            updateList.addAll(entry.getValue());
        }
        wmsSubject.ckState(updateList, SkuNodeStateEnums.DD);
        return true;
    }

    @GlobalTransactional
    @Override
    public Boolean cancel(WmsCkCancelRequest request) {
        List<WmsCk> ckList = repositoryFactory.getWmsCkRepository().listByIds(request.getIdList());
        ValidationUtil.isTrue(StringUtils.isNotEmpty(ckList), "wms取消参数id数组错误");


        Map<SkuNodeStateEnums, List<WmsCk>> ckMap = ckList.stream()
                .collect(Collectors.groupingBy(WmsCk::getNodeState));
        ValidationUtil.isTrue(
                ckMap.size() == 1 && ckMap.containsKey(SkuNodeStateEnums.JD),
                "sku状态错误无法取消"
        );

        ckList.forEach(ck -> ck.setNodeState(SkuNodeStateEnums.QX));
        wmsSubject.ckState(ckList, SkuNodeStateEnums.QX);
        return true;
    }

    @GlobalTransactional
    @Override
    public Boolean rollBack(WmsCkRollbackRequest request) {
        List<WmsCk> ckList = repositoryFactory.getWmsCkRepository().listByIds(request.getIdList());
        ValidationUtil.isTrue(StringUtils.isNotEmpty(ckList), "wms回滚参数id数组错误");

        Map<SkuNodeStateEnums, List<WmsCk>> ckMap = ckList.stream()
                .collect(Collectors.groupingBy(WmsCk::getNodeState));
        ValidationUtil.isTrue(
                ckMap.size() == 1 && ckMap.containsKey(SkuNodeStateEnums.DD),
                "出库单状态错误无法回撤"
        );

        Set<String> groupList = MultiUtils.toSet(ckList, WmsCk::getGroup);
        ckList = repositoryFactory.getWmsCkRepository().listByGroups(groupList);


        ckList.forEach(ck -> {
            ck.setGroup(UUID.randomUUID().toString());
            ck.setNodeState(SkuNodeStateEnums.JD);
        });
        wmsSubject.ckState(ckList, SkuNodeStateEnums.JD);
        return true;
    }

    @GlobalTransactional
    @Override
    public Boolean uploadExpress(WmsCkUploadExpressRequest request) {
        WmsCk parent = repositoryFactory.getWmsCkRepository().findById(request.getId());
        ValidationUtil.notNull(parent, "id错误");
        ValidationUtil.isTrue(
                parent.getNodeState() == SkuNodeStateEnums.DD,
                "出库单状态错误"
        );

        List<WmsCk> wmsCkList = repositoryFactory.getWmsCkRepository()
                .listByGroups(Collections.singleton(parent.getGroup()));
        wmsCkList.forEach(ck -> {
            ck.setNodeState(SkuNodeStateEnums.DCK);
            ck.setExpressNo(request.getExpressNo());
        });

        wmsSubject.ckState(wmsCkList, SkuNodeStateEnums.DCK);

        return true;
    }

    @GlobalTransactional
    @Override
    public Boolean ck(WmsCkRequest request) {
        List<WmsCk> ckList = repositoryFactory.getWmsCkRepository()
                .listByIds(request.getIdList())
                .stream()
                .filter(v -> v.getNodeState() == SkuNodeStateEnums.DCK)
                .collect(Collectors.toList());
        ValidationUtil.isTrue(StringUtils.isNotEmpty(ckList), "出库id错误");

        Map<SkuNodeStateEnums, List<WmsCk>> ckMap = ckList.stream()
                .collect(Collectors.groupingBy(WmsCk::getNodeState));
        ValidationUtil.isTrue(
                ckMap.size() == 1 && ckMap.containsKey(SkuNodeStateEnums.DCK),
                "出库单状态错误无法出库"
        );

        Set<String> groupList = MultiUtils.toSet(ckList, WmsCk::getGroup);
        ckList = repositoryFactory.getWmsCkRepository().listByGroups(groupList);
        ckList.forEach(ck -> ck.setNodeState(SkuNodeStateEnums.YCK));
        wmsSubject.ckState(ckList, SkuNodeStateEnums.YCK);
        return true;
    }


    @GlobalTransactional
    @Override
    public PrintResult ckPrint(WmsCkPrintRequest request) {
        //step_1 获取需要打单的出库数据
        //先获取主订单数据
        List<WmsCk> mainList = repositoryFactory.getWmsCkRepository().listByIds(request.getIds());

        //step_2 获取打单数据
        Set<String> groupNos = MultiUtils.toSet(mainList, WmsCk::getGroup);
        List<WmsCk> ckList = repositoryFactory.getWmsCkRepository().listByGroups(groupNos);

        //step_3 构建打单数据
        Map<String, List<WmsCk>> ckGroup = ckList.stream().collect(Collectors.groupingBy(WmsCk::getGroup));
        Map<String, Ext> extMap = wmsSubject.getCkExt(ckList);

        //step_4 构建顺丰下单参数数据
        List<PlaceOrderDto> sfList = new ArrayList<>();
        List<PlaceOrderDto> ksList = new ArrayList<>();
        List<PlaceOrderDto> dyLIst = new ArrayList<>();

        for (WmsCk main : mainList) {
            String serialNo = main.getSerialNo();
            Ext ext = extMap.get(serialNo);

            Set<Integer> skuIds = MultiUtils.toSet(
                    ckGroup.get(main.getGroup()),
                    WmsCk::getSkuId
            );
            SkuRpcRequest rpcRequest = new SkuRpcRequest();
            rpcRequest.setIdList(skuIds);
            List<SkuRpcResult> skus = skuFacade.list(rpcRequest);
            //转换为快递下单数据
            List<PlaceOrderDto.Product> products = MultiUtils.toList(skus, WmsCkMapping.INSTANCE::toPlaceOrderProduct);
            PlaceOrderDto dto = WmsCkMapping.INSTANCE.toPlaceOrderDeo(
                    ext,
                    products,
                    serialNo
            );

            //添加进数据集合
            if (null != ext.getSaleChannel() && ext.getSaleChannel().getType() == SaleChannelTypeEnums.tiktok) {
                dyLIst.add(dto);
            } else if (null != ext.getSaleChannel() && ext.getSaleChannel().getType() == SaleChannelTypeEnums.ks) {
                ksList.add(dto);
            } else {

                if (Objects.equals(ext.getQualityWay(), SaleQualityWayEnums.BZJ.getValue())) {
                    sfList.add(dto);
                } else {

                    //如果是现在质检生成两个面单 公司发给国检中心，国检中心发给客户
                    PlaceOrderDto dto_1 = WmsCkMapping.INSTANCE.copy(dto);
                    dto_1.setName("国检小葛");
                    dto_1.setPhone("18001602507");
                    dto_1.setProvince("上海市");
                    dto_1.setCity("上海市");
                    dto_1.setArea("闵行区");
                    dto_1.setStreet("虹桥镇");
                    dto_1.setAddress("吴中路1189号525室");
                    sfList.add(dto_1);

                    PlaceOrderDto dto_2 = WmsCkMapping.INSTANCE.copy(dto);
                    dto_2.setSpName("国检小葛");
                    dto_2.setSpPhone("18001602507");
                    dto_2.setSpProvince("上海市");
                    dto_2.setSpCity("上海市");
                    dto_2.setSpArea("闵行区");
                    dto_2.setSpStreet("虹桥镇");
                    dto_2.setSpAddress("吴中路1189号525室");
                    dto_2.setBusinessNo(dto_2.getBusinessNo() + "_GJ");
                    sfList.add(dto_2);
                }

            }
        }


        //step_5 判断是否补打
        boolean firstPrint = mainList.get(0).getNodeState() == SkuNodeStateEnums.DD;
        List<PlaceOrderResult> placeOrderResults;
        HashMap<ExpressChannel.Channel, List<PlaceOrderDto>> dtoMap = new HashMap<>();
        dtoMap.put(ExpressChannel.Channel.DY_SF, dyLIst);
        dtoMap.put(ExpressChannel.Channel.KS_SF, ksList);
        dtoMap.put(ExpressChannel.Channel.SF, sfList);

        if (firstPrint) {
            //顺丰下单
            placeOrderResults = placeOrderHandler.placeOrder(dtoMap);
            //筛选出下单成功的数据
            List<PlaceOrderResult> succeedList = placeOrderResults.stream().filter(PlaceOrderResult::getSuccess).collect(Collectors.toList());
            Map<String, PlaceOrderResult> successMap = MultiUtils.toMap(
                    succeedList,
                    PlaceOrderResult::getBusinessNo
            );

            //更新wms数据变为待发货
            for (WmsCk ck : mainList) {
                PlaceOrderResult successResult = successMap.get(ck.getSerialNo());
                if (null != successResult) {
                    WmsCkUploadExpressRequest req = new WmsCkUploadExpressRequest();
                    req.setId(ck.getId());
                    req.setExpressNo(successResult.getExpressNumber());
                    this.uploadExpress(req);
                }
            }
        }
        //补打面单
        else {

            placeOrderResults = new ArrayList<>();
            Map<String, List<WmsCk>> ckMap = ckList.stream().collect(Collectors.groupingBy(WmsCk::getSerialNo));
            for (Map.Entry<ExpressChannel.Channel, List<PlaceOrderDto>> entry : dtoMap.entrySet()) {
                for (PlaceOrderDto dto : entry.getValue()) {
                    PlaceOrderResult item = new PlaceOrderResult();
                    item.setChannel(entry.getKey());
                    item.setDto(dto);
                    item.setBusinessNo(dto.getBusinessNo());
                    item.setExpressNumber(ckMap.get(dto.getBusinessNo()).get(0).getExpressNo());
                    item.setSuccess(true);
                    placeOrderResults.add(item);
                }
            }
        }

        //step_6 返回打单数据
        return placeOrderHandler.getPrintInfo(placeOrderResults);

    }

    @GlobalTransactional
    @Override
    public Boolean ckReplace(WmsCkReplaceRequest request) {
        log.info("wms ck replace start:{}",JSONObject.toJSONString(request));
        Set<Integer> ids = MultiUtils.toSet(request.getItems(), WmsCkReplaceRequest.Item::getId);
        List<WmsCk> ckList = repositoryFactory.getWmsCkRepository().listByIds(ids);

        for (WmsCk ck : ckList) {
            ValidationUtil.isTrue(ck.getType() == WmsCkTypeEnums.XS_CK, "只允许销售出库替换唯一码");
        }

        Map<String, List<WmsCk>> group = ckList.stream().collect(Collectors.groupingBy(WmsCk::getSerialNo));
        ValidationUtil.isTrue(group.size() == 1, "只能修改同一个单号的出库单的唯一码");


        ValidationUtil.isTrue(ids.size() == ckList.size(), "需要替换的数量和待出库数量不匹配");
        Map<Integer, WmsCk> ckMap = MultiUtils.toMap(ckList, WmsCk::getId);



        //step_1 查找新替换的表身号是否存在出库中
        SkuRpcRequest skuRpcRequest = new SkuRpcRequest();
        Set<String> newSkuCodes = MultiUtils.toSet(request.getItems(), WmsCkReplaceRequest.Item::getSkuCode);
        skuRpcRequest.setSkuCodes(newSkuCodes);
        Map<Integer, SkuRpcResult> targetSkuMap = MultiUtils.toMap(skuFacade.list(skuRpcRequest), SkuRpcResult::getId);


        List<WmsCk> targetSkuWmsCkList = repositoryFactory.getWmsCkRepository()
                .listBySkuIds(targetSkuMap.keySet())
                .stream()
                .filter(ck -> ck.getNodeState() == SkuNodeStateEnums.JD ||
                        ck.getNodeState() == SkuNodeStateEnums.DD ||
                        ck.getNodeState() == SkuNodeStateEnums.DCK
                )
                .peek(ck -> {
                    if (ck.getType() != WmsCkTypeEnums.XS_CK){
                        SkuRpcResult targetSku = targetSkuMap.get(ck.getSkuId());
                        throw new ArgumentException("需要替换的表身号:" + targetSku.getSkuCode() + "出库类型必须为销售出库");
                    }
                })
                .collect(Collectors.toList());
        Map<Integer, WmsCk> targetSkuWmsMap = MultiUtils.toMap(targetSkuWmsCkList, WmsCk::getSkuId);

        Set<String> serialNos = MultiUtils.toSet(targetSkuWmsCkList, WmsCk::getSerialNo);
        Set<Integer> targetSaleOrderIds = MultiUtils.toSet(
                repositoryFactory.getSaleOrderRepository().listBySerialNos(serialNos),
                SaleOrder::getId
        );

        Map<Integer, SaleOrderLine> targetSaleOrderLineMap = MultiUtils.toMap(
                repositoryFactory.getSaleOrderLineRepository().listByMainIds(targetSaleOrderIds),
                SaleOrderLine::getSkuId
        );


        //step_2 替换sku状态
        Set<Integer> oldSkuIds = MultiUtils.toSet(ckList, WmsCk::getSkuId);
        SkuRpcRequest skuRpcRequest1 = new SkuRpcRequest();
        skuRpcRequest1.setIdList(oldSkuIds);
        Map<Integer, SkuRpcResult> oldSkuMap = MultiUtils.toMap(skuFacade.list(skuRpcRequest1), SkuRpcResult::getId);

        ArrayList<SkuCkReplaceRpcRequest> rpcRequests = new ArrayList<>();
        for (WmsCkReplaceRequest.Item item : request.getItems()) {
            WmsCk ck = ckMap.get(item.getId());
            SkuRpcResult sku = oldSkuMap.get(ck.getSkuId());
            SkuCkReplaceRpcRequest rpcRequest = new SkuCkReplaceRpcRequest();
            rpcRequest.setOldGoodsCode(sku.getSkuCode());
            rpcRequest.setNewGoodsCode(item.getSkuCode());
            rpcRequests.add(rpcRequest);
        }

        Map<Integer, Integer> replaceMap = MultiUtils.toMap(
                skuFacade.ckReplace(rpcRequests),
                SkuCkReplaceRpcResult::getOldId,
                SkuCkReplaceRpcResult::getNewId
        );


        //step_2 业务单据skuId互换
        Set<String> oldSerialNods = MultiUtils.toSet(ckList, WmsCk::getSerialNo);
        Set<Integer> oldSaleIds = MultiUtils.toSet(
                repositoryFactory.getSaleOrderRepository().listBySerialNos(oldSerialNods),
                SaleOrder::getId
        );

        Map<Integer, SaleOrderLine> oldSaleOrderLineMap = MultiUtils.toMap(
                repositoryFactory.getSaleOrderLineRepository().listByMainIds(oldSaleIds),
                SaleOrderLine::getSkuId
        );

        ArrayList<WmsCk> updateList = new ArrayList<>();
        ArrayList<SaleOrderLine> updateSaleLineList = new ArrayList<>();

        ckList.forEach(oldCk -> {
            //替换出入库数据
            Integer oldSKuId = oldCk.getSkuId();
            Integer newSkuId = replaceMap.get(oldSKuId);

            oldCk.setSkuId(newSkuId);
            updateList.add(oldCk);
            WmsCk targetWmsCk = targetSkuWmsMap.get(newSkuId);
            if (null != targetWmsCk){
                targetWmsCk.setSkuId(oldSKuId);
                updateList.add(targetWmsCk);
            }


            //替换销售单行数据
            SaleOrderLine oldSaleLine = oldSaleOrderLineMap.get(oldSKuId);
            oldSaleLine.setSkuId(newSkuId);
            updateSaleLineList.add(oldSaleLine);
            SaleOrderLine targetSaleLine = targetSaleOrderLineMap.get(newSkuId);
            if (null != targetSaleLine){
                targetSaleLine.setSkuId(oldSKuId);
                updateSaleLineList.add(targetSaleLine);
            }

        });


        repositoryFactory.getWmsCkRepository().submitBatch(updateList);
        repositoryFactory.getSaleOrderLineRepository().submitBatch(updateSaleLineList);

        return true;

    }


    @Override
    public List<WmsRfidCkListResult> rfidCkList() {

        Integer storeId = UserContext.getUser().getStore().getId();

        //step_1 查找对应仓库出库列表
        List<WmsCk> ckList = repositoryFactory.getWmsCkRepository().listForRfid(storeId);

        if (StringUtils.isEmpty(ckList)) {
            return Collections.emptyList();
        }

        //step_2 sku数据查询
        Set<Integer> skuIds = MultiUtils.toSet(ckList, WmsCk::getSkuId);
        SkuRpcRequest rpcRequest = new SkuRpcRequest();
        rpcRequest.setIdList(skuIds);
        Map<Integer, SkuRpcResult> skuMap = MultiUtils.toMap(skuFacade.list(rpcRequest), SkuRpcResult::getId);


        //step_3 分组
        ArrayList<WmsRfidCkListResult> ret = new ArrayList<>();
        ckList.stream()
                .collect(Collectors.groupingBy(WmsCk::getSerialNo))
                .forEach((serialNo, groupCkList) -> {

                    long doneCount = groupCkList.stream()
                            .filter(ck -> ck.getNodeState() == SkuNodeStateEnums.YCK)
                            .count();

                    long waitCount = groupCkList.stream()
                            .filter(ck ->
                                    ck.getNodeState() == SkuNodeStateEnums.DD ||
                                            ck.getNodeState() == SkuNodeStateEnums.JD ||
                                            ck.getNodeState() == SkuNodeStateEnums.DCK)
                            .count();

                    //根据快递单号分组
                    groupCkList.stream()
                            .filter(ck -> ck.getNodeState() == SkuNodeStateEnums.DCK)
                            .collect(Collectors.groupingBy(WmsCk::getExpressNo))
                            .forEach((k, v) -> {

                                List<WmsRfidCkListResult.Sku> skuList = MultiUtils.toList(
                                        v,
                                        ck -> {
                                            SkuRpcResult sku = skuMap.get(ck.getSkuId());
                                            return WmsCkMapping.INSTANCE.toRfidSkuList(sku, ck.getId());
                                        });

                                WmsRfidCkListResult item = WmsCkMapping.INSTANCE.toRfidResult(
                                        v.get(0),
                                        skuList,
                                        doneCount,
                                        waitCount
                                );
                                ret.add(item);
                            });

                });

        return ret;
    }


}
