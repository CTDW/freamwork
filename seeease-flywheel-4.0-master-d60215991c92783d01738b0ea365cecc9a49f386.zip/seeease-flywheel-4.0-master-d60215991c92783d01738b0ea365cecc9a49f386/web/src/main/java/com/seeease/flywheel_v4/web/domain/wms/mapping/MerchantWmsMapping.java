package com.seeease.flywheel_v4.web.domain.wms.mapping;


import com.seeease.flywheel_v4.client.enums.BusinessUnitTypeEnums;
import com.seeease.flywheel_v4.web.app.wms.result.MerchantWmsDetailResult;
import com.seeease.flywheel_v4.web.app.wms.result.MerchantWmsPageResult;
import com.seeease.flywheel_v4.web.infrastructure.config.EnumMapping;
import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.entity.SysBusinessUnit;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.MerchantWms;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.MerchantWmsLine;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.obj.ContactInfo;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.MerchantWmsStateEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.MerchantWmsTypeEnums;
import com.seeease.goods.rpc.enums.SkuNodeStateEnums;
import com.seeease.goods.rpc.enums.SkuStateEnums;
import com.seeease.goods.rpc.request.SkuStateEventSubmitRcpRequest;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;

import java.util.List;


/**
 * <p>
 * 商品附件
 * </p>
 *
 * @author 西门 游
 * @since 2023-10-27
 */
@Mapper(componentModel = "spring",
        builder = @Builder(disableBuilder = true),
        nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS,
        nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE,
        imports = {BusinessUnitTypeEnums.class,
                MerchantWmsStateEnums.class,
                MerchantWmsTypeEnums.class,
                SkuNodeStateEnums.class,
                SkuStateEnums.TransitionEnum.class,
                SkuStateEnums.class})
public interface MerchantWmsMapping extends EnumMapping {

    MerchantWmsMapping INSTANCE = Mappers.getMapper(MerchantWmsMapping.class);



    @Mapping(target = "skuList",expression = "java(toSkuStateEvent(lineList))")
    SkuStateEventSubmitRcpRequest toSkuStateEvent(List<MerchantWmsLine> lineList,
                                                  MerchantWms main,
                                                  SkuNodeStateEnums nodeState);


    SkuStateEventSubmitRcpRequest.Sku toSkuStateEvent(MerchantWmsLine line);

    List<SkuStateEventSubmitRcpRequest.Sku> toSkuStateEvent(List<MerchantWmsLine> line);


    MerchantWmsPageResult to(MerchantWms merchantWms, String toName, String fromName,String originName);

    @Mapping(target = "id",source = "main.id")
    @Mapping(target = "state",expression = "java(main.getState().getValue())")
    @Mapping(target = "type",expression = "java(main.getType().getValue())")
    @Mapping(target = "remark",source = "main.remark")
    @Mapping(target = "createdBy",source = "main.createdBy")
    @Mapping(target = "createdTime",source = "main.createdTime")
    @Mapping(target = "name",source = "contactInfo.name")
    @Mapping(target = "phone",source = "contactInfo.phone")
    @Mapping(target = "address",source = "contactInfo.address")
    @Mapping(target = "fromName",source = "from.name")
    @Mapping(target = "toName",source = "to.name")
    @Mapping(target = "originName",source = "origin.name")
    MerchantWmsDetailResult toDetailResult(MerchantWms main,
                                           SysBusinessUnit to,
                                           SysBusinessUnit from,
                                           SysBusinessUnit origin,
                                           ContactInfo contactInfo,
                                           List<MerchantWmsDetailResult.Sku> skuList);
}
