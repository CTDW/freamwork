package com.seeease.flywheel_v4.web.infrastructure.dao.purchase.repo;


import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.seeease.flywheel_v4.web.app.purchase.request.PurchaseAftersalePageRequest;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.entity.PurchaseAftersale;

import java.util.List;
import java.util.Set;

/**
 *
 * @author 西门 游
 * @version 1.0
 * @since 5/31/24 4:55 下午
 **/
public interface PurchaseAftersaleRepository {

    /**
     * 提交
     * @param aftersale
     * @return
     */
    Boolean submit(PurchaseAftersale aftersale);

    /**
     * 查询
     * @param serialNo
     * @return
     */
    List<PurchaseAftersale> listBySerialNos(Set<String> serialNo);

    /**
     * 查找
     * @param id
     * @param serialNo
     * @return
     */
    PurchaseAftersale findByIdOrSerialNo(Integer id, String serialNo);

    /**
     * 分页查询
     * @param request
     * @param ids
     * @return
     */
    Page<PurchaseAftersale> page(PurchaseAftersalePageRequest request, Set<Integer> ids);

}
