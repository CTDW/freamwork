package com.seeease.flywheel_v4.web.app.wms.request;


import com.fasterxml.jackson.annotation.JsonFormat;
import com.seeease.springframework.PageRequest;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Date;
import java.util.Set;

/**
 * @ Description   :
 * @ Author        :  西门 游
 * @ CreateDate    :  6/6/24
 * @ Version       :  1.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class WmsRkPageRequest extends PageRequest {
    /**
     * ids
     */
    private Set<Integer> ids;
    /**
     * 业务单号
     */
    private String serialNo;
    /**
     * 业务类型
     */
    private Integer type;
    /**
     * 商品名称
     */
    private String goodsName;
    /**
     * 节点状态
     */
    private Integer nodeState;

    /**
     * 来源id
     */
    private Integer originId;

    /**
     * sku编码
     */
    private String skuCode;
    /**
     * 快递单号
     */
    private String expressNo;
    /**
     * 入库开始时间
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date startTime;
    /**
     * 入库结束时间
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date endTime;
    /**
     * 当前登录人的业务单元id 用于数据隔离
     */
    private Integer buId;

}
