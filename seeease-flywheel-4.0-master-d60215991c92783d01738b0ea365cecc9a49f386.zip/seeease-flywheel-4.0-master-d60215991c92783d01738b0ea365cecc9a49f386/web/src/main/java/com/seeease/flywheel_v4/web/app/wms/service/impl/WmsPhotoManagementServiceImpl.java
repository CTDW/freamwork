package com.seeease.flywheel_v4.web.app.wms.service.impl;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.seeease.flywheel_v4.web.app.wms.request.WmsBatchTakePhotoRequest;
import com.seeease.flywheel_v4.web.app.wms.request.WmsPhoneManagementPageRequest;
import com.seeease.flywheel_v4.web.app.wms.request.WmsTakePhotoRequest;
import com.seeease.flywheel_v4.web.app.wms.result.WmsPhotoManagementPageResult;
import com.seeease.flywheel_v4.web.app.wms.service.WmsPhotoManagementService;
import com.seeease.flywheel_v4.web.domain.wms.mapping.WmsPhotoManagementMapping;
import com.seeease.flywheel_v4.web.infrastructure.dao.RepositoryFactory;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.WmsPhotoManagement;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.WmsRk;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.WmsPhotoManagementState;
import com.seeease.goods.rpc.SkuFacade;
import com.seeease.goods.rpc.request.SkuRpcRequest;
import com.seeease.goods.rpc.request.SkuUpdateRpcRequest;
import com.seeease.goods.rpc.result.SkuRpcResult;
import com.seeease.springframework.PageResult;
import com.seeease.springframework.context.UserContext;
import com.seeease.springframework.exception.ValidationUtil;
import com.seeease.springframework.utils.MultiUtils;
import com.seeease.springframework.utils.StringUtils;
import io.seata.spring.annotation.GlobalTransactional;
import org.apache.dubbo.config.annotation.DubboReference;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/20/24 11:46 上午
 **/
@Service
public class WmsPhotoManagementServiceImpl implements WmsPhotoManagementService {

    @Resource
    private RepositoryFactory repositoryFactory;

    @DubboReference(version = "1.0.0", check = false)
    private SkuFacade skuFacade;


    @Override
    public PageResult<WmsPhotoManagementPageResult> page(WmsPhoneManagementPageRequest request) {
        //spu查询
        Set<Integer> skuIdList = null;
        List<SkuRpcResult> skuList = null;

        if (StringUtils.oneOfNonNull(
                request.getGoodsName(),
                request.getBrandId(),
                request.getCategoryId(),
                request.getXyCode(),
                request.getGoodsCode(),
                request.getSkuCode()
        )) {
            SkuRpcRequest rpcRequest = WmsPhotoManagementMapping.INSTANCE.toSKuRpcRequest(request);
            skuList = skuFacade.list(rpcRequest);

            if (skuList.isEmpty()) {
                return PageResult.buildEmpty();
            }

            skuIdList = MultiUtils.toSet(skuList, SkuRpcResult::getId);
        }


        //入库单据查询
        Set<Integer> wmsRkIdList = null;
        List<WmsRk> wmsRkList = null;
        if (StringUtils.oneOfNonNull(
                skuIdList,
                request.getSerialNo(),
                request.getType()
        )) {
            wmsRkList = repositoryFactory.getWmsRkRepository()
                    .list(
                            skuIdList,
                            request.getSerialNo(),
                            request.getType()
                    );
            wmsRkIdList = MultiUtils.toSet(wmsRkList, WmsRk::getId);

            if (wmsRkIdList.isEmpty()) {
                return PageResult.buildEmpty();
            }
        }


        //主表分页查询
        Integer buId = UserContext.getUser().getStore().getId();
        request.setBuId(buId);
        Page<WmsPhotoManagement> page = repositoryFactory.getWmsPhotoManagementRepository()
                .page(
                        wmsRkIdList,
                        request
                );

        //组合数据
        if (page.getRecords().isEmpty()) {
            return PageResult.buildEmpty();
        }


        //入库单数据获取
        if (StringUtils.isEmpty(wmsRkList)) {
            wmsRkIdList = MultiUtils.toSet(page.getRecords(), WmsPhotoManagement::getRkId);
            wmsRkList = repositoryFactory.getWmsRkRepository().listByIds(wmsRkIdList);
        }
        Map<Integer, WmsRk> rkMap = MultiUtils.toMap(
                wmsRkList,
                WmsRk::getId,
                Function.identity()
        );


        //sku数据
        if (null == skuIdList) {
            skuIdList = MultiUtils.toSet(wmsRkList, WmsRk::getSkuId);
            SkuRpcRequest rpcRequest = new SkuRpcRequest();
            rpcRequest.setIdList(skuIdList);
            skuList = skuFacade.list(rpcRequest);
        }

        Map<Integer, SkuRpcResult> skuMap = MultiUtils.toMap(
                skuList,
                SkuRpcResult::getId,
                Function.identity()
        );


        //组合
        List<WmsPhotoManagementPageResult> ret = MultiUtils.toList(
                page.getRecords(),
                v -> {
                    WmsRk wmsRk = rkMap.get(v.getRkId());
                    SkuRpcResult sku = skuMap.get(wmsRk.getSkuId());
                    return WmsPhotoManagementMapping.INSTANCE.toPageResult(v, wmsRk, sku);
                }
        );


        return PageResult.<WmsPhotoManagementPageResult>builder()
                .result(ret)
                .totalCount(page.getTotal())
                .totalPage(page.getPages())
                .build();


    }

    @GlobalTransactional
    @Override
    public Boolean takePhoto(WmsTakePhotoRequest request) {
        WmsPhotoManagement photoManagement = repositoryFactory.getWmsPhotoManagementRepository()
                .findById(request.getId());

        ValidationUtil.notNull(photoManagement, "id错误");
        ValidationUtil.isTrue(photoManagement.getState() == WmsPhotoManagementState.WAIT, "状态无法拍照");

        photoManagement.setState(WmsPhotoManagementState.OK);
        ValidationUtil.isTrue(
                repositoryFactory.getWmsPhotoManagementRepository().submit(photoManagement),
                "修改拍照管理状态失败"
        );

        WmsRk wmsRk = repositoryFactory.getWmsRkRepository().findById(photoManagement.getRkId());

        SkuUpdateRpcRequest rpcRequest = WmsPhotoManagementMapping.INSTANCE.
                toSkuUpdateRequest(wmsRk.getSkuId(), request);
        skuFacade.update(rpcRequest);

        return true;
    }

    @Override
    public Boolean batchTakePhoto(WmsBatchTakePhotoRequest request) {
        List<WmsPhotoManagement> photoManagementList = repositoryFactory.getWmsPhotoManagementRepository()
                .listByIds(request.getIds());
        photoManagementList.forEach(item -> item.setState(WmsPhotoManagementState.OK));
        repositoryFactory.getWmsPhotoManagementRepository().submitBatch(photoManagementList);
        return true;
    }
}
