package com.seeease.flywheel_v4.web.infrastructure.dao.fix.entity;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.seeease.flywheel_v4.web.app.fix.common.FixItemDto;
import com.seeease.flywheel_v4.web.app.fix.common.FixMasterScoreDto;
import com.seeease.flywheel_v4.web.app.fix.request.FixOrderSaveRequest;
import com.seeease.seeeaseframework.mybatis.domain.BaseDomain;
import com.seeease.springframework.utils.StringUtils;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.apache.commons.collections4.CollectionUtils;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * @Description 维修单 表
 * @Date 2024-10-2 20:55
 * @Author by hk
 */
@EqualsAndHashCode(callSuper = true)
@TableName(value = "v4_fix_order", autoResultMap = true)
@Data
public class FixOrder extends BaseDomain {

    @TableId(type = IdType.AUTO)
    private Long id;

    /**
     * 维修单状态 1：维修登记 2：待接修 3：维修中 4：抛光中 5：清洗中 6：师傅组装 7：质检中 " +
     * "8：待维修出库 9：送外维修 10：等配件 11：已完成 12:已取消
     */
    private Integer orderStatus;

    /**
     * 上一次状态，用于状态回退
     */
    private Integer preOrderStatus;

    /**
     * 维修单号
     */
    private String orderNumber;

    /**
     * 订单类型，1：内部 2：外部
     */
    private Integer orderType;

    /**
     * 订单来源
     */
    private Integer orderSource;

    /**
     * 订单来源
     */
    private String orderSourceStr;

    /**
     * 维修优先级，1：一级 2：
     */
    private Integer priorityType;

    /**
     * 是否加急
     */
    private Boolean urgent;

    /**
     * 维修基地
     */
    private String fixBase;

    /**
     * 预计耗时 单位天
     */
    private Integer consumeTime;

    /**
     * 快递单
     */
    private String expressNumber;

    /**
     * 维修诉求
     */
    private String appeal;

    /**
     * 瑕疵说明
     */
    private String defectDesc;

    /**
     * 维修师
     */
    private String fixMaster;

    /**
     * 送外维修费
     */
    private BigDecimal sendOutFixFee;

    /**
     * 返回备注
     */
    private String returnRemark;

    /**
     * 返回快递单号
     */
    private String returnExpressNumber;

    /**
     * 送修备注
     */
    private String sendOutRemark;

    /**
     * 维修师得分
     */
    private String masterScores;

    /**
     * 维修客户
     */
    private String custom;

    /**
     * 联系电话
     */
    private String customPhone;

    /**
     * 省
     */
    private String province;

    private Long provinceId;

    /**
     * 市
     */
    private String city;

    private Long cityId;

    /**
     * 县区
     */
    private String area;

    private Long areaId;

    /**
     * 详细地址
     */
    private String address;

    /**
     * 唯一码
     */
    private String goodsUnique;

    /**
     * 品牌
     */
    private String brand;

    /**
     * 表节数
     */
    private Integer watchNodeCount;

    /**
     * 可否拆盖
     */
    private Boolean removeCover;

    /**
     * 瑕疵图
     */
    private String defectPictureList;

    /**
     * 表带类型
     */
    private String watchBandType;

    /**
     * 成色
     */
    private String newnessDegree;

    /**
     * 维修项目
     */
    private String fixItems;

    public List<FixItemDto> getFixItemList() {
        if (StringUtils.isEmpty(fixItems)) {
            return new ArrayList<>();
        }
        return JSON.parseArray(fixItems, FixItemDto.class);
    }

    public List<FixMasterScoreDto> getFixMasterScoreList() {
        if (StringUtils.isEmpty(masterScores)) {
            return new ArrayList<>();
        }
        return JSON.parseArray(masterScores, FixMasterScoreDto.class);
    }

    public String getFixMasterScore() {
        List<FixMasterScoreDto> fixMasterScores = getFixMasterScoreList();
        if (CollectionUtils.isEmpty(fixMasterScores)) {
            return "";
        }
        StringBuilder stringBuffer = new StringBuilder();
        for (FixMasterScoreDto scoreDto : fixMasterScores) {
            stringBuffer.append(scoreDto.getFixMaster()).append(":").append(scoreDto.getScore()).append("星,");
        }
        return stringBuffer.substring(0, stringBuffer.length() - 1);
    }

    public static FixOrder toEntity(FixOrderSaveRequest request) {
        FixOrder fixOrder = new FixOrder();

        // 基础信息
        request.getBasicInfo().toEntity(fixOrder);

        // 客户信息
        request.getCustomInfo().toEntity(fixOrder);

        // 商品信息
        request.getGoodsInfo().toEntity(fixOrder);

        // 维修报价项
        if (CollectionUtils.isNotEmpty(request.getFixItemList())) {
            fixOrder.setFixItems(JSON.toJSONString(request.getFixItemList()));
        }

        // 配件 保存到维修单配件表中

        return fixOrder;
    }

}