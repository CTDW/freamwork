package com.seeease.flywheel_v4.web.infrastructure.dao.purchase.repo;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.seeease.flywheel_v4.web.app.purchase.request.PurchaseDemandPageRequest;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.entity.PurchaseDemand;

import java.util.List;

/**
 *
 * @author 西门 游
 * @version 1.0
 * @since 5/31/24 4:55 下午
 **/
public interface PurchaseDemandRepository {

    /**
     * 提交数据
     *
     * @return 提交结果
     */
    Boolean submit(PurchaseDemand e);

    /**
     * 分页查询
     *
     * @return 分页结果
     */
    Page<PurchaseDemand> page(PurchaseDemandPageRequest request);

    /**
     * 执行待状态事务更新
     * @param list
     * @return 更新结果
     */
    Boolean submitBatchByState(List<PurchaseDemand> list);

    /**
     * 查找
     * @param id  id
     * @param serialNo 编码
     * @return 需求单
     */
    PurchaseDemand findByIdOrSerial(Integer id,String serialNo);

    /**
     * 绑定采购单数据
     * @param ids 主键id列表
     * @param purchaseId 采购单id
     * @param serialNo 采购单编号
     */
    Boolean bindPurchaseOrder(List<Integer> ids, Integer purchaseId, String serialNo);

    /**
     * 列表查询
     * @param purchaseId 采购单id
     * @return
     */
    List<PurchaseDemand> listByPurchaseId(Integer purchaseId);
}
