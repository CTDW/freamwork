package com.seeease.flywheel_v4.web.infrastructure.config;


import com.seeease.seeeaseframework.mybatis.transitionstate.StateChangeRejectException;
import com.seeease.springframework.SingleResponse;
import com.seeease.springframework.exception.e.ArgumentException;
import com.seeease.springframework.log.LogPrinterAutoConfiguration;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.support.DefaultMessageSourceResolvable;
import org.springframework.http.HttpStatus;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.util.HashMap;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * 全局异常处理配置
 *
 * @author wuyin
 * @date 2022/09/27
 */
@RestControllerAdvice
@Slf4j
public class ExceptionHandlerConfig {

    /**
     * 处理@RequestParam参数校验异常
     *
     * @param e 异常
     * @return 异常处理结果
     */
    @ExceptionHandler(MissingServletRequestParameterException.class)
    public SingleResponse missingServletRequestParameterExceptionHandler(MissingServletRequestParameterException e) {
        String msg = String.format("parameter '%s' is not present", e.getParameterName());
        return SingleResponse.buildFailure(HttpStatus.BAD_REQUEST.value(), msg);
    }


    /**
     * 处理@RequestBody参数校验异常
     *
     * @param e 异常
     * @return 异常处理结果
     */
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public SingleResponse handleArgumentValidException(MethodArgumentNotValidException e) {
        Stream<String> errorStream = e.getBindingResult().getAllErrors().stream().map(DefaultMessageSourceResolvable::getDefaultMessage);
        return SingleResponse.buildFailure(HttpStatus.BAD_REQUEST.value(), errorStream.collect(Collectors.joining(";")));
    }

    /**
     * 处理业务异常
     *
     * @param e 异常
     * @return 异常处理结果
     */
    @SuppressWarnings("unchecked")
    @ExceptionHandler(value = ArgumentException.class)
    public SingleResponse<String> handleBizException(ArgumentException e) {
        String requestId = LogPrinterAutoConfiguration.RequestHolder.getRequestId();
        e.printStackTrace();
        SingleResponse<String> resp = SingleResponse.buildFailure(500, e.getMessage());
        HashMap<String, Object> ext = new HashMap<>();
        ext.put("requestId",requestId);
        resp.setExt(ext);
        return resp;
    }


    /**
     * 处理状态转换异常
     *
     * @param e 异常
     * @return 异常处理结果
     */
    @SuppressWarnings("unchecked")
    @ExceptionHandler(value = StateChangeRejectException.class)
    public SingleResponse<String> handleStateChangeRejectException(StateChangeRejectException e) {
        ArgumentException ex = new ArgumentException("业务状态无法变更");
        return handleBizException(ex);
    }



    /**
     * 处理未知异常
     *
     * @param e 异常
     * @return 异常处理结果
     */
    @SuppressWarnings("unchecked")
    @ExceptionHandler(Exception.class)
    public SingleResponse<String> handleUnknownException(Exception e) {
        String requestId = LogPrinterAutoConfiguration.RequestHolder.getRequestId();
        log.error("\nUnknownError requestId:{} ",requestId);
        e.printStackTrace();
        SingleResponse<String> resp = SingleResponse.buildFailure(HttpStatus.INTERNAL_SERVER_ERROR.value(), "未知异常");
        HashMap<String, Object> ext = new HashMap<>();
        ext.put("requestId",requestId);
        resp.setExt(ext);
        return resp;
    }


    /**
     * 请求方式不支持
     *
     * @param e 异常
     * @return 异常处理结果
     */
    @ExceptionHandler(HttpRequestMethodNotSupportedException.class)
    public SingleResponse handleHttpRequestMethodNotSupportedException(HttpRequestMethodNotSupportedException e) {
        return SingleResponse.buildFailure(HttpStatus.INTERNAL_SERVER_ERROR.value(), "method not supported");
    }


}
