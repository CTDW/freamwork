package com.seeease.flywheel_v4.web.app.fix.service;

import com.seeease.flywheel_v4.web.app.fix.request.FixItemDetailRequest;
import com.seeease.flywheel_v4.web.app.fix.request.FixItemPageRequest;
import com.seeease.flywheel_v4.web.app.fix.request.FixItemSaveRequest;
import com.seeease.flywheel_v4.web.app.fix.result.FixItemPageResult;
import com.seeease.flywheel_v4.web.infrastructure.dao.fix.entity.FixItem;
import com.seeease.springframework.PageResult;

/**
 * @Description 维修项目
 * @Date 2024-10-2 21:11
 * @Author by hk
 */
public interface FixItemService {

    /**
     * 维修中心-维修项目列表
     *
     * @param request 请求
     * @return 列表结果
     */
    PageResult<FixItemPageResult> page(FixItemPageRequest request);


    /**
     * 详情
     *
     * @param request 请求
     * @return 返回
     */
    FixItem detail(FixItemDetailRequest request);

    /**
     * 新增
     *
     * @param request 请求
     * @return 结果
     */
    Boolean save(FixItemSaveRequest request);

    /**
     * 编辑
     *
     * @param request 请求
     * @return 结果
     */
    Boolean update(FixItemSaveRequest request);

    /**
     * 删除
     *
     * @param request 请求
     * @return 结果
     */
    Boolean delete(FixItemDetailRequest request);
}
