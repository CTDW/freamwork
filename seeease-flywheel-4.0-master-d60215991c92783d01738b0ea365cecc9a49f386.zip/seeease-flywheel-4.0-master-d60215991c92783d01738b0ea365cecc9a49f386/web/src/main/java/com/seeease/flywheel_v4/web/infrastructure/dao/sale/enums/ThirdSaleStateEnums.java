package com.seeease.flywheel_v4.web.infrastructure.dao.sale.enums;


import com.baomidou.mybatisplus.annotation.IEnum;
import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * <p>三方销售单状态</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/5/24 1:47 下午
 **/
@AllArgsConstructor
@Getter
public enum ThirdSaleStateEnums implements IEnum<Integer> {
    WAIT(1,"待审核"),
    OK(2,"已通过"),
    CANCEL(3,"取消")
    ;
    private Integer value;
    private String desc;


}
