package com.seeease.flywheel_v4.web.domain.excel.strategy.export;

import com.alibaba.cola.extension.Extension;
import com.seeease.flywheel_v4.client.enums.PurchaseTypeEnums;
import com.seeease.flywheel_v4.web.app.excel.result.PurchaseExportResult;
import com.seeease.flywheel_v4.web.app.purchase.request.PurchaseOrderPageRequest;
import com.seeease.flywheel_v4.web.app.purchase.result.PurchaseOrderPageResult;
import com.seeease.flywheel_v4.web.app.purchase.service.PurchaseOrderService;
import com.seeease.flywheel_v4.web.domain.excel.ExcelDomain;
import com.seeease.flywheel_v4.web.domain.excel.core.ExportExtPtl;
import com.seeease.flywheel_v4.web.domain.purchase.mapping.PurchaseOrderLineMapping;
import com.seeease.flywheel_v4.web.infrastructure.dao.RepositoryFactory;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.entity.PurchaseOrderLine;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.enums.PurchaseOrderStateEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.enums.PurchasePayTypeEnums;
import com.seeease.goods.rpc.SkuFacade;
import com.seeease.goods.rpc.request.SkuRpcRequest;
import com.seeease.goods.rpc.result.SkuRpcResult;
import com.seeease.seeeaseframework.mybatis.utils.EnumUtils;
import com.seeease.springframework.utils.MultiUtils;
import org.apache.dubbo.config.annotation.DubboReference;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;


/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 9/12/24 10:42 上午
 **/
@Service
@Extension(bizId = "export", useCase = "purchase")
public class PurchaseExport implements ExportExtPtl<PurchaseOrderPageRequest, PurchaseExportResult> {

    @Resource
    private RepositoryFactory repositoryFactory;

    @Resource
    private PurchaseOrderService purchaseOrderService;

    @DubboReference(version = "1.0.0", check = false)
    private SkuFacade skuFacade;

    @Resource
    private ExcelDomain excelDomain;


    @Override
    public Class<PurchaseOrderPageRequest> getRequestClass() {
        return PurchaseOrderPageRequest.class;
    }

    @Override
    public Class<PurchaseExportResult> getResultClass() {
        return PurchaseExportResult.class;
    }

    @Override
    public String getFileName() {
        return "采购导出";
    }

    @Override
    public List<PurchaseExportResult> handle(PurchaseOrderPageRequest request) {
        //step_1 调用采购分页查询接口
        request.setLimit(Integer.MAX_VALUE);
        List<PurchaseOrderPageResult> orderList = purchaseOrderService.page(request).getResult();
        Map<Integer, PurchaseOrderPageResult> orderMap = MultiUtils.toMap(
                orderList,
                PurchaseOrderPageResult::getId
        );
        if (orderList.isEmpty()) {
            return Collections.emptyList();
        }

        //step_2 查询采购单行
        Set<Integer> orderIds = MultiUtils.toSet(orderList, PurchaseOrderPageResult::getId);
        List<PurchaseOrderLine> lineList = repositoryFactory.getPurchaseOrderLineRepository()
                .listByPurchaseIds(orderIds);


        //step_3 查询sku
        Set<Integer> skuIds = MultiUtils.toSet(lineList, PurchaseOrderLine::getSkuId);
        SkuRpcRequest rpcRequest = new SkuRpcRequest();
        rpcRequest.setIdList(skuIds);
        Map<Integer, SkuRpcResult> skuMap = MultiUtils.toMap(
                skuFacade.list(rpcRequest),
                SkuRpcResult::getId
        );



        //step_4 数据的组合
        return MultiUtils.toList(
                lineList,
                line -> {
                    PurchaseOrderPageResult order = orderMap.get(line.getPurchaseId());
                    String state = EnumUtils.of(PurchaseOrderStateEnums.class, order.getState()).getDesc();
                    String type = EnumUtils.of(PurchaseTypeEnums.class, order.getType()).getDesc();
                    String payType = EnumUtils.of(PurchasePayTypeEnums.class, order.getPayType()).getDesc();
                    String nodeState = line.getNodeState().getDesc();

                    SkuRpcResult sku = skuMap.get(line.getSkuId());
                    String annex = excelDomain.joinAnnexe(sku.getAnnexe());
                    String param = excelDomain.joinParam(sku.getSkuParams());

                    return PurchaseOrderLineMapping.INSTANCE.toExportResult(
                            state,
                            type,
                            payType,
                            line,
                            sku,
                            annex,
                            param,
                            order,
                            nodeState
                    );
                }
        );


    }
}
