package com.seeease.flywheel_v4.web.domain.wms.mapping;


import com.seeease.flywheel_v4.client.enums.BusinessUnitTypeEnums;
import com.seeease.flywheel_v4.web.app.excel.result.WmsCkExportResult;
import com.seeease.flywheel_v4.web.app.wms.request.WmsCkPageRequest;
import com.seeease.flywheel_v4.web.app.wms.result.WmsCkPageResult;
import com.seeease.flywheel_v4.web.app.wms.result.WmsRfidCkListResult;
import com.seeease.flywheel_v4.web.domain.wms.component.express.core.PlaceOrderDto;
import com.seeease.flywheel_v4.web.domain.wms.observer.base.Ext;
import com.seeease.flywheel_v4.web.infrastructure.config.EnumMapping;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.WmsCk;
import com.seeease.goods.rpc.enums.SkuNodeStateEnums;
import com.seeease.goods.rpc.enums.SkuStateEnums;
import com.seeease.goods.rpc.request.SkuRpcRequest;
import com.seeease.goods.rpc.request.SkuStateEventSubmitRcpRequest;
import com.seeease.goods.rpc.result.SkuRpcResult;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;

import java.util.Collections;
import java.util.List;


/**
 * <p>
 * 商品附件
 * </p>
 *
 * @author 西门 游
 * @since 2023-10-27
 */
@Mapper(componentModel = "spring",
        builder = @Builder(disableBuilder = true),
        nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS,
        nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE,
        imports = {BusinessUnitTypeEnums.class,
                SkuNodeStateEnums.class, SkuStateEnums.TransitionEnum.class, SkuStateEnums.class, Collections.class})
public interface WmsCkMapping extends EnumMapping {

    WmsCkMapping INSTANCE = Mappers.getMapper(WmsCkMapping.class);


    @Mapping(target = "skuList", expression = "java(toSkuStateEvent(WmsCkList))")
    SkuStateEventSubmitRcpRequest toSkuStateEvent(List<WmsCk> WmsCkList,
                                                  SkuNodeStateEnums nodeState
    );


    SkuStateEventSubmitRcpRequest.Sku toSkuStateEvent(WmsCk WmsCk);

    List<SkuStateEventSubmitRcpRequest.Sku> toSkuStateEvent(List<WmsCk> WmsCk);


    SkuRpcRequest toSkuRpcRequest(WmsCkPageRequest request);

    @Mapping(target = "count", source = "wmsCk.count")
    @Mapping(target = "id", source = "sku.id")
    @Mapping(target = "pubPrice", source = "sku.pubPrice")
    @Mapping(target = "dealPrice", source = "skuExt.dealPrice")
    WmsCkPageResult.Sku toPageSkuListResult(WmsCk wmsCk,
                                            SkuRpcResult sku,
                                            Ext.SkuExt skuExt);

    @Mapping(target = "remark", source = "ext.remark")
    @Mapping(target = "thirdPartyNo", source = "ext.thirdPartNo")
    WmsCkPageResult toPageResult(WmsCk parent,
                                 List<WmsCkPageResult.Sku> skuList,
                                 String originName,
                                 Ext ext);


    @Mapping(target = "type", source = "type")
    @Mapping(target = "scType", source = "scType")
    @Mapping(target = "nodeState", source = "nodeState")
    @Mapping(target = "param", source = "param")
    @Mapping(target = "annexe", source = "annexe")
    WmsCkExportResult toExportResult(WmsCkPageResult item,
                                     String type,
                                     String scType,
                                     WmsCkPageResult.Sku sku,
                                     String nodeState,
                                     String param,
                                     String annexe);


    PlaceOrderDto.Product toPlaceOrderProduct(SkuRpcResult sku);


    @Mapping(target = "businessNo", source = "businessNo")
    @Mapping(target = "billRemark", source = "ext.billRemark")
    @Mapping(target = "saleRemark", source = "ext.remark")
    PlaceOrderDto toPlaceOrderDeo(Ext ext,
                                  List<PlaceOrderDto.Product> products,
                                  String businessNo
    );

    PlaceOrderDto copy(PlaceOrderDto dto);

    @Mapping(target = "id", source = "id")
    WmsRfidCkListResult.Sku toRfidSkuList(SkuRpcResult sku, Integer id);

    WmsRfidCkListResult toRfidResult(WmsCk wmsCk,
                                     List<WmsRfidCkListResult.Sku> skuList,
                                     Long doneCount,
                                     Long waitCount);
}
