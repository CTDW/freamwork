package com.seeease.flywheel_v4.web.app.finance.service;

import com.seeease.flywheel_v4.web.app.finance.request.PaymentSlipSubmitRequest;
import com.seeease.flywheel_v4.web.app.finance.request.PaymentSlipDetailRequest;
import com.seeease.flywheel_v4.web.app.finance.request.PaymentSlipPageRequest;
import com.seeease.flywheel_v4.web.app.finance.request.PaymentSlipUploadPayedImgRequest;
import com.seeease.flywheel_v4.web.app.finance.result.PaymentSlipDetailResult;
import com.seeease.flywheel_v4.web.app.finance.result.PaymentSlipPageResult;
import com.seeease.springframework.PageResult;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/12/24 9:54 上午
 **/
public interface FinancePaymentSlipService {
    /**
     * 申请打款单创建
     * <p>
     *     1.采购类型如下的即可在采购单创建时创建申请打款单
     *          - 同行采购 - 定金
     *          - 同行采购 - 备货
     *          - 个人采购 - 回收
     *          - 个人采购 - 回购
     *     2.采购类型如下的可在wms入库后创建申请打款单
     *          - 同行采购 - 集采
     *          - 同行采购 - 寄售
     *          - 个人采购 - 寄售
     *          - 个人采购-回购置换
     *          - 个人采购-回收置换
     * </p>
     * @param request
     * @return 创建结果
     */
    Boolean create(PaymentSlipSubmitRequest request);

    /**
     * 申请打款单分页查询
     * @param request
     * @return 分页结果
     */
    PageResult<PaymentSlipPageResult> page(PaymentSlipPageRequest request);

    /**
     * 申请打款单详情查询
     * @param request
     * @return 详情结果
     */
    PaymentSlipDetailResult details(PaymentSlipDetailRequest request);

    /**
     * 上传打款凭证
     * @param request
     * @return 上传结果
     */
    Boolean uploadPayedImg(PaymentSlipUploadPayedImgRequest request);

    /**
     * 申请打款单 作废 | 驳回操作
     * @param request
     * @return 操作结果
     */
    Boolean state(PaymentSlipSubmitRequest request);

    /**
     * 更新
     * @param request
     * @return 更新结果
     */
    Boolean update(PaymentSlipSubmitRequest request);
}
