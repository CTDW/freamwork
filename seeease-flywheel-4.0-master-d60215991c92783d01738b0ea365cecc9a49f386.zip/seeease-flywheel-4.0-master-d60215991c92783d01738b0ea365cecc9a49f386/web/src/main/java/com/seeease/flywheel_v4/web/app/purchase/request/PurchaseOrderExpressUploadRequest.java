package com.seeease.flywheel_v4.web.app.purchase.request;


import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * @ Description   :
 * @ Author        :  西门 游
 * @ CreateDate    :  6/6/24
 * @ Version       :  1.0
 */

@Data
public class PurchaseOrderExpressUploadRequest {

    /**
     * 采购单id
     */
    @NotNull(message = "采购单id不能为空")
    private Integer id;
    /**
     * 快递单号
     */
    @NotBlank(message = "快递单号不能为空")
    private String expressNo;

}
