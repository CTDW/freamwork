package com.seeease.flywheel_v4.web.app.purchase.result;

import lombok.Data;

import java.util.Date;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/4/24 6:00 下午
 **/
@Data
public class PurchaseDemandDetailResult {
    /**
     * id
     */
    private Integer id;
    /**
     * 编号
     */
    private String serialNo;
    /**
     * 采购单编号
     */
    private String purchaseSerialNo;

    /**
     * 取消时间
     */
    private Date cancelTime;
    /**
     * 备注
     */
    private String remark;
    /**
     * 状态
     */
    private Integer state;
    /**
     * 指定采购员
     */
    private String assignedName;
    /**
     * 指定采购员id
     */
    private Integer assignedId;
    /**
     * 商家id
     */
    private Integer merchantId;
    /**
     * 创建时间
     */
    private Date createdTime;

    /**
     * 商家
     */
    private String merchantName;

    /**
     * 创建人
     */
    private String createdBy;

    /**
     * 确认时间
     */
    private Date confirmTime;

    /**
     * spuId
     */
    private Integer spuId;
    /**
     * 商品名称
     */
    private String goodsName;
    /**
     * 主图
     */
    private String spuImage;
    /**
     * 货号
     */
    private String goodsCode;
    /**
     * 品牌
     */
    private String brandName;
    /**
     * 类目
     */
    private String categoryName;
    /**
     * 数量
     */
    private Integer count;


}
