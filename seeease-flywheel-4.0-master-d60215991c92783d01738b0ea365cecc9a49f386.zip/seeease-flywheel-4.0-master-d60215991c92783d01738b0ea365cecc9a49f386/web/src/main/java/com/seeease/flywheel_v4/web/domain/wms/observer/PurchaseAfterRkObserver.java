package com.seeease.flywheel_v4.web.domain.wms.observer;

import com.seeease.flywheel_v4.web.domain.operations.mapping.PricingMapping;
import com.seeease.flywheel_v4.web.domain.wms.observer.base.MerchantWmsObserver;
import com.seeease.flywheel_v4.web.domain.wms.observer.base.WmsRkObserver;
import com.seeease.flywheel_v4.web.infrastructure.dao.RepositoryFactory;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.Pricing;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.entity.PurchaseAftersale;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.entity.PurchaseAftersaleLine;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.entity.PurchaseOrder;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.entity.PurchaseOrderLine;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.MerchantWms;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.MerchantWmsLine;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.WmsRk;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.MerchantWmsModelEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.MerchantWmsTypeEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.WmsRkTypeEnums;
import com.seeease.flywheel_v4.web.infrastructure.listener.purchase.FinishStateListener;
import com.seeease.flywheel_v4.web.infrastructure.listener.purchaseAftersale.PurchaseAftersaleStateListener;
import com.seeease.goods.rpc.SkuFacade;
import com.seeease.goods.rpc.enums.SkuNodeStateEnums;
import com.seeease.goods.rpc.request.PurchaseSkuFinishRpcRequest;
import com.seeease.seeeaseframework.mybatis.domain.WhetherEnum;
import com.seeease.springframework.exception.ValidationUtil;
import com.seeease.springframework.utils.MultiUtils;
import org.apache.dubbo.config.annotation.DubboReference;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * <p
 *   采购售后入库观察者
 * </p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/21/24 2:46下午
 **/
@Component
public class PurchaseAfterRkObserver extends PurchaseAftersaleBaseObserver
        implements WmsRkObserver, MerchantWmsObserver {

    @Resource
    private RepositoryFactory repositoryFactory;
    @Resource
    private FinishStateListener purchaseListener;
    @Resource
    private PurchaseAftersaleStateListener aftersaleListener;

    @DubboReference(version = "1.0.0", check = false)
    private SkuFacade skuFacade;



    @Override
    public SkuNodeStateEnums adaptSkuNodeState(SkuNodeStateEnums state, String serialNo) {
        if (state == SkuNodeStateEnums.YRK){
            return SkuNodeStateEnums.YRK;
        }
        return null;
    }





    //----------------------------------------仓库wms观察者实现-----------------------------------//


    @Override
    public List<WmsRkTypeEnums> getWatchDataType() {
        return wmsRkWatchTypeList;
    }


    @Override
    public void update(List<WmsRk> rkList, SkuNodeStateEnums nodeState,String serialNo) {



        ValidationUtil.isTrue(!wmsRkNotAllow.contains(nodeState) ,"不支持该操作");

        if (nodeState == SkuNodeStateEnums.YRK){
            PurchaseAftersale aftersale = repositoryFactory.getPurchaseAftersaleRepository()
                    .findByIdOrSerialNo(null, serialNo);

            Set<Integer> skuIdList = MultiUtils.toSet(rkList, WmsRk::getSkuId);

            List<PurchaseAftersaleLine> lineList = repositoryFactory.getPurchaseAftersaleLineRepository()
                    .listByMainIdAndSkuIds(aftersale.getId(), skuIdList);

            doYrk(aftersale,lineList);
        }




    }

    @Override
    public void updateWithoutState(List<WmsRk> rkList,String serialNo) {}


    //----------------------------------------仓库wms观察者实现-----------------------------------//


    //----------------------------------------商家wms观察者实现-----------------------------------//

    @Override
    public MerchantWmsModelEnums model() {
        return MerchantWmsModelEnums.RK;
    }



    @Override
    public List<MerchantWmsTypeEnums> typeList() {
        return merchantWmsRkWatchTypeList;
    }

    @Override
    public void update(MerchantWms main, List<MerchantWmsLine> rkList, SkuNodeStateEnums nodeState) {

        ValidationUtil.isTrue(nodeState != SkuNodeStateEnums.QX,"不支持取消操作");

        if (nodeState == SkuNodeStateEnums.YRK){

            PurchaseAftersale aftersale = repositoryFactory.getPurchaseAftersaleRepository()
                    .findByIdOrSerialNo(null, main.getSerialNo());

            Set<Integer> skuIdList = MultiUtils.toSet(rkList, MerchantWmsLine::getSkuId);

            List<PurchaseAftersaleLine> lineList = repositoryFactory.getPurchaseAftersaleLineRepository()
                    .listByMainIdAndSkuIds(aftersale.getId(), skuIdList);

            doYrk(aftersale,lineList);
        }

    }



    //----------------------------------------商家wms观察者实现-----------------------------------//




    /**
     * 执行已入库操作
     */
    private void doYrk(PurchaseAftersale main, List<PurchaseAftersaleLine> lineList){
        //step_1 修改售后行装填
        lineList.forEach(l -> {
            l.setNodeState(SkuNodeStateEnums.YRK);
            l.setEndState(WhetherEnum.YES);
        });
        repositoryFactory.getPurchaseAftersaleLineRepository().submitBatch(lineList);

        //step_2 尝试修改售后主单状态
        aftersaleListener.onEvent(new PurchaseAftersaleStateListener.Event(this,main.getId()));

        //step_3 修改采购行终结状态
        PurchaseOrder purchaseOrder = repositoryFactory.getPurchaseOrderRepository()
                .findByIdOrSerialNo(null, main.getOriginSerialNo());

        Set<Integer> skuIdList = MultiUtils.toSet(lineList, PurchaseAftersaleLine::getSkuId);

        List<PurchaseOrderLine> purchaseOrderLineList = repositoryFactory.getPurchaseOrderLineRepository()
                .listByPurchaseIdAndSkuIds(purchaseOrder.getId(), skuIdList);

        Set<Integer> purchaseOrderLineIdList = MultiUtils.toSet(purchaseOrderLineList, PurchaseOrderLine::getId);

        repositoryFactory.getPurchaseOrderLineRepository().updateStateByIds(
                purchaseOrderLineIdList,
                SkuNodeStateEnums.YRK,
                WhetherEnum.YES
        );


        //step_4 创建定价任务
        ArrayList<Pricing> insertPricing = new ArrayList<>();
        for (PurchaseOrderLine l : purchaseOrderLineList){
            Pricing pricing = PricingMapping.INSTANCE.toEntity(purchaseOrder, l);
            insertPricing.add(pricing);
        }
        repositoryFactory.getPricingRepository().submitBatch(insertPricing);


        //step_5 采购订单节点变更事件推送
        purchaseListener.onEvent(new FinishStateListener.Event(this, purchaseOrder.getId()));


        //step_6 sku状态变更处理
        PurchaseSkuFinishRpcRequest rpcRequest = new PurchaseSkuFinishRpcRequest();
        rpcRequest.setSkuIdList(skuIdList);
        rpcRequest.setSerialNo(main.getSerialNo());
        skuFacade.finish(rpcRequest);
    }



}
