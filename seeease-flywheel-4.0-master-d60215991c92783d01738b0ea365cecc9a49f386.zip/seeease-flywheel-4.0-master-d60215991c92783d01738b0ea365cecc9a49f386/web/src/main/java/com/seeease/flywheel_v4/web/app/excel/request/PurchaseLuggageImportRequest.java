package com.seeease.flywheel_v4.web.app.excel.request;


import com.alibaba.excel.annotation.ExcelProperty;
import lombok.Data;

import java.math.BigDecimal;



@Data
public class PurchaseLuggageImportRequest  {

    @ExcelProperty(value = "货号")
    private String goodsCode;

    @ExcelProperty(value = "唯一码")
    private String skuCode;

    @ExcelProperty(value = "采购价")
    private BigDecimal purchasePrice;

    @ExcelProperty(value = "是否芯片款")
    private String chip;

    @ExcelProperty(value = "年份")
    private String year;

    @ExcelProperty(value = "刻印")
    private String engraving;

    @ExcelProperty(value = "盒子")
    private String box;

    @ExcelProperty(value = "防尘袋")
    private String dustBag;

    @ExcelProperty(value = "肩带")
    private String shoulderStrap;

    @ExcelProperty(value = "说明书")
    private String manual;

    @ExcelProperty(value = "身份卡")
    private String idCard;

    @ExcelProperty(value = "保卡")
    private String card;

    @ExcelProperty(value = "钥匙")
    private String key;

    @ExcelProperty(value = "锁")
    private String lock;

    @ExcelProperty(value = "皮牌")
    private String leatherTag;

    @ExcelProperty(value = "毛毡")
    private String felt;

    @ExcelProperty(value = "品牌标签卡")
    private String brandTagCard;

    @ExcelProperty(value = "购物票")
    private String shoppingTicket;

    @ExcelProperty(value = "补充备注")
    private String fillRemark;
}
