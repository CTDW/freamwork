package com.seeease.flywheel_v4.web.app.sys_config.result;


import lombok.Data;

import java.util.Date;

/**
 * @author 西门 游
 * @version 1.0
 * @since 6/3/24 11:26上午
 **/
@Data
public class SaleChannelPageResult {

    private Integer id;
    /**
     * 名称
     */
    private String name;
    /**
     * 销售渠道类型
     */
    private Integer type;

    /**
     * 渠道隶属商家id 即 sys_business_unit 表中业务类型为商家的主键id
     */
    private Integer merchantId;
    /**
     * 渠道隶属商家名称
     */
    private String merchantName;
    /**
     * 公司名称
     */
    private String firmName;
    /**
     * 备注
     */
    private String remark;
    /**
     * 营业执照编码
     */
    private String licenseNo;
    /**
     * 三方平台id
     */
    private String thirdNo;
    /**
     * 秘钥
     */
    private String secret;

    /**
     * 修改人
     */
    private String updatedBy;

    /**
     * 修改时间
     */
    private Date updatedTime;
}
