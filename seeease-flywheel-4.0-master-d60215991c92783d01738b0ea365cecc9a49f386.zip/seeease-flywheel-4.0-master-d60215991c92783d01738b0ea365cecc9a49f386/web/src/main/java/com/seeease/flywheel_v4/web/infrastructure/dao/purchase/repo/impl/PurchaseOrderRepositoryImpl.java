package com.seeease.flywheel_v4.web.infrastructure.dao.purchase.repo.impl;


import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.seeease.flywheel_v4.web.app.purchase.request.PurchaseOrderPageRequest;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.entity.PurchaseOrder;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.mapper.PurchaseOrderMapper;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.repo.PurchaseOrderRepository;
import com.seeease.seeeaseframework.mybatis.transitionstate.UpdateByIdCheckState;
import com.seeease.springframework.context.UserContext;
import com.seeease.springframework.utils.DateUtils;
import com.seeease.springframework.utils.StringUtils;
import org.springframework.stereotype.Repository;

import java.util.Collections;
import java.util.List;
import java.util.Set;


/**
 * @author 西门 游
 * @version 1.0
 * @since 5/31/24 4:55 下午
 **/
@Repository
public class PurchaseOrderRepositoryImpl extends ServiceImpl<PurchaseOrderMapper, PurchaseOrder>
        implements PurchaseOrderRepository {



    @Override
    public Boolean submit(PurchaseOrder purchaseOrder) {
        if (null == purchaseOrder.getId()){
            Integer id = UserContext.getUser().getStore().getId();
            purchaseOrder.setBuId(id);
        }
        return saveOrUpdate(purchaseOrder);
    }

    @Override
    public Page<PurchaseOrder> page(PurchaseOrderPageRequest request,Set<Integer> idList) {
        if (null != request.getStartTime() && null != request.getEndTime()) {
            request.setStartTime(DateUtils.getTimesmorning(DateUtils.getTimesmorning(request.getStartTime())));
            request.setEndTime(DateUtils.getTimesnight(DateUtils.getTimesnight(request.getEndTime())));
        }

        LambdaQueryWrapper<PurchaseOrder> wq = Wrappers.<PurchaseOrder>lambdaQuery()
                .and(StringUtils.isNotEmpty(request.getRelatedSerialNo()),wp -> {
                    wp.like(PurchaseOrder::getFpsSerialNo,request.getRelatedSerialNo())
                            .or()
                            .like(PurchaseOrder::getSaleSerialNo,request.getRelatedSerialNo())
                            .or()
                            .like(PurchaseOrder::getNewSaleSerialNo,request.getRelatedSerialNo());
                })
                .eq(null != request.getBuId(),PurchaseOrder::getBuId,request.getBuId())
                .eq(null != request.getMerchantId(),PurchaseOrder::getMerchantId,request.getMerchantId())
                .in(StringUtils.isNotEmpty(idList), PurchaseOrder::getId, idList)
                .in(StringUtils.isNotEmpty(request.getIds()),PurchaseOrder::getId,request.getIds())
                .eq(StringUtils.isNotEmpty(request.getSerialNo()), PurchaseOrder::getSerialNo, request.getSerialNo())
                .eq(null != request.getType(), PurchaseOrder::getType, request.getType())
                .eq(null != request.getState(), PurchaseOrder::getState, request.getState())
                .eq(StringUtils.isNotEmpty(request.getExpressNo()), PurchaseOrder::getExpressNo, request.getExpressNo())
                .eq(request.getMine(), PurchaseOrder::getCreatedId, UserContext.getUser().getId())
                .between(null != request.getStartTime() && null != request.getEndTime(), PurchaseOrder::getCreatedTime, request.getStartTime(), request.getEndTime())
                .orderByDesc(PurchaseOrder::getCreatedTime);
        Page<PurchaseOrder> page = new Page<>(request.getPage(), request.getLimit());
        baseMapper.selectPage(page, wq);

        return page;
    }


    @Override
    public PurchaseOrder findById(Integer id) {
        return getById(id);
    }

    @Override
    public PurchaseOrder findByIdOrSerialNo(Integer id, String serialNo) {
        LambdaQueryWrapper<PurchaseOrder> wq = Wrappers.<PurchaseOrder>lambdaQuery()
                .eq(null != id, PurchaseOrder::getId, id)
                .eq(StringUtils.isNotEmpty(serialNo), PurchaseOrder::getSerialNo, serialNo);
        return baseMapper.selectOne(wq);
    }



    @Override
    public List<PurchaseOrder> list(String serialNo, Integer supplierId) {
        LambdaQueryWrapper<PurchaseOrder> wq = Wrappers.<PurchaseOrder>lambdaQuery()
                .eq(null != supplierId, PurchaseOrder::getSupplierId, supplierId)
                .eq(StringUtils.isNotEmpty(serialNo), PurchaseOrder::getSerialNo, serialNo);
        return baseMapper.selectList(wq);
    }





    @Override
    public Boolean submitWithState(PurchaseOrder order) {
        UpdateByIdCheckState.update(baseMapper,order);
        return true;
    }


    @Override
    public List<PurchaseOrder> listByIds(Set<Integer> idList) {
        if (StringUtils.isEmpty(idList)){
            return Collections.emptyList();
        }
        return getBaseMapper().selectBatchIds(idList);
    }

    @Override
    public List<PurchaseOrder> listBySerialNos(Set<String> serialNo) {
        if (StringUtils.isEmpty(serialNo)){
            return Collections.emptyList();
        }
        LambdaQueryWrapper<PurchaseOrder> wq = Wrappers.<PurchaseOrder>lambdaQuery()
                .in(PurchaseOrder::getSerialNo, serialNo);

        return baseMapper.selectList(wq);
    }

}
