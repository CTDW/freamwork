package com.seeease.flywheel_v4.web.app.sale.result;


import com.seeease.flywheel_v4.web.infrastructure.dao.sale.entity.obj.BuyBackPolicyObj;
import com.seeease.goods.rpc.request.SkuAnnexeRpcResult;
import com.seeease.goods.rpc.result.ProductParamRpcResult;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


@Data
public class ToCSaleOrderDetailResult {
    /**
     * 销售单id
     */
    private Integer id;
    /**
     * 总金额
     */
    private BigDecimal totalAmount;
    /**
     * 总数量
     */
    private Integer totalCount;

    /**
     * 客户名称
     */
    private String buyerName;
    /**
     * 客户电话
     */
    private String buyerPhone;
    /**
     * 客户地址
     */
    private String buyerAddress;

    /**
     * 销售类型
     */
    private Integer sellType;

    /**
     * 销售单号
     */
    private String serialNo;

    /**
     * 三方单号
     */
    private String thirdPartyNo;

    /**
     * 采购单号
     */
    private String purchaseSerialNo;

    /**
     * 质检方式
     */
    private Integer qualityWay;

    /**
     * 定金金额
     */
    private BigDecimal prepayAmount;

    /**
     * 销售渠道
     */
    private Integer scType;

    /**
     * 状态
     */
    private Integer state;
    /**
     * 订单来源
     */
    private String originName;

    /**
     * 销售渠道名称
     */
    private String scName;
    /**
     * 快递单号
     */
    private String expressNo;
    /**
     * 三方订单异常信息
     */
    private String unusual;
    /**
     * 创建人
     */
    private String createdBy;
    /**
     * 创建时间
     */
    private Date createdTime;
    /**
     * 完成时间
     */
    private Date finishTime;
    /**
     * sku列表
     */
    private List<Sku> skuList;


    /**
     * 销售备注
     */
    private String sellRemark;

    /**
     * 面单备注
     */
    private String billRemark;


    /**
     * 第一销售人id
     */
    private String sellerAName;

    /**
     * 第二销售人id
     */
    private String sellerBName;

    /**
     * 第三销售人id
     */
    private String sellerCName;


    @Data
    public static class Sku{
        /**
         * 采购业务单据行id
         */
        private Integer lineId;
        /**
         * spuId
         */
        private Integer spuId;
        /**
         * skuId
         */
        private Integer skuId;
        /**
         * 商品名称
         */
        private String goodsName;
        /**
         * gmvc
         */
        private BigDecimal gmvc;
        /**
         * 类目
         */
        private String categoryName;
        /**
         * 品牌
         */
        private String brandName;

        /**
         * 绩效价
         */
        private BigDecimal perfPrice;

        /**
         * 唯一码类型
         */
        private Integer uniqueType;

        /**
         * toc价
         */
        private BigDecimal tocPrice;

        /**
         * 节点状态
         */
        private Integer nodeState;
        /**
         * sku参数列表
         */
        private List<ProductParamRpcResult> skuParams;
        /**
         * 附件
         */
        private List<SkuAnnexeRpcResult> annexe;
        /**
         * 回购政策
         */
        private List<BuyBackPolicyObj> policies;
        /**
         * 唯一码
         */
        private String skuCode;
        /**
         * 图片
         */
        private String spuImage;
        /**
         * 类目id
         */
        private Integer categoryId;
        /**
         * 销售数量
         */
        private Integer count;
        /**
         * 成交价
         */
        private BigDecimal dealPrice;
        /**
         * 最新结算价
         */
        private BigDecimal newSettlePrice;
        /**
         * 经营权
         */
        private String sellerName;
        /**
         * 商品所在
         */
        private String belongName;
        /**
         * 表带根换费
         */
        private BigDecimal strapPrice ;
        /**
         * 表节数
         */
        private Integer strapCount;
    }
}
