package com.seeease.flywheel_v4.web.app.sys_config.request;


import com.seeease.springframework.RequestValidGroup;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.List;


/**
 * <p>采购类型业务单元数据提交</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/3/24 11:26上午
 **/
@Data
public class PurchaseBusinessUnitSubmitRequest {
    /**
     * id
     */
    @NotNull(message = "id不能为空", groups = RequestValidGroup.Update.class)
    private Integer id;
    /**
     * 采购主体名称
     */
    @NotBlank(message = "采购主体名称不能为空")
    private String name;

    /**
     * 状态
     */
    @NotNull(message = "状态不能为空")
    private Integer state;

    /**
     * 支持的采购类型
     */
    @NotEmpty(message = "支持的采购类型不能为空")
    private List<Integer> typeList;

    /**
     * 仓库类型业务单元id
     */
    @NotEmpty(message = "仓库类型业务单元id不能为空")
    private List<Integer> storeIdList;

    /**
     * 寄售加点
     */
    private BigDecimal consignmentPoint;
    /**
     * 备注
     */
    private String remark;
}
