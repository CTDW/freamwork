package com.seeease.flywheel_v4.web.app.purchase.result;

import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/4/24 6:00 下午
 **/
@Data
public class PurchaseOrderPageResult {
    /**
     * id
     */
    private Integer id;
    /**
     * 编号
     */
    private String serialNo;
    /**
     * 状态
     */
    private Integer state;
    /**
     * 采购类型
     */
    private Integer type;
    /**
     * 支付方式
     */
    private Integer payType;
    /**
     * 打款比例
     */
    private BigDecimal payRatio;
    /**
     * 总金额
     */
    private BigDecimal totalPrice;
    /**
     * 快递单号
     */
    private String expressNo;
    /**
     * 备注
     */
    private String remark;
    /**
     * 供应商
     */
    private String supplierName;
    /**
     * 实际采购人
     */
    private String buyerName;
    /**
     * 商家名称
     */
    private String merchantName;
    /**
     * 采购主体名称
     */
    private String purchaseSubjectName;

    /**
     * 仓库名称
     */
    private String storeName;

    /**
     * 创建人
     */
    private String createdBy;
    /**
     * 创建时间
     */
    private Date createdTime;
}
