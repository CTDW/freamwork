package com.seeease.flywheel_v4.web.app.sys_config.request;


import com.seeease.springframework.PageRequest;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.validation.constraints.NotNull;

/**
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/3/24 11:26 上午
 **/
@EqualsAndHashCode(callSuper = true)
@Data
public class BusinessUnitPageRequest extends PageRequest {

    /**
     * 名称
     */
    private String name;
    /**
     * 业务单元类型
     */
    @NotNull(message = "业务单元类型不能为空")
    private Integer type;
    /**
     * 负责人
     */
    private String head;


}
