package com.seeease.flywheel_v4.web.domain.excel;

import com.seeease.goods.rpc.request.SkuAnnexeRpcResult;
import com.seeease.goods.rpc.result.ProductParamRpcResult;
import com.seeease.springframework.utils.StringUtils;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 9/12/24 11:29 上午
 **/
@Component
public class ExcelDomain {


    /**
     * 拼接附件字符串
     *
     * @param annexe
     * @return
     */
    public String joinAnnexe(List<SkuAnnexeRpcResult> annexe) {
        if (StringUtils.isEmpty(annexe)){
            return "";
        }
        return annexe.stream().map(item -> {
            if (item.getSelectType() != 2) {
                return item.getParamName() + "(" + item.getValue() + ")";
            } else {
                return item.getParamName();
            }
        }).collect(Collectors.joining(","));
    }


    /**
     * 拼接属性字符串
     *
     * @param params
     * @return
     */
    public String joinParam(List<ProductParamRpcResult> params) {
        if (StringUtils.isEmpty(params)){
            return "";
        }
        return params.stream()
                .map(item -> item.getParamName() + ":" + item.getParamValue())
                .collect(Collectors.joining("\n"));
    }

}
