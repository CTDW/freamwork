package com.seeease.flywheel_v4.web.app.operations.request;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity.TransferQuota;
import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.entity.SysBusinessUnit;
import com.seeease.springframework.RequestValidGroup;
import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.util.Date;
import java.util.List;


@Data
public class TransferQuotaSubmitRequest {
    /**
     * 调拨额度控制主表主键id
     * {@link TransferQuota#getId()}
     */
    @NotNull(message = "id不能为空", groups = {RequestValidGroup.Update.class, RequestValidGroup.Deleted.class})
    private Integer id;

    /**
     * 商家id
     * {@link SysBusinessUnit#getId()}
     */
    private Integer merchantId;

    /**
     * 设计到的类目id列表
     */
    private List<Integer> categoryIds;
    /**
     * 开始时间
     */
    @NotNull(message = "开始时间不能为空")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date startDate;
    /**
     * 开始时间
     */
    @NotNull(message = "结束时间不能为空")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date endDate;
    /**
     * 是否调拨控货
     */
    @NotNull(message = "是否调拨控货不能为空")
    private Integer isCtl;

    /**
     * 压货额度
     */
    @NotEmpty(message = "压货额度不能为空")
    @Valid
    private List<TransferQuotaLineSubmitRequest> osQuotas;
    /**
     * 代销额度
     */
    @NotEmpty(message = "代销额度不能为空")
    @Valid
    private List<TransferQuotaLineSubmitRequest> ctQuotas;


}
