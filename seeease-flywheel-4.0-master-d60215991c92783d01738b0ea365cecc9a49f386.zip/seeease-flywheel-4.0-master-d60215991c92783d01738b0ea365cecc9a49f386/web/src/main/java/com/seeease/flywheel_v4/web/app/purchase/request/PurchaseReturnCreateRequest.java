package com.seeease.flywheel_v4.web.app.purchase.request;


import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.List;


@Data
public class PurchaseReturnCreateRequest {

    /**
     * 备注
     */
    private String remark;
    /**
     * 供应商id
     */
    @NotNull(message = "供应商不能为空")
    private Integer supplierId;
    /**
     * 联系人id
     */
    @NotNull(message = "联系人不能为空")
    private Integer contactId;
    /**
     * sku列表
     */
    @Valid
    @NotEmpty(message = "sku列表不能为空")
    private List<Sku> skuList;

    /**
     * sku
     */
    @Data
    public static class Sku {
        /**
         * skuId
         */
        @NotNull(message = "skuId不能为空")
        private Integer id;
        /**
         * 数量
         */
        @NotNull(message = "数量不能为空")
        private Integer count;
        /**
         * 金额
         */
        @NotNull(message = "退货金额不能为空")
        private BigDecimal amount;
    }
}
