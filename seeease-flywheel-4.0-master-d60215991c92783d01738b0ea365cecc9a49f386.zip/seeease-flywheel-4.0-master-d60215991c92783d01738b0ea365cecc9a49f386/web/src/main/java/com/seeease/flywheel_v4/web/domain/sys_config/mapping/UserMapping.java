package com.seeease.flywheel_v4.web.domain.sys_config.mapping;


import com.seeease.flywheel_v4.web.app.sys_config.result.UserListResult;
import com.seeease.flywheel_v4.web.infrastructure.config.EnumMapping;
import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.entity.SysUser;
import com.seeease.flywheel_v4.client.enums.BusinessUnitTypeEnums;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;


/**
 * <p>
 * 商品附件
 * </p>
 *
 * @author 西门 游
 * @since 2023-10-27
 */
@Mapper(componentModel = "spring",
        builder = @Builder(disableBuilder = true),
        nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS,
        nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE,
        imports = {BusinessUnitTypeEnums.class})
public interface UserMapping extends EnumMapping {

    UserMapping INSTANCE = Mappers.getMapper(UserMapping.class);


    UserListResult toUserListResult(SysUser e);
}
