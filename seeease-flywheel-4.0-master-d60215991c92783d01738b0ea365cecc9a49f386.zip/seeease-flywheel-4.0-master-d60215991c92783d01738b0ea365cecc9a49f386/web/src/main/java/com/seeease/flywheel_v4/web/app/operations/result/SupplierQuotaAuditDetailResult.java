package com.seeease.flywheel_v4.web.app.operations.result;

import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/4/24 6:00 下午
 **/
@Data
public class SupplierQuotaAuditDetailResult {
    /**
     * id
     */
    private Integer id;
    /**
     * 客户名称
     */
    private String supplierName;
    /**
     * 更新时间
     */
    private String updatedTime;
    /**
     * 类型
     */
    private Integer type;
    /**
     * 状态
     */
    private Integer state;
    /**
     * 金额
     */
    private BigDecimal amount;
    /**
     * 打款账户
     */
    private String account;
    /**
     * 采购主体名称
     */
    private String purchaseSubjectName;
    /**
     * 来源
     */
    private String originName;
    /**
     * 备注
     */
    private String remark;
    /**
     * 创建人
     */
    private String createdBy;
    /**
     * 更新人
     */
    private String updatedBy;
    /**
     * 审核时间
     */
    private Date auditTime;
    /**
     * 图片
     */
    private List<String> images;
    /**
     * 打款凭证
     */
    private List<String> pzImages;
    /**
     * 创建时间
     */
    private Date createdTime;
    /**
     * 原因
     */
    private String reason;

}
