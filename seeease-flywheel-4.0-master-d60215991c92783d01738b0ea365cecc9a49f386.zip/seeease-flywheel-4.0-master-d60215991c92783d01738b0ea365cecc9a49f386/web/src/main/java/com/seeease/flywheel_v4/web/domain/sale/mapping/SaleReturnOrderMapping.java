package com.seeease.flywheel_v4.web.domain.sale.mapping;


import com.seeease.flywheel_v4.client.enums.BusinessUnitTypeEnums;
import com.seeease.flywheel_v4.web.app.excel.result.TobReturnOrderExportResult;
import com.seeease.flywheel_v4.web.app.excel.result.TocReturnOrderExportResult;
import com.seeease.flywheel_v4.web.app.sale.request.SaleReturnOrderCreateRequest;
import com.seeease.flywheel_v4.web.app.sale.request.ToBSaleReturnOrderCreateRequest;
import com.seeease.flywheel_v4.web.app.sale.request.ToCSaleReturnOrderCreateRequest;
import com.seeease.flywheel_v4.web.app.sale.result.ToBSaleReturnOrderDetailResult;
import com.seeease.flywheel_v4.web.app.sale.result.ToBSaleReturnOrderPageResult;
import com.seeease.flywheel_v4.web.app.sale.result.ToCSaleReturnOrderDetailResult;
import com.seeease.flywheel_v4.web.app.sale.result.ToCSaleReturnOrderPageResult;
import com.seeease.flywheel_v4.web.infrastructure.config.EnumMapping;
import com.seeease.flywheel_v4.web.infrastructure.config.MappingIgnore;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.enums.PurchaseDemandStateEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.entity.SaleOrder;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.entity.SaleOrderLine;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.entity.SaleReturnOrder;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.entity.SaleReturnOrderLine;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.enums.SaleModelEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.entity.SysBusinessUnit;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.MerchantWms;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.obj.ContactInfo;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.MerchantWmsModelEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.MerchantWmsTypeEnums;
import com.seeease.flywheel_v4.web.util.SerialNoGenerator;
import com.seeease.goods.rpc.request.SaleReturnSkuCreateRpcRequest;
import com.seeease.goods.rpc.result.SkuRpcResult;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;

import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;


/**
 * <p>
 * </p>
 *
 * @author 西门 游
 * @since 2023-10-27
 */
@Mapper(componentModel = "spring",
        builder = @Builder(disableBuilder = true),
        nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS,
        nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE,
        imports = {BusinessUnitTypeEnums.class,
                PurchaseDemandStateEnums.class,
                PurchaseDemandStateEnums.TransitionEnum.class,
                SerialNoGenerator.class, UUID.class})
public interface SaleReturnOrderMapping extends EnumMapping {

    SaleReturnOrderMapping INSTANCE = Mappers.getMapper(SaleReturnOrderMapping.class);


    SaleReturnOrder toEntity(
            SaleModelEnums saleModel,
            Integer storeId,
            Integer totalCount,
            BigDecimal totalAmount,
            String serialNo,
            SaleReturnOrderCreateRequest request,
            Integer buId
    );

    @Mapping(target = "originId",source = "returnOrder.buId")
    @Mapping(target = "state",ignore = true)
    @Mapping(target = "type",source = "type")
    @Mapping(target = "model",source = "model")
    @Mapping(target = "amount",source = "returnOrder.totalAmount")
    @Mapping(target = "toId",source = "returnOrder.storeId")
    @MappingIgnore
    MerchantWms toMerchantWms(
            SaleReturnOrder returnOrder,
            ContactInfo contactInfo,
            MerchantWmsTypeEnums type,
            MerchantWmsModelEnums model
    );

    @Mapping(target = "serialNo",source = "returnOrder.serialNo")
    @Mapping(target = "saleSerialNo",source = "saleOrder.serialNo")
    @Mapping(target = "state",source = "returnOrder.state")
    @Mapping(target = "totalAmount",source = "returnOrder.totalAmount")
    @Mapping(target = "createdBy",source = "returnOrder.createdBy")
    @Mapping(target = "createdTime",source = "returnOrder.createdTime")
    @Mapping(target = "finishTime",source = "returnOrder.finishTime")
    @Mapping(target = "id",source = "returnOrder.id")
    ToCSaleReturnOrderPageResult tocPageResult(
            SaleOrder saleOrder,
            SaleReturnOrder returnOrder,
            String buyerName,
            String originName);


    @Mapping(target = "serialNo",source = "returnOrder.serialNo")
    @Mapping(target = "saleSerialNo",source = "saleOrder.serialNo")
    @Mapping(target = "createdBy",source = "returnOrder.createdBy")
    @Mapping(target = "createdTime",source = "returnOrder.createdTime")
    @Mapping(target = "finishTime",source = "returnOrder.finishTime")
    @Mapping(target = "state",source = "returnOrder.state")
    @Mapping(target = "expressNo",source = "returnOrder.expressNo")
    @Mapping(target = "totalCount",source = "returnOrder.totalCount")
    @Mapping(target = "totalAmount",source = "returnOrder.totalAmount")
    @Mapping(target = "id",source = "returnOrder.id")
    ToCSaleReturnOrderDetailResult tocDetailResult(
            SaleReturnOrder returnOrder,
            SaleOrder saleOrder,
            String buyerName,
            String buyerPhone,
            String buyerAddress,
            String originName,
            List<ToCSaleReturnOrderDetailResult.Sku> skuList);

    @Mapping(target = "count",source = "returnCount")
    SaleReturnSkuCreateRpcRequest.Sku toTocReturnCreateRpcRequest(SaleReturnOrderCreateRequest.Sku sku);


    @Mapping(target = "serialNo",source = "returnOrder.serialNo")
    @Mapping(target = "state",source = "returnOrder.state")
    @Mapping(target = "totalAmount",source = "returnOrder.totalAmount")
    @Mapping(target = "createdBy",source = "returnOrder.createdBy")
    @Mapping(target = "createdTime",source = "returnOrder.createdTime")
    @Mapping(target = "finishTime",source = "returnOrder.finishTime")
    @Mapping(target = "expressNo",source = "returnOrder.expressNo")
    @Mapping(target = "id",source = "returnOrder.id")
    @Mapping(target = "mainSerialNo",source = "returnOrder.mainSerialNo")
    @Mapping(target = "saleSerialNo",source = "saleOrder.serialNo")
    ToBSaleReturnOrderPageResult tobPageResult(
            SaleOrder saleOrder,
            SaleReturnOrder returnOrder,
            String buyerName,
            String originName);

    @Mapping(target = "serialNo",source = "returnOrder.serialNo")
    @Mapping(target = "saleSerialNo",source = "saleOrder.serialNo")
    @Mapping(target = "createdBy",source = "returnOrder.createdBy")
    @Mapping(target = "createdTime",source = "returnOrder.createdTime")
    @Mapping(target = "finishTime",source = "returnOrder.finishTime")
    @Mapping(target = "state",source = "returnOrder.state")
    @Mapping(target = "expressNo",source = "returnOrder.expressNo")
    @Mapping(target = "totalCount",source = "returnOrder.totalCount")
    @Mapping(target = "totalAmount",source = "returnOrder.totalAmount")
    @Mapping(target = "id",source = "returnOrder.id")
    ToBSaleReturnOrderDetailResult tobDetailResult(
            SaleReturnOrder returnOrder,
            SaleOrder saleOrder,
            String buyerName,
            String buyerPhone,
            String buyerAddress,
            String originName,
            List<ToBSaleReturnOrderDetailResult.Sku> skuList
    );

    @Mapping(target = "saleLineId",source = "sku.lineId")
    @Mapping(target = "returnCount",source = "sku.count")
    @Mapping(target = "skuId",source = "sku.skuId")
    SaleReturnOrderCreateRequest.Sku toCreateRequest(
            ToCSaleReturnOrderCreateRequest.Sku sku,
            Integer saleId,
            SaleOrderLine line
    );

    @Mapping(target = "saleLineId",source = "saleLine.id")
    @Mapping(target = "saleId",source = "saleLine.saleId")
    @Mapping(target = "skuId",source = "saleLine.skuId")
    @Mapping(target = "returnCount",source = "paramSku.count")
    SaleReturnOrderCreateRequest.Sku toCreateRequest(
            SaleOrderLine saleLine,
            ToBSaleReturnOrderCreateRequest.Sku paramSku);

    @Mapping(target = "state",source = "state")
    @Mapping(target = "scType",source = "scType")
    @Mapping(target = "nodeState",source = "nodeState")
    @Mapping(target = "param",source = "param")
    @Mapping(target = "annexe",source = "annexe")
    @Mapping(target = "returnAmount",source = "line.returnAmount")
    @Mapping(target = "tocPrice",source = "line.tocPrice")
    @Mapping(target = "newSettlePrice",source = "line.newSettlePrice")
    @Mapping(target = "createdTime",source = "returnOrder.createdTime")
    @Mapping(target = "createdBy",source = "returnOrder.createdBy")
    @Mapping(target = "sellerName",source = "seller.name")
    @Mapping(target = "belongName",source = "belong.name")
    TocReturnOrderExportResult tocExportResult(SaleReturnOrderLine line,
                                               SkuRpcResult sku,
                                               ToCSaleReturnOrderPageResult returnOrder,
                                               String state,
                                               String scType,
                                               String nodeState,
                                               String param,
                                               String annexe,
                                               SysBusinessUnit seller,
                                               SysBusinessUnit belong,
                                               String psName
    );

    @Mapping(target = "state",source = "state")
    @Mapping(target = "scType",source = "scType")
    @Mapping(target = "nodeState",source = "nodeState")
    @Mapping(target = "param",source = "param")
    @Mapping(target = "annexe",source = "annexe")
    @Mapping(target = "returnAmount",source = "line.returnAmount")
    @Mapping(target = "tobPrice",source = "line.tobPrice")
    @Mapping(target = "newSettlePrice",source = "line.newSettlePrice")
    @Mapping(target = "createdTime",source = "returnOrder.createdTime")
    @Mapping(target = "createdBy",source = "returnOrder.createdBy")
    @Mapping(target = "sellerName",source = "seller.name")
    @Mapping(target = "belongName",source = "belong.name")
    TobReturnOrderExportResult tobExportResult(SaleReturnOrderLine line,
                                               SkuRpcResult sku,
                                               ToBSaleReturnOrderPageResult returnOrder,
                                               String state,
                                               String scType,
                                               String nodeState,
                                               String param,
                                               String annexe,
                                               SysBusinessUnit seller,
                                               SysBusinessUnit belong,
                                               String psName);
}
