package com.seeease.flywheel_v4.web.app.purchase.service;

import com.seeease.flywheel_v4.web.app.purchase.request.PurchaseOrderLinePageRequest;
import com.seeease.flywheel_v4.web.app.purchase.request.PurchaseOrderLineStateRequest;
import com.seeease.flywheel_v4.web.app.purchase.request.PurchaseOrderLineToNormalRequest;
import com.seeease.flywheel_v4.web.app.purchase.result.PurchaseOrderLinePageResult;
import com.seeease.springframework.PageResult;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/24/24 5:43 下午
 **/
public interface PurchaseOrderLineService {

    /**
     * 采购单行状态变更
     *
     * @return 变更结果
     */
    Boolean lineState(PurchaseOrderLineStateRequest request);
    /**
     * 采购订单行分页查询
     *
     * @return 分页结果
     */
    PageResult<PurchaseOrderLinePageResult> page(PurchaseOrderLinePageRequest request);

    /**
     * 采购-采购单行转正常
     *
     * @return 变更结果
     */
    Boolean lineToNormal(PurchaseOrderLineToNormalRequest request);
}
