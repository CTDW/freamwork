package com.seeease.flywheel_v4.web.adptor;

import com.seeease.flywheel_v4.web.app.wms.request.*;
import com.seeease.flywheel_v4.web.app.wms.result.*;
import com.seeease.flywheel_v4.web.app.wms.service.*;
import com.seeease.flywheel_v4.web.domain.wms.component.express.core.PrintResult;
import com.seeease.flywheel_v4.web.infrastructure.config.IdentifyLogPrinter;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.MerchantWmsModelEnums;
import com.seeease.springframework.PageResult;
import com.seeease.springframework.RequestValidGroup;
import com.seeease.springframework.SingleResponse;
import com.seeease.springframework.log.annotation.LogPrinter;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.validation.groups.Default;
import java.util.List;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 5/30/24 5:35 下午
 **/
@RestController
@RequestMapping("wms")
public class WmsController {

    @Resource
    private WmsRkService wmsRkService;
    @Resource
    private MerchantWmsService merchantWmsService;
    @Resource
    private WmsCkService wmsCkService;
    @Resource
    private WmsPhotoManagementService wmsPhotoManagementService;
    @Resource
    private WmsStoreLocationService wmsStoreLocationService;


    /**
     * 门店wms-入库管理分页查询
     *
     * @return 分页结果
     */
    @PostMapping("merchant/rk/page")
    @LogPrinter(scenario = "商家wms-入库管理分页查询", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<PageResult<MerchantWmsPageResult>> merchantRkPage(
            @RequestBody MerchantWmsPageRequest request) {
        request.setModel(MerchantWmsModelEnums.RK.getValue());
        return SingleResponse.of(merchantWmsService.page(request));
    }

    /**
     * 门店wms-出库管理分页查询
     *
     * @return 分页结果
     */
    @PostMapping("merchant/ck/page")
    @LogPrinter(scenario = "门店wms-出库管理分页查询", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<PageResult<MerchantWmsPageResult>> merchantCkPage(
            @RequestBody MerchantWmsPageRequest request) {
        request.setModel(MerchantWmsModelEnums.CK.getValue());
        return SingleResponse.of(merchantWmsService.page(request));
    }


    /**
     * 门店wms-出库管理详情
     *
     * @return 详情结果
     */
    @PostMapping("merchant/detail")
    @LogPrinter(scenario = "门店wms-出库管理详情", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<MerchantWmsDetailResult> merchantWmsDetail(
            @RequestBody MerchantWmsDetailRequest request) {

        return SingleResponse.of(merchantWmsService.detail(request));
    }


    /**
     * 门店wms- 取消操作
     *
     * @return 取消结果
     */
    @PostMapping("merchant/cancel")
    @LogPrinter(scenario = "门店wms- 取消操作", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<Boolean> merchantWmCancel(
            @RequestBody MerchantWmsCancelRequest request) {

        return SingleResponse.of(merchantWmsService.cancel(request));
    }


    /**
     * 门店wms-确认
     *
     * @return 操作结果
     */
    @PostMapping("merchant/confirm")
    @LogPrinter(scenario = "门店wms-确认", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<Boolean> merchantWmsState(
            @Validated @RequestBody MerchantWmsConfirmRequest request) {

        return SingleResponse.of(merchantWmsService.confirm(request));
    }


    /**
     * wms-商家出库打印
     *
     * @return 打印结果
     */
    @PostMapping("merchant/ck/print")
    @LogPrinter(scenario = "wms-出库打印", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<PrintResult> merchantCkPrint(
            @Validated @RequestBody WmsMerchantCkPrintRequest request) {

        return SingleResponse.of(merchantWmsService.merchantCkPrint(request));
    }


    /**
     * wms-入库管理分页查询
     *
     * @return 分页结果
     */
    @PostMapping("rk/page")
    @LogPrinter(scenario = "wms-入库管理分页查询", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<PageResult<WmsRkPageResult>> rkPage(
            @RequestBody WmsRkPageRequest request) {

        return SingleResponse.of(wmsRkService.page(request));
    }


    /**
     * wms-出库管理分页查询
     *
     * @return 分页结果
     */
    @PostMapping("ck/page")
    @LogPrinter(scenario = "wms-出库管理分页查询", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<PageResult<WmsCkPageResult>> ckPage(
            @RequestBody WmsCkPageRequest request) {

        return SingleResponse.of(wmsCkService.page(request));
    }



    /**
     * wms-rfid待出库列表
     *
     * @return 分页结果
     */
    @PostMapping("rfid/ck/list")
    @LogPrinter(scenario = "wms-rfid待出库列表", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<List<WmsRfidCkListResult>> rfidCkList() {
        return SingleResponse.of(wmsCkService.rfidCkList());
    }




    /**
     * wms-出库换表
     *
     * @return 分页结果
     */
    @PostMapping("ck/replace")
    @LogPrinter(scenario = "wms-出库换表", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<Boolean> ckReplace(
         @Validated  @RequestBody WmsCkReplaceRequest request) {

        return SingleResponse.of(wmsCkService.ckReplace(request));
    }



    /**
     * wms-出库打印
     *
     * @return 打印结果
     */
    @PostMapping("ck/print")
    @LogPrinter(scenario = "wms-出库打印", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<PrintResult> ckPrint(
            @Validated @RequestBody WmsCkPrintRequest request) {

        return SingleResponse.of(wmsCkService.ckPrint(request));
    }


    /**
     * wms-出库取消
     *
     * @return 取消结果
     */
    @PostMapping("ck/cancel")
    @LogPrinter(scenario = "wms-出库取消", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<Boolean> ckCancel(
            @Validated @RequestBody WmsCkCancelRequest request) {
        return SingleResponse.of(wmsCkService.cancel(request));
    }


    /**
     * wms-出库打单回滚到集单状态
     *
     * @return 操作结果
     */
    @PostMapping("ck/rollback")
    @LogPrinter(scenario = "wms-出库打单回滚到集单状态", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<Boolean> ckRollback(
            @Validated @RequestBody WmsCkRollbackRequest request) {
        return SingleResponse.of(wmsCkService.rollBack(request));
    }

    /**
     * wms-出库上传快递单号
     *
     * @return 操作结果
     */
    @PostMapping("ck/upload/express")
    @LogPrinter(scenario = "wms-出库上传快递单号", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<Boolean> ckUploadExpress(
            @Validated @RequestBody WmsCkUploadExpressRequest request) {
        return SingleResponse.of(wmsCkService.uploadExpress(request));
    }

    /**
     * wms-出库单出库
     *
     * @return 操作结果
     */
    @PostMapping("ck")
    @LogPrinter(scenario = " wms-出库单出库", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<Boolean> ck(
            @Validated @RequestBody WmsCkRequest request) {
        return SingleResponse.of(wmsCkService.ck(request));
    }


    /**
     * wms-出库集单操作
     *
     * @return 集单结果
     */
    @PostMapping("ck/jd")
    @LogPrinter(scenario = "wms-出库集单操作", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<Boolean> rkJd(
            @Validated @RequestBody WmsJdRequest request) {

        return SingleResponse.of(wmsCkService.jd(request));
    }


    /**
     * wms-入库单状态变更
     *
     * @return 变更结果
     */
    @PostMapping("rk/state")
    @LogPrinter(scenario = "wms-入库单状态变更", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<Boolean> rkState(
            @Validated @RequestBody WmsRkStateRequest request) {

        return SingleResponse.of(wmsRkService.state(request));
    }


    /**
     * wms-待入库单据入库数量修改
     *
     * @return 变更结果
     */
    @PostMapping("rk/count/update")
    @LogPrinter(scenario = "wms-待入库单据入库数量修改", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<Boolean> rkCountUpdate(
            @Validated @RequestBody WmsRkCountUpdateRequest request) {

        return SingleResponse.of(wmsRkService.countUpdate(request));
    }


    /**
     * wms-入库拍照任务分页
     *
     * @return 分页结果
     */
    @PostMapping("photo/management/page")
    @LogPrinter(scenario = "wms-入库拍照任务分页", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<PageResult<WmsPhotoManagementPageResult>> photoManagementPage(
            @Validated @RequestBody WmsPhoneManagementPageRequest request) {

        return SingleResponse.of(wmsPhotoManagementService.page(request));
    }


    /**
     * wms-入库拍照
     *
     * @return 拍照结果
     */
    @PostMapping("rk/take/photo")
    @LogPrinter(scenario = "wms-入库拍照", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<Boolean> takePhoto(
            @Validated @RequestBody WmsTakePhotoRequest request) {

        return SingleResponse.of(wmsPhotoManagementService.takePhoto(request));
    }


    /**
     * wms-批量拍照通过
     *
     * @return 通过结果
     */
    @PostMapping("rk/batch/take/photo")
    @LogPrinter(scenario = "wms-入库拍照", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<Boolean> batchTakePhoto(
            @Validated @RequestBody WmsBatchTakePhotoRequest request) {

        return SingleResponse.of(wmsPhotoManagementService.batchTakePhoto(request));
    }


    /**
     * wms-库区树结构查询
     *
     * @return 库区树返回
     */
    @PostMapping("store/area/tree")
    @LogPrinter(scenario = "wms-库区树结构查询", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<List<WmsStoreAreaTreeResult>> storeAreaTree() {

        return SingleResponse.of(wmsStoreLocationService.areaTree());
    }


    /**
     * wms-库区列表查询
     *
     * @return 列表结果
     */
    @PostMapping("store/area/list")
    @LogPrinter(scenario = "wms-库区列表查询", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<List<WmsStoreAreaListResult>> storeAreaList(
            @RequestBody WmsStoreAreaListRequest request
    ) {

        return SingleResponse.of(wmsStoreLocationService.areaList(request));
    }


    /**
     * wms-库区创建
     *
     * @return 创建结果
     */
    @PostMapping("store/area/create")
    @LogPrinter(scenario = "wms-库区创建", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<Boolean> storeAreaCreate(
            @Validated({RequestValidGroup.Create.class, Default.class})
            @RequestBody WmsStoreAreaSubmitRequest request
    ) {

        return SingleResponse.of(wmsStoreLocationService.areaCreate(request));
    }


    /**
     * wms-库区更新
     *
     * @return 更新结果
     */
    @PostMapping("store/area/update")
    @LogPrinter(scenario = "wms-库区更新", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<Boolean> storeAreaUpdate(
            @Validated({RequestValidGroup.Update.class, Default.class})
            @RequestBody WmsStoreAreaSubmitRequest request
    ) {

        return SingleResponse.of(wmsStoreLocationService.areaUpdate(request));
    }

    /**
     * wms-库区删除
     *
     * @return 删除结果
     */
    @PostMapping("store/area/del")
    @LogPrinter(scenario = "wms-库区删除", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<Boolean> storeAreaDel(
            @Validated(RequestValidGroup.Deleted.class) @RequestBody WmsStoreAreaSubmitRequest request
    ) {
        return SingleResponse.of(wmsStoreLocationService.areaDel(request.getId()));
    }


    /**
     * wms-库位分页
     *
     * @return 删除结果
     */
    @PostMapping("store/location/page")
    @LogPrinter(scenario = "wms-库位分页", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<PageResult<WmsStoreLocationPageResult>> storeLocationPage(
            @Validated @RequestBody WmsStoreLocationPageRequest request
    ) {
        return SingleResponse.of(wmsStoreLocationService.locationPage(request));
    }


    /**
     * wms-库位新增
     *
     * @return 新增结果
     */
    @PostMapping("store/location/create")
    @LogPrinter(scenario = "wms-库位新增", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<Boolean> storeLocationCreate(
            @Validated @RequestBody WmsStoreLocationSubmitRequest request
    ) {
        return SingleResponse.of(wmsStoreLocationService.locationCreate(request));
    }


    /**
     * wms-库位更新
     *
     * @return 更新结果
     */
    @PostMapping("store/location/update")
    @LogPrinter(scenario = "wms-库位更新", customPrinter = IdentifyLogPrinter.class)
    public SingleResponse<Boolean> storeLocationUpdate(
            @Validated({Default.class, RequestValidGroup.Update.class})
            @RequestBody WmsStoreLocationSubmitRequest request
    ) {
        return SingleResponse.of(wmsStoreLocationService.locationUpdate(request));
    }


}
