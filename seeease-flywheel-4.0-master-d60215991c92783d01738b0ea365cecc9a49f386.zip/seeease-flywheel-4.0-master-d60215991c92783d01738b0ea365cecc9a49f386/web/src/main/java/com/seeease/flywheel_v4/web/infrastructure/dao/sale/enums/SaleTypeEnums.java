package com.seeease.flywheel_v4.web.infrastructure.dao.sale.enums;

import com.baomidou.mybatisplus.annotation.IEnum;
import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * <p>销售方式</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/6/24 3:06 下午
 **/
@Getter
@AllArgsConstructor
public enum SaleTypeEnums implements IEnum<Integer> {
    XX(101,"线下"),
    DJ(102,"定金"),
    ZP(103,"赠品"),
    PT(104,"平台"),
    ZC(201,"正常"),
    JS(202,"寄售"),
    FD(203,"返点")
    ;

    private Integer value;
    private String desc;

}
