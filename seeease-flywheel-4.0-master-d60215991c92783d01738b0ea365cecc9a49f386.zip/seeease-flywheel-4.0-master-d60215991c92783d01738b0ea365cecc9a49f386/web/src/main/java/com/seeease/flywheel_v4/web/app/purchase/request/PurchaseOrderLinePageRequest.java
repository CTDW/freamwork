package com.seeease.flywheel_v4.web.app.purchase.request;


import com.seeease.springframework.PageRequest;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.validation.constraints.NotNull;

/**
 * @ Description   :
 * @ Author        :  西门 游
 * @ CreateDate    :  6/6/24
 * @ Version       :  1.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class PurchaseOrderLinePageRequest extends PageRequest {

    /**
     * 采购单号
     */
    private String serialNo;

    /**
     * 节点状态
     */
    @NotNull(message = "状态不能为空")
    private Integer nodeState;
    /**
     * sku编码
     */
    private String skuCode;

    /**
     * 是否查看自己创建的采购单
     */
    private Boolean mine = false;




}
