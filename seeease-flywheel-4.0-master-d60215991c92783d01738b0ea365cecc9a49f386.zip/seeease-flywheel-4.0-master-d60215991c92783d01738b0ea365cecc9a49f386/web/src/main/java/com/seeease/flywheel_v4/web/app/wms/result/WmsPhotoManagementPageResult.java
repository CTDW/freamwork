package com.seeease.flywheel_v4.web.app.wms.result;

import com.seeease.goods.rpc.request.SkuAnnexeRpcResult;
import com.seeease.goods.rpc.result.ProductParamRpcResult;
import lombok.Data;

import java.util.Date;
import java.util.List;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/4/24 6:00 下午
 **/
@Data
public class WmsPhotoManagementPageResult {
    /**
     * id
     */
    private Integer id;
    /**
     * 状态
     */
    private Integer state;
    /**
     * skuId
     */
    private Integer skuId;
    /**
     * 业务编号
     */
    private String serialNo;
    /**
     * 业务类型
     */
    private Integer type;
    /**
     * 蜥蜴编码
     */
    private String xyCode;
    /**
     * 商品名称
     */
    private String goodsName;
    /**
     * 类目名称
     */
    private String categoryName;
    /**
     * 图片
     */
    private String spuImage;
    /**
     * 品牌名称
     */
    private String brandName;
    /**
     * 是否唯一码管控
     */
    private Integer uniqueType;
    /**
     * spu图片
     */
    private List<String> spuImages;
    /**
     * sku图片
     */
    private List<String> skuImages;

    /**
     * sku参数列表
     */
    private List<ProductParamRpcResult> skuParams;
    /**
     * 附件
     */
    private List<SkuAnnexeRpcResult> annexe;
    /**
     * 唯一码
     */
    private String skuCode;
    /**
     * 快递单号
     */
    private String expressNo;
    /**
     * 入库数量
     */
    private Integer count;
    /**
     * 货号
     */
    private String goodsCode;
    /**
     * 创建人
     */
    private String updatedBy;
    /**
     * 创建时间
     */
    private Date createdTime;
    /**
     * 入库时间
     */
    private Date updatedTime;

}
