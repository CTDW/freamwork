package com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.seeease.seeeaseframework.mybatis.domain.BaseDomain;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;

/**
 * 供应商保证金
 */
@EqualsAndHashCode(callSuper = true)
@TableName(value = "v4_ops_supplier_quota", autoResultMap = true)
@Data
public class SupplierQuota extends BaseDomain {
    @TableId(type = IdType.AUTO)
    private Integer id;
    /**
     * 类型
     */
    private Integer supplierId;
    /**
     * 寄售余额
     */
    private BigDecimal jsQuota;
    /**
     * 正常余额
     */
    private BigDecimal normalQuota;


}