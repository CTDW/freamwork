package com.seeease.flywheel_v4.web.domain.wms.component.express.core;

/**
 * <p>快递能力接口</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 9/20/24 4:53 下午
 **/
public interface ExpressChannel<R> {

    enum Channel {
        KS_SF, //快手顺丰
        DY_SF, //抖音顺丰
        SF    //普通顺丰
    }

    /**
     * 获取下单渠道
     * @return
     */
    Channel getChannel();

    /**
     * 下单
     */
    PlaceOrderResult placeOrder(PlaceOrderDto dto);

    /**
     * 获取打印面单信息
     */
    R printInfo(PlaceOrderResult placeOrderResult);

}
