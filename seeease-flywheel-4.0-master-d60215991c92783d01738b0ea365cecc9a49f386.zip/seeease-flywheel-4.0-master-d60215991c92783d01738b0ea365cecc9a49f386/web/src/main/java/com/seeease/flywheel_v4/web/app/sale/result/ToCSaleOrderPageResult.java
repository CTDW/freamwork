package com.seeease.flywheel_v4.web.app.sale.result;


import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;


@Data
public class ToCSaleOrderPageResult  {

    /**
     * 销售单id
     */
    private Integer id;
    /**
     * 销售单号
     */
    private String serialNo;
    /**
     * 三方单号
     */
    private String thirdPartyNo;

    /**
     * 第一销售人
     */
    private String sellerA;

    /**
     * 第二销售人
     */
    private String sellerB;

    /**
     * 第三销售人
     */
    private String sellerC;

    /**
     * 状态
     */
    private Integer state;
    /**
     * 客户名称
     */
    private String buyerName;
    /**
     * 总金额
     */
    private BigDecimal totalAmount;
    /**
     * 销售渠道
     */
    private Integer scType;
    /**
     * 销售方式
     */
    private Integer sellType;
    /**
     * 销售渠道名称
     */
    private String scName;
    /**
     * 快递单号
     */
    private String expressNo;
    /**
     * 三方订单异常信息
     */
    private String unusual;
    /**
     * 创建人
     */
    private String createdBy;
    /**
     * 创建时间
     */
    private Date createdTime;
    /**
     * 完成时间
     */
    private Date finishTime;

    /**
     * 订单来源
     */
    private String originName;



}
