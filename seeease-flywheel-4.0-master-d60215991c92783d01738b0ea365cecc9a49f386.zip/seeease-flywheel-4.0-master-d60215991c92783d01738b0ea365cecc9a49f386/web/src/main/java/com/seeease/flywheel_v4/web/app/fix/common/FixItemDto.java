package com.seeease.flywheel_v4.web.app.fix.common;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @Description 维修单-维修项目
 * @Date 2024-10-4 18:22
 * @Author by hk
 */
@Data
public class FixItemDto implements Serializable {

    @ApiModelProperty(name = "维修项目名称")
    private String itemName;

    @ApiModelProperty(name = "默认维修价")
    private BigDecimal defaultFixPrice;
}
