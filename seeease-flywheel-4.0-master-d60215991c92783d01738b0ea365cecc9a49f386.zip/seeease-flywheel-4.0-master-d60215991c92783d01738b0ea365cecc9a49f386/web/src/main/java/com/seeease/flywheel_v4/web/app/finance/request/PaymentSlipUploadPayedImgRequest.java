package com.seeease.flywheel_v4.web.app.finance.request;



import lombok.Data;
import javax.validation.constraints.NotNull;

/**
 * @ Description   :
 * @ Author        :  西门 游
 * @ CreateDate    :  6/6/24
 * @ Version       :  1.0
 */

@Data
public class PaymentSlipUploadPayedImgRequest {
    /**
     * 申请打款单id
     */
    @NotNull(message = "id不能为空")
    private Integer id;

    /**
     * 打款凭证图片
     */
    @NotNull(message = "打款凭证图片不能为空")
    private String payedImg;



}
