package com.seeease.flywheel_v4.web.domain.finance.strategy.paymentSlip;

import com.google.common.collect.Lists;
import com.seeease.flywheel_v4.client.enums.PurchaseTypeEnums;
import com.seeease.flywheel_v4.web.app.finance.request.PaymentSlipSubmitRequest;
import com.seeease.flywheel_v4.web.infrastructure.dao.RepositoryFactory;
import com.seeease.flywheel_v4.web.infrastructure.dao.finance.entity.FinancePaymentSlip;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.entity.PurchaseOrder;
import com.seeease.flywheel_v4.web.infrastructure.listener.purchase.StartingStateListener;
import com.seeease.springframework.exception.ValidationUtil;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

/**
 * 申请打款单创建后置策略A
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/13/24 11:20上午
 **/
@Component
public class PostCreateStrategyA implements PostCreateStrategy {

    @Resource
    private RepositoryFactory repositoryFactory;
    @Resource
    private StartingStateListener listener;

    List<PurchaseTypeEnums> condition = Lists.newArrayList(
            PurchaseTypeEnums.TH_CG_DJ,
            PurchaseTypeEnums.TH_CG_BH,
            PurchaseTypeEnums.GR_HS,
            PurchaseTypeEnums.GR_HG
    );

    @Override
    public void post(PaymentSlipSubmitRequest request, FinancePaymentSlip paymentSlip) {

        /**
         * 该类型的策略在创建申请打款单后 推动采购状态变更事件
         * 注意 事件推送后状态不一定会变 因为该事件要基于 快递单号上传 & 创建完申请打款单 状态才会变更成功
         */
        PurchaseOrder purchaseOrder = repositoryFactory.getPurchaseOrderRepository().findById(request.getPurchaseId());
        purchaseOrder.setFpsId(paymentSlip.getId());
        purchaseOrder.setFpsSerialNo(paymentSlip.getSerialNo());

        ValidationUtil.isTrue(
                repositoryFactory.getPurchaseOrderRepository().submit(purchaseOrder),
                "采购订单绑定申请打款单数据失败"
        );

        //分布式事务和事件监听冲突所以通过bean方法提交
        listener.onEvent(new StartingStateListener.Event(this,request.getPurchaseId()));

    }


    @Override
    public Boolean match(PurchaseTypeEnums purchaseTypeEnums) {
        return condition.contains(purchaseTypeEnums);
    }
}
