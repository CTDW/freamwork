package com.seeease.flywheel_v4.web.domain.transfer.mapping;


import com.seeease.flywheel_v4.client.enums.BusinessUnitTypeEnums;
import com.seeease.flywheel_v4.web.app.transfer.request.TransferCreateRequest;
import com.seeease.flywheel_v4.web.app.transfer.result.TransferDetailResult;
import com.seeease.flywheel_v4.web.infrastructure.config.EnumMapping;
import com.seeease.flywheel_v4.web.infrastructure.config.MappingIgnore;
import com.seeease.flywheel_v4.web.infrastructure.dao.transfer.entity.TransferOrderLine;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.MerchantWmsLine;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.MerchantWmsTypeEnums;
import com.seeease.goods.rpc.enums.SkuNodeStateEnums;
import com.seeease.goods.rpc.request.TransferSkuFinishRpcRequest;
import com.seeease.goods.rpc.result.SkuCreateRpcResult;
import com.seeease.goods.rpc.result.SkuRpcResult;
import com.seeease.seeeaseframework.mybatis.domain.WhetherEnum;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;

import java.math.BigDecimal;


/**
 * <p>
 * 商品附件
 * </p>
 *
 * @author 西门 游
 * @since 2023-10-27
 */
@Mapper(componentModel = "spring",
        builder = @Builder(disableBuilder = true),
        nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS,
        nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE,
        imports = {BusinessUnitTypeEnums.class,
                BigDecimal.class, SkuNodeStateEnums.class, MerchantWmsTypeEnums.class, WhetherEnum.class})
public interface TransferOrderLineMapping extends EnumMapping {

    TransferOrderLineMapping INSTANCE = Mappers.getMapper(TransferOrderLineMapping.class);

    @MappingIgnore
    @Mapping(target = "skuId", source = "sku.id")
    @Mapping(target = "endState", expression = "java(WhetherEnum.NO)")
    @Mapping(target = "nodeState", expression = "java(SkuNodeStateEnums.DB_ZT)")
    TransferOrderLine toEntity(TransferCreateRequest.Sku paramSku,
                               SkuCreateRpcResult sku,
                               Integer transferId,
                               BigDecimal profit
    );


    @Mapping(target = "lineId", source = "line.id")
    @Mapping(target = "skuId", source = "sku.id")
    @Mapping(target = "count", source = "line.count")
    @Mapping(target = "settlePrice", source = "line.settlePrice")
    @Mapping(target = "newSettlePrice", source = "line.newSettlePrice")
    TransferDetailResult.Sku toDetailResult(TransferOrderLine line, SkuRpcResult sku);

    @MappingIgnore
    @Mapping(target = "endState", expression = "java(WhetherEnum.NO)")
    @Mapping(target = "price", source = "line.transferPrice")
    @Mapping(target = "nodeState", source = "nodeState.value")
    MerchantWmsLine toMerchantWmsLine(TransferOrderLine line,
                                      SkuNodeStateEnums nodeState);

    TransferSkuFinishRpcRequest.Sku toSkuFinishRequest(TransferOrderLine line);
}
