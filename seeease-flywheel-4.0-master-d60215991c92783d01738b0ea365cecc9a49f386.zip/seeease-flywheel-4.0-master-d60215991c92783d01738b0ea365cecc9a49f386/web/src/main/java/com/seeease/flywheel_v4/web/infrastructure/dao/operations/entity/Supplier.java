package com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.enums.SupplierTypeEnums;
import com.seeease.seeeaseframework.mybatis.domain.BaseDomain;
import com.seeease.seeeaseframework.mybatis.domain.WhetherEnum;
import com.seeease.seeeaseframework.mybatis.type.JsonTypeHandler;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

/**
 * 供应商
 */
@EqualsAndHashCode(callSuper = true)
@TableName(value = "v4_ops_supplier", autoResultMap = true)
@Data
public class Supplier extends BaseDomain {
    @TableId(type = IdType.AUTO)
    private Integer id;
    /**
     * 供应商类型 1:个人 2.企业
     */
    private SupplierTypeEnums type;
    /**
     * 供应商名称
     */
    private String name;
    /**
     * 状态
     */
    private WhetherEnum state;
    /**
     * 省
     */
    private String province;
    /**
     * 市
     */
    private String city;
    /**
     * 县
     */
    private String area;
    /**
     * 街道
     */
    private String street;
    /**
     * 详细地址
     */
    private String address;
    /**
     * 省市县id列表
     */
    @TableField(typeHandler = JsonTypeHandler.class)
    private List<Integer> areaCodes;
    /**
     * 备注说明
     */
    private String remark;



    public String getCompleteAddress(){
        String res ="";
        if (null != province){
            res += province + " ";
        }
        if (null != city){
            res += city + " ";
        }
        if (null != area){
            res += area + " ";
        }
        if (null != street){
            res += street + " ";
        }
        if (null != address){
            res += address;
        }
        return res;
    }


}