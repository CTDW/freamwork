package com.seeease.flywheel_v4.web.domain.transfer.mapping;


import com.seeease.flywheel_v4.web.app.excel.result.TransferOrderExportResult;
import com.seeease.flywheel_v4.web.app.excel.result.TransferSkuImportResult;
import com.seeease.flywheel_v4.web.app.transfer.request.TransferCreateRequest;
import com.seeease.flywheel_v4.web.app.transfer.request.TransferPageRequest;
import com.seeease.flywheel_v4.web.app.transfer.result.TransferDetailResult;
import com.seeease.flywheel_v4.web.app.transfer.result.TransferPageResult;
import com.seeease.flywheel_v4.web.domain.operations.OpsDomain;
import com.seeease.flywheel_v4.web.domain.wms.observer.base.Ext;
import com.seeease.flywheel_v4.web.infrastructure.config.EnumMapping;
import com.seeease.flywheel_v4.web.infrastructure.config.MappingIgnore;
import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.entity.SysBusinessUnit;
import com.seeease.flywheel_v4.web.infrastructure.dao.transfer.entity.TransferOrder;
import com.seeease.flywheel_v4.web.infrastructure.dao.transfer.entity.TransferOrderLine;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.MerchantWms;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.WmsCk;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.WmsRk;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.obj.ContactInfo;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.MerchantWmsModelEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.MerchantWmsTypeEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.WmsCkTypeEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.WmsRkTypeEnums;
import com.seeease.flywheel_v4.web.util.SerialNoGenerator;
import com.seeease.goods.rpc.enums.SkuNodeStateEnums;
import com.seeease.goods.rpc.request.SkuRpcRequest;
import com.seeease.goods.rpc.request.TransferSkuCreateRpcRequest;
import com.seeease.goods.rpc.result.SkuRpcResult;
import com.seeease.springframework.utils.MultiUtils;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;

import java.math.BigDecimal;
import java.util.List;


/**
 * <p>
 * 商品附件
 * </p>
 *
 * @author 西门 游
 * @since 2023-10-27
 */
@Mapper(componentModel = "spring",
        builder = @Builder(disableBuilder = true),
        nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS,
        nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE,
        imports = {SerialNoGenerator.class,
                SerialNoGenerator.Type.class,
                MultiUtils.class,
                WmsCkTypeEnums.class,
                SkuNodeStateEnums.class,
                WmsRkTypeEnums.class,
                MerchantWmsModelEnums.class,
                MerchantWmsTypeEnums.class})
public interface TransferOrderMapping extends EnumMapping {

    TransferOrderMapping INSTANCE = Mappers.getMapper(TransferOrderMapping.class);


    @Mapping(target = "serialNo", expression = "java(SerialNoGenerator.generalSerial(SerialNoGenerator.Type.DB))")
    TransferOrder toEntity(TransferCreateRequest request,
                           int totalCount,
                           BigDecimal totalSettlePrice,
                           BigDecimal totalNewSettlePrice,
                           BigDecimal totalProfit,
                           Integer buId);

    OpsDomain.SkuTransferCheckParam toTransferQuotaCheckParam(TransferCreateRequest.Sku paramSku);

    @Mapping(source = "nodeState", target = "nodeState")
    TransferSkuCreateRpcRequest toTransferSKuCreate(
            TransferCreateRequest request,
            String serialNo,
            SkuNodeStateEnums nodeState

    );


    TransferSkuCreateRpcRequest.Sku toTransferSKuCreate(TransferCreateRequest.Sku sku);

    List<TransferSkuCreateRpcRequest.Sku> toTransferSKuCreate(List<TransferCreateRequest.Sku> sku);


    @MappingIgnore
    @Mapping(target = "type", expression = "java(WmsCkTypeEnums.DB)")
    @Mapping(target = "nodeState", expression = "java(SkuNodeStateEnums.JD)")
    @Mapping(target = "storeId", source = "transferOrder.fromId")
    WmsCk toWmsCk(TransferOrder transferOrder, TransferOrderLine line, Integer originId);

    @Mapping(target = "state", ignore = true)
    SkuRpcRequest toSkuRpcRequest(TransferPageRequest request);

    TransferPageResult toPageResult(TransferOrder transferOrder,
                                    String toName,
                                    String fromName,
                                    String originName );

    @Mapping(target = "id", source = "transferOrder.id")
    TransferDetailResult toDetailResult(TransferOrder transferOrder,
                                        List<TransferDetailResult.Sku> skuList,
                                        String toName,
                                        String fromName);




    @MappingIgnore
    @Mapping(target = "state", ignore = true)
    @Mapping(target = "spTime", ignore = true)
    @Mapping(target = "remark", ignore = true)
    @Mapping(target = "originId", source = "transferOrder.buId")
    @Mapping(target = "transitionStateEnum", ignore = true)
    @Mapping(target = "type", source = "type")
    @Mapping(target = "amount", source = "transferOrder.totalNewSettlePrice")
    @Mapping(target = "toId", source = "toId")
    @Mapping(target = "fromId", source = "fromId")
    MerchantWms toMerchantWms(TransferOrder transferOrder,
                              ContactInfo contactInfo,
                              MerchantWmsModelEnums model,
                              MerchantWmsTypeEnums type,
                              Integer fromId,
                              Integer toId
    );


    @Mapping(target = "address", expression = "java(fromUnit.getAddressDetail())")
    ContactInfo toMerchantWmsContactInfo(SysBusinessUnit fromUnit);

    @MappingIgnore
    @Mapping(target = "type", expression = "java(WmsRkTypeEnums.DB)")
    @Mapping(target = "nodeState", expression = "java(SkuNodeStateEnums.DSH)")
    @Mapping(target = "buId", source = "order.buId")
    WmsRk toWmsRk(TransferOrder order,
                  TransferOrderLine line,
                  Integer storeId,
                  String expressNo
    );

    @Mapping(target = "transferPrice", source = "newSettlePrice")
    TransferSkuImportResult toImportResult(SkuRpcResult sku);

    @Mapping(target = "state", source = "state")
    @Mapping(target = "nodeState", source = "nodeState")
    @Mapping(target = "annexe", source = "annexe")
    @Mapping(target = "type", source = "type")
    @Mapping(target = "param", source = "param")
    @Mapping(target = "createdTime", source = "order.createdTime")
    @Mapping(target = "createdBy", source = "order.createdBy")
    @Mapping(target = "settlePrice", source = "line.settlePrice")
    @Mapping(target = "newSettlePrice", source = "line.newSettlePrice")
    TransferOrderExportResult toExportResult(TransferOrderLine line,
                                             TransferPageResult order,
                                             SkuRpcResult sku,
                                             String state,
                                             String nodeState,
                                             String annexe,
                                             String param,
                                             String type);

    @Mapping(target = "address", expression = "java(to.getAddressDetail())")
    @Mapping(target = "name",source = "to.name")
    @Mapping(target = "phone",source = "to.phone")
    @Mapping(target = "province",source = "to.province")
    @Mapping(target = "city",source = "to.city")
    @Mapping(target = "area",source = "to.area")
    @Mapping(target = "street",source = "to.street")
    @Mapping(target = "spAddress",expression = "java(from.getAddressDetail())")
    @Mapping(target = "spPhone",source = "from.phone")
    @Mapping(target = "spProvince",source = "from.province")
    @Mapping(target = "spCity",source = "from.city")
    @Mapping(target = "spArea",source = "from.area")
    @Mapping(target = "spStreet",source = "from.street")
    @Mapping(target = "spName",source = "from.name")
    @Mapping(target = "qualityWay", constant = "1")
    @Mapping(target = "remark", source = "remark")
    Ext toCkExt(SysBusinessUnit to, SysBusinessUnit from,String remark);
}
