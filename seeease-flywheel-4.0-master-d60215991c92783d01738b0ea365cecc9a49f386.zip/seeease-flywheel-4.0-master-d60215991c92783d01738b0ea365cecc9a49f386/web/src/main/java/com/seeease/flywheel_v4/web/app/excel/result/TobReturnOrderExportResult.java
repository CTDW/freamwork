package com.seeease.flywheel_v4.web.app.excel.result;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.format.DateTimeFormat;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 9/11/24 5:00 下午
 **/
@Data
public class TobReturnOrderExportResult implements Serializable {

    @ExcelProperty("销售单号")
    private String serialNo;

    @ExcelProperty("订单号")
    private String thirdPartyNo;

    @ExcelProperty("状态")
    private String state;

    @ExcelProperty("业务伙伴")
    private String buyerName;

    @ExcelProperty("销售单号")
    private String saleSerialNo;

    @ExcelProperty("货号")
    private String goodsCode;

    @ExcelProperty("采购主体名称")
    private String psName;

    @ExcelProperty("金额")
    private String totalAmount;

    @ExcelProperty("销售渠道")
    private String scType;

    @ExcelProperty("渠道名称")
    private String scName;

    @ExcelProperty("快递单号")
    private String expressNo;

    @ExcelProperty("商品名称")
    private String goodsName;

    @ExcelProperty("品牌")
    private String brandName;

    @ExcelProperty("类目")
    private String categoryName;

    @ExcelProperty("入库参数")
    private String param;

    @ExcelProperty("唯一码")
    private String skuCode;

    @ExcelProperty("数量")
    private Integer count;

    @ExcelProperty("附件")
    private String annexe;

    @ExcelProperty("退款金额")
    private String returnAmount;

    @ExcelProperty("同行价")
    private String tobPrice;

    @ExcelProperty("最新结算价")
    private String newSettlePrice;

    @ExcelProperty("流程节点")
    private String nodeState;

    @ExcelProperty("经营权")
    private String sellerName;

    @ExcelProperty("商品所在")
    private String belongName;

    @ExcelProperty("订单来源")
    private String originName;

    @DateTimeFormat("yyyy-MM-dd HH:mm:ss")
    @ExcelProperty("创建时间")
    private Date createdTime;

    @ExcelProperty("创建人")
    private String createdBy;








}
