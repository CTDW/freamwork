package com.seeease.flywheel_v4.web.domain.excel.strategy.export;

import com.alibaba.cola.extension.Extension;
import com.seeease.flywheel_v4.web.app.excel.result.TocOrderExportResult;
import com.seeease.flywheel_v4.web.app.sale.request.ToCSaleOrderPageRequest;
import com.seeease.flywheel_v4.web.app.sale.result.ToCSaleOrderPageResult;
import com.seeease.flywheel_v4.web.app.sale.service.SaleOrderService;
import com.seeease.flywheel_v4.web.domain.excel.ExcelDomain;
import com.seeease.flywheel_v4.web.domain.excel.core.ExportExtPtl;
import com.seeease.flywheel_v4.web.domain.sale.mapping.SaleOrderMapping;
import com.seeease.flywheel_v4.web.infrastructure.dao.RepositoryFactory;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.entity.SaleOrderLine;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.enums.SaleStateEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.entity.SysBusinessUnit;
import com.seeease.flywheel_v4.web.infrastructure.dao.sys_config.enums.SaleChannelTypeEnums;
import com.seeease.goods.rpc.SkuFacade;
import com.seeease.goods.rpc.request.SkuRpcRequest;
import com.seeease.goods.rpc.result.SkuRpcResult;
import com.seeease.seeeaseframework.mybatis.utils.EnumUtils;
import com.seeease.springframework.utils.MultiUtils;
import org.apache.dubbo.config.annotation.DubboReference;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 9/12/24 10:42 上午
 **/
@Service
@Extension(bizId = "export", useCase = "saleCOrder")
public class TocSaleOrderExport implements ExportExtPtl<ToCSaleOrderPageRequest, TocOrderExportResult> {

    @Resource
    private SaleOrderService saleOrderService;
    @Resource
    private RepositoryFactory repositoryFactory;
    @DubboReference(version = "1.0.0", check = false)
    private SkuFacade skuFacade;
    @Resource
    private ExcelDomain excelDomain;

    @Override
    public Class<ToCSaleOrderPageRequest> getRequestClass() {
        return ToCSaleOrderPageRequest.class;
    }

    @Override
    public Class<TocOrderExportResult> getResultClass() {
        return TocOrderExportResult.class;
    }

    @Override
    public String getFileName() {
        return "销售单导出";
    }

    @Override
    public List<TocOrderExportResult> handle(ToCSaleOrderPageRequest request) {
        //step_1 调用toc销售分页查询
        request.setLimit(Integer.MAX_VALUE);
        List<ToCSaleOrderPageResult> saleOrders = saleOrderService.tocPage(request).getResult();
        if (saleOrders.isEmpty()) {
            return Collections.emptyList();
        }
        Map<Integer, ToCSaleOrderPageResult> saleOrderMap = MultiUtils.toMap(
                saleOrders,
                ToCSaleOrderPageResult::getId
        );


        //step_2 查询销售单行
        Set<Integer> saleOrderIds = MultiUtils.toSet(saleOrders, ToCSaleOrderPageResult::getId);
        List<SaleOrderLine> saleLineList = repositoryFactory.getSaleOrderLineRepository().listByMainIds(saleOrderIds);

        //step_3 sku查询
        Set<Integer> skuIds = MultiUtils.toSet(saleLineList, SaleOrderLine::getSkuId);
        SkuRpcRequest rpcRequest = new SkuRpcRequest();
        rpcRequest.setIdList(skuIds);
        Map<Integer, SkuRpcResult> skuMap = MultiUtils.toMap(
                skuFacade.list(rpcRequest),
                SkuRpcResult::getId
        );

        //经营权
        Set<Integer> sellerIds = MultiUtils.toSet(saleLineList, SaleOrderLine::getSellerId);
        Map<Integer, SysBusinessUnit> sellerMap = MultiUtils.toMap(
                repositoryFactory.getBusinessUnitRepository().listByIds(sellerIds),
                SysBusinessUnit::getId
        );

        //商品所在
        Set<Integer> belongIds = MultiUtils.toSet(saleLineList, SaleOrderLine::getStoreId);
        Map<Integer, SysBusinessUnit> belongMap = MultiUtils.toMap(
                repositoryFactory.getBusinessUnitRepository().listByIds(belongIds),
                SysBusinessUnit::getId
        );

        //采购主题
        Set<Integer> psIds = MultiUtils.toSet(skuMap.values(), SkuRpcResult::getPurchaseSubjectId);
        Map<Integer, String> psMap = MultiUtils.toMap(
                repositoryFactory.getBusinessUnitRepository().listByIds(psIds),
                SysBusinessUnit::getId,
                SysBusinessUnit::getName
        );


        //step_4 组合数据
        return MultiUtils.toList(
                saleLineList,
                line ->{
                    SysBusinessUnit seller = sellerMap.get(line.getSellerId());
                    SysBusinessUnit belong = belongMap.get(line.getStoreId());


                    SkuRpcResult sku = skuMap.get(line.getSkuId());
                    ToCSaleOrderPageResult saleOrder = saleOrderMap.get(line.getSaleId());


                    String psName = psMap.get(sku.getPurchaseSubjectId());
                    String state = EnumUtils.of(SaleStateEnums.class,saleOrder.getState()).getDesc();
                    String scType = EnumUtils.of(SaleChannelTypeEnums.class,saleOrder.getScType()).getDesc();
                    String nodeState = line.getNodeState().getDesc();
                    String param = excelDomain.joinParam(sku.getSkuParams());
                    String annexe = excelDomain.joinAnnexe(sku.getAnnexe());

                    return SaleOrderMapping.INSTANCE.tocExportResult(
                            line,
                            sku,
                            saleOrder,
                            state,
                            scType,
                            nodeState,
                            param,
                            annexe,
                            seller,
                            belong,
                            psName
                    );
                }
        );
    }
}
