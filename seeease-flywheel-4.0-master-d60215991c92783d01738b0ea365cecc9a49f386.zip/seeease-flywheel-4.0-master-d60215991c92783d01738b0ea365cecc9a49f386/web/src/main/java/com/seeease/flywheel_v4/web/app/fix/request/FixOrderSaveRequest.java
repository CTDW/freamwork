package com.seeease.flywheel_v4.web.app.fix.request;

import com.seeease.flywheel_v4.web.app.fix.common.*;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.List;

/**
 * @Description 维修中心-维修管理 请求值
 * @Date 2024-10-2 20:20
 * @Author by hk
 */
@Data
public class FixOrderSaveRequest implements Serializable {

    @ApiModelProperty(value = "id",notes = "编辑时必填")
    private Long id;

    @ApiModelProperty(value = "基本信息")
    private FixOrderBasicInfoDto basicInfo;

    @ApiModelProperty(value = "客户信息")
    private FixCustomInfoDto customInfo;

    @ApiModelProperty(value = "商品信息")
    private FixGoodsDto goodsInfo;

    @ApiModelProperty(value = "维修报价项")
    private List<FixItemDto> fixItemList;

    @ApiModelProperty(value = "配件")
    private List<FixPartsDto> partList;


}
