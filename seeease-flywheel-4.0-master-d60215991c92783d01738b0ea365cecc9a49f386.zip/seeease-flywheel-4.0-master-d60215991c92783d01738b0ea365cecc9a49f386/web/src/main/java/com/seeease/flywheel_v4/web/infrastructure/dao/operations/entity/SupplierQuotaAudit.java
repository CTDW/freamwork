package com.seeease.flywheel_v4.web.infrastructure.dao.operations.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.enums.SupplierQuotaAuditStateEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.operations.enums.SupplierQuotaAuditTypeEnums;
import com.seeease.seeeaseframework.mybatis.domain.BaseDomain;
import com.seeease.seeeaseframework.mybatis.type.JsonTypeHandler;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.apache.ibatis.type.JdbcType;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * 供应商保证金充值审核表
 */
@EqualsAndHashCode(callSuper = true)
@TableName(value = "v4_ops_supplier_quota_audit", autoResultMap = true)
@Data
public class SupplierQuotaAudit extends BaseDomain {
    @TableId(type = IdType.AUTO)
    private Integer id;
    /**
     * 类型
     */
    private SupplierQuotaAuditTypeEnums type;
    /**
     * 供应商id
     */
    private Integer supplierId;
    /**
     * 采购主体id
     */
    private Integer purchaseSubjectId;
    /**
     * 金额
     */
    private BigDecimal amount;
    /**
     * 打款账户
     */
    private String account;
    /**
     * 备注
     */
    private String remark;
    /**
     * 状态
     */
    private SupplierQuotaAuditStateEnums state;
    /**
     * 原因
     */
    private String reason;
    /**
     * 审核时间
     */
    private Date auditTime;
    /**
     * 图片
     */
    @TableField(jdbcType = JdbcType.VARCHAR, typeHandler = JsonTypeHandler.class)
    private List<String> images;
    /**
     * 打款凭证
     */
    @TableField(jdbcType = JdbcType.VARCHAR, typeHandler = JsonTypeHandler.class)
    private List<String> pzImages;
    /**
     * 创建人业务单元id
     */
    private Integer buId;


}