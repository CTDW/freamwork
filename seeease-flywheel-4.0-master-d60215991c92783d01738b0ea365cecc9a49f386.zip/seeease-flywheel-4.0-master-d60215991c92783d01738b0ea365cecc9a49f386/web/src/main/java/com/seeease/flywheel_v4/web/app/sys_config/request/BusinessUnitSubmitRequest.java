package com.seeease.flywheel_v4.web.app.sys_config.request;


import com.seeease.springframework.RequestValidGroup;
import lombok.Data;


import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.util.List;

/**
 * <p>通用业务单元数据提交</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/3/24 11:26 上午
 **/
@Data
public class BusinessUnitSubmitRequest {
    /**
     * id
     */
    @NotNull(message = "id不能为空",groups = RequestValidGroup.Update.class)
    private Integer id;
    /**
     * 名称
     */
    @NotBlank(message = "名称不能为空")
    private String name;
    /**
     * 业务单元类型
     */
    @NotNull(message = "业务单元类型不能为空")
    private Integer type;
    /**
     * 负责人
     */
    @NotBlank(message = "负责人不能为空")
    private String head;
    /**
     * 联系方式
     */
    private String phone;
    /**
     * 状态
     */
    @NotNull(message = "状态不能为空")
    private Integer state;
    /**
     * 地址id列表
     */
    private List<Integer> areaCodes;
    /**
     * 省
     */
    private String province;
    /**
     * 市
     */
    private String city;
    /**
     * 区
     */
    private String area;
    /**
     * 地址详细信息
     */
    private String address;

    /**
     * 街道
     */
    private String street;

    /**
     * 备注
     */
    private String remark;

    //------------------------------------------以下两个字段属于商家--------------------------------------//
    /**
     * 是否自主经营
     */
    private Integer isSell;
    /**
     * 一件代发id
     */
    private Integer dobId;
//------------------------------------------以下两个字段属于商家--------------------------------------//
}
