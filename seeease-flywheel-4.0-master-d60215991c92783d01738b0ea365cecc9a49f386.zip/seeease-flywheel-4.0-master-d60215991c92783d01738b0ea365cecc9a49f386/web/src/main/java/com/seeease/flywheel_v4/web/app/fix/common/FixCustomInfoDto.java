package com.seeease.flywheel_v4.web.app.fix.common;

import com.seeease.flywheel_v4.web.infrastructure.dao.fix.entity.FixOrder;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @Description 维修单 客户信息
 * @Date 2024-10-4 18:18
 * @Author by hk
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FixCustomInfoDto implements Serializable {

    @ApiModelProperty(value = "维修客户")
    private String custom;

    @ApiModelProperty(value = "联系电话")
    private String customPhone;

    @ApiModelProperty(value = "省")
    private String province;

    @ApiModelProperty(value = "省id")
    private Long provinceId;

    @ApiModelProperty(value = "市")
    private String city;

    @ApiModelProperty(value = "市id")
    private Long cityId;

    @ApiModelProperty(value = "县区")
    private String area;

    @ApiModelProperty(value = "县区id")
    private Long areaId;

    @ApiModelProperty(value = "详细地址")
    private String address;

    public static FixCustomInfoDto fromEntity(FixOrder detail) {
        return FixCustomInfoDto.builder()
                .custom(detail.getCustom())
                .customPhone(detail.getCustomPhone())
                .province(detail.getProvince())
                .provinceId(detail.getProvinceId())
                .city(detail.getCity())
                .cityId(detail.getCityId())
                .area(detail.getArea())
                .areaId(detail.getAreaId())
                .address(detail.getAddress())
                .build();
    }

    public void toEntity(FixOrder detail) {
        detail.setCustom(custom);
        detail.setCustomPhone(customPhone);
        detail.setProvince(province);
        detail.setProvinceId(provinceId);
        detail.setCity(city);
        detail.setCityId(cityId);
        detail.setArea(area);
        detail.setAreaId(areaId);
        detail.setAddress(address);
    }
}
