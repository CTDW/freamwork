package com.seeease.flywheel_v4.web.app.common.service.impl;

import com.seeease.flywheel_v4.web.app.common.request.AreaListRequest;
import com.seeease.flywheel_v4.web.app.common.result.AreaListResult;
import com.seeease.flywheel_v4.web.app.common.service.CommonService;
import com.seeease.flywheel_v4.web.infrastructure.dao.RepositoryFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.stream.Collectors;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 7/25/24 1:36 下午
 **/
@Service
public class CommonServiceImpl implements CommonService {
    @Resource
    private RepositoryFactory repositoryFactory;

    @Override
    public List<AreaListResult> areaList(AreaListRequest request) {
        return repositoryFactory.getAreaRepository().listByPid(request.getParentId())
                .stream()
                .map(v -> {
                    AreaListResult ret = new AreaListResult();
                    BeanUtils.copyProperties(v,ret);
                    return ret;
                }).collect(Collectors.toList());

    }
}
