package com.seeease.flywheel_v4.web.app.sale.request;


import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.List;


@Data
public class ToCSaleReturnOrderCreateRequest {

    /**
     * 销售单id
     */
    @NotNull(message = "销售单id不能为空")
    private Integer saleId;

    /**
     * 备注
     */
    private String remark;

    /**
     * 三方退货id
     */
    private String thirdReturnId;

    /**
     * sku列表
     */
    @Valid
    @NotEmpty(message = "sku不能为空")
    private List<Sku> skuList;


    @Data
    public static class Sku {
        /**
         * 采购单行id
         */
        @NotNull(message = "采购单行id不能为空")
        private Integer lineId;
        /**
         * skuId
         */
        @NotNull(message = "skuId不能为空")
        private Integer skuId;
        /**
         * 退款金额
         */
        @NotNull(message = "退款金额不能为空")
        private BigDecimal returnAmount;
        /**
         * 退款数量
         */
        @NotNull(message = " 退款数量不能为空")
        private Integer count;
    }


}
