package com.seeease.flywheel_v4.web.app.sale.result;


import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;


@Data
public class ToBSaleReturnOrderPageResult {

    /**
     * 退货单
     */
    private Integer id;
    /**
     * 主销售单号
     */
    private String mainSerialNo;
    /**
     * 销售退货单号
     */
    private String serialNo;
    /**
     * 客户名称
     */
    private String buyerName;

    /**
     * 总退款金额
     */
    private BigDecimal totalAmount;
    /**
     * 来源名称
     */
    private String originName;
    /**
     * 状态
     */
    private Integer state;
    /**
     * 快递单号
     */
    private String expressNo;

    /**
     * 创建人
     */
    private String createdBy;
    /**
     * 创建时间
     */
    private Date createdTime;
    /**
     * 完成时间
     */
    private Date finishTime;
    /**
     * 销售渠道类型
     */
    private Integer scType;

    /**
     * 销售单号
     */
    private String saleSerialNo;





}
