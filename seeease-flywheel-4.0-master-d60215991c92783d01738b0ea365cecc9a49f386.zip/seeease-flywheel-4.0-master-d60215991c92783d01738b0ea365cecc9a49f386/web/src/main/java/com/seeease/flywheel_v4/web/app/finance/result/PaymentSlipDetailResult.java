package com.seeease.flywheel_v4.web.app.finance.result;


import com.seeease.goods.rpc.request.SkuAnnexeRpcResult;
import com.seeease.goods.rpc.result.ProductParamRpcResult;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * @ Description   :
 * @ Author        :  西门 游
 * @ CreateDate    :  6/6/24
 * @ Version       :  1.0
 */


@Data
public class PaymentSlipDetailResult {
    /**
     * 打款单id
     */
    private Integer id;
    /**
     * 采购单号
     */
    private String purchaseSerialNo;
    /**
     * 申请打款单号
     */
    private String serialNo;
    /**
     * 打款金额
     */
    private BigDecimal amount;
    /**
     * 实际打款金额
     */
    private BigDecimal payAmount;
    /**
     * 商家名称
     */
    private String merchantName;
    /**
     * 供应商名称
     */
    private String supplierName;
    /**
     * 联系人名称
     */
    private String contactName;
    /**
     * 联系人银行
     */
    private String bank;
    /**
     * 联系人银行账号
     */
    private String account;
    /**
     * 联系人开户行
     */
    private String bankName;
    /**
     * 打款单状态
     */
    private Integer state;
    /**
     * 采购类型
     */
    private Integer purchaseType;
    /**
     * 核销状态
     */
    private Integer verifyState;
    /**
     * 核销状态说明
     */
    private String verifyRemark;

    /**
     * 支付方式
     */
    private Integer payType;
    /**
     * 采购主体名称
     */
    private String purchaseSubjectName;
    /**
     * 创建人
     */
    private String createdBy;
    /**
     * 创建时间
     */
    private Date createdTime;

    /**
     * 图片列表
     */
    private List<String> images;
    /**
     * 转让协议图片
     */
    private String contractImg;
    /**
     * 回收定价聊天记录/回购承诺函图片
     */
    private String evidenceImg;
    /**
     * 身份证正面图片
     */
    private String idFrontImg;
    /**
     * 身份证反面图片
     */
    private String idBackImg;
    /**
     * 打款凭证图片
     */
    private String payedImg;
    /**
     * sku列表
     */
    private List<Sku> skuList;

    /**
     * 打款时间
     */
    private Date payedTime;


    @Data
    public static class Sku{
        /**
         * skuId
         */
        private Integer skuId;
        /**
         * 商品名称
         */
        private String goodsName;
        /**
         * 类目
         */
        private String categoryName;
        /**
         * 品牌
         */
        private String brandName;
        /**
         * 节点状态
         */
        private Integer nodeState;
        /**
         * 采购价
         */
        private BigDecimal purchasePrice;
        /**
         * 采购数量
         */
        private Integer count;

        /**
         * 入库时实际的收货数量
         */
        private Integer actualCount;

        /**
         * sku参数列表
         */
        private List<ProductParamRpcResult> skuParams;
        /**
         * 附件
         */
        private List<SkuAnnexeRpcResult> annexe;
        /**
         * 唯一码
         */
        private String skuCode;
        /**
         * 图片
         */
        private String spuImage;
    }
}
