package com.seeease.flywheel_v4.web.infrastructure.dao.fix.repo;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.seeease.flywheel_v4.web.app.fix.request.*;
import com.seeease.flywheel_v4.web.app.fix.result.FixStatusCountResult;
import com.seeease.flywheel_v4.web.infrastructure.dao.fix.entity.FixOrder;

import java.util.List;

/**
 * @Description 维修单
 * @Date 2024-10-2 21:04
 * @Author by hk
 */
public interface FixOrderRepository {

    /**
     * 分页
     *
     * @param request 请求
     * @return 维修单
     */
    Page<FixOrder> page(FixOrderPageRequest request);

    /**
     * 维修中心-维修单-查询状态对应数量
     *
     * @param request 请求 * @return 列表结果
     */
    List<FixStatusCountResult> getStatusCount(FixOrderPageRequest request);

    /**
     * 详情
     *
     * @param id 请求
     * @return 返回
     */
    FixOrder detail(Long id);

    /**
     * 根据维修单号查询
     *
     * @param orderNo 维修单号
     * @return 返回
     */
    FixOrder getByOrderNoOrGoodsUnique(String orderNo);

    /**
     * 新增
     *
     * @param request 请求
     * @return 结果
     */
    FixOrder save(FixOrderSaveRequest request);

    /**
     * 编辑
     *
     * @param request 请求
     * @return 结果
     */
    Boolean update(FixOrderSaveRequest request);

    /**
     * 删除
     *
     * @param request 请求
     * @return 结果
     */
    Boolean delete(FixOrderDetailRequest request);

    /**
     * 分配维修师
     *
     * @param request 请求
     */
    void updateMasterAndOrderStatusToWaitFix(FixOrderDistributeRequest request);

    /**
     * 更新为已取消
     *
     * @param id id
     */
    void updateOrderStatusToCancel(Long id);

    /**
     * 更新为送外维修
     *
     * @param request 送外维修
     */
    void updateOrderStatusToSendOut(FixOrderSendOutRequest request,FixOrder fixOrder);

    /**
     * 维修完成
     *
     * @param request 请求
     */
    void complete(FixOrderCompleteRequest request);

    /**
     * 回退
     *
     * @param id id
     */
    void updateOrderStatusToPreOrderStatus(Long id,Integer newOrderStatus);

    /**
     * 跳过
     *
     * @param request 请求
     */
    void updateOrderStatusToAppoint(FixOrderJumpRequest request);

    /**
     * 维修师扫码领用
     *
     * @param fixOrder 维修单
     * @param request 请求
     */
    void masterUpdateOrderStatusToAppoint(FixOrder fixOrder,FixOrderMasterUseRequest request);

    /**
     * 完成质检
     * @param id id
     */
    void completeQuality(Long id);

}
