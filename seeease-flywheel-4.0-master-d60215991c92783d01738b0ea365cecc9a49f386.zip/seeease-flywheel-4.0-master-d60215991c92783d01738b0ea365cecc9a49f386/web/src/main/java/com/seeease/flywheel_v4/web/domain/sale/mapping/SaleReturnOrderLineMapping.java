package com.seeease.flywheel_v4.web.domain.sale.mapping;


import com.seeease.flywheel_v4.client.enums.BusinessUnitTypeEnums;
import com.seeease.flywheel_v4.web.app.sale.request.SaleReturnOrderCreateRequest;
import com.seeease.flywheel_v4.web.app.sale.result.ToBSaleReturnOrderDetailResult;
import com.seeease.flywheel_v4.web.app.sale.result.ToCSaleReturnOrderDetailResult;
import com.seeease.flywheel_v4.web.infrastructure.config.EnumMapping;
import com.seeease.flywheel_v4.web.infrastructure.config.MappingIgnore;
import com.seeease.flywheel_v4.web.infrastructure.dao.purchase.enums.PurchaseDemandStateEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.entity.SaleReturnOrder;
import com.seeease.flywheel_v4.web.infrastructure.dao.sale.entity.SaleReturnOrderLine;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.MerchantWmsLine;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.entity.WmsRk;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.WmsRkTypeEnums;
import com.seeease.flywheel_v4.web.util.SerialNoGenerator;
import com.seeease.goods.rpc.enums.SkuNodeStateEnums;
import com.seeease.goods.rpc.result.SkuCreateRpcResult;
import com.seeease.goods.rpc.result.SkuRpcResult;
import com.seeease.seeeaseframework.mybatis.domain.WhetherEnum;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;


/**
 * <p>
 * </p>
 *
 * @author 西门 游
 * @since 2023-10-27
 */
@Mapper(componentModel = "spring",
        builder = @Builder(disableBuilder = true),
        nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS,
        nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE,
        imports = {BusinessUnitTypeEnums.class,
                PurchaseDemandStateEnums.class,
                PurchaseDemandStateEnums.TransitionEnum.class,
                SerialNoGenerator.class, WhetherEnum.class})
public interface SaleReturnOrderLineMapping extends EnumMapping {

    SaleReturnOrderLineMapping INSTANCE = Mappers.getMapper(SaleReturnOrderLineMapping.class);


    @MappingIgnore
    @Mapping(target = "skuId",source = "rpcSku.id")
    @Mapping(target = "nodeState",source = "nodeState")
    @Mapping(target = "count",source = "sku.returnCount")
    @Mapping(target = "newSettlePrice",source = "sku.newSettlePrice")
    @Mapping(target = "gmvc",source = "sku.gmvc")
    @Mapping(target = "endState", expression = "java(WhetherEnum.NO)")
    @Mapping(target = "storeId", source = "storeId")
    SaleReturnOrderLine toEntity(
            SkuCreateRpcResult rpcSku,
            SaleReturnOrderCreateRequest.Sku sku,
            Integer returnId,
            SkuNodeStateEnums nodeState,
            Integer storeId
    );

    @MappingIgnore
    @Mapping(target = "expressNo",ignore = true)
    @Mapping(target = "storeId",source ="returnOrder.storeId")
    @Mapping(target = "buId",source ="returnOrder.buId")
    WmsRk toWmsRk(
            SaleReturnOrderLine line,
            SaleReturnOrder returnOrder,
            WmsRkTypeEnums type
    );

    @MappingIgnore
    @Mapping(target = "price",source = "line.returnAmount")
    @Mapping(target = "endState", expression = "java(WhetherEnum.NO)")
    MerchantWmsLine toMerchantWmsLine(
            SaleReturnOrderLine line,
            SkuNodeStateEnums nodeState
    );

    @Mapping(target = "tocPrice",source = "line.tocPrice")
    @Mapping(target = "newSettlePrice",source = "line.newSettlePrice")
    ToCSaleReturnOrderDetailResult.Sku tocDetailResult(
            SaleReturnOrderLine line ,
            SkuRpcResult sku,
            String sellerName,
            String belongName);

    @Mapping(target = "tobPrice",source = "line.tobPrice")
    @Mapping(target = "newSettlePrice",source = "line.newSettlePrice")
    ToBSaleReturnOrderDetailResult.Sku tobDetailResult(
            SaleReturnOrderLine line,
            SkuRpcResult sku,
            String sellerName,
            String belongName);
}
