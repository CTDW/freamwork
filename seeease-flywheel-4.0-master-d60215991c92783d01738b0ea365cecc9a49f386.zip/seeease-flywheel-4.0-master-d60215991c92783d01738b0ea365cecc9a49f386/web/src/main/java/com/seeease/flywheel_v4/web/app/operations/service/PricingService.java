package com.seeease.flywheel_v4.web.app.operations.service;

import com.seeease.flywheel_v4.web.app.operations.request.PricingBatchPassRequest;
import com.seeease.flywheel_v4.web.app.operations.request.PricingDetailRequest;
import com.seeease.flywheel_v4.web.app.operations.request.PricingPageRequest;

import com.seeease.flywheel_v4.web.app.operations.request.PricingStateRequest;
import com.seeease.flywheel_v4.web.app.operations.result.PricingDetailResult;
import com.seeease.flywheel_v4.web.app.operations.result.PricingPageResult;
import com.seeease.springframework.PageResult;

/**
 * <p>供应商</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/4/24 4:43 下午
 **/
public interface PricingService {
    /**
     * 系统运营-定价管理分页查询
     *
     * @return 分页结果
     */
    PageResult<PricingPageResult> page(PricingPageRequest request);


    /**
     * 系统运营-sku定价管理状态变更
     *
     * @return 状态变更结果
     */
    Boolean state(PricingStateRequest request);

    /**
     * 系统运营-定价管理详情查询
     *
     * @return 详情结果
     */
    PricingDetailResult detail(PricingDetailRequest request);

    /**
     * 系统运营-sku批量定价通过
     *
     * @return 状态变更结果
     */
    Boolean batchPass(PricingBatchPassRequest request);

}
