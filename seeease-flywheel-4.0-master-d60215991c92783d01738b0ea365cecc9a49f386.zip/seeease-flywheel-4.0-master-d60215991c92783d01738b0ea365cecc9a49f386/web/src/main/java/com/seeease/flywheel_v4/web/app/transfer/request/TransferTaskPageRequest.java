package com.seeease.flywheel_v4.web.app.transfer.request;


import com.seeease.springframework.PageRequest;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author 西门 游
 * @version 1.0
 * @since 6/3/24 11:26 上午
 **/
@EqualsAndHashCode(callSuper = true)
@Data
public class TransferTaskPageRequest extends PageRequest {
    /**
     * sku编码
     */
    private String skuCode;
    /**
     * 商品所在
     */
    private Integer belongId;

    /**
     * 调入方
     */
    private Integer toId;

    /**
     * 品牌id
     */
    private Integer brandId;
    /**
     * 货号
     */
    private String goodsCode;
    /**
     * 商品名称
     */
    private String goodsName;
    /**
     * 蜥蜴编码
     */
    private String xyCode;
    /**
     * 采购类型
     */
    private Integer purchaseType;
    /**
     * 当前操作人业务单元id 权限控制
     */
    private Integer buId;
}
