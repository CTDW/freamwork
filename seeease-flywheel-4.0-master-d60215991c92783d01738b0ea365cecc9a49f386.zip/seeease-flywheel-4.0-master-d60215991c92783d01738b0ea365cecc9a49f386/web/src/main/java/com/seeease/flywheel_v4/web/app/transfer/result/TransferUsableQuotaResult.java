package com.seeease.flywheel_v4.web.app.transfer.result;


import com.seeease.flywheel_v4.web.domain.operations.OpsDomain;
import com.seeease.seeeaseframework.mybatis.domain.WhetherEnum;
import lombok.Data;

import java.math.BigDecimal;
import java.util.List;

/**
 * @author 西门 游
 * @version 1.0
 * @since 6/3/24 11:26 上午
 **/
@Data
public class TransferUsableQuotaResult {
    /**
     * 调拨额度id
     */
    private Integer id;
    /**
     * 可用压货额度
     */
    private BigDecimal usableOsQuota = BigDecimal.ZERO;
    /**
     * 可用代销额度
     */
    private BigDecimal usableCtQuota  = BigDecimal.ZERO;

    /**
     * 详情已使用额度
     */
    private List<OpsDomain.TransferUsedQuotaDto.Item> detailUsedQuota;

    /**
     * 是否调拨管控
     */
    private Integer isCtl  = WhetherEnum.NO.getValue();
}
