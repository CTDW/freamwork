package com.seeease.flywheel_v4.web.domain.wms.observer;

import com.google.common.collect.Lists;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.MerchantWmsTypeEnums;
import com.seeease.flywheel_v4.web.infrastructure.dao.wms.enums.WmsRkTypeEnums;

import java.util.List;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 7/26/24 11:24 上午
 **/
public class PurchaseBaseObserver {


    /**
     * 仓库端wms 入库观察者类型
     */
    protected final List<WmsRkTypeEnums> wmsRkWatchTypeList = Lists.newArrayList(
            WmsRkTypeEnums.TH_CG_DJ,
            WmsRkTypeEnums.TH_CG_BH,
            WmsRkTypeEnums.TH_CG_JC,
            WmsRkTypeEnums.TH_JS,
            WmsRkTypeEnums.GR_HS,
            WmsRkTypeEnums.GR_JS,
            WmsRkTypeEnums.GR_HG,
            WmsRkTypeEnums.GR_HSZH,
            WmsRkTypeEnums.GR_HGZH
    );





    /**
     * 商家端wms 入库观察的类型
     */
    protected final List<MerchantWmsTypeEnums> merchantWmsRkWatchTypeList = Lists.newArrayList(
            MerchantWmsTypeEnums.TH_CG_DJ,
            MerchantWmsTypeEnums.TH_CG_DJ,
            MerchantWmsTypeEnums.TH_CG_BH,
            MerchantWmsTypeEnums.TH_CG_JC,
            MerchantWmsTypeEnums.TH_JS,
            MerchantWmsTypeEnums.GR_HS,
            MerchantWmsTypeEnums.GR_JS,
            MerchantWmsTypeEnums.GR_HG,
            MerchantWmsTypeEnums.GR_HSZH,
            MerchantWmsTypeEnums.GR_HGZH
    );







}
