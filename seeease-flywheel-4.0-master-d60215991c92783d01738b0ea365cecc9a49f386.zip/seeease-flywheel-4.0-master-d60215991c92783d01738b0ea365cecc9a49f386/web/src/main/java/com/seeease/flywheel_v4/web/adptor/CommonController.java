package com.seeease.flywheel_v4.web.adptor;

import com.seeease.flywheel_v4.web.app.common.request.AreaListRequest;
import com.seeease.flywheel_v4.web.app.common.result.AreaListResult;
import com.seeease.flywheel_v4.web.app.common.service.CommonService;
import com.seeease.framework.alioss.AliOssApi;
import com.seeease.framework.alioss.dto.UploadTokenDto;
import com.seeease.springframework.SingleResponse;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/29/24 4:34 下午
 **/
@RestController
@RequestMapping("common")
public class CommonController {

    @Resource
    private AliOssApi ossApi;
    @Resource
    private CommonService commonService;

    /**
     * 获取oss上传token
     * @param dir  上传的目录
     * @param expire  过期时间
     * @return
     */
    @GetMapping("oss/upload/token")
    public SingleResponse<UploadTokenDto> getOssUploadToken(@RequestParam String dir,
                                            @RequestParam String expire){

        return SingleResponse.of(ossApi.getUploadToken(dir, Long.parseLong(expire)));
    }


    /**
     * 获取省市县
     * @return
     */
    @PostMapping("area/list")
    public SingleResponse<List<AreaListResult>> areaList(@RequestBody AreaListRequest request){
        return SingleResponse.of(commonService.areaList(request));
    }


}
