package com.seeease.flywheel_v4.web.app.fix.request;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import java.math.BigDecimal;

/**
 * @Description 维修中心-维修项目 请求值
 * @Date 2024-10-2 20:20
 * @Author by hk
 */
@Data
public class FixItemSaveRequest {

    @ApiModelProperty(value = "id")
    private Long id;

    @ApiModelProperty(value = "维修项目名称", required = true)
    @NotBlank(message = "维修项目不能为空")
    private String itemName;

    @ApiModelProperty(value = "默认维修价")
    private BigDecimal defaultFixPrice;
}
