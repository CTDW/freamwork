package com.seeease.flywheel_v4.web.app.sale.request;


import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.List;


@Data
public class SaleOrderCreateRequest {


    /**
     * 联系人id
     */
    @NotNull(message = "联系人不能为空")
    private Integer buyerId;


    /**
     * 三方单号
     */
    private String thirdPartyNo;

    /**
     * 主单号
     */
    private transient String mainSerialNo;

    /**
     * 销售模型
     */
    private Integer model;

    /**
     * 销售方式
     */
    @NotNull(message = "销售方式不能为空")
    private Integer sellType;

    /**
     * 三方单号合并id
     */
    private String mergedId;

    /**
     * 订金金额
     */
    private BigDecimal prepayAmount;

    /**
     * 销售备注
     */
    private String sellRemark;

    /**
     * 面单备注
     */
    private String billRemark;

    /**
     * 质检方式
     */
    private Integer qualityWay;

    /**
     * 销售渠道类型枚举
     */
    @NotNull(message = "销售渠道类型枚举不能为空")
    private Integer scType;

    /**
     * 销售渠道配置id
     */
    private Integer scId;


    /**
     * 第一销售人id
     */
    @NotNull(message = "第一销售人id不能为空")
    private Integer sellerAId;

    /**
     * 第二销售人id
     */
    private Integer sellerBId;

    /**
     * 第三销售人id
     */
    private Integer sellerCId;


    /**
     * sku列表
     */
    @Valid
    @NotEmpty(message = "skuList不能为空")
    private List<Sku> skuList;


    @Data
    public static class Sku {
        /**
         * uuid
         */
        private String uuid;
        /**
         * 寄售价
         */
        private BigDecimal consignmentPrice;

        @NotNull(message = "sku商品位置不能为空")
        private Integer belongId;

        /**
         * skuId
         */
        @NotNull(message = "skuId不能为空")
        private Integer id;

        /**
         * 数量
         */
        @NotNull(message = "数量不能为空")
        @Min(value = 1, message = "数量最少为1")
        private Integer sellCount;
        /**
         * 成交价
         */
        private BigDecimal dealPrice = BigDecimal.ZERO;
        /**
         * 表带根换费
         */
        private BigDecimal strapPrice = BigDecimal.ZERO;
        /**
         * 表节数
         */
        private Integer strapCount;
    }


}
