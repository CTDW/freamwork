package com.seeease.flywheel_v4.web.app.sale.result;


import com.seeease.goods.rpc.request.SkuAnnexeRpcResult;
import com.seeease.goods.rpc.result.ProductParamRpcResult;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


@Data
public class ToCSaleReturnOrderDetailResult {

    /**
     * id
     */
    private Integer id;
    /**
     * 客户名称
     */
    private String buyerName;
    /**
     * 客户电话
     */
    private String buyerPhone;
    /**
     * 客户地址
     */
    private String buyerAddress;

    /**
     * 销售单号
     */
    private String saleSerialNo;

    /**
     * 单号
     */
    private String serialNo;

    /**
     * 状态
     */
    private Integer state;
    /**
     * 订单来源
     */
    private String originName;

    /**
     * 快递单号
     */
    private String expressNo;

    /**
     * 创建人
     */
    private String createdBy;
    /**
     * 创建时间
     */
    private Date createdTime;
    /**
     * 完成时间
     */
    private Date finishTime;
    /**
     * 备注
     */
    private String remark;
    /**
     * sku列表
     */
    private List<Sku> skuList;
    /**
     * 总数量
     */
    private Integer totalCount;
    /**
     * 总金额
     */
    private BigDecimal totalAmount;



    @Data
    public static class Sku{
        /**
         * 采购业务单据行id
         */
        private Integer lineId;
        /**
         * 成交价
         */
        private BigDecimal dealPrice;
        /**
         * 最新结算价
         */
        private BigDecimal newSettlePrice;
        /**
         * c gmv
         */
        private BigDecimal gmvc;
        /**
         * 退款金额
         */
        private BigDecimal returnAmount;

        /**
         * c价
         */
        private BigDecimal tocPrice;

        /**
         * skuId
         */
        private Integer skuId;
        /**
         * 商品名称
         */
        private String goodsName;
        /**
         * 类目
         */
        private String categoryName;
        /**
         * 品牌
         */
        private String brandName;
        /**
         * 唯一码类型
         */
        private Integer uniqueType;
        /**
         * 节点状态
         */
        private Integer nodeState;
        /**
         * sku参数列表
         */
        private List<ProductParamRpcResult> skuParams;
        /**
         * 附件
         */
        private List<SkuAnnexeRpcResult> annexe;
        /**
         * 唯一码
         */
        private String skuCode;
        /**
         * 图片
         */
        private String spuImage;
        /**
         * 类目id
         */
        private Integer categoryId;
        /**
         * 数量
         */
        private Integer count;
        /**
         * 经营权
         */
        private String sellerName;
        /**
         * 商品所在
         */
        private String belongName;
    }
}
