package com.seeease.flywheel_v4.client.result;

import lombok.Data;

import java.io.Serializable;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/17/24 4:20 下午
 **/
@Data
public class SupplierContactsRpcResult implements Serializable {
    /**
     * id
     */
    private Integer id;
    /**
     * 联系人名称
     */
    private String name;
    /**
     * 联系人电话
     */
    private String phone;
}
