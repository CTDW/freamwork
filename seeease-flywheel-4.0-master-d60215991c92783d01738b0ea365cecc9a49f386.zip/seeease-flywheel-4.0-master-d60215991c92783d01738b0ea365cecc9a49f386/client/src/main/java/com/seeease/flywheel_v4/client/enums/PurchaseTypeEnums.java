package com.seeease.flywheel_v4.client.enums;

import com.baomidou.mybatisplus.annotation.IEnum;
import lombok.AllArgsConstructor;
import lombok.Getter;


/**
 * 采购业务枚举
 */
@Getter
@AllArgsConstructor
public enum PurchaseTypeEnums implements IEnum<Integer> {

    TH_CG_DJ(101, "同行采购-订金"),
    TH_CG_BH(102, "同行采购-备货"),
    TH_CG_JC(103, "同行采购-集采"),
    TH_JS(104, "同行采购-寄售"),
    GR_HS(105, "个人采购-回收"),
    GR_JS(106, "个人采购-寄售"),
    GR_HG(107, "个人采购-回购"),
    GR_HSZH(108, "个人采购-回收置换"),
    GR_HGZH(109, "个人采购-回购置换"),


    ;
    private Integer value;
    private String desc;




}
