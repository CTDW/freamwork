package com.seeease.flywheel_v4.client.rpc;

import com.seeease.flywheel_v4.client.result.SupplierContactsRpcResult;
import com.seeease.flywheel_v4.client.result.SupplierRpcResult;

import java.util.List;
import java.util.Set;

/**
 * <p>供应商查询</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/15/24 3:07 下午
 **/

public interface SupplierFacade {

    /**
     * 查找供应商
     * @param id 主键id
     * @return
     */
    SupplierRpcResult findById(Integer id);

    /**
     * 查找供应商列表
     * @param ids
     * @return
     */
    List<SupplierRpcResult> listByIds(Set<Integer> ids);


    /**
     * 查找供应商联系人
     * @param id 主键id
     * @return
     */
    SupplierContactsRpcResult findContactById(Integer id);

    /**
     * 查找供应商联系人列表
     * @param ids
     * @return
     */
    List<SupplierContactsRpcResult> listContactByIds(Set<Integer> ids);
}
