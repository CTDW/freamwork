package com.seeease.flywheel_v4.client.enums;

import com.baomidou.mybatisplus.annotation.IEnum;
import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * <p>
 *     业务单元类型枚举，该系统的所有业务都基于以下业务单元拼接构成，并且部分单元可独立运行
 *
 *     简单的采购流程如下
 *     商家(提出采购需求) -> 采购(采购商品) -> 维修(商品维修) -> 定价(商品定价) -> 仓库(入库)
 *
 * </p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 5/31/24 6:13下午
 **/
@Getter
@AllArgsConstructor
public enum BusinessUnitTypeEnums implements IEnum<Integer> {
    /**
     * 平台
     */
    PLATFORM(1, "平台"),

    /**
     * 仓库单元
     * - 对商品进行入库管理
     * - 调拨
     */
    WAREHOUSE(2, "仓库单元"),
    /**
     * 商家单元
     * - 提出采购需求
     * - 对提出的采购需求进行付款
     * - 商品的销售
     * - 调拨
     */
    MERCHANT(3, "商家单元"),
    /**
     * 维修单元
     * - 商品维修方
     * - 维修配件的需求方
     * - 维修配件的付款方
     * - 支持调拨
     */
    MAINTENANCE(4, "维修单元"),

    /**
     * 采购主题单元
     * - 商品采购
     */
    PURCHASE(5, "采购主题单元"),

    /**
     * 定价单元
     * - 商品定价
     */
    PRICING(6,"定价单元");


    ;
    private Integer value;
    private String desc;
}
