package com.seeease.flywheel_v4.client.result;

import com.seeease.flywheel_v4.client.enums.BusinessUnitTypeEnums;
import lombok.Data;

import java.io.Serializable;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/15/24 3:09 下午
 **/
@Data
public class BusinessUnitRpcResult implements Serializable {
    /**
     * id
     */
    private Integer id;
    /**
     * 名称
     */
    private String name;
    /**
     * 类型
     */
    private BusinessUnitTypeEnums type;
}
