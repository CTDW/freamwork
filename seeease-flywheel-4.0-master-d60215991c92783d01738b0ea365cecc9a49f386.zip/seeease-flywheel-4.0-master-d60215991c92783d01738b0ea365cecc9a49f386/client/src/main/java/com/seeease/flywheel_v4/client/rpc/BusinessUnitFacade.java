package com.seeease.flywheel_v4.client.rpc;

import com.seeease.flywheel_v4.client.result.BusinessUnitRpcResult;

import java.util.List;
import java.util.Set;

/**
 * <p>业务单元</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 6/15/24 3:07 下午
 **/
public interface BusinessUnitFacade {

    /**
     * 查找
     * @param id 主键id
     * @return
     */
    BusinessUnitRpcResult findById(Integer id);

    /**
     * 列表查询
     * @param  type {@link com.seeease.flywheel_v4.client.enums.BusinessUnitTypeEnums}
     * @return
     */
    List<BusinessUnitRpcResult> listByType(Integer type);

    /**
     * 查找列表
     * @param ids 主键id列表
     * @return
     */
    List<BusinessUnitRpcResult> listByIds(Set<Integer> ids);
}
