package com.seeease.springframework.log.core;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.seeease.springframework.utils.StringUtils;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.util.Enumeration;
import java.util.Locale;

/**
 * <p>curl打印器</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 12/18/23
 **/
public class HttpPrinter {

    private static final ObjectMapper mapper = new ObjectMapper();


    /**
     * 打印curl
     * @param apiArgs 参数
     */
    public static String printCurl(Object[] apiArgs) {
        ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        HttpServletRequest request = attributes.getRequest();
        switch (request.getMethod().toUpperCase(Locale.ROOT)) {
            case "POST":
                return buildPostCurlCommand(apiArgs);
            case "GET":
                return buildHeader("GET").toString();
            default:
                return "";
        }
    }

    /**
     * 构建头
     */
    private static StringBuilder buildHeader(String method) {
        HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
        StringBuilder curlCommand = new StringBuilder("curl");
        curlCommand.append(" -X").append(method).append(" '").append(request.getRequestURL());
        // 添加请求 URL 和参数
        if (StringUtils.isNotEmpty(request.getQueryString())) {
            curlCommand.append("?").append(request.getQueryString());
        }
        curlCommand.append("'");
        Enumeration<String> headerNames = request.getHeaderNames();
        while (headerNames.hasMoreElements()) {
            String headerName = headerNames.nextElement();
            String headerValue = request.getHeader(headerName);
            curlCommand.append(" -H '").append(headerName).append(": ").append(headerValue).append("'");
        }
        return curlCommand;
    }


    /**
     * 构建 cURL 命令（POST 请求，包含 JSON 请求体）
     */
    private static String buildPostCurlCommand(Object[] apiArgs) {
        StringBuilder curlCommand = buildHeader("POST");
        String jsonBody = "";
        try {
            jsonBody = mapper.writeValueAsString(apiArgs);
            jsonBody = jsonBody.substring(1, jsonBody.length() - 1);
        } catch (JsonProcessingException ignore) {
        }
        if (!jsonBody.isEmpty()) {
            curlCommand.append(" -H 'Content-Type: application/json'"); // 指定请求体的内容类型为 JSON
            curlCommand.append(" -d '").append(jsonBody).append("'");
        }
        return curlCommand.toString();
    }


}
