package com.seeease.springframework.exception.e;

/**
 * @author Tiro
 * @date 2024/3/20
 */
public class ArgumentException extends RuntimeException {

    public ArgumentException(String message) {
        super(message);
    }
}
