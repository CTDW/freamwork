package com.seeease.springframework.exception.e;

import com.seeease.springframework.exception.SystemExceptionCode;
import lombok.Getter;

import java.util.Objects;

/**
 * @author Tiro
 * @date 2022/12/6
 */
@Getter
public class SeeeaseBaseException extends RuntimeException {

    private SeeeaseBaseExceptionCode code;
    private Object[] argArray;

    public SeeeaseBaseException(SeeeaseBaseExceptionCode code) {
        super(code.toStringExceptionCode());
        this.code = code;
    }

    public SeeeaseBaseException(SeeeaseBaseExceptionCode code, Object... argArray) {
        super(code.toStringExceptionCode(argArray));
        this.code = code;
        this.argArray = argArray;
    }

    /**
     * @param code
     * @return
     */
    public static SeeeaseBaseException error(SeeeaseBaseExceptionCode code) {
        if (Objects.isNull(code)) {
            return new SeeeaseBaseException(SystemExceptionCode.SYSTEM);
        }
        if (code instanceof BusinessExceptionCode) {
            return new BusinessException((BusinessExceptionCode) code);
        }
        if (code instanceof OperationRejectedExceptionCode) {
            return new OperationRejectedException((OperationRejectedExceptionCode) code);
        }
        return new SeeeaseBaseException(code);
    }
}
