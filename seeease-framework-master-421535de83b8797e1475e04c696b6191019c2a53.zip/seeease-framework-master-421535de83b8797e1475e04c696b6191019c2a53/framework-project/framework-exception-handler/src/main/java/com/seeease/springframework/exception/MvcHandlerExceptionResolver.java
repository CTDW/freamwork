package com.seeease.springframework.exception;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.lang.Nullable;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.AbstractHandlerExceptionResolver;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * @author Tiro
 * @date 2022/12/8
 */
@Slf4j
public class MvcHandlerExceptionResolver extends AbstractHandlerExceptionResolver {


    @Nullable
    protected ModelAndView doResolveException(HttpServletRequest request, HttpServletResponse response, @Nullable Object handler, Exception ex) {
        try {
            //打印日志
            log.error(ex.getMessage(), ex);

            response.setCharacterEncoding("UTF-8");
            response.setHeader("content-type", "application/json;charset=UTF-8");
            ObjectMapper objectMapper = new ObjectMapper();
            String errResult = objectMapper.writeValueAsString(ExceptionConvert.convert(ex));
            response.getWriter().println(errResult);
        } catch (IOException e) {
            log.error(e.getMessage(), e);
        }

        return new ModelAndView();
    }
}
