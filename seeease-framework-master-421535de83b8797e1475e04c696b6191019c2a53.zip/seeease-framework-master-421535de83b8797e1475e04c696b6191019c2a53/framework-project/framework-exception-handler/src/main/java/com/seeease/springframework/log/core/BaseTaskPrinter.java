package com.seeease.springframework.log.core;

import com.seeease.springframework.log.LogPrinterAutoConfiguration;
import com.seeease.springframework.log.annotation.LogPrinter;

import java.util.UUID;

/**
 * <p>打印器基类主要只是封装成员变量使用</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 12/18/23
 **/
public abstract class BaseTaskPrinter implements TaskPrinter {

    public BaseTaskPrinter(LogPrinter printer,
                           LogPrinter.PostPrinter postPrinter,
                           String apiSignature,
                           Object[] apiArgs) {
        this.printer = printer;
        this.postPrinter = postPrinter;
        this.apiSignature = apiSignature;
        this.apiArgs = apiArgs;
        String requestId = LogPrinterAutoConfiguration.RequestHolder.getRequestId();
        counter = new TaskCounter(requestId == null ? UUID.randomUUID().toString() : requestId);
    }



    /**
     * 自定义stopWatch
     */
    private final TaskCounter counter;
    /**
     * 接口上的打印注解
     */
    private final LogPrinter printer;
    /**
     * 自定义打印处理
     */
    private final LogPrinter.PostPrinter postPrinter;
    /**
     * 接口签名
     */
    private final String apiSignature;
    /**
     * 接口参数
     */
    private final Object[] apiArgs;
    /**
     * 任务记录过程中发生的异常
     */
    private Exception e;



    @Override
    public String print(Exception e) {
        this.e = e;
        return TaskPrinter.super.print(e);
    }

    public Exception getE() {
        return e;
    }

    public LogPrinter getPrinter() {
        return printer;
    }

    public String getApiSignature() {
        return apiSignature;
    }

    public Object[] getApiArgs() {
        return apiArgs;
    }

    @Override
    public String printBase(Exception e) {
        return counter.prettyPrint();
    }

    @Override
    public LogPrinter.PostPrinter getPostPrinter() {
        return postPrinter;
    }

    @Override
    public String getTaskId() {
        return counter.getId();
    }


    @Override
    public void start(String taskName) {
        counter.start(taskName);
    }

    @Override
    public void stop() {
        counter.stop();
    }
}
