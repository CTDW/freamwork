package com.seeease.springframework.log.annotation;

import com.seeease.springframework.log.core.TaskPrinter;
import org.springframework.lang.Nullable;

import java.lang.annotation.*;


/**
 * 接口日志打印
 */
@Target({ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface LogPrinter {

    /**
     * 接口定义
     */
    String scenario();

    /**
     * 是否打印详情信息，详情信息根据 apiModel 字段确定
     */
    boolean printDetail() default true;

    /**
     * 接口请求类型
     */
    ApiModel apiModel() default ApiModel.WEB_API;

    /**
     * 后置的自定义打印日志内容.实现 PostPrinter 后注入ico中即可
     */
    Class<? extends PostPrinter> customPrinter() default PostPrinter.class;

    /**
     * 日志打印级别
     */
    PrintLevel level() default PrintLevel.AUTO;

    /**
     * 打印完成后的回调
     */
    Class<? extends  PostPrint> postPrint() default PostPrint.class;



    /**
     * 日志打印级别
     */
    enum PrintLevel{
        /**
         * 总是输出info日志
         */
        INFO,
        /**
         * 当无异常情况下输出info，异常情况下输出error
         */
        AUTO,
        /**
         * 仅发生异常是打印error日志
         */
        ONLY_ERROR
    }


    /**
     * 接口类型
     */
    enum ApiModel{
        /**
         * 详情打印的是curl
         */
        WEB_API
    }

    /**
     * 自定义打印内容实现基类
     */
    interface PostPrinter{
        /**
         * 执行自定义打印内容
         * @param taskId 任务id
         */
        String print(String taskId);
    }

    /**
     * 打印过后的后置处理
     */
    interface PostPrint{
        /**
         * 执行打印过后的后置处理
         * @param printer 执行过程中的打印器
         * @param e       执行打印过程中发送的异常
         */
        void postPrint(TaskPrinter printer,@Nullable Exception e);
    }



}
