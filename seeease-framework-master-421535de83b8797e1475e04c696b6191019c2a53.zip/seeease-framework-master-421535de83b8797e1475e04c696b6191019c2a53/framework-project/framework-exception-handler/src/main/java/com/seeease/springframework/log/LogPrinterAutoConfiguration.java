package com.seeease.springframework.log;

import com.seeease.springframework.log.core.PrinterFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.UUID;

/**
 * <p>日志打印配置</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 12/18/23 3:01下午
 **/
@Configuration
public class LogPrinterAutoConfiguration {


    /**
     * 注入日志打印器工厂，如需自定工厂。基础PrinterFactory类后注入ioc即可
     */
    @Bean
    @ConditionalOnMissingBean(PrinterFactory.class)
    public PrinterFactory printerFactory(){
        return new PrinterFactory();
    }

    /**
     * 注入日志打印切面
     */
    @Bean
    public LogPrintAspect logPrintAspect(PrinterFactory factory){
        return new LogPrintAspect(factory);
    }

    /**
     * 注入请求拦截器，生成请求对应的数据
     */
    @Bean
    public WebMvcConfigurer RequestHolderWebMvcConfigurer(){
        return new WebMvcConfigurer() {
            @Override
            public void addInterceptors(InterceptorRegistry registry) {
                // 可添加多个，/**是对所有的请求都做拦截
                registry.addInterceptor(new RequestHolder()).addPathPatterns("/**");
            }
        };
    }




    /**
     * 请求id缓存
     */
    public static class RequestHolder implements HandlerInterceptor {
        private static final ThreadLocal<String> requestId = new ThreadLocal<>();

        /**
         * 获取请求id
         */
        public static String getRequestId(){
            return requestId.get();
        }
        @Override
        public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
            requestId.set(UUID.randomUUID().toString());
            return HandlerInterceptor.super.preHandle(request, response, handler);
        }

        @Override
        public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
            try {
                HandlerInterceptor.super.afterCompletion(request, response, handler, ex);
            }finally {
                requestId.remove();
            }
        }
    }

}
