package com.seeease.springframework.log.core;

import com.seeease.springframework.log.annotation.LogPrinter;
import org.aspectj.lang.ProceedingJoinPoint;

/**
 * <p>默认的日志打印器</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 12/15/23
 **/
class DefaultLogTaskPrinter extends BaseTaskPrinter {


    public DefaultLogTaskPrinter(LogPrinter printer,
                                 LogPrinter.PostPrinter postPrinter,
                                 ProceedingJoinPoint joinPoint) {
        super(printer, postPrinter, joinPoint.getSignature().toString(), joinPoint.getArgs());
    }

    @Override
    public String printDetail(Exception e) {
        StringBuilder ret = new StringBuilder();
        ret.append("---------------------detail------------------\n");
        ret.append("api: ").append(getApiSignature()).append("\n");
        if (e != null) {
            StackTraceElement top = getExceptionStackTop(e);
            if (top != null) {
                ret.append("errorMsg: ").append(e.getMessage()).append("\n");

                ret.append("errorMethod: ")
                        .append(top.getClassName())
                        .append("#")
                        .append(top.getMethodName())
                        .append("\n");

                ret.append("errorLine: ").append(top.getLineNumber()).append("\n");
            }
        }
        LogPrinter printer = getPrinter();
        if (printer.printDetail()) {
            switch (printer.apiModel()) {
                case WEB_API:
                    ret.append(HttpPrinter.printCurl(getApiArgs()));
                default:
                    break;
            }
        }
        return ret.append("\n").toString();
    }

}
