package com.seeease.springframework.exception.e;

/**
 * @author Tiro
 * @date 2022/12/6
 */
public class BusinessException extends SeeeaseBaseException {
    public BusinessException(BusinessExceptionCode code) {
        super(code);
    }

    public BusinessException(BusinessExceptionCode code, Object... argArray) {
        super(code, argArray);
    }
}
