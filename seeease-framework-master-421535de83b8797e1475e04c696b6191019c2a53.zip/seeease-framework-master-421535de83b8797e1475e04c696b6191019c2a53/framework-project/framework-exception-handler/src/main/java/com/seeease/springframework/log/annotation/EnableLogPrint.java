package com.seeease.springframework.log.annotation;


import com.seeease.springframework.log.LogPrinterAutoConfiguration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.context.annotation.Import;

import java.lang.annotation.*;

@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Documented
@EnableAspectJAutoProxy(exposeProxy = true)
@Import(LogPrinterAutoConfiguration.class)
public @interface EnableLogPrint {
}
