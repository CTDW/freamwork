package com.seeease.springframework.exception;

import lombok.extern.slf4j.Slf4j;
import org.springframework.core.annotation.AnnotationUtils;

import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Objects;

/**
 * @author Tiro
 * @date 2022/12/8
 */
@Slf4j
public class ExceptionHandlerBeanPostProcessor extends AbstractBeanPostProcessor {

    protected boolean withGlobalExceptionHandler(Object bean) {
        Method[] methods = bean.getClass().getMethods();
        return Arrays.stream(methods)
                .anyMatch(this::withHandler);
    }

    protected boolean withHandler(Method method) {
        return Objects.nonNull(AnnotationUtils.findAnnotation(method, GlobalExceptionHandler.class));
    }
}
