package com.seeease.springframework.exception.e;

/**
 * @author Tiro
 * @date 2022/12/6
 */
public interface OperationRejectedExceptionCode extends SeeeaseBaseExceptionCode {

    default int getErrCode() {
        return 1;
    }
}
