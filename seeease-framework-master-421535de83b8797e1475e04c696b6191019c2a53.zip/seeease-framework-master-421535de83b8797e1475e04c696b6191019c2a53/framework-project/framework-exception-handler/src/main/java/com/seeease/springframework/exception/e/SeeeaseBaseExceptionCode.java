package com.seeease.springframework.exception.e;

import com.seeease.springframework.utils.StrFormatterUtil;

import java.io.Serializable;

/**
 * @author Tiro
 * @date 2022/12/6
 */
public interface SeeeaseBaseExceptionCode extends Serializable {

    /**
     * @return
     */
    int getErrCode();

    /**
     * @return
     */
    String getErrMsg();


    /**
     * @param argArray
     * @return
     */
    default String formatErrMsg(Object... argArray) {
        return StrFormatterUtil.format(this.getErrMsg(), argArray);
    }

    /**
     * @param argArray
     * @return
     */
    default String toStringExceptionCode(Object... argArray) {
        return String.format("[%d@%s]", this.getErrCode(), formatErrMsg(argArray));
    }
}
