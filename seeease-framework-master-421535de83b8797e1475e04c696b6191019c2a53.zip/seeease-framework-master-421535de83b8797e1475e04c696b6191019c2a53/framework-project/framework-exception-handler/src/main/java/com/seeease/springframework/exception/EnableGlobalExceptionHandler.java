package com.seeease.springframework.exception;

import org.springframework.context.annotation.AdviceMode;
import org.springframework.context.annotation.Import;
import org.springframework.core.Ordered;

import java.lang.annotation.*;

/**
 * @author Tiro
 * @date 2022/12/7
 */
@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Import({ExceptionHandlerConfigurationSelector.class})
public @interface EnableGlobalExceptionHandler {

    boolean proxyTargetClass() default false;

    /**
     * ASPECTJ 暂不支持
     *
     * @return
     */
    AdviceMode mode() default AdviceMode.PROXY;


    int order() default Ordered.LOWEST_PRECEDENCE;
}
