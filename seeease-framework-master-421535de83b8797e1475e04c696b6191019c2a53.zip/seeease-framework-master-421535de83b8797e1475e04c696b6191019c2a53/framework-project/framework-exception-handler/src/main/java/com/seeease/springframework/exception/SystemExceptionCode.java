package com.seeease.springframework.exception;

import com.seeease.springframework.exception.e.SeeeaseBaseExceptionCode;
import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author Tiro
 * @date 2022/12/6
 */
@AllArgsConstructor
@Getter
public enum SystemExceptionCode implements SeeeaseBaseExceptionCode {

    SYSTEM(-1, "系统异常"),
    ARGUMENT(-2, "参数异常");

    /**
     * @return
     */
    int errCode;
    String errMsg;
}
