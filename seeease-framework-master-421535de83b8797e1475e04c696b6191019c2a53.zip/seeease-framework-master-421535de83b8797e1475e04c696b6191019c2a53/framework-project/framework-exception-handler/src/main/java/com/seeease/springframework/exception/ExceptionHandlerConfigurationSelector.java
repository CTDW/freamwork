package com.seeease.springframework.exception;

import org.springframework.context.annotation.AdviceMode;
import org.springframework.context.annotation.AdviceModeImportSelector;
import org.springframework.lang.Nullable;

/**
 * @author Tiro
 * @date 2022/12/8
 */
public class ExceptionHandlerConfigurationSelector extends AdviceModeImportSelector<EnableGlobalExceptionHandler> {
    @Override
    @Nullable
    public String[] selectImports(AdviceMode adviceMode) {
        switch (adviceMode) {
            case PROXY:
                return new String[]{ProxyExceptionHandlerConfiguration.class.getName()};
            default:
                return null;
        }
    }
}
