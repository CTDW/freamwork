package com.seeease.springframework.exception.e;

/**
 * @author Tiro
 * @date 2022/12/6
 */
public class OperationRejectedException extends SeeeaseBaseException {
    public OperationRejectedException(OperationRejectedExceptionCode code) {
        super(code);
    }

    public OperationRejectedException(OperationRejectedExceptionCode code, Object... argArray) {
        super(code, argArray);
    }

}
