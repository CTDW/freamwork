package com.seeease.springframework.exception.e;

/**
 * @author Tiro
 * @date 2022/12/6
 */
public interface BusinessExceptionCode extends SeeeaseBaseExceptionCode {
}
