package com.seeease.springframework.log.core;

import com.seeease.springframework.log.annotation.LogPrinter;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;

/**
 *<p>
 *     打印器工厂
 *</p>
 *@author 西门 游
 *@since 12/18/23 下午
 *@version 1.0
**/
@Slf4j
public class PrinterFactory implements BeanFactoryAware {

    private BeanFactory beanFactory;

    /**
     * 构建默认的日志打印器，如果需要自定义，重写该方法后注入ioc即可
     * @param joinPoint 切面参数
     * @param printer   日志注解
     */
    public TaskPrinter build(ProceedingJoinPoint joinPoint, LogPrinter printer){
        LogPrinter.PostPrinter postPrinter = null;
        if (printer.customPrinter() != LogPrinter.PostPrinter.class) {
            try {
                postPrinter = beanFactory.getBean(printer.customPrinter());
            } catch (BeansException e) {
                log.warn("customerPrinter get fail");
            }
        }

        return new DefaultLogTaskPrinter(
                printer,
                postPrinter,
                joinPoint
        );
    }

    @Override
    public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
        this.beanFactory = beanFactory;
    }
}
