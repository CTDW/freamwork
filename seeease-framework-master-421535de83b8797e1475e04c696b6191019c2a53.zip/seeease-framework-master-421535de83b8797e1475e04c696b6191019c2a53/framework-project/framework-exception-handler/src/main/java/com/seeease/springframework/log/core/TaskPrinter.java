package com.seeease.springframework.log.core;

import com.seeease.springframework.log.annotation.LogPrinter;
import org.springframework.lang.Nullable;

/**
 * <p>任务打印器</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 12/18/23 2:06下午
 **/
public interface TaskPrinter extends Counter{


    /**
     * 打印任务执行完成日志
     * @param e 任务执行过程中的异常
     * @return 日志字符串
     */
    default String print(@Nullable Exception e){
        return printBase(e) + printDetail(e) + postPrint();
    }

    /**
     * 打印基础信息
     * @param e 任务执行过程中出现的异常
     */
     String printBase(@Nullable Exception e);

    /**
     * 打印详情
     * @param e 任务执行过程中出现的异常
     */
     String printDetail(@Nullable Exception e);

    /**
     * 获取后置打印结果
     */
     default String postPrint(){
         StringBuilder ret = new StringBuilder("");
         if (null != getPostPrinter()){
             ret.append("---------------------custom------------------\n");
             ret.append(getPostPrinter().print(getTaskId())).append("\n");
             ret.append("---------------------end---------------------\n");
         }
         return ret.toString();
     }

    /**
     * 获取后置自定义打印器
     */
     @Nullable LogPrinter.PostPrinter getPostPrinter();

    /**
     * 获取本次打印的任务id
     */
     String getTaskId();


    /**
     * 根据异常信息获取引用项目异常栈顶
     * 例如a项目引用了该包，并且抛出异常后该方法能够通过该异常捕获a项目中最早抛出异常的那一行
     * 如果不是a项目抛出的异常 则返回null
     *
     * @param e 抛出的异常
     */
    default @Nullable
    StackTraceElement getExceptionStackTop(Exception e) {
        StackTraceElement[] stackTrace = e.getStackTrace();
        for (StackTraceElement i : stackTrace) {
            if (i.getClassName().startsWith(IApplicationListener.projectBasePackageName)) {
                return i;
            }
        }
        return null;
    }

}
