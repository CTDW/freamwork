package com.seeease.springframework.log.core;

/**
 * <p>计时器</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 12/18/23 2:45 下午
 **/
public interface Counter {

    /**
     * 任务开启
     * @param taskName 任务名称
     */
    void start(String taskName);

    /**
     * 任务结束
     */
    void stop();
}
