package com.seeease.springframework.log.core;

import org.springframework.util.StopWatch;

import java.text.NumberFormat;
import java.util.UUID;

/**
 * <p>自定义stopWatch</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 12/18/23
 **/
public class TaskCounter extends StopWatch implements Counter {

    public TaskCounter() {
        super(UUID.randomUUID().toString());
    }

    public TaskCounter(String taskId){
        super(taskId);
    }

    @Override
    public String prettyPrint() {
        StringBuilder sb = new StringBuilder("\n");
        sb.append("---------------------------------------------\n");
        sb.append("taskId:").append(getId()).append("\n");
        sb.append("---------------------------------------------\n");
        sb.append("ns         %     Task name\n");
        sb.append("---------------------------------------------\n");
        NumberFormat nf = NumberFormat.getNumberInstance();
        nf.setMinimumIntegerDigits(9);
        nf.setGroupingUsed(false);
        NumberFormat pf = NumberFormat.getPercentInstance();
        pf.setMinimumIntegerDigits(3);
        pf.setGroupingUsed(false);
        for (TaskInfo task : getTaskInfo()) {
            sb.append(nf.format(task.getTimeNanos())).append("  ");
            sb.append(pf.format((double) task.getTimeNanos() / getTotalTimeNanos())).append("  ");
            sb.append(task.getTaskName()).append("\n");
        }
        return sb.toString();
    }
}
