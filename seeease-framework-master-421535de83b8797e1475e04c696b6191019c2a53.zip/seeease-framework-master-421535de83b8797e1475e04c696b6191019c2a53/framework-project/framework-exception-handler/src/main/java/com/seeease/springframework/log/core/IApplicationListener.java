package com.seeease.springframework.log.core;

import org.springframework.boot.context.event.ApplicationEnvironmentPreparedEvent;
import org.springframework.context.ApplicationListener;

/**
 * @author 西门 游
 * @version 1.0
 * @since 12/15/23
 **/
public class IApplicationListener implements ApplicationListener<ApplicationEnvironmentPreparedEvent> {

    /**
     * 引用项目包基础包名
     */
    public static String projectBasePackageName;

    @Override
    public void onApplicationEvent(ApplicationEnvironmentPreparedEvent event) {
        Class<?> mainApplicationClass = event.getSpringApplication().getMainApplicationClass();
        projectBasePackageName = mainApplicationClass.getPackage().getName();
    }

}