package com.seeease.springframework.exception;

import java.lang.annotation.*;

/**
 * @author Tiro
 * @date 2022/12/7
 */
@Target({ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface GlobalExceptionHandler {
}
