package com.seeease.springframework.exception;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.SmartInstantiationAwareBeanPostProcessor;
import org.springframework.cglib.proxy.Enhancer;
import org.springframework.cglib.proxy.MethodInterceptor;
import org.springframework.cglib.proxy.MethodProxy;

import java.lang.reflect.Method;

/**
 * @author Tiro
 * @date 2022/12/8
 */
@Slf4j
public abstract class AbstractBeanPostProcessor implements SmartInstantiationAwareBeanPostProcessor {

    protected abstract boolean withGlobalExceptionHandler(Object bean);

    protected abstract boolean withHandler(Method method);

    @Override
    public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {
        if (!withGlobalExceptionHandler(bean)) {
            return bean;
        }
        InternalMethodInterceptor interceptor = new InternalMethodInterceptor();
        Object proxyBean = interceptor.warpBean(bean, beanName);
        return proxyBean;
    }


    class InternalMethodInterceptor implements MethodInterceptor {
        private Object bean;

        public Object warpBean(Object bean, String beanName) {
            Enhancer enhancer = new Enhancer();
            this.bean = bean;
            enhancer.setSuperclass(bean.getClass());
            enhancer.setCallback(this);
            return enhancer.create();
        }

        @Override
        public Object intercept(Object o, Method method, Object[] objects, MethodProxy methodProxy) throws Throwable {
            if (!withHandler(method)) {
                return methodProxy.invoke(bean, objects);
            }
            try {
                return methodProxy.invoke(bean, objects);
            } catch (Exception e) {
                log.error(e.getMessage(), e);
                return ExceptionConvert.convert(e);
            }

        }
    }
}
