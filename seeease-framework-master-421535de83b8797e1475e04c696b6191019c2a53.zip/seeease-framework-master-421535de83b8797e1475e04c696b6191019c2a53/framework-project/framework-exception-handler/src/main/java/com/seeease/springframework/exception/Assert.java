package com.seeease.springframework.exception;


import com.seeease.springframework.exception.e.BusinessException;
import com.seeease.springframework.exception.e.BusinessExceptionCode;
import org.springframework.util.StringUtils;

/**
 * <p>
 *     断言工具类 抛出 {@link BusinessExceptionCode}
 * </p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 11/1/23 11:10 上午
 **/
public class Assert {


    /**
     * Assert a boolean expression, throwing an {@code IllegalArgumentException}
     * if the expression evaluates to {@code false}.
     * <pre class="code">Assert.isTrue(i &gt; 0, "The value must be greater than zero");</pre>
     * @param expression a boolean expression
     * @param code
     * @throws BusinessException if {@code expression} is {@code false}
     */
    public static void isTrue(boolean expression, BusinessExceptionCode code) {
        if (!expression) {
            throw new BusinessException(code);
        }
    }


    /**
     * Assert that an object is {@code null}.
     * <pre class="code">Assert.isNull(value, "The value must be null");</pre>
     * @param object the object to check
     * @param code
     * @throws BusinessException if the object is not {@code null}
     */
    public static void isNull( Object object,  BusinessExceptionCode code) {
        if (object != null) {
            throw new BusinessException(code);
        }
    }


    /**
     * Assert that an object is not {@code null}.
     * <pre class="code">Assert.notNull(clazz, "The class must not be null");</pre>
     * @param object the object to check
     * @param code
     * @throws BusinessException if the object is {@code null}
     */
    public static void notNull( Object object,  BusinessExceptionCode code) {
        if (object == null) {
            throw new BusinessException(code);
        }
    }


    /**
     * Assert that the given String is not empty; that is,
     * it must not be {@code null} and not the empty String.
     * <pre class="code">Assert.hasLength(name, "Name must not be empty");</pre>
     * @param text the String to check
     * @param code
     * @throws IllegalArgumentException if the text is empty
     * @see StringUtils#hasLength
     */
    public static void hasLength(String text,  BusinessExceptionCode code) {
        if (!StringUtils.hasLength(text)) {
            throw new BusinessException(code);
        }
    }

    /**
     * Assert that the given String contains valid text content; that is, it must not
     * be {@code null} and must contain at least one non-whitespace character.
     * <pre class="code">Assert.hasText(name, "'name' must not be empty");</pre>
     * @param text the String to check
     * @param code
     * @throws IllegalArgumentException if the text does not contain valid text content
     * @see StringUtils#hasText
     */
    public static void hasText(String text, BusinessExceptionCode code) {
        if (!StringUtils.hasText(text)) {
            throw new BusinessException(code);
        }
    }
}
