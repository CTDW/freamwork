package com.seeease.springframework.exception;

import com.seeease.springframework.SingleResponse;
import com.seeease.springframework.exception.e.ArgumentException;
import com.seeease.springframework.exception.e.OperationRejectedException;
import com.seeease.springframework.exception.e.SeeeaseBaseExceptionCode;
import org.apache.commons.lang3.StringUtils;

import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author Tiro
 * @date 2022/12/7
 */
public class ExceptionConvert {

    private static final String CODE_MES_RGEX = "(?<=\\[).*?(?=\\])";

    /**
     * @param e
     * @return
     */
    public static SingleResponse convert(Exception e) {
        int errCode = SystemExceptionCode.SYSTEM.getErrCode();
        String errMessage = SystemExceptionCode.SYSTEM.getErrMsg();
        if (e instanceof ArgumentException) {
            errCode = SystemExceptionCode.ARGUMENT.getErrCode();
            errMessage = Optional.ofNullable(e.getMessage()).orElse(SystemExceptionCode.ARGUMENT.getErrMsg());
        } else if (e instanceof OperationRejectedException) {
            OperationRejectedException e1 = (OperationRejectedException) e;
            errCode = e1.getCode().getErrCode();
            errMessage = e1.getCode().formatErrMsg(e1.getArgArray());
        } else if (StringUtils.contains(e.getMessage(), "com.seeease.springframework.exception.e.OperationRejectedException")) {
            SeeeaseBaseExceptionCode code = matchOperationRejectedException(e.getMessage(), SystemExceptionCode.SYSTEM);
            errCode = code.getErrCode();
            errMessage = code.getErrMsg();
        }
        SingleResponse response = SingleResponse.buildFailure(errCode, errMessage);
        return response;

    }

    /**
     * @param message
     * @param defaultCode
     * @return
     */
    private static SeeeaseBaseExceptionCode matchOperationRejectedException(String message, SeeeaseBaseExceptionCode defaultCode) {
        try {
            Matcher matcher = Pattern.compile(CODE_MES_RGEX).matcher(message); //进行匹配
            if (!matcher.find()) {
                return defaultCode;
            }
            String msg = matcher.group();
            String[] arr = msg.split("@");
            return new SeeeaseBaseExceptionCode() {
                @Override
                public int getErrCode() {
                    return Integer.valueOf(arr[0]);
                }

                @Override
                public String getErrMsg() {
                    return arr[1];
                }
            };

        } catch (Exception e) {
            return defaultCode;
        }
    }
}
