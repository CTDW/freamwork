package com.seeease.springframework.log;

import com.seeease.springframework.log.annotation.LogPrinter;
import com.seeease.springframework.log.core.PrinterFactory;
import com.seeease.springframework.log.core.TaskPrinter;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;


/**
 * <p>日志打印切面</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 12/15/23
 **/
@Aspect
@Slf4j
public class LogPrintAspect implements BeanFactoryAware {


    private final PrinterFactory factory;
    private BeanFactory beanFactory;

    public LogPrintAspect(PrinterFactory factory) {
        this.factory = factory;
    }

    @Around("@annotation(printer)")
    public Object logMethodExecution(ProceedingJoinPoint joinPoint, LogPrinter printer) throws Throwable {

        TaskPrinter p = factory.build(joinPoint, printer);
        p.start(printer.scenario());
        Exception ex = null;
        try {
            return joinPoint.proceed();
        } catch (Exception e) {
            ex = e;
            throw e;
        } finally {
            p.stop();
            String ret = p.print(ex);

            //根据level输出结果
            LogPrinter.PrintLevel level = printer.level();
            if (level == LogPrinter.PrintLevel.ONLY_ERROR && ex == null) {
                //do nothing
            } else if (level == LogPrinter.PrintLevel.INFO ||
                    (level == LogPrinter.PrintLevel.AUTO && ex == null)) {
                log.info(ret);
            } else {
                log.error(ret);
            }

            //执行打印后的回调处理
            Class<? extends LogPrinter.PostPrint> callback = printer.postPrint();
            if (callback != LogPrinter.PostPrint.class){
                try {
                    LogPrinter.PostPrint bean = beanFactory.getBean(callback);
                    bean.postPrint(p,ex);
                }catch (Exception e){
                    log.error("postPrint invoke error:msg{}",e.getMessage());
                }
            }
        }
    }

    @Override
    public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
        this.beanFactory = beanFactory;
    }
}
