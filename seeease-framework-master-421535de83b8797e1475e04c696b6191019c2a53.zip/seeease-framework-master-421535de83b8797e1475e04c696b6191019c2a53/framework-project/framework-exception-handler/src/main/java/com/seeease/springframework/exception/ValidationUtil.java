package com.seeease.springframework.exception;

import com.seeease.springframework.exception.e.ArgumentException;
import org.springframework.util.StringUtils;

/**
 * @author Tiro
 * @date 2024/3/20
 */
public abstract class ValidationUtil {

    public static void isTrue(boolean expression, String msg) {
        if (!expression) {
            throw new ArgumentException(msg);
        }
    }

    public static void notNull(Object object, String msg) {
        if (object == null) {
            throw new ArgumentException(msg);
        }
    }

    public static void notEmpty(String str, String msg) {
        if (StringUtils.isEmpty(str)) {
            throw new ArgumentException(msg);
        }
    }

    public static void notEmptyWithMaxLength(String str, int maxLength, String msg) {
        if (StringUtils.isEmpty(str) || str.length() > maxLength) {
            throw new ArgumentException(msg);
        }
    }
}
