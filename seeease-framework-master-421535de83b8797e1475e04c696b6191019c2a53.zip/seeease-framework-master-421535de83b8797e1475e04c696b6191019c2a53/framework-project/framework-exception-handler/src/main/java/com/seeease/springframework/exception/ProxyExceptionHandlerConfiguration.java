package com.seeease.springframework.exception;

import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Role;

/**
 * @author Tiro
 * @date 2022/12/8
 */
@Configuration
@Role(BeanDefinition.ROLE_INFRASTRUCTURE)
public class ProxyExceptionHandlerConfiguration {

    @Bean(name = {"exceptionHandlerBeanPostProcessor"})
    @Role(BeanDefinition.ROLE_INFRASTRUCTURE)
    public ExceptionHandlerBeanPostProcessor exceptionHandlerBeanPostProcessor() {
        return new ExceptionHandlerBeanPostProcessor();
    }

    @Configuration
    @ConditionalOnClass(name = "org.springframework.web.servlet.HandlerExceptionResolver")
    public static class MvcProxyExceptionHandlerConfiguration {

        @Bean(name = {"mvcHandlerExceptionResolver"})
        @Role(BeanDefinition.ROLE_INFRASTRUCTURE)
        @ConditionalOnWebApplication
        public MvcHandlerExceptionResolver mvcHandlerExceptionResolver() {
            return new MvcHandlerExceptionResolver();
        }
    }

}
