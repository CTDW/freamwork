package com.seeease.tb;

import com.seeease.tb.properties.TaoBaoProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 8/8/24 10:21 上午
 **/
@Configuration
@EnableConfigurationProperties({TaoBaoProperties.class})
public class AutoConfiguration {


}
