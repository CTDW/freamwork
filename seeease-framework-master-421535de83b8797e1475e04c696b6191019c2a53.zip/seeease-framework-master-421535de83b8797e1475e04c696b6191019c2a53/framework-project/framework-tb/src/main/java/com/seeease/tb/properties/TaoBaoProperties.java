package com.seeease.tb.properties;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 8/8/24 10:24 上午
 **/
@Data
@ConfigurationProperties(prefix = "tb")
public class TaoBaoProperties {

    private String appKey;
    private String secret;

}
