package com.seeease.frameworkinsurance.pacific;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * 产品代码
 */
@AllArgsConstructor
@Getter
public enum ProductCodeEnum {
    ONE("1107KO00","数据服务咨询机构专业责任保险");

    private String code;
    private String desc;

}
