package com.seeease.frameworkinsurance.pacific;

/**
 * <p>太平洋保险常量</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 4/16/24 6:24下午
 **/
public interface Constant {
    /**
     * 正式环境url
     */
     String PROD_BASE_URL = "https://cxsuz-tp.cpic.com.cn/";
    /**
     * 测试环境url
     */
     String TEST_BASE_URL = "https://cxsuzcs.cpic.com.cn/";
}
