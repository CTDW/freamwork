package com.seeease.frameworkinsurance.pacific.result;

import lombok.Data;

import java.io.Serializable;

/**
 * <p>基础返回</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 4/17/24 9:50上午
 **/
@Data
public class BaseResult<T> implements Serializable {

    private Integer code;
    private String message;
    private T data;


}
