package com.seeease.frameworkinsurance.pacific;

/**
 * <p>请求失败异常</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 4/17/24 10:00 上午
 **/
public class RequestFailException extends RuntimeException{
    public RequestFailException(String message) {
        super(message);
    }
}
