package com.seeease.frameworkinsurance.pacific.request;

import lombok.Data;

/**
 * <p>获取auth请求</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 4/16/24 6:27 下午
 **/
@Data
public class AuthenticateQueryRequest {
    /**
     * 连接凭证，太平洋保险提供
     */
    private String ticket;
}
