package com.seeease.frameworkinsurance.pacific.result;

import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * <p>提交报价单后对方的回调参数</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 4/29/24 3:12 下午
 **/
@Data
public class PolicyIssuedNotifyResult {
    /**
     * 保单
     */
    private String policyNo;
    /**
     * 起保日期
     */
    private Date insStartDate;
    /**
     * 截止日期
     */
    private Date insEndDate;
    /**
     * 金额种类
     */
    private String curyCode;
    /**
     * 保费
     */
    private BigDecimal premium;
    /**
     * 订单列表
     */
    private List<Order> orderList;
    @Data
    public static class Order{
        private String orderNo;
    }
}
