
package com.seeease.frameworkinsurance.pacific;

/**
 * <p>重复投保异常</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 4/17/24 10:00 上午
 **/
public class RepeatInsuranceException extends RuntimeException{
    public RepeatInsuranceException(String message) {
        super(message);
    }
}
