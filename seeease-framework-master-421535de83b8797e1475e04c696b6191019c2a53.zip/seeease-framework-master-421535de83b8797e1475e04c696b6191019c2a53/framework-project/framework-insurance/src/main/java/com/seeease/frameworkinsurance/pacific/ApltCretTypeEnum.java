package com.seeease.frameworkinsurance.pacific;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * 证件类型枚举
 */
@Getter
@AllArgsConstructor
public enum ApltCretTypeEnum {

    ID_CARD(111,"居民身份证","个人客户类型"),
    FOREIGN_ID_CARD(553,"外国人永久居留证","个人客户类型"),
    ORGANIZATION_CODE(602,"组织机构代码","团体客户类型"),
    PASS_PORT(623,"外国护照","个人客户类型"),
    USC_CODE(633,"社会统一信用代码","团体客户类型"),
    OTHER(990,"其他","上述不适用的情形"),
    ;


    private Integer code;
    private String name;
    private String desc;
}
