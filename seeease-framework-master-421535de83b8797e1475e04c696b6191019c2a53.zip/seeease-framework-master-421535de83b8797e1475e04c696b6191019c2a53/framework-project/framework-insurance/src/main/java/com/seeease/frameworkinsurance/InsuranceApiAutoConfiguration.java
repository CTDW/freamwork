package com.seeease.frameworkinsurance;

import com.seeease.framework.FastJsonConverterFactory;
import com.seeease.frameworkinsurance.api.PacificApi;
import com.seeease.frameworkinsurance.pacific.Constant;
import okhttp3.OkHttpClient;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import retrofit2.Retrofit;

import java.util.concurrent.TimeUnit;

/**
 * <p>api接口配置</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 11/22/23 上午
 **/
@Configuration
public class InsuranceApiAutoConfiguration {

    @Value("${spring.profiles.active}")
    private String env;

    /**
     * 注入小程序api
     */
    @Bean
    public PacificApi wechatAppletApi() {
        String host = env.equals("prod") ? Constant.PROD_BASE_URL : Constant.TEST_BASE_URL;

        OkHttpClient okHttpClient = new OkHttpClient.Builder()
                .connectTimeout(1, TimeUnit.MINUTES)
                .readTimeout(2, TimeUnit.MINUTES)
                .writeTimeout(3, TimeUnit.MINUTES)
                .build();
        return new Retrofit.Builder()
                .baseUrl(host) //网络请求URL相对固定的地址
                .addConverterFactory(FastJsonConverterFactory.create())
                .client(okHttpClient) //使用OkHttp请求
                .build()
                .create(PacificApi.class);
    }


}
