package com.seeease.frameworkinsurance.pacific;

import org.springframework.util.Base64Utils;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.security.SecureRandom;

public class AESUtil {



	private static final String KEY_ALGORITHM = "AES";

	private static final String DEFAULT_CIPHER_ALGORITHM = "AES/ECB/PKCS5Padding";// 默认的加密算法

	//AES加密
	public static String encrypt(String content, String password) {
		try {
			Cipher cipher = Cipher.getInstance(DEFAULT_CIPHER_ALGORITHM);//创建密码器
			byte[] byteContent = content.getBytes("utf-8");
			cipher.init(Cipher.ENCRYPT_MODE, getSecretKey(password));//初始化为加密模式的密码器
			byte[] result = cipher.doFinal(byteContent);//加密
			return Base64Utils.encodeToString(result);//通过Base64转码返回
		} catch (Exception e) {
			//do nothing
		}
		return null;
	}

	//AES解密
	public static String decrypt(String content, String password) {
		try {
			//实例化
			Cipher cipher = Cipher.getInstance(DEFAULT_CIPHER_ALGORITHM);
			//使用密钥初始化，设置为解密模式
			cipher.init(Cipher.DECRYPT_MODE, getSecretKey(password));
			//执行操作
			byte[] result = cipher.doFinal(Base64Utils.decodeFromString(content));
			String s = new String(result, "utf-8");
			return s;
		} catch (Exception e) {
			//do nothing
		}
		return null;
	}

	//生成加密秘钥
	private static SecretKeySpec getSecretKey(String password) {
		//返回生成指定算法密钥生成器的 KeyGenerator 对象
		KeyGenerator kg = null;
		try {
			kg = KeyGenerator.getInstance(KEY_ALGORITHM);
			SecureRandom random = SecureRandom.getInstance("SHA1PRNG");
			random.setSeed(password.getBytes());
			//AES 要求密钥长度为 128
			kg.init(128, random);
			//生成一个密钥
			SecretKey secretKey = kg.generateKey();
			return new SecretKeySpec(secretKey.getEncoded(),KEY_ALGORITHM);//转换为AES专用密钥
		} catch (Exception e) {
			//do nothing
		}
		return null;
	}

	public static String bytesToHex(byte[] src){
		if (src == null || src.length <= 0) {
			return null;
		}

		StringBuilder stringBuilder = new StringBuilder("");
		for (int i = 0; i < src.length; i++) {
			// 之所以用byte和0xff相与，是因为int是32位，与0xff相与后就舍弃前面的24位，只保留后8位
			String str = Integer.toHexString(src[i] & 0xff);
			if (str.length() < 2) { // 不足两位要补0
				stringBuilder.append(0);
			}
			stringBuilder.append(str);
		}
		return stringBuilder.toString();
	}

}
