package com.seeease.frameworkinsurance.pacific.request;

import com.seeease.frameworkinsurance.pacific.ProductCodeEnum;
import lombok.Data;

import java.math.BigDecimal;
import java.util.List;

/**
 * <p>投保请求</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 4/17/24 10:14上午
 **/
@Data
public class InsureApplyRequest {
    /**
     * 订单号,合作方的交易流水号，幂等字段
     * Y
     */
    private String orderNo;
    /**
     * 订单号,合作方的交易流水号，幂等字段
     * 投保的产品，参照附表：产品代码
     * Y
     */
    private String prodCode = ProductCodeEnum.ONE.getCode();
    /**
     * 保险方案代码，太保分配
     * Y
     */
    private String planCode;
    /**
     * 发起交易时间，格式yyyy-MM-ddHH:mm:ss
     * Y
     */
    private String applyDate;
    /**
     * 起保日期，格式yyyy-MM-ddHH:mm:ss
     * Y
     */
    private String insStartDate;
    /**
     * 止保日期，格式yyyy-MM-ddHH:mm:ss
     * 本案，=起保日期的下年同日-1天
     * Y
     */
    private String insEndDate;
    /**
     * 标的数量
     */
    private Integer objNumber;
    /**
     * 投保人列表节点
     */
    private List<Applicant> applicantList;
    /**
     * 被保险人列表节点
     */
    private List<Insured> insuredList;
    /**
     * 保险标的列表节点
     */
    private List<Object> objectList;

    /**
     * 投保人数据
     */
    @Data
    public static class Applicant{
        /**
         * 投保人序号，从1开始递增
         * Y
         */
        private Integer apltId;
        /**
         * 投保人名称
         * Y
         */
        private String apltName;
        /**
         * 投保人证件类型，参照附表：证件类型 {@link com.seeease.frameworkinsurance.pacific.ApltCretTypeEnum}
         * Y
         */
        private String apltCretType;
        /**
         * 投保人证件号
         * Y
         */
        private String apltCretCode;
        /**
         * 投保人地址（省市县+详细地址）
         * Y
         */
        private String apltAddress;
        /**
         * 投保人电话（电子保单必填，短信会发送到手机号）
         * CY
         */
        private String apltMobile;
        /**
         * 投保人电子邮箱（电子保单必填，电子保单会发送到这个邮箱）
         * CY
         */
        private String apltEmail;
    }


    /**
     * 被投保人数据
     */
    @Data
    public static class Insured{
        /**
         * 被投保人序号，从1开始递增
         * Y
         */
        private Integer isrdId;
        /**
         * 被投保人名称
         * Y
         */
        private String isrdName;
        /**
         * 被投保人证件类型，参照附表：证件类型 {@link com.seeease.frameworkinsurance.pacific.ApltCretTypeEnum}
         * Y
         */
        private String isrdCretType;
        /**
         * 被投保人证件号
         * Y
         */
        private String isrdCretCode;
        /**
         * 被投保人地址（省市县+详细地址）
         * Y
         */
        private String isrdAddress;
        /**
         * 被投保人电话（电子保单必填，短信会发送到手机号）
         * CY
         */
        private String isrdMobile;
        /**
         * 被投保人电子邮箱（电子保单必填，电子保单会发送到这个邮箱）
         * CY
         */
        private String isrdEmail;
    }


    /**
     * 投保物品
     */
    @Data
    public static class Object{
        /**
         * 序号，从1开始递增
         * Y
         */
        private String objId;
        /**
         * 标的品牌
         * Y
         */
        private String objBrand;
        /**
         * 标的型号
         * Y
         */
        private String objType;
        /**
         * 标的编码，序列号
         * Y
         */
        private String objCode;
        /**
         * 标的登记/成交日期，yyyy-mm-dd
         * Y
         */
        private BigDecimal dealValue;
        /**
         * 标的价值，成交价格
         * Y
         */
        private String dealDate;
        /**
         * 销售门店
         * Y
         */
        private String storeName;
    }
}
