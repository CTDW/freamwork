package com.seeease.frameworkinsurance.api;

import com.alibaba.fastjson.JSONObject;
import com.seeease.frameworkinsurance.pacific.AESUtil;
import com.seeease.frameworkinsurance.pacific.RepeatInsuranceException;
import com.seeease.frameworkinsurance.pacific.RequestFailException;
import com.seeease.frameworkinsurance.pacific.request.AuthenticateQueryRequest;
import com.seeease.frameworkinsurance.pacific.request.InsureApplyRequest;
import com.seeease.frameworkinsurance.pacific.result.BaseResult;
import okhttp3.ResponseBody;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.digest.DigestUtils;
import retrofit2.Call;
import retrofit2.Response;
import retrofit2.http.*;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Base64;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * <p>太平洋保险接口</p>
 *
 * @author 西门游
 * @version 1.0
 * @date 4/16/24 6:21下午
 **/
public interface PacificApi {


    /**
     * 获取时间
     */
    default String getTime() {
        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        return now.format(formatter);
    }

    /**
     * 验证结果
     */
    default <T> T verify(BaseResult<T> ret) {
        if (ret.getCode().equals(605) && ret.getMessage().startsWith("订单号已存在")) {
            throw new RepeatInsuranceException(String.format("太平洋保险请求失败，失败详细信息:%s", JSONObject.toJSONString(ret)));
        }
        if (!ret.getCode().equals(200)) {
            throw new RequestFailException(String.format("太平洋保险请求失败，失败详细信息:%s", JSONObject.toJSONString(ret)));
        }
        return ret.getData();
    }


    /**
     * 请求体编码
     *
     * @param body     请求参数
     * @param password 秘钥
     * @param token    token
     * @param time     请求时间
     * @throws NoSuchAlgorithmException
     */
    default <T> JSONObject encodeBody(T body,
                                      String password,
                                      String token,
                                      String time) throws NoSuchAlgorithmException {
        String data = AESUtil.encrypt(JSONObject.toJSONString(body), password);
        String sign = Hex.encodeHexString(MessageDigest.getInstance("MD5").digest((token + data + time).getBytes(StandardCharsets.UTF_8)));

        JSONObject ret = new JSONObject();
        ret.put("data", data);
        ret.put("sign", sign);
        return ret;
    }

    /**
     * 用户登录获取authenticate
     *
     * @param body 请求参数
     * @param time 请求时间 {{@link #getTime()}}
     * @return authenticate 从返回的header中获取
     */
    @POST("thirdParty/getToken")
    Call<BaseResult<Object>> getAuthenticate(@Body AuthenticateQueryRequest body,
                                             @Header("time") String time);


    /**
     * 用户登录获取authenticate
     *
     * @param ticket 连接凭证
     */
    default String getAuthenticate(String ticket) throws IOException {
        AuthenticateQueryRequest authenticateQueryRequest = new AuthenticateQueryRequest();
        authenticateQueryRequest.setTicket(ticket);
        Response<BaseResult<Object>> response = getAuthenticate(authenticateQueryRequest, getTime()).execute();
        verify(response.body());
        return response.headers().get("authenticate");
    }


    /**
     * 获取token
     *
     * @param body          请求参数
     * @param time          请求时间 {{@link #getTime()}}
     * @param authorization {@link #getAuthenticate(String)}
     * @return token
     */
    @POST("thirdParty/getToken")
    Call<BaseResult<String>> getToken(@Body AuthenticateQueryRequest body,
                                      @Header("time") String time,
                                      @Header("Authorization") String authorization);


    /**
     * 获取token
     *
     * @param ticket   连接凭证
     * @param username 企业编码
     * @param password 秘钥
     * @throws Exception
     */
    default String getToken(String ticket,
                            String username,
                            String password) throws Exception {
        String firstRequestOut = getAuthenticate(ticket);

        AuthenticateQueryRequest authenticateQueryRequest = new AuthenticateQueryRequest();
        authenticateQueryRequest.setTicket(ticket);

        Pattern HEADER_PATTERN = Pattern.compile("Digest realm=\"(.*)\",qop=\"(.*)\",nonce=\"(.*)\"");

        Matcher matcher = HEADER_PATTERN.matcher(firstRequestOut);
        String GET_TOKEN_URL = "/getToken";
        if (matcher.matches()) {
            String a1 = username + ":" + matcher.group(1) + ":" + password;

            String a2 = Hex.encodeHexString(MessageDigest.getInstance("MD5")
                    .digest(a1.getBytes(StandardCharsets.UTF_8)));

            String a3 = Hex.encodeHexString(MessageDigest.getInstance("MD5")
                    .digest(("POST:" + GET_TOKEN_URL).getBytes(StandardCharsets.UTF_8)));

            String a4 = a2 + ":" + matcher.group(3) + ":" + ":" + "" + ":" + matcher.group(2) + ":" + a3;
            String a5 = DigestUtils.md5Hex(a4.getBytes());

            firstRequestOut = "Digest username=\"" + username + "\",realm=\"" + matcher.group(1) + "\",nonce=\"" + matcher.group(3) + "\",uri=\"" + GET_TOKEN_URL + "\",qop=" + matcher.group(2) + ",nc=,cnonce=\"\",response=\"" + a5 + "\",opaque=\"\"";
        }

        BaseResult<String> ret = getToken(authenticateQueryRequest, getTime(), firstRequestOut)
                .execute()
                .body();
        return verify(ret);

    }


    /**
     * 投保交易接口
     *
     * @param token token
     * @param time  时间戳
     * @param body  请求体
     */
    @POST("thirdParty/dsol/insureApply")
    Call<BaseResult<Object>> insureApply(@Header("token") String token,
                                         @Header("time") String time,
                                         @Body JSONObject body);


    /**
     * 投保交易接口
     *
     * @param ticket   连接凭证
     * @param username 企业编码
     * @param password 秘钥
     * @param body     请求体
     */
    default Object insureApply(InsureApplyRequest body,
                               String ticket,
                               String username,
                               String password) throws Exception {
        String token = getToken(ticket, username, password);
        String time = getTime();
        JSONObject req = encodeBody(body, password, token, time);
        Response<BaseResult<Object>> execute = insureApply(token, time, req).execute();
        BaseResult<Object> ret = execute.body();
        if (ret == null) {
            throw new RuntimeException("太平洋保险投保失败::" + JSONObject.toJSONString(execute.errorBody()));
        }
        return verify(ret);
    }


    /**
     * 保单下载
     *
     * @param token base64编码后的token
     * @param plcNo 太保保单号
     */
    @GET("thirdParty/dwledoc")
    Call<ResponseBody> dwledoc(@Header("token") String tokenh,
                               @Header("time") String time,
                               @Query("token") String token,
                               @Query("plcNo") String plcNo);

    /**
     * 保单下载
     *
     * @param plcNo 太保保单号
     */
    @GET("thirdParty/dwledoc")
    default ResponseBody downLoadDoc(String plcNo,
                                               String ticket,
                                               String username,
                                               String password) throws Exception {
        String token = getToken(ticket, username, password);
        String encodedString = Base64.getEncoder().encodeToString(token.getBytes());
        Call<ResponseBody> responseBodyCall = dwledoc(token, getTime(), encodedString, plcNo);
        return responseBodyCall.execute().body();
    }
}
