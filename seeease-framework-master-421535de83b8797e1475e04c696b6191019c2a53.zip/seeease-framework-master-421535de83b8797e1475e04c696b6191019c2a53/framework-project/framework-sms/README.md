# 该模块整理了短信发送业务
#使用 @EnableSms 开启服务 ，包含以下短信业务
- 三体云短信发送.使用 com.seeease.framework.stcloud.StCloudApi .使用时请注意填写三体云配置文件。配置文件格式如 com.seeease.framework.stcloud.Properties 所示