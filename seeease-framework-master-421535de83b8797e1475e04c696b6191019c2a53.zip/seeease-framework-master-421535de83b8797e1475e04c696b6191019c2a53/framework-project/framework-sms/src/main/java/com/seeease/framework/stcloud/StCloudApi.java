package com.seeease.framework.stcloud;

import com.seeease.springframework.utils.StringUtils;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

/**
 * <p>三体云接口调用</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 12/15/23 2:17下午
 **/
public interface StCloudApi {

    /**
     * 短信发送
     *
     * @param phone    电话
     * @param moduleId 模块id
     * @param arg      短信参数多个参数之间使用 | 分割
     * @param sign     签名
     * @param appId    appId
     * @return  发送结果
     */
    @GET("http://sms.smspaas.com/mt.php")
    Call<String> sent(@Query("appId") String appId,
                      @Query("mobile") String phone,
                      @Query("modeId") String moduleId,
                      @Query("vars") String arg,
                      @Query("sign") String sign);


    /**
     * 适配{@link #sent(String, String, String, String, String)} 方法
     * @param moduleId 模块id
     * @param phone    电话
     * @param args    短信参数
     * @return  发送结果
     */
    default Call<String> sent(String moduleId,String phone,String ... args) throws Exception{
        String appId = Properties.getAppIdStatic();
        String appKey = Properties.getAppKeyStatic();
        String sign = createSign(appKey, appId, phone);
        return sent(appId,phone,moduleId,String.join("|",args),sign);
    }


    /**
     * 计算sign
     *
     * @param appKey appKey
     * @param appId  appId
     * @param phone  phone
     * @throws Exception
     */
    default String createSign(String appKey, String appId, String phone) throws Exception {
        return StringUtils.encoderByMd5(appKey + appId + phone).toLowerCase();
    }
}
