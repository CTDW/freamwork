package com.seeease.framework;

import org.springframework.context.annotation.ImportSelector;
import org.springframework.core.type.AnnotationMetadata;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;


/**
 * <p>扫描器</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 11/13/23 下午
 **/
public class ConfigurationSelector implements ImportSelector {


    @Override
    public String[] selectImports(AnnotationMetadata importingClassMetadata) {
        Map<String, Object> attributes = importingClassMetadata.getAnnotationAttributes(EnableSms.class.getName());
        EnableSms.Model[] models = (EnableSms.Model[]) attributes.get("models");
        List<String> imports = new ArrayList<>(models.length);
        for (EnableSms.Model model:models){
            imports.add(model.getConfiguration().getName());
        }
        return imports.toArray(new String[0]);
    }


}
