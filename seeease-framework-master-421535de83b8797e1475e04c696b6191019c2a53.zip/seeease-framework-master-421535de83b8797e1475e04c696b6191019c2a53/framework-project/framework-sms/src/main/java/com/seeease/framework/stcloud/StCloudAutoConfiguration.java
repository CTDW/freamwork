package com.seeease.framework.stcloud;

import com.seeease.framework.FastJsonConverterFactory;
import okhttp3.OkHttpClient;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import retrofit2.Retrofit;

/**
 * <p>三体云配置文件</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 12/15/23 2:30下午
 **/
@Configuration
@EnableConfigurationProperties({Properties.class})
public class StCloudAutoConfiguration {

    /**
     * 注入api
     */
    @Bean
    public StCloudApi stCloudApi(){
        OkHttpClient okHttpClient = new OkHttpClient.Builder().build();
        return new Retrofit.Builder()
                .addConverterFactory(FastJsonConverterFactory.create())
                .client(okHttpClient) //使用OkHttp请求
                .build()
                .create(StCloudApi.class);
    }
}
