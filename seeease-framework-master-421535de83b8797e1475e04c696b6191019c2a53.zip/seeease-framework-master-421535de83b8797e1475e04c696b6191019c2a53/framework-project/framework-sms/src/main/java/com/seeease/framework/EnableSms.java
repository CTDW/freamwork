package com.seeease.framework;

import com.seeease.framework.stcloud.StCloudAutoConfiguration;
import org.springframework.context.annotation.Import;

import java.lang.annotation.*;

/**
 * 开启短信服务注解
 */

@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Import(ConfigurationSelector.class)
public @interface EnableSms {

    /**
     * 开启的短信模型
     */
    Model[] models() default {Model.ST};

    /**
     * 短信模型
     */
    enum Model{
        /**
         * 三体云
         */
        ST(StCloudAutoConfiguration.class),
        ;
        private final Class<?> configuration;

        Model(Class<?> configuration) {
            this.configuration = configuration;
        }

        public Class<?> getConfiguration() {
            return configuration;
        }
    }
}
