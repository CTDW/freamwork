package com.seeease.framework.stcloud;

import org.springframework.boot.context.properties.ConfigurationProperties;

import javax.annotation.PostConstruct;
import java.util.Objects;

/**
 * <p>三体云配置文件</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 12/15/23 2:14下午
 **/
@ConfigurationProperties(prefix = "sms.st")
public class Properties {

    private static String appId;
    private static String appKey;



    public  String getAppId() {
        return appId;
    }

    public static String getAppIdStatic() {
        return appId;
    }

    public  void setAppId(String appId) {
        Properties.appId = appId;
    }

    public  String getAppKey() {
        return appKey;
    }

    public static String getAppKeyStatic() {
        return appKey;
    }


    public  void setAppKey(String appKey) {
        Properties.appKey = appKey;
    }



    @PostConstruct
    public void init() {
        Objects.requireNonNull(getAppId(), "[三体云SMS]:appId配置不能为空");
        Objects.requireNonNull(getAppKey(), "[三体云SMS]:appKey配置不能为空");
    }
}
