package com.seeease.framework.ks.api;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.kuaishou.merchant.open.api.KsMerchantApiException;
import com.kuaishou.merchant.open.api.client.oauth.OauthAccessTokenKsClient;
import com.kuaishou.merchant.open.api.client.oauth.OauthCredentialKsClient;
import com.kuaishou.merchant.open.api.response.oauth.KsAccessTokenResponse;
import com.kuaishou.merchant.open.api.response.oauth.KsCredentialResponse;
import lombok.Data;

import java.util.Objects;
import java.util.concurrent.TimeUnit;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 9/3/24 3:04 下午
 **/
public class KsShopApi {


    private static final LoadingCache<ParamToken, String> ACCESS_TOKEN_CACHE = CacheBuilder.newBuilder()
            .refreshAfterWrite(1, TimeUnit.HOURS)
            .build(new CacheLoader<ParamToken, String>() {
                @Override
                public String load(ParamToken param) throws KsMerchantApiException {

                    OauthCredentialKsClient client = new OauthCredentialKsClient(
                            param.getAppId(),
                            param.getSecret()
                    );
                    KsCredentialResponse response = client.getAccessToken();
                    return response.getAccessToken();
                }
            });


    private static final LoadingCache<ParamUserToken, ParamUserToken> ACCESS_USER_TOKEN_CACHE = CacheBuilder.newBuilder()
            .refreshAfterWrite(1, TimeUnit.HOURS)
            .build(new CacheLoader<ParamUserToken, ParamUserToken>() {
                @Override
                public ParamUserToken load(ParamUserToken param) throws KsMerchantApiException {
                    OauthAccessTokenKsClient client = new OauthAccessTokenKsClient(
                            param.getAppId(),
                            param.getSecret()
                    );

                    KsAccessTokenResponse resp = client.refreshAccessToken(param.getRefreshToken());
                    ParamUserToken newToken = new ParamUserToken();
                    newToken.setToken(resp.getAccessToken());
                    newToken.setRefreshToken(resp.getRefreshToken());
                    newToken.setExpire(resp.getRefreshTokenExpiresIn());
                    return newToken;
                }
            });


    /**
     * 抖音平台获取AccessToken
     *
     * @param param
     * @return
     */
    public static String getAccessToken(ParamToken param) {
        return ACCESS_TOKEN_CACHE.getUnchecked(param);
    }


    /**
     * 抖音平台获取User AccessToken
     *
     * @param param
     * @return
     */
    public static ParamUserToken getUserAccessToken(ParamUserToken param) {
        return ACCESS_USER_TOKEN_CACHE.getUnchecked(param);
    }


    /**
     * 用户token参数
     */

    @Data
    public static class ParamUserToken extends ParamToken{
        private Long expire;
        private String token;
        private String refreshToken;

        @Override
        public int hashCode() {
            return super.hashCode();
        }

        @Override
        public boolean equals(Object obj) {
            return super.equals(obj);
        }

    }


    /**
     * token参数
     */
    @Data
    public static class ParamToken {
        protected String appId;
        protected String secret;

        @Override
        public int hashCode() {
            return Objects.hash(appId, secret);
        }

        @Override
        public boolean equals(Object obj) {
            if (this == obj) return true;
            if (obj == null || getClass() != obj.getClass()) return false;
            ParamToken that = (ParamToken) obj;
            return Objects.equals(appId, that.appId) && Objects.equals(secret, that.secret);
        }

    }

}
