package com.seeease.seeeaseframework.mq;

import org.apache.rocketmq.client.apis.*;
import org.apache.rocketmq.client.apis.producer.Producer;
import org.apache.rocketmq.client.apis.producer.ProducerBuilder;
import org.apache.rocketmq.client.apis.producer.TransactionChecker;

import java.util.Objects;

/**
 * @author Tiro
 * @date 2023/11/23
 */
public class ProducerSingleton {

    private RocketmqProperties properties;

    public ProducerSingleton(RocketmqProperties properties) {
        this.properties = properties;
    }

    /**
     * @param checker
     * @param topics
     * @return
     * @throws ClientException
     */
    private Producer buildProducer(TransactionChecker checker, String... topics) throws ClientException {
        SessionCredentialsProvider sessionCredentialsProvider =
                new StaticSessionCredentialsProvider(properties.getAccessKey(), properties.getSecretKey());
        ClientConfiguration clientConfiguration = ClientConfiguration.newBuilder()
                .setEndpoints(properties.getEndpoints())

                .setCredentialProvider(sessionCredentialsProvider)
                .build();

        final ClientServiceProvider provider = ClientServiceProvider.loadService();
        final ProducerBuilder builder = provider.newProducerBuilder()
                .setClientConfiguration(clientConfiguration)
                .setTopics(topics);
        if (Objects.nonNull(checker)) {
            builder.setTransactionChecker(checker);
        }
        return builder.build();
    }

    /**
     * @param topics
     * @return
     * @throws ClientException
     */
    public Producer getInstance(String... topics) throws ClientException {
        return buildProducer(null, topics);
    }

    /**
     * @param checker
     * @param topics
     * @return
     * @throws ClientException
     */
    public Producer getTransactionalInstance(TransactionChecker checker,
                                             String... topics) throws ClientException {
        return buildProducer(checker, topics);
    }
}