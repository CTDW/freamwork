package com.seeease.seeeaseframework.mq.bean;

import com.alibaba.fastjson.JSONObject;
import com.seeease.seeeaseframework.mq.RocketmqProperties;
import com.seeease.seeeaseframework.mq.annotation.MqConsumer;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.rocketmq.client.apis.*;
import org.apache.rocketmq.client.apis.consumer.ConsumeResult;
import org.apache.rocketmq.client.apis.consumer.FilterExpression;
import org.apache.rocketmq.client.apis.consumer.FilterExpressionType;
import org.apache.rocketmq.client.apis.consumer.PushConsumer;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.cglib.proxy.Enhancer;
import org.springframework.cglib.proxy.MethodInterceptor;
import org.springframework.cglib.proxy.MethodProxy;
import org.springframework.core.annotation.AnnotationUtils;

import java.lang.reflect.Method;
import java.lang.reflect.ParameterizedType;
import java.nio.ByteBuffer;
import java.util.Collections;
import java.util.Objects;
import java.util.Optional;

/**
 * @author Tiro
 * @date 2023/11/23
 */
@Slf4j
public class ConsumerBeanPostProcessor implements BeanPostProcessor {

    private RocketmqProperties properties;

    public ConsumerBeanPostProcessor(RocketmqProperties properties) {
        this.properties = properties;
    }

    @SneakyThrows
    @Override
    public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {
        MqConsumer consumer = AnnotationUtils.findAnnotation(bean.getClass(), MqConsumer.class);
        if (Objects.isNull(consumer)) {
            return bean;
        }

        ConsumerInterceptor interceptor = new ConsumerInterceptor();
        Object proxyBean = interceptor.warpBean((IConsumer) bean, consumer);
        return proxyBean;
    }


    class ConsumerInterceptor implements MethodInterceptor {
        private MqConsumer consumer;
        private String topic;
        private IConsumer bean;
        private Class type;
        private PushConsumer pushConsumer;

        public Object warpBean(IConsumer bean, MqConsumer consumer) throws ClientException {
            this.consumer = consumer;
            this.bean = bean;
            this.type = (Class) ((ParameterizedType) bean.getClass().getGenericInterfaces()[0]).getActualTypeArguments()[0];
            this.topic = consumer.topic() + StringUtils.defaultString(properties.getTopicSuffix());

            SessionCredentialsProvider sessionCredentialsProvider =
                    new StaticSessionCredentialsProvider(properties.getAccessKey(), properties.getSecretKey());

            ClientConfiguration clientConfiguration = ClientConfiguration.newBuilder()
                    .setEndpoints(properties.getEndpoints())
                    .setCredentialProvider(sessionCredentialsProvider)
                    .build();

            FilterExpression filterExpression = Optional.ofNullable(consumer.filterTag())
                    .filter(StringUtils::isNotBlank)
                    .map(tag -> new FilterExpression(tag, FilterExpressionType.TAG))
                    .orElse(new FilterExpression());

            final ClientServiceProvider provider = ClientServiceProvider.loadService();

            this.pushConsumer = provider.newPushConsumerBuilder()
                    .setClientConfiguration(clientConfiguration)
                    .setConsumerGroup(consumer.group())
                    .setSubscriptionExpressions(Collections.singletonMap(this.topic, filterExpression))
                    .setMessageListener(messageView -> {
                        try {
                            this.bean.consume(JSONObject.parseObject(bytebuffer2ByteArray(messageView.getBody().asReadOnlyBuffer()), this.type));
                            log.info("MQ消息消费成功,topic={},message={}", this.topic, messageView);
                            return ConsumeResult.SUCCESS;
                        } catch (Exception e) {
                            log.error("MQ消息消费异常,topic={},message={},e={}", this.topic, messageView, e.getMessage(), e);
                            return ConsumeResult.FAILURE;
                        }
                    })
                    .build();

            Enhancer enhancer = new Enhancer();
            enhancer.setSuperclass(bean.getClass());
            enhancer.setCallback(this);
            return enhancer.create();
        }

        @Override
        public Object intercept(Object o, Method method, Object[] objects, MethodProxy methodProxy) throws Throwable {
            return methodProxy.invoke(bean, objects);
        }
    }

    /**
     * @param buffer
     * @return
     */
    public static byte[] bytebuffer2ByteArray(ByteBuffer buffer) {
        //获取buffer中有效大小
        int len = buffer.limit() - buffer.position();
        byte[] bytes = new byte[len];
        for (int i = 0; i < bytes.length; i++) {
            bytes[i] = buffer.get();

        }
        return bytes;
    }
}
