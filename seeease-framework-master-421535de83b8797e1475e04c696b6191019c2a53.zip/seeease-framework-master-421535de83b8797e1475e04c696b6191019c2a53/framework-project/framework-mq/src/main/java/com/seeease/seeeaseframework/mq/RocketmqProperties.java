package com.seeease.seeeaseframework.mq;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

import java.io.Serializable;

/**
 * @author Tiro
 * @date 2023/11/23
 */
@Data
@ConfigurationProperties(prefix = "spring.rocketmq")
public class RocketmqProperties implements Serializable {

    private String endpoints;

    private String secretKey;

    private String accessKey;

    /**
     * topic后缀
     */
    private String topicSuffix;

}
