package com.seeease.seeeaseframework.mq.bean;

/**
 * @author Tiro
 * @date 2023/11/29
 */
public interface IConsumer<M> {

    /**
     * 消费
     *
     * @param msg
     */
    void consume(M msg);
}
