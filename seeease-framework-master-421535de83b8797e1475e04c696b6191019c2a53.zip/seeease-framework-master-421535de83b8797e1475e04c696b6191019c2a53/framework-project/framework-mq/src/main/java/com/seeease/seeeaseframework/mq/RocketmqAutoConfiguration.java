package com.seeease.seeeaseframework.mq;

import com.seeease.seeeaseframework.mq.bean.ConsumerBeanPostProcessor;
import com.seeease.seeeaseframework.mq.bean.ProducerBeanPostProcessor;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Role;

/**
 * @author Tiro
 * @date 2023/11/23
 */
@Configuration
@EnableConfigurationProperties({RocketmqProperties.class})
public class RocketmqAutoConfiguration {


    @Bean(name = {"producerBeanPostProcessor"})
    @Role(BeanDefinition.ROLE_INFRASTRUCTURE)
    @ConditionalOnProperty(prefix = "spring.rocketmq", name = "endpoints")
    public ProducerBeanPostProcessor producerBeanPostProcessor(RocketmqProperties properties) {
        return new ProducerBeanPostProcessor(properties);
    }


    @Bean(name = {"consumerBeanPostProcessor"})
    @Role(BeanDefinition.ROLE_INFRASTRUCTURE)
    @ConditionalOnProperty(prefix = "spring.rocketmq", name = "endpoints")
    public ConsumerBeanPostProcessor consumerBeanPostProcessor(RocketmqProperties properties) {
        return new ConsumerBeanPostProcessor(properties);
    }

}
