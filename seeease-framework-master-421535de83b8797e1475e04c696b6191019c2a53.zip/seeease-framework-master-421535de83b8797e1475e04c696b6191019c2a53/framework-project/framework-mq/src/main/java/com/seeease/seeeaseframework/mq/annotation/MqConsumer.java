package com.seeease.seeeaseframework.mq.annotation;

import org.springframework.stereotype.Component;

import java.lang.annotation.*;

/**
 * @author Tiro
 * @date 2023/11/23
 */
@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Component
public @interface MqConsumer {

    /**
     * topic
     *
     * @return
     */
    String topic();

    /**
     * 消费组
     *
     * @return
     */
    String group();

    /**
     * 过滤标签
     *
     * @return
     */
    String filterTag() default "";
}
