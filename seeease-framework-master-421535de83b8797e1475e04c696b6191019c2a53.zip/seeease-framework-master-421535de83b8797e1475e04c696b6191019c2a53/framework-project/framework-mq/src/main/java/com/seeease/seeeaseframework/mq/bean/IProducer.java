package com.seeease.seeeaseframework.mq.bean;

/**
 * @author Tiro
 * @date 2023/11/23
 */
public interface IProducer<M> {

    /**
     * 发送消息/发送半事务消息
     *
     * @param msg
     * @throws RuntimeException
     */
    default void send(M msg) {
    }

    /**
     * 执行本地事务，并确定本地事务结果。
     * 1. 如果本地事务提交成功，则提交消息事务。
     * 2. 如果本地事务提交失败，则回滚消息事务。
     * 3. 如果本地事务未知异常，则不处理，等待事务消息回查。
     *
     * @param msg
     * @return
     */
    default boolean doLocalTransaction(M msg) throws RuntimeException {
        throw new RuntimeException("无本地事物代码,等待消息回查");
    }

    /**
     * 构建消息key
     *
     * @param msg
     * @return
     */
    default String generateKey(M msg) {
        return null;
    }

    /**
     * 动态延迟时间，优先级高于注解中固定延时时间
     *
     * @param msg
     * @return
     */
    default int delaySeconds(M msg) {
        return 0;
    }
}
