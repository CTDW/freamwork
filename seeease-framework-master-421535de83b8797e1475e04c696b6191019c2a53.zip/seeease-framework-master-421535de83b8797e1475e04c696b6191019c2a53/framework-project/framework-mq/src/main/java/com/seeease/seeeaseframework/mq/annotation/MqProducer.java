package com.seeease.seeeaseframework.mq.annotation;

import org.springframework.stereotype.Component;

import java.lang.annotation.*;

/**
 * @author Tiro
 * @date 2023/11/23
 */
@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Component
public @interface MqProducer {

    /**
     * topic
     *
     * @return
     */
    String topic();

    /**
     * tag
     *
     * @return
     */
    String tag() default "";

    /**
     * 延迟消息的延迟时间
     *
     * @return
     */
    int delaySeconds() default 0;

    /**
     * 顺序消息的排序分组
     *
     * @return
     */
    String fifoGroup() default "";

    /**
     * 开启事物消息
     *
     * @return
     */
    boolean transaction() default false;

    /**
     * 事物消息检查bean名称
     *
     * @return
     */
    String transactionCheckerBeanName() default "";

}
