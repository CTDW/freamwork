package com.seeease.seeeaseframework.mq.bean;

import com.alibaba.fastjson.JSONObject;
import com.seeease.seeeaseframework.mq.ProducerSingleton;
import com.seeease.seeeaseframework.mq.RocketmqProperties;
import com.seeease.seeeaseframework.mq.annotation.MqProducer;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.rocketmq.client.apis.ClientException;
import org.apache.rocketmq.client.apis.ClientServiceProvider;
import org.apache.rocketmq.client.apis.message.Message;
import org.apache.rocketmq.client.apis.message.MessageBuilder;
import org.apache.rocketmq.client.apis.message.MessageView;
import org.apache.rocketmq.client.apis.producer.*;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.cglib.proxy.Enhancer;
import org.springframework.cglib.proxy.MethodInterceptor;
import org.springframework.cglib.proxy.MethodProxy;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.core.annotation.AnnotationUtils;

import java.lang.reflect.Method;
import java.time.Duration;
import java.util.Objects;
import java.util.Optional;

/**
 * @author Tiro
 * @date 2023/11/23
 */
@Slf4j
public class ProducerBeanPostProcessor implements BeanPostProcessor, ApplicationContextAware {

    private ApplicationContext context;
    private RocketmqProperties properties;
    private ProducerSingleton producerSingleton;

    public ProducerBeanPostProcessor(RocketmqProperties properties) {
        this.properties = properties;
        this.producerSingleton = new ProducerSingleton(properties);
    }

    @SneakyThrows
    @Override
    public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {
        MqProducer producer = AnnotationUtils.findAnnotation(bean.getClass(), MqProducer.class);
        if (Objects.isNull(producer)) {
            return bean;
        }
        Method tm = null;
        try {
            tm = bean.getClass().getDeclaredMethod("doLocalTransaction", Object.class);
        } catch (NoSuchMethodException e) {
        }

        if (Objects.nonNull(tm) || StringUtils.isNotBlank(producer.transactionCheckerBeanName())) {
            TransactionProducerInterceptor interceptor = new TransactionProducerInterceptor();
            Object proxyBean = interceptor.warpBean((IProducer) bean, producer, Optional.ofNullable(producer.transactionCheckerBeanName())
                    .filter(StringUtils::isNotBlank)
                    .map(name -> (TransactionChecker) context.getBean(name))
                    .orElseGet(() -> new TransactionChecker() {
                        @Override
                        public TransactionResolution check(MessageView messageView) {
                            return TransactionResolution.COMMIT;
                        }
                    }));
            return proxyBean;
        } else {
            ProducerInterceptor interceptor = new ProducerInterceptor();
            Object proxyBean = interceptor.warpBean((IProducer) bean, producer);
            return proxyBean;
        }
    }

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        this.context = applicationContext;
    }


    class TransactionProducerInterceptor implements MethodInterceptor {
        private IProducer bean;
        private MqProducer mqProducer;
        private Producer producer;
        private String topic;

        public Object warpBean(IProducer bean, MqProducer mqProducer, TransactionChecker checker) throws ClientException {
            Enhancer enhancer = new Enhancer();
            this.bean = bean;
            this.mqProducer = mqProducer;
            this.topic = Objects.requireNonNull(mqProducer.topic()) + StringUtils.defaultString(properties.getTopicSuffix());
            this.producer = producerSingleton.getTransactionalInstance(Objects.requireNonNull(checker), this.topic);
            enhancer.setSuperclass(bean.getClass());
            enhancer.setCallback(this);
            return enhancer.create();
        }

        @Override
        public Object intercept(Object o, Method method, Object[] objects, MethodProxy methodProxy) throws Throwable {
            if (method.getName().equals("send")) {
                try {
                    final ClientServiceProvider provider = ClientServiceProvider.loadService();
                    final Transaction transaction = producer.beginTransaction();
                    Message message = messageBuilder(objects[0], provider, mqProducer, bean, this.topic);
                    SendReceipt sendReceipt = producer.send(message, transaction);
                    //执行本地事物
                    try {
                        boolean transactionState = bean.doLocalTransaction(objects[0]);
                        if (transactionState) {
                            transaction.commit();
                            log.info("MQ事物消息发送成功,topic={},messageId={},message={}", this.topic, sendReceipt.getMessageId(), message);
                        } else {
                            transaction.rollback();
                            log.info("MQ事物消息发送成功,回滚成功,topic={},messageId={},message={}", this.topic, sendReceipt.getMessageId(), message);
                        }
                    } catch (Exception e) {
                        log.warn("MQ事物消息发送成功,本地事物执行异常等待回查,topic={},messageId={},message={},e={}", this.topic, sendReceipt.getMessageId(), message, e.getMessage(), e);
                    }
                } catch (Exception e) {
                    log.error("MQ事物消息发送异常,topic={},objects={},e={}", this.topic, JSONObject.toJSONString(objects), e.getMessage(), e);
                }
            }
            return methodProxy.invoke(bean, objects);
        }
    }

    class ProducerInterceptor implements MethodInterceptor {
        private IProducer bean;
        private MqProducer mqProducer;
        private Producer producer;
        private String topic;

        public Object warpBean(IProducer bean, MqProducer mqProducer) throws ClientException {
            Enhancer enhancer = new Enhancer();
            this.bean = bean;
            this.mqProducer = mqProducer;
            this.topic = Objects.requireNonNull(mqProducer.topic()) + StringUtils.defaultString(properties.getTopicSuffix());
            this.producer = producerSingleton.getInstance(this.topic);
            enhancer.setSuperclass(bean.getClass());
            enhancer.setCallback(this);
            return enhancer.create();
        }

        @Override
        public Object intercept(Object o, Method method, Object[] objects, MethodProxy methodProxy) throws Throwable {
            if (method.getName().equals("send")) {
                try {
                    final ClientServiceProvider provider = ClientServiceProvider.loadService();
                    Message message = messageBuilder(objects[0], provider, mqProducer, bean, this.topic);
                    SendReceipt sendReceipt = producer.send(message);
                    log.info("MQ消息发送成功,topic={},messageId={},message={}", this.topic, sendReceipt.getMessageId(), message);
                } catch (Exception e) {
                    log.error("MQ消息发送异常,topic={},objects={},e={}", this.topic, JSONObject.toJSONString(objects), e.getMessage(), e);
                }
            }
            return methodProxy.invoke(bean, objects);
        }
    }


    /**
     * @param obj
     * @param provider
     * @param mqProducer
     * @param producer
     * @param topic
     * @return
     */
    private static Message messageBuilder(Object obj, ClientServiceProvider provider,
                                          MqProducer mqProducer, IProducer producer, String topic) {
        MessageBuilder messageBuilder = provider.newMessageBuilder()
                .setTopic(topic)
                .setBody(JSONObject.toJSONBytes(obj));

        String key = producer.generateKey(obj);
        if (StringUtils.isNotBlank(key)) {
            messageBuilder.setKeys(key);
        }
        if (StringUtils.isNotBlank(mqProducer.tag())) {
            messageBuilder.setTag(mqProducer.tag());
        }
        if (StringUtils.isNotBlank(mqProducer.fifoGroup())) {
            messageBuilder.setMessageGroup(mqProducer.fifoGroup());
        }

        int delaySeconds = Optional.ofNullable(producer.delaySeconds(obj))
                .filter(t -> t > 0)
                .orElse(mqProducer.delaySeconds());

        if (delaySeconds > 0) {
            Duration messageDelayTime = Duration.ofSeconds(delaySeconds);
            messageBuilder.setDeliveryTimestamp(System.currentTimeMillis() + messageDelayTime.toMillis());
        }
        return messageBuilder.build();
    }

}
