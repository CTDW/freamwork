package com.seeease.framework;

import com.alibaba.fastjson.JSON;
import okhttp3.MediaType;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Converter;
import retrofit2.Retrofit;

import java.io.IOException;
import java.lang.annotation.Annotation;
import java.lang.reflect.Type;

/**
 * <p>FastJSON转换器</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 11/22/23 上午
 **/
public class FastJsonConverterFactory extends Converter.Factory{

    public static FastJsonConverterFactory create() {

        return new FastJsonConverterFactory();
    }

    private FastJsonConverterFactory() {}

    @Override
    public Converter<ResponseBody, ?> responseBodyConverter(Type type, Annotation[] annotations, Retrofit retrofit) {
        return value -> {
            try {
                String json = value.string();
                return JSON.parseObject(json, type);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        };
    }

    @Override
    public Converter<?, RequestBody> requestBodyConverter(Type type, Annotation[] parameterAnnotations,
                                                          Annotation[] methodAnnotations, Retrofit retrofit) {
        return value -> {
            try {
                String json = JSON.toJSONString(value);
                return RequestBody.create(MediaType.parse("application/json"), json);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        };
    }
}
