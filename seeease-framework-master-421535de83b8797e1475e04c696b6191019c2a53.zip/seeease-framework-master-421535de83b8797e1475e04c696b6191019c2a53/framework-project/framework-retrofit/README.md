# 该模块主要应用网络请求的retrofit包

## 关于关于retrofit使用demo请看模块  framework-wechat 中的WeChatAppletApi