package com.seeease.frameworkbank.pingan.request;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>交易明细请求</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 4/8/24 4:25 下午
 **/
@EqualsAndHashCode(callSuper = true)
@Data
public class TsDetailRequest extends PageRequest{
    /**
     * 证件类型
     * 必填
     */
    private String certificateType;
    /**
     * 证件号码
     * 必填
     */
    private String certificateNo;
    /**
     * 请求流水号
     * 必填
     */
    private String requestId;
    /**
     * 渠道号
     */
    private String channelNo;
    /**
     * 租户号
     */
    private String tenantId;
    /**
     * 账号
     */
    private String account;
    /**
     * 开始日期
     */
    private String beginDate;
    /**
     * 结束日期
     */
    private String endDate;
    /**
     * 退票标识
     */
    private String refundFlag;
}
