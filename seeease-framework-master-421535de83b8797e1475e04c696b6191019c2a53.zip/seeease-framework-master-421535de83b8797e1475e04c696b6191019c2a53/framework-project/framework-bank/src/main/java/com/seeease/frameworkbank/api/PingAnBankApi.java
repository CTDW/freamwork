package com.seeease.frameworkbank.api;

import com.alibaba.fastjson.JSONObject;
import com.pingan.openbank.api.sdk.OpenBankClient;
import com.pingan.openbank.api.sdk.client.ApiClient;
import com.pingan.openbank.api.sdk.common.http.HttpResult;
import com.pingan.openbank.api.sdk.entity.SdkRequest;
import com.seeease.frameworkbank.pingan.request.TsDetailRequest;

/**
 * <p>平安银行api</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 4/8/24 4:21 下午
 **/
public class PingAnBankApi {


    /**
     * 获取流水详情
     * @param propertiesPath 配置文件路径
     * @param request  请求数据
     * 返回列表对象为 {@link com.seeease.frameworkbank.pingan.result.TsDetailResult}
     */
    public static String tsDetail(String propertiesPath, TsDetailRequest request){

        OpenBankClient apiClient = ApiClient.getInstance(propertiesPath);
        SdkRequest sdkRequest = new SdkRequest();
        sdkRequest.setConfigFilePath(propertiesPath);
        sdkRequest.setInterfaceName("/V1.0/business/accountitem/v2/accountitem001");
        sdkRequest.setBody( JSONObject.parseObject(JSONObject.toJSONString(request)));
        HttpResult result = apiClient.invoke(sdkRequest);
        return result.getData();

    }
}
