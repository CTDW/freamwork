package com.seeease.frameworkbank.pingan.result;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

/**
 * <p>分页结果</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 4/8/24 4:39 下午
 **/
@Data
public class PageResult<T>{

    private Data<T> data;


    @Getter
    @Setter
    public static class Data<T>{
        private String code;
        private String message;
        private String total;
        private String pageNo;
        private String pageSize;
        private List<T> record;
    }
}
