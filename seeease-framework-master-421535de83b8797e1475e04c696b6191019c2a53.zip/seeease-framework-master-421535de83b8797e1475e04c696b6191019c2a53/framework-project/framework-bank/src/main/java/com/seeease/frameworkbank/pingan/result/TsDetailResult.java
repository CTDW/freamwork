package com.seeease.frameworkbank.pingan.result;

import lombok.Data;

/**
 * <p>交易流水返回</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 4/8/24 4:25 下午
 **/
@Data
public class TsDetailResult {
    /**
     *银行流水号
     */
    private String bankBusinessId;
    /**
     *银行核心流水号
     */
    private String hostTrace;
    /**
     *银行交易序号
     */
    private String businessOrderNo;
    /**
     *外部业务流水号
     */
    private String otherBusinessId;
    /**
     *财资业务流水号
     */
    private String businessId;
    /**
     *交易日期
     */
    private String tradeDate;
    /**
     *交易时间
     */
    private String tradeTime;
    /**
     *记账日期
     */
    private String tradeAcctDate;
    /**
     *账号
     */
    private String account;
    /**
     *企业名称
     */
    private String enterpriseName;
    /**
     *账户名称
     */
    private String accountName;
    /**
     *对方账号
     */
    private String otherPartyAccount;
    /**
     *对方账户名称
     */
    private String otherPartyAccountName;
    /**
     *对方开户行
     */
    private String otherPartyBankName;
    /**
     *借/贷标记
     */
    private String loanType;
    /**
     *交易金额
     */
    private String amount;
    /**
     *账户余额
     */
    private String balance;
    /**
     *币种
     */
    private String currency;
    /**
     *币种中文名
     */
    private String currencyName;
    /**
     *用途
     */
    private String use;
    /**
     *备注
     */
    private String remark;
    /**
     *附言
     */
    private String postscript;
    /**
     *摘要
     */
    private String summary;
    /**
     *冲正、退票标识
     */
    private String beReverseFlag;
    /**
     *交易类型
     */
    private String businessType;
    /**
     *财资回单标识
     */
    private String receiptNo;
    /**
     *原支付银行流水号
     */
    private String originalBankSerialNumber;
    /**
     *原支付核心流水号
     */
    private String originalCoreNumber;
    /**
     *原系统流水号
     */
    private String originalBusinessId;
    /**
     *原系统第三方流水号
     */
    private String originalOtherBusinessId;
    /**
     *银行交易类型
     */
    private String bankBusinessType;
    /**
     *明细标识
     */
    private String id;
    /**
     *订单号
     */
    private String orderNo;
    /**
     *电子回单编号
     */
    private String receiptBusinessNo;

}
