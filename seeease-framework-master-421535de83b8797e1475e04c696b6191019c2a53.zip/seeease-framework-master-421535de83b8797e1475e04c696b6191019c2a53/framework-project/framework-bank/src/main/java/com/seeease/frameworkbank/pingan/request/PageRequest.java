package com.seeease.frameworkbank.pingan.request;

import lombok.Data;

/**
 * <p>分页请求</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 4/8/24 4:32 下午
 **/
@Data
public class PageRequest {

    private String pageNo = "1";
    private String pageSize = "10";
}
