package com.seeease.springframework.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * @author Tiro
 * @date 2023/10/19
 */
public abstract class DateUtils {
    public static String Y = "yyyy";
    public static String YM = "yyyy-MM";
    public static String YMD = "yyyy-MM-dd";
    public static String YMD2 = "yyyyMMdd";
    public static String YMD_HMS = "yyyy-MM-dd HH:mm:ss";
    public static String YMD_HMS2 = "yyyyMMddHHmmss";


    /**
     * @param format
     * @param date
     * @return
     */
    public static final String toDateString(final String format, final Date date) {
        return new SimpleDateFormat(format).format(date);
    }

    /**
     * @param format
     * @param dateStr
     * @return
     */
    public static final Date parseDate(final String format, final String dateStr) {

        try {
            return new SimpleDateFormat(format).parse(dateStr);
        } catch (ParseException e) {
            e.printStackTrace();
            return null;
        }
    }


    /**
     * 获得某天23:59:59点时间
     * @return
     */
    public static Date getTimesnight(Date date) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.set(Calendar.HOUR_OF_DAY, 23);
        cal.set(Calendar.SECOND, 59);
        cal.set(Calendar.MINUTE, 59);
        cal.set(Calendar.MILLISECOND, 0);
        return cal.getTime();
    }

    /**
     * 获得某天0点时间
     * @return
     */
    public static Date getTimesmorning(Date date) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.MILLISECOND, 0);
        return cal.getTime();
    }


}
