package com.seeease.springframework.utils;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;
import java.io.InputStream;
import java.io.StringReader;

/**
 * XML解析工具
 *
 * @author Tiro
 * @date 2023/3/24
 */
public abstract class XMLUtil {

    /**
     * 将xml转换成对象
     *
     * @param xmlStr
     * @param clazz
     * @param <T>
     * @return
     */
    public static <T> T convertXmlStrToObject(String xmlStr, Class<T> clazz) {
        T xmlObject = null;
        try {
            JAXBContext context = JAXBContext.newInstance(clazz);
            Unmarshaller unmarshal = context.createUnmarshaller();
            StringReader sr = new StringReader(xmlStr);
            xmlObject = (T) unmarshal.unmarshal(sr);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return xmlObject;
    }

    /**
     * 将xml流转换成对象
     *
     * @param stream
     * @param clazz
     * @param <T>
     * @return
     */
    public static <T> T convertStreamToObject(InputStream stream, Class<T> clazz) {
        T xmlObject = null;
        try {
            JAXBContext context = JAXBContext.newInstance(clazz);
            Unmarshaller unmarshal = context.createUnmarshaller();
            xmlObject = (T) unmarshal.unmarshal(stream);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return xmlObject;
    }
}
