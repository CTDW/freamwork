package com.seeease.springframework.utils.excel;

/**
 * excel 模版异常
 *
 * @author Tiro
 * @date 2023/3/31
 */
public class ExcelTemplateException extends RuntimeException {
}
