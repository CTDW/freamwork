package com.seeease.springframework.utils;

import java.math.BigDecimal;

/**
 * @author Tiro
 * @date 2023/3/27
 */
public abstract class BigDecimalUtil {

    /**
     * 取整，4舍5入
     *
     * @param price
     * @return
     */
    public static BigDecimal roundNumber(BigDecimal price) {
        return price.setScale(0, BigDecimal.ROUND_HALF_UP);
    }

    /**
     * 向上取整
     *
     * @param price
     * @return
     */
    public static BigDecimal roundNumberUp(BigDecimal price) {
        return price.setScale(0, BigDecimal.ROUND_UP);
    }


    /**
     * 分转换元
     *
     * @param price
     * @return
     */
    public static BigDecimal centToYuan(String price) {
        BigDecimal p = new BigDecimal(price);
        return p.divide(new BigDecimal(100));
    }

    /**
     * 元转换分
     *
     * @param price
     * @return
     */
    public static Long yuanToCent(BigDecimal price) {
        BigDecimal p = price.multiply(new BigDecimal(100));
        return p.longValue();
    }

    /**
     * 等于0
     *
     * @param price
     * @return
     */
    public static boolean eqZero(BigDecimal price) {
        return price.compareTo(BigDecimal.ZERO) == 0;
    }

    /**
     * 不等于0
     *
     * @param price
     * @return
     */
    public static boolean neZero(BigDecimal price) {
        return price.compareTo(BigDecimal.ZERO) != 0;
    }

    /**
     * 大于0
     *
     * @param price
     * @return
     */
    public static boolean gtZero(BigDecimal price) {
        return price.compareTo(BigDecimal.ZERO) > 0;
    }

    /**
     * 小于0
     *
     * @param price
     * @return
     */
    public static boolean ltZero(BigDecimal price) {
        return price.compareTo(BigDecimal.ZERO) < 0;
    }

    /**
     * 大于等于0
     *
     * @param price
     * @return
     */
    public static boolean geZero(BigDecimal price) {
        return price.compareTo(BigDecimal.ZERO) >= 0;
    }

    /**
     * 小于等于0
     *
     * @param price
     * @return
     */
    public static boolean leZero(BigDecimal price) {
        return price.compareTo(BigDecimal.ZERO) <= 0;
    }


    /**
     * 等于
     *
     * @param price1
     * @param price2
     * @return
     */
    public static boolean eq(BigDecimal price1, BigDecimal price2) {
        return price1.compareTo(price2) == 0;
    }

    /**
     * 不等于
     *
     * @param price1
     * @param price2
     * @return
     */
    public static boolean ne(BigDecimal price1, BigDecimal price2) {
        return price1.compareTo(price2) != 0;
    }

    /**
     * 大于
     *
     * @param price1
     * @param price2
     * @return
     */
    public static boolean gt(BigDecimal price1, BigDecimal price2) {
        return price1.compareTo(price2) > 0;
    }

    /**
     * 小于
     *
     * @param price1
     * @param price2
     * @return
     */
    public static boolean lt(BigDecimal price1, BigDecimal price2) {
        return price1.compareTo(price2) < 0;
    }

    /**
     * 大于等于0
     *
     * @param price1
     * @param price2
     * @return
     */
    public static boolean ge(BigDecimal price1, BigDecimal price2) {
        return price1.compareTo(price2) >= 0;
    }

    /**
     * 小于等于
     *
     * @param price1
     * @param price2
     * @return
     */
    public static boolean le(BigDecimal price1, BigDecimal price2) {
        return price1.compareTo(price2) <= 0;
    }
}
