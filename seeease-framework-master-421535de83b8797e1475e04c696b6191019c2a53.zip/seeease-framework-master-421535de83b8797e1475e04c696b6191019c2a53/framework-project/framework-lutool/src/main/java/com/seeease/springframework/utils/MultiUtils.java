package com.seeease.springframework.utils;

import java.util.*;
import java.util.function.BiConsumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * 多元素对象处理工具类
 *
 * @author wuyin
 * @date 2022/09/27
 */
@SuppressWarnings(value = "all")
public class MultiUtils {

    /**
     * 构建树
     *
     * @param src          节点集合
     * @param idGenerator  ID获取方法
     * @param pidGenerator 父ID获取方法
     * @param rootArbiter  判定根方法
     * @param linker       关联父子关系
     * @param <E>          节点类型
     * @param <ID>         关联ID类型
     * @return 树根节点列表
     */
    public static <E,ID> List<E> buildTree(Collection<E> src, Function<E,ID> idGenerator, Function<E,ID> pidGenerator,
                                           Predicate<ID> rootArbiter, BiConsumer<E,List<E>> linker){
        if(null == src || src.isEmpty()){
            return new ArrayList<>();
        }
        Map<ID, E> map = src.stream().collect(Collectors.toMap(idGenerator, e -> e));
        Map<ID, List<E>> groups = groupBy(src, pidGenerator);
        Predicate<Map.Entry<ID, List<E>>> filter = entry -> {
            E e = map.get(entry.getKey());
            if(null == e && rootArbiter.test(entry.getKey())){
                return true;
            } else {
                linker.accept(e, entry.getValue());
                return false;
            }
        };
        return groups.entrySet().stream().filter(filter).flatMap(e -> e.getValue().stream()).collect(Collectors.toList());
    }


    /**
     * 更新列表内的元素
     * @param src 集合
     * @param biConsumer 集合属性操作函数
     * @param value 操作值
     * @param <E>
     * @param <T>
     * @return 结果集合
     */
    public static <E,T> List<E> toUpdate(List<E> src, BiConsumer<E, T> biConsumer, T value){
        src.forEach(item->{
            biConsumer.accept(item,value);
        });
        return src;
    }

    /**
     * 集合元素转换为列表
     *
     * @param src    源集合
     * @param action 元素转换方法
     * @param <E>    源元素类型
     * @param <T>    结果元素类型
     * @return 结果集合
     */
    public static <E,T> List<T> toList(Collection<E> src, Function<E, T> action){
        return toList(src, true, true, action);
    }

    /**
     * 集合元素转换为集
     *
     * @param src    源集合
     * @param action 元素转换方法
     * @param <E>    源元素类型
     * @param <T>    结果元素类型
     * @return 结果集
     */
    public static <E,T> Set<T> toSet(Collection<E> src, Function<E, T> action){
        return to(src, true, true, action, Collectors.toSet());
    }

    /**
     * 集合元素转换为Map
     *
     * @param src     源集合
     * @param kAction 键转换方法
     * @param <E>     源元素类型
     * @param <K>     键类型
     * @return Map
     */
    public static <E,K> Map<K,E> toMap(Collection<E> src, Function<E, K> kAction){
        return toMap(src,true, kAction, e -> e);
    }

    /**
     * 集合元素转换为Map
     *
     * @param src     源集合
     * @param kAction 键转换方法
     * @param vAction 值转换方法
     * @param <E>     源元素类型
     * @param <K>     键类型
     * @param <V>     值类型
     * @return Map
     */
    public static <E,K,V> Map<K,V> toMap(Collection<E> src, Function<E, K> kAction, Function<E, V> vAction){
        return toMap(src,true, kAction, vAction);
    }

    /**
     * 集合元素分组为Map
     *
     * @param src    源集合
     * @param action 键生成方法
     * @param <E>    源元素类型
     * @param <K>    键类型
     * @return 分组Map
     */
    public static <E,K> Map<K, List<E>> groupBy(Collection<E> src, Function<E, K> action){
        return groupBy(src, true, action);
    }

    /**
     * 根据条件取元素的交集，只要存在一个符合条件则返回true
     *
     * @param container    结果容器
     * @param isFilterNull 是否过滤NULL
     * @param predicate    判断是否符合条件
     * @param action       元素获取方法
     * @param ts           元素获取键数组
     * @param <T>          元素获取键类型
     * @param <R>          元素类型
     * @return 是否全部符合条件
     */
    public static <T,R> boolean intersectAndAnyTrue(Set<R> container, boolean isFilterNull, Predicate<T> predicate, Function<T, Collection<R>> action, T ...ts){
        if(null == ts || ts.length <= 0){
            return false;
        }
        List<T> tList;
        if(isFilterNull){
            tList = Arrays.stream(ts).filter(Objects::nonNull).collect(Collectors.toList());
            if(tList.isEmpty()){
                return false;
            }
        } else {
            tList = Arrays.asList(ts);
        }
        boolean isPassed = false;
        for (T t : tList) {
            if(predicate.test(t)){
                if(isPassed){
                    container.retainAll(action.apply(t));
                } else {
                    isPassed = true;
                    container.addAll(action.apply(t));
                }
            }
        }
        return isPassed;
    }

    /**
     * 根据条件取元素的交集，只有存在一个不符合条件则返回false
     *
     * @param container    结果容器
     * @param isFilterNull 是否过滤NULL
     * @param predicate    判断是否符合条件
     * @param action       元素获取方法
     * @param ts           元素获取键数组
     * @param <T>          元素获取键类型
     * @param <R>          元素类型
     * @return 是否存在符合条件
     */
    public static <T,R> boolean unionAndAllTrue(Set<R> container, boolean isFilterNull, Predicate<T> predicate, Function<T, Collection<R>> action, T ...ts){
        if(null == ts || ts.length <= 0){
            return false;
        }
        List<T> tList;
        if(isFilterNull){
            tList = Arrays.stream(ts).filter(Objects::nonNull).collect(Collectors.toList());
        } else {
            tList = Arrays.asList(ts);
        }
        for (T t : tList) {
            if(predicate.test(t)){
                container.addAll(action.apply(t));
            } else {
                return false;
            }
        }
        return true;
    }

    /**
     * 集合元素转换为列表
     *
     * @param src               源集合
     * @param isPreFilterNull   是否过滤源集合空值
     * @param isAfterFilterNull 是否过滤结果集合空值
     * @param action            元素转换方法
     * @param <E>               源元素类型
     * @param <T>               结果元素类型
     * @return 结果集合
     */
    private static <E,T> List<T> toList(Collection<E> src, boolean isPreFilterNull, boolean isAfterFilterNull, Function<E, T> action){
        if(null == src){
            return new ArrayList<>();
        }
        return to(src, isPreFilterNull, isAfterFilterNull, action, Collectors.toList());
    }

    /**
     * 集合元素转换为集
     *
     * @param src               源集合
     * @param isPreFilterNull   是否过滤源集合空值
     * @param isAfterFilterNull 是否过滤结果集合空值
     * @param action            元素转换方法
     * @param <E>               源元素类型
     * @param <T>               结果元素类型
     * @return 结果集
     */
    private static <E,T> Set<T> toSet(Collection<E> src, boolean isPreFilterNull, boolean isAfterFilterNull, Function<E, T> action){
        if(null == src){
            return new HashSet<>();
        }
        return to(src, isPreFilterNull, isAfterFilterNull, action, Collectors.toSet());
    }

    /**
     * 集合元素转换为Map
     *
     * @param src             源集合
     * @param isPreFilterNull 是否过滤源集合空值
     * @param kAction         键转换方法
     * @param vAction         值转换方法
     * @param <E>             源元素类型
     * @param <K>             键类型
     * @param <V>             值类型
     * @return Map
     */
    private static <E,K,V> Map<K,V> toMap(Collection<E> src, boolean isPreFilterNull, Function<E, K> kAction, Function<E, V> vAction){
        if(null == src){
            return new HashMap<>();
        }
        Stream<E> srcStream = src.stream();
        if(isPreFilterNull){
            srcStream = srcStream.filter(Objects::nonNull);
        }
        return srcStream.collect(Collectors.toMap(kAction, vAction));
    }

    /**
     * 集合元素分组为Map
     *
     * @param src             源集合
     * @param isPreFilterNull 是否过滤源集合空值
     * @param action          键生成方法
     * @param <E>             源元素类型
     * @param <K>             键类型
     * @return 分组Map
     */
    private static <E,K> Map<K, List<E>> groupBy(Collection<E> src, boolean isPreFilterNull, Function<E, K> action){
        if(null == src){
            return new HashMap<>();
        }
        Stream<E> srcStream = src.stream();
        if(isPreFilterNull){
            srcStream = srcStream.filter(Objects::nonNull);
        }
        return srcStream.collect(Collectors.groupingBy(action));
    }

    /**
     * 集合元素转换
     *
     * @param src               源集合
     * @param isPreFilterNull   是否过滤源集合空值
     * @param isAfterFilterNull 是否过滤结果集合空值
     * @param action            元素转换方法
     * @param collector         转换集合的方法
     * @param <E>               源元素类型
     * @param <T>               结果元素类型
     * @param <R>               结果集合类型
     * @return 结果集合
     */
    private static <E,T,R extends Collection<T>> R to(Collection<E> src, boolean isPreFilterNull, boolean isAfterFilterNull, Function<E, T> action, Collector<T, ?, R> collector){
        Stream<E> srcStream = src.stream();
        if(isPreFilterNull){
            srcStream = srcStream.filter(Objects::nonNull);
        }
        Stream<T> dstStream = srcStream.map(action);
        if(isAfterFilterNull){
            dstStream = dstStream.filter(Objects::nonNull);
        }
        return dstStream.collect(collector);
    }
}
