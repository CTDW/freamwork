package com.seeease.springframework.utils;

import org.apache.commons.lang3.StringUtils;

import javax.servlet.http.HttpServletRequest;
import java.util.Arrays;

/**
 * @author Tiro
 * @date 2024/2/27
 */
public class IPUtils {
    private static final String[] HEADERS = {"X-Forwarded-For", "X-Real-IP", "Proxy-Client-IP", "WL-Proxy-Client-IP", "HTTP_CLIENT_IP", "HTTP_X_FORWARDED_FOR"};


    /**
     * 获取客户端IP
     *
     * @param request
     * @return
     */
    public static String getClientIP(HttpServletRequest request) {
        return getClientIPByHeader(request, HEADERS);
    }

    private static String getClientIPByHeader(HttpServletRequest request, String... headerNames) {
        String ip;
        for (String header : headerNames) {
            ip = request.getHeader(header);
            if (false == isUnknown(ip)) {
                return getMultistageReverseProxyIp(ip);
            }
        }
        ip = request.getRemoteAddr();
        return getMultistageReverseProxyIp(ip);
    }

    private static String getMultistageReverseProxyIp(String ip) {
        // 多级反向代理检测
        if (ip != null && ip.indexOf(",", 0) > 0) {
            return Arrays.stream(ip.split(","))
                    .filter(StringUtils::isNotBlank)
                    .map(String::trim)
                    .filter(i -> !isUnknown(i))
                    .findFirst()
                    .orElse(ip);
        }
        return ip;
    }

    private static boolean isUnknown(String checkString) {
        return StringUtils.isBlank(checkString) || "unknown".equalsIgnoreCase(checkString);
    }
}
