package com.seeease.springframework.utils;

import com.alibaba.excel.EasyExcel;

import java.io.InputStream;
import java.util.List;

/**
 * @author Tiro
 * @date 2023/3/29
 */
public class ExcelUtil {

    /**
     * 同步读
     *
     * @param inputStream
     * @param clazz
     * @param <T>
     * @return
     */
    public static <T> List<T> read(InputStream inputStream, Class<T> clazz) {
        return EasyExcel.read(inputStream)
                .head(clazz)
                .sheet()
                .doReadSync();
    }
}
