package com.seeease.framework.dto.result.applet;

import com.alibaba.fastjson.annotation.JSONField;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * <p>小程序通用返回结果</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 11/22/23 上午
 **/
@Data
@AllArgsConstructor
@NoArgsConstructor
public class WechatAppletBaseResult implements Serializable {

    @JSONField(name = "errmsg")
    protected String errMsg;
    @JSONField(name = "errcode")
    protected Integer errCode;

    /**
     * 断言结果
     */
    public void assertSuccess(){
        if (errCode != 0 || !errMsg.equals("ok")){
            throw new RuntimeException("invoke wechat applet api error : " + errMsg);
        }
    }
}
