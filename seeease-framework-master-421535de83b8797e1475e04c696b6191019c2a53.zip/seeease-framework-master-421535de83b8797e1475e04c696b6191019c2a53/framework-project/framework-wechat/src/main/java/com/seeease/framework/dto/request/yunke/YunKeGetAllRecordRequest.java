package com.seeease.framework.dto.request.yunke;

import lombok.Data;

/**
 * <p>获取公司所有微信聊天记录请求</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 4/19/24 11:07 上午
 **/
@Data
public class YunKeGetAllRecordRequest {
    /**
     * 翻页时间戳，初始值可按照实际想获取的记录的开始时间设置以后请求都使用上一次返回的“最后一条消息的保存时间”
     */
    private  Long timestamp;
    /**
     * 消息发送时间（同一个消息保存时间大于最大分页的情况下的补充查询条件，传0或者使用上一次接口返回的createTimestamp，缺省为0）
     */
    private Long createTimestamp;

}
