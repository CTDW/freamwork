package com.seeease.framework.dto.result.yunke;

import lombok.Data;

/**
 * <p>获取userId获取微信号信息返回</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 4/19/24 11:07 上午
 **/
@Data
public class YunKeGetAccountsResult {
    /**
     * 员工id
     */
    private String wechatId;
    /**
     * 微信头像
     */
    private String headUrl;
    /**
     * 微信昵称
     */
    private String nickname;
    /**
     * 微信绑定手机号
     */
    private String phone;
    /**
     * 微信号
     */
    private String alias;

}
