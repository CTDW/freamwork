package com.seeease.framework.dto.result.applet;

import com.alibaba.fastjson.annotation.JSONField;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * <p>小程序登录放回结果</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 11/22/23上午
 **/
@EqualsAndHashCode(callSuper = true)
@Data
@AllArgsConstructor
@NoArgsConstructor
public class WechatAppletLoginResult extends WechatAppletBaseResult {

    /**
     * 会话密钥
     */
    @JSONField(name = "session_key")
    private String sessionKey;
    /**
     * 用户在开放平台的唯一标识符，若当前小程序已绑定到微信开放平台账号下会返回，
     */
    @JSONField(name = "unionid")
    private String unionId;
    /**
     * 用户唯一标识
     */
    @JSONField(name = "openid")
    private String openId;

}
