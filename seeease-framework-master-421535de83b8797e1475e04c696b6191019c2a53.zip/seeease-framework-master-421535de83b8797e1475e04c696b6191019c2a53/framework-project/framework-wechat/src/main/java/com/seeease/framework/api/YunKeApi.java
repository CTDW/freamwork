package com.seeease.framework.api;

import com.alibaba.fastjson.JSONObject;
import com.seeease.framework.dto.request.yunke.*;
import com.seeease.framework.dto.result.yunke.*;
import com.seeease.framework.e.YunKeRequestFailException;
import com.seeease.framework.properties.YunKeProperties;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Header;
import retrofit2.http.POST;

import java.io.IOException;
import java.util.List;

/**
 * <p>
 * <a href="https://crm.yunkecn.com/xdapi/doc/open.html#d05cd701d187dd3da931">云客微信聚合开放接口</a>
 * </p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 4/19/24 10:07 上午
 **/
public interface YunKeApi {


    /**
     * 结果校验
     *
     * @param result
     * @param <T>
     * @return
     */
    default <T> T verify(YunKeBaseResult<T> result) {
        assert result != null;
        if (!result.getSuccess()) throw new YunKeRequestFailException("云客接口调用异常：" + JSONObject.toJSONString(result));
        return result.getData();
    }


    /**
     * <h2>根据手机号查询用户信息</h2>
     *
     * <a href ="https://crm.yunkecn.com/xdapi/doc/open.html#u6839u636eu7528u6237u624bu673au53f7u67e5u8be2u7528u6237u4fe1u606f28phone290a3ca20id3du6839u636eu7528u6237u624bu673au53f7u67e5u8be2u7528u6237u4fe1u606f28phone296993e203ca3e" >链接</a>
     *
     * @param partnerId 用户id，用于识别调用人，大部分请求为云客分配的管理员id，个别接口需要传员工的用户id
     * @param company   企业代码
     * @param timestamp unix时间戳，精确到毫秒 例如 1530081688201（如果时间相差1分钟 会返回错误结果）
     * @param sign      签名 MD5后转大写，计算方式 md5(签名key+company+partnerId+timestamp).toUpper
     * @param body      请不求参数
     */
    @POST("open/user/getUserByPhone")
    Call<YunKeBaseResult<YunKeGetUserResult>> getUserByPhone(@Header("partnerId") String partnerId,
                                                             @Header("company") String company,
                                                             @Header("timestamp") Long timestamp,
                                                             @Header("sign") String sign,
                                                             @Body YunKeGetUserByPhoneRequest body);


    /**
     * <h2>根据手机号查询用户信息</h2>
     *
     * <a href ="https://crm.yunkecn.com/xdapi/doc/open.html#u6839u636eu7528u6237u624bu673au53f7u67e5u8be2u7528u6237u4fe1u606f28phone290a3ca20id3du6839u636eu7528u6237u624bu673au53f7u67e5u8be2u7528u6237u4fe1u606f28phone296993e203ca3e" >链接</a>
     *
     * @param partnerId 用户id，用于识别调用人，大部分请求为云客分配的管理员id，个别接口需要传员工的用户id
     * @param company   企业代码
     * @param key       云客分配的ke
     * @param phone     查询的用户电话
     */
    default YunKeGetUserResult getUserByPhone(String partnerId,
                                              String company,
                                              String key,
                                              String phone) throws IOException {
        YunKeGetUserByPhoneRequest body = new YunKeGetUserByPhoneRequest(phone);
        YunKeProperties p = new YunKeProperties(partnerId, key, company);

        YunKeBaseResult<YunKeGetUserResult> ret = getUserByPhone(
                p.getPartnerId(),
                p.getCompany(),
                p.getTimestamp(),
                p.getSign(),
                body
        ).execute().body();

        return verify(ret);
    }


    /**
     * <h2>根据用户id查询用户信息</h2>
     *
     * <a href ="https://crm.yunkecn.com/xdapi/doc/open.html#u67e5u8be2u7528u6237u4fe1u606fuff08userid290a3ca20id3du67e5u8be2u7528u6237u4fe1u606fuff08userid296993e203ca3e" >链接</a>
     *
     * @param partnerId 用户id，用于识别调用人，大部分请求为云客分配的管理员id，个别接口需要传员工的用户id
     * @param company   企业代码
     * @param timestamp unix时间戳，精确到毫秒 例如 1530081688201（如果时间相差1分钟 会返回错误结果）
     * @param sign      签名 MD5后转大写，计算方式 md5(签名key+company+partnerId+timestamp).toUpper
     * @param body      请不求参数
     */
    @POST("open/user/getUserById")
    Call<YunKeBaseResult<YunKeGetUserResult>> getUserByUserid(@Header("partnerId") String partnerId,
                                                              @Header("company") String company,
                                                              @Header("timestamp") Long timestamp,
                                                              @Header("sign") String sign,
                                                              @Body YunKeGetUserByUseridRequest body);


    /**
     * <h2>根据手机号查询用户信息</h2>
     *
     * <a href ="https://crm.yunkecn.com/xdapi/doc/open.html#u67e5u8be2u7528u6237u4fe1u606fuff08userid290a3ca20id3du67e5u8be2u7528u6237u4fe1u606fuff08userid296993e203ca3e" >链接</a>
     *
     * @param partnerId 用户id，用于识别调用人，大部分请求为云客分配的管理员id，个别接口需要传员工的用户id
     * @param company   企业代码
     * @param key       云客分配的ke
     * @param userId    用户id
     */
    default YunKeGetUserResult getUserByUserid(String partnerId,
                                               String company,
                                               String key,
                                               String userId) throws IOException {
        YunKeGetUserByUseridRequest body = new YunKeGetUserByUseridRequest(userId);
        YunKeProperties p = new YunKeProperties(partnerId, key, company);

        YunKeBaseResult<YunKeGetUserResult> ret = getUserByUserid(
                p.getPartnerId(),
                p.getCompany(),
                p.getTimestamp(),
                p.getSign(),
                body
        ).execute().body();

        return verify(ret);
    }


    /**
     * <h2>获取公司所有微信好友或微信群</h2>
     *
     * <a href ="https://crm.yunkecn.com/xdapi/doc/open.html#u83b7u53d6u516cu53f8u6240u6709u5faeu4fe1u597du53cbu6216u5faeu4fe1u7fa40a3ca20id3du83b7u53d6u516cu53f8u6240u6709u5faeu4fe1u597du53cbu6216u5faeu4fe1u7fa412233e203ca3e" >链接</a>
     *
     * @param partnerId 用户id，用于识别调用人，大部分请求为云客分配的管理员id，个别接口需要传员工的用户id
     * @param company   企业代码
     * @param timestamp unix时间戳，精确到毫秒 例如 1530081688201（如果时间相差1分钟 会返回错误结果）
     * @param sign      签名 MD5后转大写，计算方式 md5(签名key+company+partnerId+timestamp).toUpper
     * @param body      请不求参数
     */
    @POST("open/wechat/getAllFriends")
    Call<YunKeBaseResult<List<YunKeGetAllFriendsResult>>> getAllFriends(@Header("partnerId") String partnerId,
                                                                        @Header("company") String company,
                                                                        @Header("timestamp") Long timestamp,
                                                                        @Header("sign") String sign,
                                                                        @Body YunKeGetAllFriendsRequest body);


    /**
     * <h2>获取公司所有微信好友或微信群</h2>
     *
     * <a href ="https://crm.yunkecn.com/xdapi/doc/open.html#u83b7u53d6u516cu53f8u6240u6709u5faeu4fe1u597du53cbu6216u5faeu4fe1u7fa40a3ca20id3du83b7u53d6u516cu53f8u6240u6709u5faeu4fe1u597du53cbu6216u5faeu4fe1u7fa412233e203ca3e" >链接</a>
     *
     * @param partnerId 用户id，用于识别调用人，大部分请求为云客分配的管理员id，个别接口需要传员工的用户id
     * @param company   企业代码
     * @param key       云客分配的ke
     * @param body      请不求参数
     * @apiNote <p>
     * *注意：此每次最多返回5000条；接口限制5秒调用一次
     * *注意：此接口根据入库时间正序排序
     * </p>
     */
    default List<YunKeGetAllFriendsResult> getAllFriends(String partnerId,
                                                         String company,
                                                         String key,
                                                         YunKeGetAllFriendsRequest body) throws IOException {
        YunKeProperties p = new YunKeProperties(partnerId, key, company);

        YunKeBaseResult<List<YunKeGetAllFriendsResult>> ret = getAllFriends(
                p.getPartnerId(),
                p.getCompany(),
                p.getTimestamp(),
                p.getSign(),
                body
        ).execute().body();

        return verify(ret);
    }


    /**
     * <h2>查询公司销售每天的微信沟通人数统计</h2>
     *
     * <a href ="https://crm.yunkecn.com/xdapi/doc/open.html#u67e5u8be2u516cu53f8u9500u552eu6bcfu5929u7684u5faeu4fe1u6c9fu901au4ebau6570u7edfu8ba10a3ca20id3du67e5u8be2u516cu53f8u9500u552eu6bcfu5929u7684u5faeu4fe1u6c9fu901au4ebau6570u7edfu8ba112233e203ca3e" >链接</a>
     *
     * @param partnerId 用户id，用于识别调用人，大部分请求为云客分配的管理员id，个别接口需要传员工的用户id
     * @param company   企业代码
     * @param timestamp unix时间戳，精确到毫秒 例如 1530081688201（如果时间相差1分钟 会返回错误结果）
     * @param sign      签名 MD5后转大写，计算方式 md5(签名key+company+partnerId+timestamp).toUpper
     * @param body      请不求参数
     */
    @POST("open/wechat/salesWechatStatistics")
    Call<YunKeBaseResult<YunKeGetSalesWechatStatisticsResult>> salesWechatStatistics(@Header("partnerId") String partnerId,
                                                                                     @Header("company") String company,
                                                                                     @Header("timestamp") Long timestamp,
                                                                                     @Header("sign") String sign,
                                                                                     @Body YunKeGetSalesWechatStatisticsRequest body);


    /**
     * <h2>查询公司销售每天的微信沟通人数统计</h2>
     *
     * <a href ="https://crm.yunkecn.com/xdapi/doc/open.html#u67e5u8be2u516cu53f8u9500u552eu6bcfu5929u7684u5faeu4fe1u6c9fu901au4ebau6570u7edfu8ba10a3ca20id3du67e5u8be2u516cu53f8u9500u552eu6bcfu5929u7684u5faeu4fe1u6c9fu901au4ebau6570u7edfu8ba112233e203ca3e" >链接</a>
     *
     * @param partnerId 用户id，用于识别调用人，大部分请求为云客分配的管理员id，个别接口需要传员工的用户id
     * @param company   企业代码
     * @param key       云客分配的ke
     * @param body      请不求参数
     * @apiNote <p>
     * *注意：此每次最多返回5000条；接口限制5秒调用一次
     * *注意：此接口根据入库时间正序排序
     * </p>
     */
    default YunKeGetSalesWechatStatisticsResult salesWechatStatistics(String partnerId,
                                                                      String company,
                                                                      String key,
                                                                      YunKeGetSalesWechatStatisticsRequest body) throws IOException {
        YunKeProperties p = new YunKeProperties(partnerId, key, company);

        YunKeBaseResult<YunKeGetSalesWechatStatisticsResult> ret = salesWechatStatistics(
                p.getPartnerId(),
                p.getCompany(),
                p.getTimestamp(),
                p.getSign(),
                body
        ).execute().body();

        return verify(ret);
    }


    /**
     * <h2>查询用户及设备信息</h2>
     *
     * <a href ="https://crm.yunkecn.com/xdapi/doc/open.html#u67e5u8be2u7528u6237u53cau8bbeu5907u4fe1u606f0a3ca20id3du67e5u8be2u7528u6237u53cau8bbeu5907u4fe1u606f6993e203ca3e" >链接</a>
     *
     * @param partnerId 用户id，用于识别调用人，大部分请求为云客分配的管理员id，个别接口需要传员工的用户id
     * @param company   企业代码
     * @param timestamp unix时间戳，精确到毫秒 例如 1530081688201（如果时间相差1分钟 会返回错误结果）
     * @param sign      签名 MD5后转大写，计算方式 md5(签名key+company+partnerId+timestamp).toUpper
     * @param body      请不求参数
     */
    @POST("open/user/getUserAndDeviceInfo")
    Call<YunKeBaseResult<YunKeGetUserAndDeviceInfoResult>> getUserAndDeviceInfo(@Header("partnerId") String partnerId,
                                                                                @Header("company") String company,
                                                                                @Header("timestamp") Long timestamp,
                                                                                @Header("sign") String sign,
                                                                                @Body YunKeGetUserAndDeviceInfoRequest body);


    /**
     * <h2>查询用户及设备信息</h2>
     *
     * <a href ="https://crm.yunkecn.com/xdapi/doc/open.html#u67e5u8be2u7528u6237u53cau8bbeu5907u4fe1u606f0a3ca20id3du67e5u8be2u7528u6237u53cau8bbeu5907u4fe1u606f6993e203ca3e" >链接</a>
     *
     * @param partnerId 用户id，用于识别调用人，大部分请求为云客分配的管理员id，个别接口需要传员工的用户id
     * @param company   企业代码
     * @param key       云客分配的ke
     * @param body      请不求参数
     * @apiNote <p>
     * *注意：此每次最多返回5000条；接口限制5秒调用一次
     * *注意：此接口根据入库时间正序排序
     * </p>
     */
    default YunKeGetUserAndDeviceInfoResult getUserAndDeviceInfo(String partnerId,
                                                                 String company,
                                                                 String key,
                                                                 YunKeGetUserAndDeviceInfoRequest body) throws IOException {
        YunKeProperties p = new YunKeProperties(partnerId, key, company);

        YunKeBaseResult<YunKeGetUserAndDeviceInfoResult> ret = getUserAndDeviceInfo(
                p.getPartnerId(),
                p.getCompany(),
                p.getTimestamp(),
                p.getSign(),
                body
        ).execute().body();

        return verify(ret);
    }


    /**
     * <h2>增量获取公司员工的聊天数据</h2>
     *
     * <a href ="https://crm.yunkecn.com/xdapi/doc/open.html#u589eu91cfu83b7u53d6u516cu53f8u5458u5de5u7684u804au5929u6570u636e0a3ca20id3du589eu91cfu83b7u53d6u516cu53f8u5458u5de5u7684u804au5929u6570u636e12233e203ca3e" >链接</a>
     *
     * @param partnerId 用户id，用于识别调用人，大部分请求为云客分配的管理员id，个别接口需要传员工的用户id
     * @param company   企业代码
     * @param timestamp unix时间戳，精确到毫秒 例如 1530081688201（如果时间相差1分钟 会返回错误结果）
     * @param sign      签名 MD5后转大写，计算方式 md5(签名key+company+partnerId+timestamp).toUpper
     * @param body      请不求参数
     */
    @POST("open/wechat/allRecords")
    Call<YunKeBaseResult<YunKeGetAllRecordResult>> getAllRecord(@Header("partnerId") String partnerId,
                                                                @Header("company") String company,
                                                                @Header("timestamp") Long timestamp,
                                                                @Header("sign") String sign,
                                                                @Body YunKeGetAllRecordRequest body);


    /**
     * <h2>增量获取公司员工的聊天数据</h2>
     *
     * <a href ="https://crm.yunkecn.com/xdapi/doc/open.html#u589eu91cfu83b7u53d6u516cu53f8u5458u5de5u7684u804au5929u6570u636e0a3ca20id3du589eu91cfu83b7u53d6u516cu53f8u5458u5de5u7684u804au5929u6570u636e12233e203ca3e" >链接</a>
     *
     * @param partnerId 用户id，用于识别调用人，大部分请求为云客分配的管理员id，个别接口需要传员工的用户id
     * @param company   企业代码
     * @param key       云客分配的ke
     * @param body      请不求参数
     * @apiNote <p>
     * 注意：此接口返回聊天文本、图片（当前只提供图片缩略图）、短语音消息、视频消息、文件、链接、定位、GIF、引用类型、拍一拍等类型的聊天数据
     * 注意：可以根据*wechatId + talker + msgSvrId作为唯一索引
     * 注意：按照公司码拉取全部，根据入参的timestamp增量最多查询1小时的数据，按照消息保存时间正序排序，每次最多返回2000条；接口限制5秒调用一次（数据存储会有延迟，入参的timestamp要小于当前时间30分钟以上）
     * 例如：入参的timestamp=1664899200000，则查询1664899200000~(1664899200000 + 3600000) 这一段时间内保存的数据
     * 注意：返回记录根据入库时间和消息发送时间增量排序
     * 注意：由于聊天记录和文件是分别上传，（图片、短语音消息、视频、文件）等类型的数据会延迟上传到服务器，当查询的聊天数据缺少文件时，可以等30分钟后通过“根据消息id获取语音等文件消息补充链接（/open/wechat/getRecordsByMsgId）接口补充链接
     * 说明：为了兼容处理同一个消息保存时间下的聊天消息的入库时间大于2000条的情况，增加了createTimestamp参数：当createTimestamp大于0时，会按照     createTimestamp增量查询同一消息保存时间下的聊天消息，同一个消息保存时间下的数据获取完后，再查询新的消息保存时间的数据
     * <p>
     * type字段说明：1聊天文本, 2图片，3短语音消息，4视频消息，8GIF表情，9文件，10链接，14定位信息，18小程序，21引用类型，22拍一拍消息
     * text字段说明： type=1时，text为聊天内容；type=3时，text为语音时长；type=9时，text为文件名；type=10时，text为标题；type=14时，text为定位地址；type=18时，text为小程序标题；type=21时，text为聊天内容，type=22时，text为文本内容（其他类不返回）
     * <p>
     * file字段说明： type=2时，file为图片链接；type=3时，file为语音消息id，需调用微信语音文件转码接口（/open/mp3trans/trans/wechatAmrTrans）获取语音地址；type=4时，file为视频消息链接；type=8时，file为图片链接；type=9时，file为文件链接； type=10时，file为url地址；type=14时，file为经纬度；type=18时，file为小程序logo（其他类型不返回）
     * </p>
     */
    default YunKeGetAllRecordResult getAllRecord(String partnerId,
                                                 String company,
                                                 String key,
                                                 YunKeGetAllRecordRequest body) throws IOException {
        YunKeProperties p = new YunKeProperties(partnerId, key, company);

        YunKeBaseResult<YunKeGetAllRecordResult> ret = getAllRecord(
                p.getPartnerId(),
                p.getCompany(),
                p.getTimestamp(),
                p.getSign(),
                body
        ).execute().body();
        return verify(ret);
    }


    /**
     * <h2>根据员工id获取微信账号</h2>
     *
     * <a href ="https://crm.yunkecn.com/xdapi/doc/open.html#u6839u636eu5458u5de5idu83b7u53d6u5faeu4fe1u8d26u53f70a3ca20id3du6839u636eu5458u5de5idu83b7u53d6u5faeu4fe1u8d26u53f712233e203ca3e" >链接</a>
     *
     * @param partnerId 用户id，用于识别调用人，大部分请求为云客分配的管理员id，个别接口需要传员工的用户id
     * @param company   企业代码
     * @param timestamp unix时间戳，精确到毫秒 例如 1530081688201（如果时间相差1分钟 会返回错误结果）
     * @param sign      签名 MD5后转大写，计算方式 md5(签名key+company+partnerId+timestamp).toUpper
     * @param body      请不求参数
     */
    @POST("open/wechat/accounts")
    Call<YunKeBaseResult<List<YunKeGetAccountsResult>>> getAccounts(@Header("partnerId") String partnerId,
                                                                    @Header("company") String company,
                                                                    @Header("timestamp") Long timestamp,
                                                                    @Header("sign") String sign,
                                                                    @Body YunKeGetAccountsRequest body);


    /**
     * <h2>根据员工id获取微信账号</h2>
     *
     * <a href ="https://crm.yunkecn.com/xdapi/doc/open.html#u6839u636eu5458u5de5idu83b7u53d6u5faeu4fe1u8d26u53f70a3ca20id3du6839u636eu5458u5de5idu83b7u53d6u5faeu4fe1u8d26u53f712233e203ca3e" >链接</a>
     *
     * @param partnerId 用户id，用于识别调用人，大部分请求为云客分配的管理员id，个别接口需要传员工的用户id
     * @param company   企业代码
     * @param key       云客分配的ke
     * @param body      请不求参数
     * @apiNote <p>
     * 查询用户的微信 一个员工可能有多个微信序
     * </p>
     */
    default List<YunKeGetAccountsResult> getAccounts(String partnerId,
                                                     String company,
                                                     String key,
                                                     YunKeGetAccountsRequest body) throws IOException {
        YunKeProperties p = new YunKeProperties(partnerId, key, company);

        YunKeBaseResult<List<YunKeGetAccountsResult>> ret = getAccounts(
                p.getPartnerId(),
                p.getCompany(),
                p.getTimestamp(),
                p.getSign(),
                body
        ).execute().body();

        return verify(ret);
    }


    /**
     * <h2>根据员工id获取微信账号</h2>
     *
     * <a href ="https://crm.yunkecn.com/xdapi/doc/open.html#u6839u636eu5458u5de5idu83b7u53d6u5faeu4fe1u8d26u53f70a3ca20id3du6839u636eu5458u5de5idu83b7u53d6u5faeu4fe1u8d26u53f712233e203ca3e" >链接</a>
     *
     * @param partnerId 用户id，用于识别调用人，大部分请求为云客分配的管理员id，个别接口需要传员工的用户id
     * @param company   企业代码
     * @param timestamp unix时间戳，精确到毫秒 例如 1530081688201（如果时间相差1分钟 会返回错误结果）
     * @param sign      签名 MD5后转大写，计算方式 md5(签名key+company+partnerId+timestamp).toUpper
     * @param body      请不求参数
     */
    @POST("open/wechat/companyAccounts")
    Call<YunKeBaseResult<YunKeGetCompanyAccountsResult>> getCompanyAccounts(@Header("partnerId") String partnerId,
                                                                            @Header("company") String company,
                                                                            @Header("timestamp") Long timestamp,
                                                                            @Header("sign") String sign,
                                                                            @Body YunKeGetCompanyAccountsRequest body);


    /**
     * <h2>根据员工id获取微信账号</h2>
     *
     * <a href ="https://crm.yunkecn.com/xdapi/doc/open.html#u6839u636eu5458u5de5idu83b7u53d6u5faeu4fe1u8d26u53f70a3ca20id3du6839u636eu5458u5de5idu83b7u53d6u5faeu4fe1u8d26u53f712233e203ca3e" >链接</a>
     *
     * @param partnerId 用户id，用于识别调用人，大部分请求为云客分配的管理员id，个别接口需要传员工的用户id
     * @param company   企业代码
     * @param key       云客分配的ke
     * @param body      请不求参数
     * @apiNote <p>
     * 查询用户的微信 一个员工可能有多个微信序
     * </p>
     */
    default YunKeGetCompanyAccountsResult getCompanyAccounts(String partnerId,
                                                             String company,
                                                             String key,
                                                             YunKeGetCompanyAccountsRequest body) throws IOException {
        YunKeProperties p = new YunKeProperties(partnerId, key, company);

        YunKeBaseResult<YunKeGetCompanyAccountsResult> ret = getCompanyAccounts(
                p.getPartnerId(),
                p.getCompany(),
                p.getTimestamp(),
                p.getSign(),
                body
        ).execute().body();

        return verify(ret);
    }


}
