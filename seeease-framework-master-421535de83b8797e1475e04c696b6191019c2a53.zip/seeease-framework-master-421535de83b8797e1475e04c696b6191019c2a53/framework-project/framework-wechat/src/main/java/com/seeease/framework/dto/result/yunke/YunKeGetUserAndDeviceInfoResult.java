package com.seeease.framework.dto.result.yunke;

import lombok.Data;

import java.util.List;

/**
 * <p>云客用户级设备信息返回</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 4/19/24 10:35上午
 **/
@Data
public class YunKeGetUserAndDeviceInfoResult {

    /**
     * 用户列表
     */
    private List<User> users;
    /**
     * 总条数
     */
    private Integer total;

    private String pageIndex;

    private String pageSize;

    /**
     * 用户信息
     */
    @Data
    public static class User{

        /**
         *手机系统版本号
         */
        private String sysVersion;
        /**
         *部门名称
         */
        private String deptName;
        /**
         *手机工作台版本号
         */
        private String appVersion;
        /**
         *手机用户id
         */
        private String phoneUserId;
        /**
         *用户手机号
         */
        private String phone;
        /**
         *用户姓名
         */
        private String name;
        /**
         *手机imei
         */
        private String imei;
        /**
         *最近一次在线时间 yyyy-MM-dd HH:mm:ss
         */
        private String lastOnlineTime;
        /**
         *手机部门id
         */
        private String phoneDeptId;
        /**
         *调用方的部门id 对接后有值
         */
        private String deptId;
        /**
         *调用方的用户id
         */
        private String userId;
        /**
         *邮箱
         */
        private String email;

    }
}
