package com.seeease.framework.dto.result.yunke;

import lombok.Data;

/**
 * <p>云客基础返回</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 4/19/24 10:38 上午
 **/
@Data
public class YunKeBaseResult<T> {
     private Boolean success;
     private String message;
     private T data;
     private String code;


}
