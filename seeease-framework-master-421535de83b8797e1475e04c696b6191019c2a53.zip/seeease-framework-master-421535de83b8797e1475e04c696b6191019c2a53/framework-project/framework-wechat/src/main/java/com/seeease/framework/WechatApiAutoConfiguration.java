package com.seeease.framework;

import com.seeease.framework.properties.WechatProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * <p>api接口配置</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 11/22/23 上午
 **/
@Configuration
@EnableConfigurationProperties({WechatProperties.class})
public class WechatApiAutoConfiguration {


}
