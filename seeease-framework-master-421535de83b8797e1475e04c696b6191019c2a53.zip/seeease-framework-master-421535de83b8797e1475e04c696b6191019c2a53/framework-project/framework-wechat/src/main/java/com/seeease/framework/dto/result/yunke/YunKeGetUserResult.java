package com.seeease.framework.dto.result.yunke;

import lombok.Data;

/**
 * <p>云客用户信息返回</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 4/19/24 10:35上午
 **/
@Data
public class YunKeGetUserResult {
    /**
     *用户姓名
     */
    private String name;
    /**
     *手机的设备号（在手机上登陆后会有值）
     */
    private String imei;
    /**
     *手机号
     */
    private String phone;
    /**
     *用户id
     */
    private String userId;
    /**
     *云客的用户id
     */
    private String yunkeUserId;
    /**
     *邮箱
     */
    private String email;
    /**
     *是否在职（1在职，2离职）
     */
    private String isVaild;
}
