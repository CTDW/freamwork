package com.seeease.framework.properties;

import com.seeease.springframework.utils.StringUtils;
import lombok.Data;
import org.springframework.util.Assert;

/**
 * <p>云客基础配置</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 4/19/24 10:16 上午
 **/
@Data
public class YunKeProperties {
    /**
     * 用户id，用于识别调用人，大部分请求为云客分配的管理员id，个别接口需要传员工的用户id
     */
    private String partnerId;
    /**
     * 分配的key
     */
    private String key;
    /**
     * 企业代码
     */
    private String company;
    /**
     * unix时间戳，精确到毫秒 例如 1530081688201（如果时间相差1分钟 会返回错误结果）
     */
    private Long timestamp;
    /**
     * 签名 MD5后转大写，计算方式 md5(签名key+company+partnerId+timestamp).toUpper
     */
    private String sign;

    /**
     * 计算签名
     */
    public String buildSign(){
        Assert.hasLength(partnerId,"计算sign时partnerId为空");
        Assert.hasLength(company,"计算sign时company为空");
        Assert.notNull(timestamp,"计算sign时时间戳不能为空");
        try {
            return StringUtils.encoderByMd5(key+company+partnerId + timestamp).toUpperCase();
        }catch (Exception e){
            throw new RuntimeException("云客sign MD5计算出错");
        }
    }

    /**
     * 填充sign
     */
    public void fillSign(){
        this.sign = buildSign();
    }

    private YunKeProperties() {}

    public YunKeProperties(String partnerId, String key, String company) {
        this.partnerId = partnerId;
        this.key = key;
        this.company = company;
        this.timestamp  = System.currentTimeMillis();
        fillSign();
    }




}
