package com.seeease.framework.api;


import com.seeease.framework.dto.request.applet.WechatAppletGetPhoneRequest;
import com.seeease.framework.dto.request.applet.WechatAppletGetSchemeRequest;
import com.seeease.framework.dto.result.applet.WechatAppletGetPhoneResult;
import com.seeease.framework.dto.result.applet.WechatAppletGetSchemeResult;
import com.seeease.framework.dto.result.applet.WechatAppletLoginResult;
import com.seeease.framework.dto.result.applet.WechatAppletTokenResult;
import com.seeease.framework.properties.WechatProperties;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Query;

import java.io.IOException;
import java.util.Objects;

/**
 * <p>小程序api</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 11/22/23 上午
 **/
public interface WechatAppletApi {


    /**
     * <h2>获取token</h2>
     * <a href="https://developers.weixin.qq.com/miniprogram/dev/OpenApiDoc/mp-access-token/getAccessToken.html">
     * 链接
     * </a>
     *
     * @param appid      小程序 appId
     * @param secret     小程序 appSecret
     * @param grant_type 授权类型，此处只需填写 client_credential
     */
    @GET("cgi-bin/token")
    Call<WechatAppletTokenResult> getToken(@Query("appid") String appid,
                                           @Query("secret") String secret,
                                           @Query("grant_type") String grant_type);


    /**
     * <h2>适配方法 {@link #getToken(String, String, String)}</h2>
     */
    default Call<WechatAppletTokenResult> getToken() {
        WechatProperties.Applet applet = WechatProperties.getAppletStatic();
        return getToken(applet.getAppId(), applet.getAppSecret(), "client_credential");
    }


    /**
     * <h2>获取token字符串</h2>
     *
     * @throws IOException
     */
    default String getTokenStr() throws IOException {
        return Objects.requireNonNull(getToken().execute().body()).getAccessToken();
    }


    /**
     * <h2>
     *     小程序登录
     * </h2>
     * <a href="https://developers.weixin.qq.com/miniprogram/dev/OpenApiDoc/user-login/code2Session.html">链接</a>
     * @apiNote
     * <p>登录凭证校验。通过 wx.login 接口获得临时登录凭证 code 后传到开发者服务器调用此接口完成登录流程</p>
     *
     *
     * @param appid      小程序 appId
     * @param secret     小程序 appSecret
     * @param js_code    登录时获取的 code，可通过wx.login获取
     * @param grant_type 授权类型，此处只需填写 authorization_code
     */
    @GET("sns/jscode2session")
    Call<WechatAppletLoginResult> login(@Query("appid") String appid,
                                        @Query("secret") String secret,
                                        @Query("js_code") String js_code,
                                        @Query("grant_type") String grant_type);


    /**
     * <h2>适配方法 {@link #login(String, String, String, String)}</h2>
     */
    default Call<WechatAppletLoginResult> login(String js_code) {
        WechatProperties.Applet applet = WechatProperties.getAppletStatic();
        return login(applet.getAppId(), applet.getAppSecret(), js_code, "authorization_code");
    }


    /**
     * <h2>该接口用于将code换取用户手机号。 说明，每个code只能使用一次，code的有效期为5min。</h2>
     * <a href="https://developers.weixin.qq.com/miniprogram/dev/OpenApiDoc/user-info/phone-number/getPhoneNumber.html">
     *     链接</a>
     *
     * @param token token
     * @param body  请求体
     */
    @POST("wxa/business/getuserphonenumber")
    Call<WechatAppletGetPhoneResult> getPhone(@Query("access_token") String token,
                                              @Body WechatAppletGetPhoneRequest body);



    /**
     * <h2>适配方法 {@link #getPhone(String, WechatAppletGetPhoneRequest)}</h2>
     * @param code 用于解析手机号的code {@link WechatAppletGetPhoneRequest#getCode()}
     */
    default Call<WechatAppletGetPhoneResult> getPhone(String code) throws IOException {
        String tokenStr = getTokenStr();
        return getPhone(tokenStr, new WechatAppletGetPhoneRequest(code));
    }


    /**
     * <h2>获取加密scheme码</h2>
     * <a href="https://developers.weixin.qq.com/miniprogram/dev/OpenApiDoc/qrcode-link/url-scheme/generateScheme.html">链接</a>
     * @apiNote
     * <p>
     * 该接口用于获取小程序 scheme 码，适用于短信、邮件、外部网页、微信内等拉起小程序的业务场景。
     * 目前仅针对国内非个人主体的小程序开放，详见获取 URL scheme。
     * </p>
     * @param token
     * @param body
     */
    @POST("wxa/generatescheme")
    Call<WechatAppletGetSchemeResult> getScheme(@Query("access_token") String token,
                                               @Body WechatAppletGetSchemeRequest body);



    /**
     * <h2>适配{@link #getScheme(String, WechatAppletGetSchemeRequest)}</h2>
     * @param body
     * @throws IOException
     */
   default Call<WechatAppletGetSchemeResult> getScheme(WechatAppletGetSchemeRequest body) throws IOException {
       String tokenStr = getTokenStr();
       return getScheme(tokenStr,body);
   }


}
