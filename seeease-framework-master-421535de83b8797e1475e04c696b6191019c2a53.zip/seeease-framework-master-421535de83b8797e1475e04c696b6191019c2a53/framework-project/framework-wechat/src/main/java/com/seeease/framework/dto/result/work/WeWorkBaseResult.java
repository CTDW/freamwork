package com.seeease.framework.dto.result.work;

import com.alibaba.fastjson.annotation.JSONField;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * <p>企业微信基础返回</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 1/5/24 2:15下午
 **/
@Data
@NoArgsConstructor
@AllArgsConstructor
public class WeWorkBaseResult implements Serializable {
    /**
     * 出错返回码，为0表示成功，非0表示调用失败
     */
    @JSONField(name = "errcode")
    private Integer errCode;
    /**
     * 返回码提示语
     */
    @JSONField(name = "errmsg")
    private String errorMsg;


}
