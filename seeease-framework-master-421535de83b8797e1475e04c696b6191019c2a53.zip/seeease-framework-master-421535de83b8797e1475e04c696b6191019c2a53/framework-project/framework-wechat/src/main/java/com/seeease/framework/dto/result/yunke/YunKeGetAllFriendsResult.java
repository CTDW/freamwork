package com.seeease.framework.dto.result.yunke;

import lombok.Data;

/**
 * <p>获取公司所有微信好友或微信群返回</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 4/19/24 11:07上午
 **/
@Data
public class YunKeGetAllFriendsResult {
    /**
     *好友微信id或群id
     */
    private String id;
    /**
     *好友微信号
     */
    private String alias;
    /**
     *微信好友昵称或群昵称
     */
    private String name;
    /**
     *微信好友备注或群备注
     */
    private String remark;
    /**
     *1好友 2群
     */
    private String type;
    /**
     * 对方通过群聊添加 1000014
     * 通过群聊添加 14
     * 通过手机通讯录添加 10、13
     * 对方通过搜索手机号添加 1000015
     * 通过搜索手机号添加 15
     * 对方通过名片分享添加 1000017
     * 通过名片分享添加 17
     * 通过附近的人添加 18
     * 对方通过扫一扫添加 1000030
     * 通过扫一扫添加 30
     * 对方通过搜索微信号添加 1000003
     * 通过搜索微信号添加 3
     * 通过群聊添加 8
     * 来自QQ好友 4
     */
    private String fromType;
    /**
     *头像url
     */
    private String headUrl;
    /**
     *好友微信手机号
     */
    private String phone;
    /**
     *微信好友标签，多个标签逗号分隔
     */
    private String label;
    /**
     *微信好友性别（1男 2女）
     */
    private String gender;
    /**
     *微信好友地区
     */
    private String region;
    /**
     *群主微信号，type=2查询群聊时返回
     */
    private String ownerWchatId;
    /**
     *数据入库时间
     */
    private String createTime;
    /**
     *用户微信id
     */
    private String salesWechatId;
    /**
     *0未删除 1已删除(只适用于好友)
     */
    private String delete;
    /**
     *实际添加好友的时间（非必须返回）
     */
    private String addTime;

}
