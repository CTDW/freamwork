package com.seeease.framework.dto.request.yunke;

import lombok.Data;

/**
 * <p>云客用户级设备信息返回</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 4/19/24 10:35上午
 **/
@Data
public class YunKeGetUserAndDeviceInfoRequest {

    /**
     * 用户id非必须
     */
    private String userId;
    /**
     * 页码 从1开始 按照userId查询时不需要传
     */
    private String pageIndex;
    /**
     * 每页条数 最大不超过100 按照userId查询时不需要传
     */
    private String pageSize;

}
