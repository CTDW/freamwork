package com.seeease.framework.dto.result.yunke;

import lombok.Data;

import java.util.List;

/**
 * <p>获取公司所有微信聊天记录返回</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 4/19/24 11:07上午
 **/
@Data
public class YunKeGetAllRecordResult {

    /**
     * 消息列表
     */
    private List<Message> messages;
    /**
     * 拍一拍消息列表
     */
    private List<PatMsg> patMsgs;
    /**
     * 同一个消息保存时间大于分页（2000条）的情况下的补充的查询条件（消息发送时间，如果createTimestamp>0，下次请求需要加上该参数）
     */
    private String createTimestamp;
    /**
     * 当前消息列表第一条消息的保存时间
     */
    private Long start;
    /**
     * 当前消息列表最后一条消息的保存时间（翻页用）
     */
    private Long end;

    /**
     * 拍一拍消息
     */
    @Data
    public static class PatMsg{
        /**
         *拍一拍-拍的人
         */
        private String fromUser;
        /**
         *拍一拍消息内容
         */
        private String template;
        /**
         *创建时间
         */
        private String createTime;
        /**
         *消息id
         */
        private String svrId;
        /**
         *拍一拍消息数
         */
        private Integer patMsgRecordNum;
    }

    /**
     * 消息内容
     */
    @Data
    public static class Message{
        /**
         *和好友聊天时返回好友微信id，群聊时（mine=true返回群id，mine=false返回说话人的微信id）
         */
        private String talker;
        /**
         *微信群id（群聊消息时返回）
         */
        private String roomid;
        /**
         *微信消息的唯一id（不同的员工可能会上传同一条消息）
         */
        private String msgSvrId;
        /**
         *talker对应的微信名
         */
        private String name;
        /**
         *type=1时，text为聊天内容；
         * type=3时，text为语音时长；
         * type=9时，text为文件名；
         * type=10时，text为标题；
         * type=14时，text为定位地址；
         * type=18时，text为小程序标题（其他类型不返回）
         */
        private String text;
        /**
         *  1聊天文本,
         *  2图片，
         *  3短语音消息，
         *  4视频消息，
         *  8GIF表情，
         *  9文件，
         *  10链接，
         *  14定位信息，
         *  18小程序，
         *  21引用类型，
         *  22拍一拍消息
         */
        private Integer type;
        /**
         *消息发送时间
         */
        private Long timestamp;
        /**
         *消息保存时间
         */
        private Long time;
        /**
         *type=2时，file为图片链接；
         * type=3时，file为语音消息id，
         * 需调用微信语音文件转码接口（/open/mp3trans/trans/wechatAmrTrans）获取语音地址；
         * type=4时，file为视频消息链接;
         * type=9时 file为文件链接；
         * type=10时，file为url地址；
         * type=14时，file为经纬度；
         * type=18时，file为小程序链接（其他类型不返回）
         */
        private String file;
        /**
         *是否是员工发送的消息
         */
        private Boolean mine;
        /**
         *员工微信id
         */
        private String wechatId;
        /**
         *用户id
         */
        private String partnerId;
        /**
         *引用消息json字符串
         */
        private String refermsgjson;
    }

}
