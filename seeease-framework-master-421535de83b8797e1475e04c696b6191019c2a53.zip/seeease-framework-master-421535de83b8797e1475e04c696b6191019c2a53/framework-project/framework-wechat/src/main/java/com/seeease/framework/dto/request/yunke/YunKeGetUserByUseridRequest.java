package com.seeease.framework.dto.request.yunke;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * <p>云客根据用户id取用户信息请求</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 4/19/24 10:35上午
 **/
@Data
@AllArgsConstructor
public class YunKeGetUserByUseridRequest {
    private String userId;
}
