package com.seeease.framework.dto.request.yunke;

import lombok.Data;

/**
 * <p>分页获取公司所有的微信账号请求</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 4/19/24 11:07 上午
 **/
@Data
public class YunKeGetCompanyAccountsRequest {
    /**
     *页码
     */
    private Integer pageIndex;
    /**
     *每页条数
     */
    private String pageSize;
    /**
     * 更新时间start（yyyy-MM-dd HH:mm:ss）
     */
    private String updateTimeStart;
    /**
     * 更新时间end（yyyy-MM-dd HH:mm:ss）
     */
    private String updateTimeEnd;

}
