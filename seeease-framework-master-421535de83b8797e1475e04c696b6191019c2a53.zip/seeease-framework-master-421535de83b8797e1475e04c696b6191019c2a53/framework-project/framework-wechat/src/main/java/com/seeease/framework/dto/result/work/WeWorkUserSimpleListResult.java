package com.seeease.framework.dto.result.work;


import com.alibaba.fastjson.annotation.JSONField;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

/**
 * <p>获取部门成员</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 1/5/24 2:29下午
 **/
@EqualsAndHashCode(callSuper = true)
@Data
@NoArgsConstructor
@AllArgsConstructor
public class WeWorkUserSimpleListResult extends WeWorkBaseResult{

    /**
     * 用户列表
     */
    private List<User> userList;

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class User implements Serializable {
        /**
         * 成员UserID。对应管理端的账号，企业内必须唯一。不区分大小写，长度为1~64个字节；第三方应用返回的值为open_userid
         */
        private String userid;
        /**
         * 	成员名称；第三方不可获取，调用时返回userid以代替name；代开发自建应用需要管理员授权才返回；
         * 	对于非第三方创建的成员，第三方通讯录应用也不可获取；未返回name的情况需要通过通讯录展示组件来展示名字
         */
        private String name;
        /**
         * 成员所属部门id列表，仅返回该应用有查看权限的部门id；成员授权模式下，固定返回根部门id，即固定为1。
         * 对授权了“组织架构信息”权限的第三方应用或授权了“组织架构信息”-“部门及父部门ID、部门负责人”权限的代开发应用，
         * 返回成员所属的全部部门id
         */
        private List<Integer> department;
        /**
         * 全局唯一。对于同一个服务商，不同应用获取到企业内同一个成员的open_userid是相同的，最多64个字节。仅第三方应用可获取。
         */
        @JSONField(name = "open_userid")
        private String openUserid;
    }
}
