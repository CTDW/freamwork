package com.seeease.framework.dto.result.applet;

import com.alibaba.fastjson.annotation.JSONField;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * <p>小程序获取token返回</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 11/22/23 上午
 **/
@Data
@AllArgsConstructor
@NoArgsConstructor
public class WechatAppletTokenResult implements Serializable {

    /**
     * 获取到的凭证
     */
    @JSONField(name = "access_token")
    private String accessToken;
    /**
     * 凭证有效时间，单位：秒。目前是7200秒之内的值。
     */
    @JSONField(name = "expires_in")
    private Long expiresIn;
}
