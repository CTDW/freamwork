package com.seeease.framework.dto.result.applet;

import com.alibaba.fastjson.annotation.JSONField;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * <p>获取小程序短链请求</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 11/22/23 11:20上午
 **/
@EqualsAndHashCode(callSuper = true)
@Data
@AllArgsConstructor
@NoArgsConstructor
public class WechatAppletGetSchemeResult extends WechatAppletBaseResult {

    /**
     * 生成的小程序 scheme 码
     */
    @JSONField(name = "openlink")
    private String openLink;
}
