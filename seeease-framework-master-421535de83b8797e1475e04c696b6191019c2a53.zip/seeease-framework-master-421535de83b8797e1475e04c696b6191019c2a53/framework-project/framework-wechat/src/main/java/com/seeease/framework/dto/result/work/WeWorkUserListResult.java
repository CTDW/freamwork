package com.seeease.framework.dto.result.work;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * <p>获取部门成员</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 1/5/24 2:29下午
 **/
@EqualsAndHashCode(callSuper = true)
@Data
@NoArgsConstructor
@AllArgsConstructor
public class WeWorkUserListResult extends WeWorkBaseResult{

    /**
     * 用户列表
     */
    private List<WeWorkUserResult> userList;

}
