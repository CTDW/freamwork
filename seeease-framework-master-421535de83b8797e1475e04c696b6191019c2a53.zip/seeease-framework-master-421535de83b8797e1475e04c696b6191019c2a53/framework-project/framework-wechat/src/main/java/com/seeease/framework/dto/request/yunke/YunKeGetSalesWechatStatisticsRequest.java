package com.seeease.framework.dto.request.yunke;

import lombok.Data;

/**
 * <p>查询公司销售每天的微信沟通人数统计</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 4/19/24 11:07上午
 **/
@Data
public class YunKeGetSalesWechatStatisticsRequest {

    private Integer page;
    private Integer size;
    /**
     * 开始时间
     */
    private String beginYmd;
    /**
     * 结束时间
     */
    private String endYmd;
}
