package com.seeease.framework.properties;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * <p>微信配置</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 11/22/23 下午
 **/
@ConfigurationProperties(prefix = "wechat")
public class WechatProperties {

    /**
     * 小程序配置
     */
    private static Applet applet = new Applet();
    /**
     * 企微配置
     */
    private static WeWork work = new WeWork();


    public static WeWork getWorkStatic() {
        return work;
    }

    public WeWork getWork() {
        return work;
    }

    public void setWork(WeWork work) {
        WechatProperties.work = work;
    }

    public static Applet getAppletStatic() {
        return applet;
    }

    public Applet getApplet() {
        return applet;
    }

    public void setApplet(Applet at) {
        applet = at;
    }

    /**
     * 小程序
     */
    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class Applet {
        /**
         * 小程序id
         */
        private String appId;
        /**
         * 小程序secret
         */
        private String appSecret;
        /**
         * 连接超时时间
         */
        private Integer connectTimeout = 1;
        /**
         * 读取超时时间
         */
        private Integer readTimeout = 2;
        /**
         * 写入超时时间
         */
        private Integer writeTimeout = 3;
    }


    /**
     * 企微
     */
    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class WeWork {
        /**
         * id
         */
        private String corpId;
        /**
         * secret
         */
        private String corpSecret;
        /**
         * 连接超时时间
         */
        private Integer connectTimeout = 1;
        /**
         * 读取超时时间
         */
        private Integer readTimeout = 2;
        /**
         * 写入超时时间
         */
        private Integer writeTimeout = 3;
    }
}
