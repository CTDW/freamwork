package com.seeease.framework.dto.request.yunke;

import lombok.Data;

/**
 * <p>获取userId获取微信号信息</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 4/19/24 11:07 上午
 **/
@Data
public class YunKeGetAccountsRequest {
    /**
     * 员工id
     */
    private String userId;
}
