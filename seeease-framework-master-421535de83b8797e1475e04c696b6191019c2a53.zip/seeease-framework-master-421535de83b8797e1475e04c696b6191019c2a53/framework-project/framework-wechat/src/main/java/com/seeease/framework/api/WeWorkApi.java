package com.seeease.framework.api;


import com.seeease.framework.dto.result.work.WeWorkAccessTokenResult;
import com.seeease.framework.dto.result.work.WeWorkUserResult;
import com.seeease.framework.properties.WechatProperties;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

import java.io.IOException;
import java.util.Objects;

/**
 * <p>企业微信api</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 1/5/24 下午
 **/
public interface WeWorkApi {

    /**
     * <h2>获取access_token</h2>
     *
     * <a href ="https://developer.work.weixin.qq.com/document/path/91039" >链接</a>
     *
     * @param corPid     id
     * @param corpSecret secret
     * @apiNote <p>
     * 获取access_token是调用企业微信API接口的第一步，相当于创建了一个登录凭证，其它的业务API接口，都需要依赖于access_token来鉴权调用者身份。
     * </p>
     */
    @GET("gettoken")
    Call<WeWorkAccessTokenResult> getAccessToken(@Query("corpid") String corPid,
                                                 @Query("corpsecret") String corpSecret);

    /**
     * 适配 {@link #getAccessToken(String, String)}
     */
    default String getAccessToken() throws IOException {
        WechatProperties.WeWork work = WechatProperties.getWorkStatic();
        return Objects.requireNonNull(getAccessToken(work.getCorpId(), work.getCorpSecret()).execute().body()).getAccessToken();
    }


    /**
     * <H2>
     *     获取用户信息
     * </H2>
     * <a href = "https://developer.work.weixin.qq.com/document/path/90196">链接<a/>
     *
     * @param accessToken 调用接口凭证
     * @param userid      成员UserID。对应管理端的账号，企业内必须唯一。不区分大小写，长度为1~64个字节
     * @apiNote <p>
     * 应用只能获取可见范围内的成员信息，且每种应用获取的字段有所不同，在返回结果说明中会逐个说明。
     * 企业通讯录安全特别重要，企业微信将持续升级加固通讯录接口的安全机制，以下是关键的变更点：
     * <p>
     * 从2022年6月20号20点开始，除通讯录同步以外的基础应用（如客户联系、微信客服、会话存档、日程等），
     * 以及新创建的自建应用与代开发应用，调用该接口时，
     * 不再返回以下字段：头像、性别、手机、邮箱、企业邮箱、员工个人二维码、地址，应用需要通过oauth2手工授权的方式获取管理员与员工本人授权的字段。
     * <p>
     * <li>
     * 【重要】从2022年8月15日10点开始，“企业管理后台 - 管理工具 - 通讯录同步”的新增IP将不能再调用此接口，
     * 企业可通过「获取成员ID列表」和「获取部门ID列表」接口获取userid和部门ID列表。查看调整详情。
     * </li>
     */
    @GET("user/get")
    Call<WeWorkUserResult> getUser(@Query("access_token") String accessToken,
                                   @Query("userid") String userid);

    /**
     * <h2>
     * 适配 {@link #getUser(String, String)}
     * </h2>
     *
     * @param userid 成员UserID。对应管理端的账号，企业内必须唯一。不区分大小写，长度为1~64个字节
     */
    default Call<WeWorkUserResult> getUser(String userid) throws IOException {
        return getUser(getAccessToken(), userid);
    }


    /**
     * <h2>
     * "获取部门成员简易版"
     * </h2>
     * <a href = "https://developer.work.weixin.qq.com/document/path/90200">链接</a>
     *
     * @param accessToken  调用接口凭证
     * @param departmentId 获取的部门id
     * @apiNote 企业通讯录安全特别重要，企业微信将持续升级加固通讯录接口的安全机制，以下是关键的变更点：
     * <li>    【重要】从2022年8月15日10点开始，“企业管理后台 - 管理工具 - 通讯录同步”的新增IP将不能再调用此接口，
     * 企业可通过「获取成员ID列表」和「获取部门ID列表」接口获取userid和部门ID列表。查看调整详情。
     * </li>
     */
    @GET("user/simplelist")
    Call<WeWorkUserResult> getUserSimpleList(@Query("access_token") String accessToken,
                                             @Query("department_id") Integer departmentId);

    /**
     * <h2>适配 {@link #getUserSimpleList(String, Integer)}</h2>
     *
     * @param departmentId 获取的部门id
     * @throws IOException
     */
    default Call<WeWorkUserResult> getUserSimpleList(Integer departmentId) throws IOException {
        return getUserSimpleList(getAccessToken(), departmentId);
    }


    /**
     * <h2>"获取部门成员详情"</h2>
     * <a href = "https://developer.work.weixin.qq.com/document/path/90200">链接</a>
     * @apiNote
     * <li>
     * 【重要】从2022年8月15日10点开始，“企业管理后台 - 管理工具 - 通讯录同步”的新增IP将不能再调用此接口，
     * 企业可通过「获取成员ID列表」和「获取部门ID列表」接口获取userid和部门ID列表。查看调整详情。
     * </li>
     * @param accessToken  调用接口凭证
     * @param departmentId 获取的部门id
     */
    @GET("user/list")
    Call<WeWorkUserResult> getUserList(@Query("access_token") String accessToken,
                                       @Query("department_id") Integer departmentId);

    /**
     * <h2>适配 {@link #getUserList(String, Integer)}</h2>
     *
     * @param departmentId 获取的部门id
     * @throws IOException
     */
    default Call<WeWorkUserResult> getUserList(Integer departmentId) throws IOException {
        return getUserList(getAccessToken(), departmentId);
    }





}
