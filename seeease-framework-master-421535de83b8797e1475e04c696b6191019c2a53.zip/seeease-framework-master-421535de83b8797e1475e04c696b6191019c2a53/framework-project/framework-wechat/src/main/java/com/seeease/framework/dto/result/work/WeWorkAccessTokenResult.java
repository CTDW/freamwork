package com.seeease.framework.dto.result.work;

import com.alibaba.fastjson.annotation.JSONField;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * <p>企业微信基础返回</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 1/5/24 2:15下午
 **/
@EqualsAndHashCode(callSuper = true)
@Data
@NoArgsConstructor
@AllArgsConstructor
public class WeWorkAccessTokenResult extends WeWorkBaseResult {
    /**
     * 获取到的凭证，最长为512字节
     */
    @JSONField(name = "access_token")
    private String accessToken;
    /**
     * 凭证的有效时间（秒）
     */
    @JSONField(name = "expires_in")
    private Integer expiresIn;
}
