package com.seeease.framework.dto.request.yunke;

import lombok.Data;

/**
 * <p>获取公司所有微信好友或微信群请求</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 4/19/24 11:07 上午
 **/
@Data
public class YunKeGetAllFriendsRequest {
    /**
     * 1好友 2群
     */
    private  Integer type;
    /**
     * 更新时间start（yyyy-MM-dd HH:mm:ss）
     */
    private String updateTimeStart;
    /**
     * 更新时间end（yyyy-MM-dd HH:mm:ss）
     */
    private String updateTimeEnd;
    /**
     * 数据入库时间戳，以后请求都使用上一次获取的最后一条记录的入库时间的时间戳（初始可以传1420041600000）timestamp和updateTime二选一必填
     */
    private Long timestamp;
}
