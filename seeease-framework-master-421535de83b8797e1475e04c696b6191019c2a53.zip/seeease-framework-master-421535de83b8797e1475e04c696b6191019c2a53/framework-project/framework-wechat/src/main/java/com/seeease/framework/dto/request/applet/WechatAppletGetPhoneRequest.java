package com.seeease.framework.dto.request.applet;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * <p>获取手机号请求</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 11/22/23 11:20 上午
 **/
@Data
@AllArgsConstructor
@NoArgsConstructor
public class WechatAppletGetPhoneRequest implements Serializable {

    /**
     *手机号获取凭证
     * <a href="https://developers.weixin.qq.com/miniprogram/dev/OpenApiDoc/user-info/phone-number/getPhoneNumber.html"></a>
     */
    private String code;

}
