package com.seeease.framework.dto.result.yunke;

import lombok.Data;

/**
 * <p>查询公司销售每天的微信沟通人数统计</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 4/19/24 11:07上午
 **/
@Data
public class YunKeGetSalesWechatStatisticsResult {

    /**
     * 总页数
     */
    private String totalPages;
    /**
     * 页大小
     */
    private String pageSize;
    /**
     * 索引页
     */
    private String pageIndex;
    /**
     * 总数
     */
    private String total;
    /**
     * 结束时间
     */
    private Data data;

    @lombok.Data
    public static class Data{
        /**
         * 微信id
         */
        private String wechatId;
        /**
         * 统计时间
         */
        private String ymd;
        /**
         * 总数
         */
        private Integer countNum;
        /**
         * 主动沟通人数
         */
        private Integer sendTalkerCount;
        /**
         * 被动沟通人数
         */
        private Integer receiveTalkerCount;
    }
}
