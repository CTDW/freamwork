package com.seeease.framework.e;

/**
 * <p>云客请求报错异常</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 4/19/24 10:51 上午
 **/
public class YunKeRequestFailException extends RuntimeException{
    public YunKeRequestFailException(String message) {
        super(message);
    }
}
