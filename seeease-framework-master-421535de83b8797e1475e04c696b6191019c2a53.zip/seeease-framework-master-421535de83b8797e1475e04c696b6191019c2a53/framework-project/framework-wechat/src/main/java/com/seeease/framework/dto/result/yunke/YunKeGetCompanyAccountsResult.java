package com.seeease.framework.dto.result.yunke;

import lombok.Data;

import java.util.List;

/**
 * <p>分页获取公司所有的微信账号请求返回</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 4/19/24 11:07 上午
 **/
@Data
public class YunKeGetCompanyAccountsResult {
    /**
     * 每页条数
     */
    private Integer pageSize;
    /**
     * 当前页码
     */
    private Integer pageIndex;
    /**
     * 总条数
     */
    private Integer totalCount;
    /**
     * 总页码
     */
    private Integer pageCount;

    /**
     * 微信用户信息列表
     */
    private List<Page> page;

    /**
     * 微信用户信息列表
     */
    @Data
    public static class Page{
        /**
         * 微信用户信息
         */
        private List<YunKeGetAccountsResult> data;
        /**
         * 员工手机号
         */
        private String userPhone;
        /**
         * 员工id
         */
        private String userId;
    }


}
