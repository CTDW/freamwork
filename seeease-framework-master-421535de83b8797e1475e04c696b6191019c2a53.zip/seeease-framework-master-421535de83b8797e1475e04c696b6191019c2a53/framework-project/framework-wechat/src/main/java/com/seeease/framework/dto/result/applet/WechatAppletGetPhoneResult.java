package com.seeease.framework.dto.result.applet;

import com.alibaba.fastjson.annotation.JSONField;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * <p>小程序获取用户电话返回值</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 11/22/23 11:13 上午
 **/
@EqualsAndHashCode(callSuper = true)
@Data
@AllArgsConstructor
@NoArgsConstructor
public class WechatAppletGetPhoneResult extends WechatAppletBaseResult{


    @JSONField(name = "phone_info")
    private PhoneInfo phoneInfo;


    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class PhoneInfo{
        /**
         *用户绑定的手机号（国外手机号会有区号）
         */
        private String phoneNumber;
        /**
         *没有区号的手机号
         */
        private String purePhoneNumber;
        /**
         *区号
         */
        private String countryCode;

    }

}
