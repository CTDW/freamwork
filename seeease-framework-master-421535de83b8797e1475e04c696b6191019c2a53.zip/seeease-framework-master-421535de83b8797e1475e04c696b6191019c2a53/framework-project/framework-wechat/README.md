# 该模块整理了微信相关业务，包含以下功能

- 云客微信聚合api
- 小程序相关接口 {com.seeease.framework.api.WechatAppletApi} 使用时配置文件格式如{com.seeease.framework.properties.WechatProperties}所示
- 企业微信相关接口 {com.seeease.framework.api.WeWorkApi}  使用时配置文件格式如{com.seeease.framework.properties.WechatProperties}所示