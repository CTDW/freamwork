package com.seeease.framework;

import com.seeease.framework.alioss.AliOssAutoConfiguration;
import lombok.AllArgsConstructor;
import lombok.Getter;
import org.springframework.context.annotation.Import;

import java.lang.annotation.*;

/**
 * <p>oss开启注解</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 11/22/23 3:39 下午
 **/
@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Import(OssAutoConfigurationSelector.class)
public @interface EnableOss {


    UseCase[] useCase() default {UseCase.ALI};

    @Getter
    @AllArgsConstructor
    enum UseCase {
        ALI(AliOssAutoConfiguration.class),
        ;
        public Class<?> importClass;
    }
}
