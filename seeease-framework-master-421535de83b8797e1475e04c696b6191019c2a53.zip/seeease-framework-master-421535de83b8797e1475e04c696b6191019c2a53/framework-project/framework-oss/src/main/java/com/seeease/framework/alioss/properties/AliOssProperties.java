package com.seeease.framework.alioss.properties;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

import javax.annotation.PostConstruct;
import java.util.Objects;

/**
 * <p>阿里oss配置</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 11/22/23 3:04下午
 **/
@ConfigurationProperties("oss.ali")
@Data
public class AliOssProperties {
    /**
     * 端点
     */
    private String endpoint;
    /**
     * key
     */
    private String accessKeyId;
    /**
     * secret
     */
    private String accessKeySecret;
    /**
     * bucketName
     */
    private String bucketName;


    @PostConstruct
    public void init() {
        String endpoint = getEndpoint();
        Objects.requireNonNull(endpoint, "[阿里云OSS]:endpoint配置不能为空");
        String accessKeyId = getAccessKeyId();
        Objects.requireNonNull(accessKeyId, "[阿里云OSS]:accessKeyId配置不能为空");
        String accessKeySecret = getAccessKeySecret();
        Objects.requireNonNull(accessKeySecret, "[阿里云OSS]:accessKeySecret配置不能为空");
        String bucketName = getBucketName();
        Objects.requireNonNull(bucketName, "[阿里云OSS]:bucketName配置不能为空");
    }
}
