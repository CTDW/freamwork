package com.seeease.framework;

import org.springframework.context.annotation.ImportSelector;
import org.springframework.core.type.AnnotationMetadata;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;


/**
 * <p>扫描器</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 11/13/23 下午
 **/
public class OssAutoConfigurationSelector implements ImportSelector {


    @Override
    public String[] selectImports(AnnotationMetadata importingClassMetadata) {
        Map<String, Object> attributes = importingClassMetadata.getAnnotationAttributes(EnableOss.class.getName());
        assert attributes != null;
        EnableOss.UseCase[] useCaseArr = (EnableOss.UseCase[]) attributes.get("useCase");
        List<String> imports = new ArrayList<>(useCaseArr.length);
        for (EnableOss.UseCase useCase:useCaseArr){
            imports.add(useCase.getImportClass().getName());
        }
        return imports.toArray(new String[0]);
    }


}
