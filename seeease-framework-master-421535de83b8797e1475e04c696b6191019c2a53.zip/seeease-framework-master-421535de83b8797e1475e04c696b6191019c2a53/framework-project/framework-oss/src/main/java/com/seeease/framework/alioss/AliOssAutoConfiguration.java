package com.seeease.framework.alioss;

import com.seeease.framework.alioss.properties.AliOssProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;

/**
 * <p>阿里云自动配置文件</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 11/22/23 3:05下午
 **/
@EnableConfigurationProperties(AliOssProperties.class)
public class AliOssAutoConfiguration {

    @Bean
    public AliOssApi aliOssApi(){
        return new AliOssApi();
    }
}
