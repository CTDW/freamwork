package com.seeease.framework.alioss.dto;

import lombok.Builder;
import lombok.Data;

import java.io.Serializable;

/**
 * <p>返回一个前端使用的临时上传数据</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 11/22/23 下午
 **/
@Data
@Builder
public class UploadTokenDto implements Serializable {
    /**
     * appId
     */
    private String accessKeyId;
    /**
     * 上传的加密数据
     */
    private String policy;
    /**
     * 上传签名
     */
    private String signature;
    /**
     * 上传的目录
     */
    private String dir;
    /**
     * 上传的url
     */
    private String host;
    /**
     * 凭证过期时间（时间戳）
     */
    private Long expire;
}
