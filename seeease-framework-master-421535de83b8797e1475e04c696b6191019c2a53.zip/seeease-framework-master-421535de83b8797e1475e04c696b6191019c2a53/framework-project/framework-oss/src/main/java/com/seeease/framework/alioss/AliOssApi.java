package com.seeease.framework.alioss;

import com.aliyun.oss.OSS;
import com.aliyun.oss.OSSClientBuilder;
import com.aliyun.oss.common.utils.BinaryUtil;
import com.aliyun.oss.common.utils.StringUtils;
import com.aliyun.oss.model.DeleteObjectsRequest;
import com.aliyun.oss.model.MatchMode;
import com.aliyun.oss.model.OSSObject;
import com.aliyun.oss.model.PolicyConditions;
import com.seeease.framework.alioss.dto.UploadTokenDto;
import com.seeease.framework.alioss.properties.AliOssProperties;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.sql.Date;
import java.util.List;
import java.util.UUID;


/**
 * <p>ossApi</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 11/22/23 3:16 下午
 **/
public class AliOssApi {
    /**
     * oss客户端
     */
    private OSS ossClient;
    /**
     * 属性文件
     */
    @Resource
    private AliOssProperties aliOssProperties;
    /**
     * 上传的url
     */
    private String host;

    @PostConstruct
    public void initClient() {
        ossClient = new OSSClientBuilder().build(
                this.aliOssProperties.getEndpoint(),
                this.aliOssProperties.getAccessKeyId(),
                this.aliOssProperties.getAccessKeySecret()
        );
        host = "https://" + this.aliOssProperties.getBucketName() + "." + this.aliOssProperties.getEndpoint();
    }


    /**
     * 获取媒体资源byte数组
     *
     * @param url
     * @return
     */
    public byte[] getMediaByte(String url) {
        try {
            // 从OSS获取对象
            OSSObject ossObject = ossClient.getObject(this.aliOssProperties.getBucketName(), url);

            try (InputStream inputStream = ossObject.getObjectContent();
                 ByteArrayOutputStream baos = new ByteArrayOutputStream()) {

                // 将输入流转换为字节数组
                byte[] buffer = new byte[1024];
                int len;
                while ((len = inputStream.read(buffer)) != -1) {
                    baos.write(buffer, 0, len);
                }
                return baos.toByteArray();
            }
        } catch (Exception e) {
            System.err.println("访问OSS时发生错误: " + e.getMessage());
            return null;
        }
    }


    /**
     * 上传url资源
     *
     * @param url        url资源
     * @param uploadPath 上传的路径
     * @param fileName   自定义文件名称前缀
     * @return oss资源地址
     */
    public String uploadUrl(String url, String uploadPath, String fileName) throws Exception {
        String type = getFileTypeFromURL(url);
        if (StringUtils.isNullOrEmpty(type)) {
            throw new RuntimeException("url error");
        }

        URL resource = new URL(url);
        HttpURLConnection connection = (HttpURLConnection) resource.openConnection();
        connection.setRequestMethod("GET");
        connection.setConnectTimeout(5000);

        if (connection.getResponseCode() != HttpURLConnection.HTTP_OK) {
            throw new RuntimeException("获取url资源异常");
        }

        try (InputStream inputStream = connection.getInputStream()) {
            return upload(inputStream, type, uploadPath, fileName);
        }
    }


    /**
     * 组合图片变成新的图片
     * @param mainUrl
     * @param otherUrl
     * @param uploadPath
     * @param fileName
     * @return
     */
    public String combinationImage(String mainUrl,
                                   String otherUrl,
                                   String uploadPath,
                                   String fileName) {
        try {
            BufferedImage other = ImageIO.read(new URL(otherUrl));
            BufferedImage mainImage = ImageIO.read(new URL(mainUrl));

            // 创建一个新的图像，宽高根据需要调整
            BufferedImage combinedImage = new BufferedImage(
                    mainImage.getWidth(),
                    mainImage.getHeight(),
                    BufferedImage.TYPE_INT_ARGB);

            // 绘制主图
            Graphics g = combinedImage.getGraphics();
            g.drawImage(mainImage, 0, 0, null);

            // 在主图上绘制边框图
            g.drawImage(other, 0, 0, null);
            g.dispose();

            // 创建一个字节输出流
            ByteArrayOutputStream baos = new ByteArrayOutputStream();

            // 将 BufferedImage 写入字节输出流
            ImageIO.write(combinedImage, "png", baos);
            // 将字节输出流转换为字节数组
            byte[] imageBytes = baos.toByteArray();

            return upload(new ByteArrayInputStream(imageBytes), "png", uploadPath, fileName);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }


    /**
     * oss上传
     *
     * @param inputStream 文件输入流
     * @param type        文件类型
     * @param uploadPath  上传的路径 路径不要以 `/` 开头
     * @param fileName    文件名称
     * @return oss地址
     */
    public String upload(InputStream inputStream, String type, String uploadPath, String fileName) {
        String newName = createFileName(type, fileName);
        uploadPath = uploadPath.endsWith("/") ? uploadPath + newName : uploadPath + "/" + newName;
        ossClient.putObject(aliOssProperties.getBucketName(), uploadPath, inputStream);
        return host + "/" + uploadPath;
    }


    /**
     * 需要临时上传的目录
     *
     * @param dir        上传目录
     * @param expireTime 过期时间 秒为单位
     * @return 临时上传凭证
     */
    public UploadTokenDto getUploadToken(String dir, Long expireTime) {
        long expireEndTime = System.currentTimeMillis() + expireTime * 1000;
        Date expiration = new Date(expireEndTime);
        PolicyConditions policyConds = new PolicyConditions();
        policyConds.addConditionItem(PolicyConditions.COND_CONTENT_LENGTH_RANGE, 0, 1048576000);
        policyConds.addConditionItem(MatchMode.StartWith, PolicyConditions.COND_KEY, dir);
        String postPolicy = ossClient.generatePostPolicy(expiration, policyConds);
        byte[] binaryData = postPolicy.getBytes(StandardCharsets.UTF_8);
        String encodedPolicy = BinaryUtil.toBase64String(binaryData);
        String postSignature = ossClient.calculatePostSignature(postPolicy);

        return UploadTokenDto.builder()
                .accessKeyId(aliOssProperties.getAccessKeyId())
                .policy(encodedPolicy)
                .signature(postSignature)
                .dir(dir)
                .host(host)
                .expire(expireEndTime)
                .build();
    }


    /**
     * 删除文件
     *
     * @param fileNames 相对路径列表
     */
    public void delete(List<String> fileNames) {
        DeleteObjectsRequest req = new DeleteObjectsRequest(aliOssProperties.getBucketName())
                .withKeys(fileNames)
                .withEncodingType("url");
        ossClient.deleteObjects(req);
    }


    /**
     * 根据需要上传的类型获取上传的ContentType
     *
     * @param type 需要上传的类型
     */
    private String getContentType(String type) {
        if (".pdf".equalsIgnoreCase(type)) {
            return "application/pdf";
        }
        if (".bmp".equalsIgnoreCase(type)) {
            return "image/bmp";
        }
        if (".gif".equalsIgnoreCase(type)) {
            return "image/gif";
        }
        if (".jpeg".equalsIgnoreCase(type) ||
                ".jpg".equalsIgnoreCase(type) ||
                ".png".equalsIgnoreCase(type)) {
            return "image/jpg";
        }
        if (".html".equalsIgnoreCase(type)) {
            return "text/html";
        }
        if (".txt".equalsIgnoreCase(type)) {
            return "text/plain";
        }
        if (".vsd".equalsIgnoreCase(type)) {
            return "application/vnd.visio";
        }
        if (".pptx".equalsIgnoreCase(type) ||
                ".ppt".equalsIgnoreCase(type)) {
            return "application/vnd.ms-powerpoint";
        }
        if (".docx".equalsIgnoreCase(type)) {
            return "application/msword";
        }
        if (".xml".equalsIgnoreCase(type)) {
            return "text/xml";
        }
        return "image/jpg";
    }


    /**
     * 创建文件新名称使用uuid方式.
     *
     * @param type     文件类型
     * @param fileName 自定义文件前缀
     * @return 自定义名称 + 随机uuid
     */
    private static String createFileName(String type, String fileName) {
        String randomName = UUID.randomUUID().toString().replace("-", "") + "." + type;
        if (StringUtils.isNullOrEmpty(fileName)) {
            return randomName;
        }
        return fileName + randomName;
    }

    /**
     * 从url最中获取类型
     *
     * @param url
     */
    private static String getFileTypeFromURL(String url) {
        // 检查URL是否有效
        if (url == null || url.isEmpty()) {
            return "";
        }
        // 找到最后一个'/'后的内容，即文件名
        String fileName = url.substring(url.lastIndexOf('/') + 1);
        // 寻找文件名中的'.'来获取扩展名
        int dotIndex = fileName.lastIndexOf('.');
        if (dotIndex == -1 || dotIndex == fileName.length() - 1) {
            return ""; // 没有扩展名
        }
        // 返回扩展名，不包括点
        return fileName.substring(dotIndex + 1);
    }
}
