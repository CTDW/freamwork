# 该模块整理了oss相关业务，包含以下功能

# 使用方式：使用 @EnableOss 开启功能


- 阿里云oss服务 {com.seeease.framework.alioss.AliOssApi} 使用时配置文件格式如{com.seeease.framework.alioss.properties.AliOssProperties}所示