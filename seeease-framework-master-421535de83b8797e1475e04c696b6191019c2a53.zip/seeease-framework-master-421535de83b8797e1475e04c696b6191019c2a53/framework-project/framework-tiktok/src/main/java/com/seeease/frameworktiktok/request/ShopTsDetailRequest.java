package com.seeease.frameworktiktok.request;

import lombok.Data;

/**
 * <p>门店流水详情请求</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 4/10/24 1:51 下午
 **/
@Data
public class ShopTsDetailRequest {
}
