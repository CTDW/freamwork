package com.seeease.frameworktiktok.properties;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * <p></p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 8/26/24 5:32 下午
 **/
@Data
@ConfigurationProperties(prefix = "tiktok.shop")
public class TikTokShopProperties {

    private String appKey;

    private String secret;

}
