package com.seeease.frameworktiktok;


import com.seeease.frameworktiktok.api.TikTokShopApi;
import com.seeease.frameworktiktok.properties.TikTokShopProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * <p>api接口配置</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 11/22/23 上午
 **/
@Configuration
@EnableConfigurationProperties({TikTokShopProperties.class})
public class AutoConfiguration {


    /**
     * 注入抖音店铺api
     * @return
     */
    @Bean
    public TikTokShopApi tikTokShopApi(){
        return new TikTokShopApi();
    }

}
