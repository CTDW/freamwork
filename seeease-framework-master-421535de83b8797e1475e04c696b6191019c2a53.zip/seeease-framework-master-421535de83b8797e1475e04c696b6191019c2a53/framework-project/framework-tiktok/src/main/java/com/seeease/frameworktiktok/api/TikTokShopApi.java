package com.seeease.frameworktiktok.api;

import com.doudian.open.core.AccessToken;
import com.doudian.open.core.AccessTokenBuilder;
import com.doudian.open.core.GlobalConfig;
import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.seeease.frameworktiktok.properties.TikTokShopProperties;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

/**
 * <p>抖店api</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 4/10/24 10:04上午
 **/
public class TikTokShopApi {

    private final  LoadingCache<Long, AccessToken> ACCESS_TOKEN_CACHE = CacheBuilder.newBuilder()
            .refreshAfterWrite(1, TimeUnit.HOURS)
            .build(new CacheLoader<Long, AccessToken>() {
                @Override
                public AccessToken load(Long shopId) {
                    AccessToken accessToken = AccessTokenBuilder.build(shopId);
                    if (accessToken.getExpireIn() < 3600) {
                        //过期时间小于1小时，刷新token
                        accessToken = AccessTokenBuilder.refresh(accessToken);
                    }
                    return accessToken;
                }
            });
    
    
    @Resource
    private TikTokShopProperties properties;
    
    
    @PostConstruct
    public void init(){
        GlobalConfig.initAppKey(properties.getAppKey());
        GlobalConfig.initAppSecret(properties.getSecret());
    }


    /**
     * 抖音平台获取AccessToken
     *
     * @param shopId 抖音店铺id
     * @return
     */
    public  AccessToken getAccessToken(Long shopId) {
        return ACCESS_TOKEN_CACHE.getUnchecked(Objects.requireNonNull(shopId));
    }
    


}
