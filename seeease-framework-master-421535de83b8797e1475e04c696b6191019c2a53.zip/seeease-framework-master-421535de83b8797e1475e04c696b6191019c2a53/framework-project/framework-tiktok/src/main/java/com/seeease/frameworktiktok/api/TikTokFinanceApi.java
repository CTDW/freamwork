package com.seeease.frameworktiktok.api;

import com.doudian.open.api.order_getShopAccountItem.OrderGetShopAccountItemRequest;
import com.doudian.open.api.order_getShopAccountItem.OrderGetShopAccountItemResponse;
import com.doudian.open.api.order_getShopAccountItem.data.OrderGetShopAccountItemData;
import com.doudian.open.api.order_getShopAccountItem.param.OrderGetShopAccountItemParam;
import com.doudian.open.core.AccessToken;
import com.doudian.open.core.AccessTokenBuilder;
import com.doudian.open.core.DefaultDoudianOpClient;
import com.doudian.open.core.DoudianOpConfig;
import com.seeease.springframework.Tuple2;

import java.util.concurrent.ConcurrentHashMap;

/**
 * <p>抖音店铺财务流水接口封装</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 4/10/24 10:04上午
 **/
public class TikTokFinanceApi {

    private static final Long EXPIRES_TIME = 60 * 60 * 1000L;

    private static final ConcurrentHashMap<Long, Tuple2<AccessToken,Long>> TOKEN_MAP = new ConcurrentHashMap<>();


    /**
     * 获取门店账号流水
     * @param config  抖音配置
     * @param shopId  店铺id
     * @param startTime 开始时间
     * @param endTime   结束时间
     * @param size   页大小
     * @param startIndex  开始页初始不传为null
     */
    public static OrderGetShopAccountItemData shopTsDetail(DoudianOpConfig config,
                                                           Long shopId,
                                                           String startTime,
                                                           String endTime,
                                                           Integer size,
                                                           String startIndex) {
        AccessToken token = getToken(config, shopId);
        OrderGetShopAccountItemRequest shopRequest = new OrderGetShopAccountItemRequest();
        shopRequest.setConfig(config);
        OrderGetShopAccountItemParam param = shopRequest.getParam();
        param.setStartTime(startTime);
        param.setEndTime(endTime);
        param.setSize(size);
        param.setAccountType(0);
        param.setBizType(0);
        param.setTimeType(0);
        param.setStartIndex(startIndex);
        OrderGetShopAccountItemResponse response = shopRequest.execute(token);
        return response.getData();
    }


    /**
     * 获取token
     * @param config 抖音配置
     * @param shopId 店铺id
     */
    private static AccessToken getToken(DoudianOpConfig config,Long shopId){
        Tuple2<AccessToken, Long> token = TOKEN_MAP.get(shopId);
        if (token == null || token.getV2() + EXPIRES_TIME < System.currentTimeMillis()){
             synchronized (TikTokFinanceApi.class){
                 if (token == null || token.getV2() + EXPIRES_TIME < System.currentTimeMillis()){
                     //init
                     AccessToken t = AccessTokenBuilder.build(config,
                             DefaultDoudianOpClient.getDefaultClient(),
                             shopId);
                     TOKEN_MAP.put(shopId,Tuple2.of(t,System.currentTimeMillis()));
                     token = TOKEN_MAP.get(shopId);
                 }
             }
        }
        return token.getV1();
    }



}
