package com.seeease.frameworkai;

import com.seeease.framework.FastJsonConverterFactory;
import com.seeease.frameworkai.gpt.LocalChatGptApi;
import okhttp3.OkHttpClient;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import retrofit2.Retrofit;

import java.util.concurrent.TimeUnit;

/**
 *
 *
 * @author 西门 游
 * @version 1.0
 * @since 3/14/24 5:20 下午
 **/
@Configuration
public class AutoConfiguration {

    @Bean
    public LocalChatGptApi localChatGptApi(){

        OkHttpClient okHttpClient = new OkHttpClient.Builder()
                .connectTimeout(1, TimeUnit.MINUTES)
                .readTimeout(2, TimeUnit.MINUTES)
                .writeTimeout(3, TimeUnit.MINUTES)
                .build();

        return new Retrofit.Builder()
                .baseUrl("http://47.245.10.245:3000") //网络请求URL相对固定的地址
                .addConverterFactory(FastJsonConverterFactory.create())
                .client(okHttpClient) //使用OkHttp请求
                .build()
                .create(LocalChatGptApi.class);

    }




}
