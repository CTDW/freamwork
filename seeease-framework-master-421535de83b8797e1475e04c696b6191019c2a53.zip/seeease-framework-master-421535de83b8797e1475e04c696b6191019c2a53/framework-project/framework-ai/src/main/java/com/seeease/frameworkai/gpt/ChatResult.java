package com.seeease.frameworkai.gpt;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * <p>聊天结果</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 3/14/24 5:06 下午
 **/
@Data
public class ChatResult implements Serializable {

    private String id;
    private String object;
    private Long created;
    private String model;
    private List<Choice> choices;
    private String system_fingerprint;
    private Usage usage;
    @Data
    private static class Choice implements Serializable{
        private Integer index;
        private ChatMessage message;
        private String logprobs;
        private String finish_reason;

    }

    @Data
    private static class Usage implements Serializable{
        private Integer prompt_tokens;
        private Integer completion_tokens;
        private Integer total_tokens;
    }
}
