package com.seeease.frameworkai.gpt;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Headers;
import retrofit2.http.POST;

/**
 * <p>本地gpt接口</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 3/14/24 5:02 下午
 **/
public interface LocalChatGptApi {

    @Headers({
            "Authorization: Bearer sk-yDAevMsHTgx0QQGBC67fC6C762664d15B7Ba9d3c2a5a0b97",
            "Content-Type: application/json"
    })
    @POST("v1/chat/completions")
    Call<ChatResult> chat(@Body ChatRequest body);
}
