package com.seeease.frameworkai.gpt;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * <p>聊天内容</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 3/14/24 5:18 下午
 **/
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ChatMessage implements Serializable {
    private String role;
    private String content;
}