package com.seeease.frameworkai.gpt;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

/**
 * <p>聊天请求</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 3/14/24 5:17 下午
 **/
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ChatRequest implements Serializable {

    private Boolean stream;
    private String model;
    private List<ChatMessage> messages;

}
