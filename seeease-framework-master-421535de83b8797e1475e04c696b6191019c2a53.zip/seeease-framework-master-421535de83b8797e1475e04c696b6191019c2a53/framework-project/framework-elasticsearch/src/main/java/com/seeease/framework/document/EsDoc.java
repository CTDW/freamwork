package com.seeease.framework.document;

import com.alibaba.fastjson.annotation.JSONField;

import java.io.Serializable;

/**
* @Description:  es存储单位规则
* @Auther  Gilbert
* @Date  2023/11/18
*/
public interface EsDoc extends Serializable {

    /**
     * 获取文档
     * @return
     */
    @JSONField(serialize = false)
    String getDocId();

    /**
     * 获取索引
     * @return
     */
    @JSONField(serialize = false)
    String getIndex();

}
