package com.seeease.framework.constant;

/**
 * @Description:
 * @Auther Gilbert
 * @Date 2023/11/20
 */
public enum EsEnum {

    INSERT,
    UPDATE,
    DELETE,
}
