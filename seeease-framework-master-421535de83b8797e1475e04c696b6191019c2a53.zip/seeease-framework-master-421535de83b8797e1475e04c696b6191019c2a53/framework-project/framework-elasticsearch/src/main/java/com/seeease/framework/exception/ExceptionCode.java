package com.seeease.framework.exception;

import com.seeease.springframework.exception.e.BusinessExceptionCode;
import lombok.AllArgsConstructor;
import lombok.Getter;

/**
* @Description: es错误返回
* @Auther  Gilbert
* @Date  2023/11/18
*/
@Getter
@AllArgsConstructor
public enum ExceptionCode implements BusinessExceptionCode {

    ES_INDEX_ERROR(-1, "es操作失败"),
    ES_SEARCH_ERROR(-1, "es查询操作失败"),
    ES_UPDATE_ERROR(-1, "es修改操作失败"),
    ES_SAVE_ERROR(-1, "es保存操作失败"),
    ES_DELETE_ERROR(-1, "es删除操作失败"),
    ES_INDEX_SURE_ERROR(-1, "es索引已存在"),
    ES_INDEX_PACH_ERROR(-1, "es批量操作数据不能为空"),
    ES_PACH_ERROR(-1, "es批量操作失败"),
    ;
    private int errCode;

    private String errMsg;
}
