package com.seeease.framework.constant;

/**
 * @Description:
 * @Auther Gilbert
 * @Date 2023/11/20
 */
public class EsConstant {
    /**
     * 默认类型
     */
    public static final String DEFAULT_TYPE = "_doc";

    /**
     * set方法前缀
     */
    public static final String SET_METHOD_PREFIX = "set";

    /**
     * 返回状态-CREATED
     */
    public static final String RESPONSE_STATUS_CREATED = "CREATED";

    /**
     * 返回状态-OK
     */
    public static final String RESPONSE_STATUS_OK = "OK";

    /**
     * 返回状态-NOT_FOUND
     */
    public static final String RESPONSE_STATUS_NOT_FOUND = "NOT_FOUND";

    /**
     * 需要过滤的文档数据
     */
    public static final String[] IGNORE_KEY = {"@version","type"};


    /**
     * 查询时需要
     */
    public static final String ID = "_id";
    /**
     * 精确查询需要用到
     */
    public static final String KEY_WORD = ".keyword";
}
