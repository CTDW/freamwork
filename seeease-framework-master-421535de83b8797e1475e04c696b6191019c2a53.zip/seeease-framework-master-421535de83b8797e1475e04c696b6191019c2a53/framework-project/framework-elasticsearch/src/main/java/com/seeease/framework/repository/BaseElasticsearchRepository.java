package com.seeease.framework.repository;

import com.alibaba.fastjson.JSONObject;
import com.seeease.framework.EsPage.EsPage;
import com.seeease.framework.constant.EsConstant;
import com.seeease.framework.constant.EsEnum;
import com.seeease.framework.document.EsDoc;
import com.seeease.framework.exception.ExceptionCode;
import com.seeease.springframework.exception.e.BusinessException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.elasticsearch.action.admin.indices.delete.DeleteIndexRequest;
import org.elasticsearch.action.bulk.BulkRequest;
import org.elasticsearch.action.bulk.BulkResponse;
import org.elasticsearch.action.delete.DeleteRequest;
import org.elasticsearch.action.delete.DeleteResponse;
import org.elasticsearch.action.get.GetRequest;
import org.elasticsearch.action.get.GetResponse;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.action.index.IndexResponse;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.action.support.master.AcknowledgedResponse;
import org.elasticsearch.action.update.UpdateRequest;
import org.elasticsearch.action.update.UpdateResponse;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.client.indices.CreateIndexRequest;
import org.elasticsearch.client.indices.CreateIndexResponse;
import org.elasticsearch.client.indices.GetIndexRequest;
import org.elasticsearch.common.text.Text;
import org.elasticsearch.common.unit.TimeValue;
import org.elasticsearch.common.xcontent.XContentType;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.elasticsearch.search.fetch.subphase.FetchSourceContext;
import org.elasticsearch.search.fetch.subphase.highlight.HighlightField;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.beans.PropertyDescriptor;
import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.util.*;

/**
 * @Description: api方法
 * @Auther Gilbert
 * @Date 2023/11/18
 */
@Slf4j
@Component
public class BaseElasticsearchRepository{

    @Resource
    private RestHighLevelClient restHighLevelClient;


    /**
     * 超时时间 5s
     */
    public static final TimeValue TIME_VALUE_SECONDS = TimeValue.timeValueSeconds(5);

    /**
     * es索引断言
     * @param index 索引名称
     */
    private void assertIndex(String index){
        if (StringUtils.isBlank(index)){
            log.error("[es索引断言]:es索引不能为null或者空");
            throw new BusinessException(ExceptionCode.ES_INDEX_ERROR);
        }
    }
    /**
     * es Id断言
     * @param id id
     */
    private void assertId(String id){
        if (StringUtils.isBlank(id)){
            log.error("[es-Id断言]:esId不能为null或者空");
            throw new BusinessException(ExceptionCode.ES_INDEX_ERROR);
        }
    }
    public boolean isIndexExist(String index) {
        try {
            GetIndexRequest request = new GetIndexRequest(index);
            return restHighLevelClient.indices().exists(request, RequestOptions.DEFAULT);
        } catch (IOException ioException) {
            log.error("[es判断索引存在]:es查询索引是否存在失败:{}", ioException.getMessage());
            throw new BusinessException(ExceptionCode.ES_SEARCH_ERROR);
        }
    }
    public boolean isDocExist(String index, String id) {
        GetRequest request = new GetRequest(index, id);
        request.fetchSourceContext(new FetchSourceContext(false));
        request.storedFields("_none_");
        try {
            return restHighLevelClient.exists(request, RequestOptions.DEFAULT);
        } catch (IOException e) {
            log.error("[es判断文档存在]:es查询文档是否存在失败:{}", e.getMessage());
            throw new BusinessException(ExceptionCode.ES_SEARCH_ERROR);
        }

    }
    /**
     * 创建索引
     * @param index
     * @return
     */
    public  boolean createIndex(String index) {
        assertIndex(index);
        if(isIndexExist(index)){
            throw new BusinessException(ExceptionCode.ES_INDEX_SURE_ERROR);
        }
        try {
            CreateIndexRequest indexRequest = new CreateIndexRequest(index);
            CreateIndexResponse response = restHighLevelClient.indices().create(indexRequest, RequestOptions.DEFAULT);
            log.info("执行建立成功：{}" + response.isAcknowledged());
            return response.isAcknowledged();
        } catch (IOException e) {
            log.error("[es判断索引存在]:es查询索引是否存在失败:{}", e.getMessage());
            throw new BusinessException(ExceptionCode.ES_SEARCH_ERROR);
        }
    }

    /**
     * 删除索引
     *
     * @param index
     * @return
     */
    public boolean deleteIndex(String index) throws IOException {
        assertIndex(index);
        DeleteIndexRequest request = new DeleteIndexRequest("mdx_index");
        AcknowledgedResponse response = restHighLevelClient.indices().delete(request, RequestOptions.DEFAULT);
        if (response.isAcknowledged()) {
            log.info("delete index " + index + "  successfully!");
        } else {
            log.info("Fail to delete index " + index);
        }
        return response.isAcknowledged();
    }
    /**
     * 指定文档是否存在
     *
     * @param index 索引
     * @param type  类型
     * @param id    文档id
     */
    public boolean isExists(String index, String type, String id) {
        GetRequest request = new GetRequest(index, type, id);
        try {
            GetResponse response = restHighLevelClient.get(request, RequestOptions.DEFAULT);
            return response.isExists();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
    /**
     * 根据id查询文档
     * @param index 索引
     * @param id    文档id
     * @param clazz 转换目标Class对象
     * @return 对象
     */
    public <T> T selectDocumentById(String index, String id, Class<T> clazz) {
        return selectDocumentById(index, EsConstant.DEFAULT_TYPE, id, clazz);
    }
    /**
     * 根据id查询文档
     *
     * @param index 索引
     * @param type  类型
     * @param id    文档id
     * @param clazz 转换目标Class对象
     * @return 对象
     */
    public <T> T selectDocumentById(String index, String type, String id, Class<T> clazz) {
        try {
            type = type == null || type.equals("") ? EsConstant.DEFAULT_TYPE : type;
            GetRequest request = new GetRequest(index, type, id);
            GetResponse response = restHighLevelClient.get(request, RequestOptions.DEFAULT);
            if (response.isExists()) {
                Map<String, Object> sourceAsMap = response.getSourceAsMap();
                return dealObject(sourceAsMap, clazz);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
    /**
     *（筛选条件）获取数据集合
     * 如果使用排序则 sourceBuilder.sort("name",SortOrder.DESC)
     * 如果使用高亮则 :
     * HighlightBuilder highlightBuilder = new HighlightBuilder();
     * highlightBuilder.field("");
     * sourceBuilder.highlighter(highlightBuilder);
     * @param index         索引
     * @param sourceBuilder 请求条件
     * @param clazz         转换目标Class对象
     */
    public <T> List<T> selectDocumentList(String index, SearchSourceBuilder sourceBuilder, Class<T> clazz) {
        try {


            SearchRequest request = new SearchRequest(index);
            if (sourceBuilder != null) {
                // 返回实际命中数
                sourceBuilder.trackTotalHits(true);
                sourceBuilder.size(10000);
                request.source(sourceBuilder);
            }
            log.info("[es搜索]:es查询索引:{},查询语句:{}",index,sourceBuilder.toString());
            SearchResponse response = restHighLevelClient.search(request, RequestOptions.DEFAULT);

            if (response.getHits() != null) {
                List<T> list = new ArrayList<>();
                SearchHit[] hits = response.getHits().getHits();
                //获取总数量
                long totalHits = Arrays.stream(response.getHits().getHits()).count();
                for (SearchHit documentFields : hits) {
                    Map<String, Object> sourceAsMap = documentFields.getSourceAsMap();
                    // 高亮结果集特殊处理 -- 高亮信息会显示在highlight标签下  需要将实体类中的字段进行替换
                    Map<String, Object> map = this.highlightBuilderHandle(sourceAsMap, documentFields);
                    list.add(dealObject(map, clazz));
                }
                return list;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 新增/修改文档信息
     * @param doc  数据
     */
    public <T extends EsDoc> String insertDocument(T doc) {
        try {
            String index = doc.getIndex();
            String id = doc.getDocId();
            assertIndex(index);
            assertId(id);
            Map<String, Object> map = JSONObject.parseObject(JSONObject.toJSONBytes(doc),Map.class);
            IndexRequest request = new IndexRequest(index);
            request.timeout(TIME_VALUE_SECONDS);
            request.id(id); // 文档id
            //传入id为空，默认给uuid
            if(StringUtils.isEmpty(id)){
                request.id(UUID.randomUUID().toString().replaceAll("-", "").toUpperCase());
            }
            request.source(map, XContentType.JSON);
            IndexResponse response = restHighLevelClient.index(request, RequestOptions.DEFAULT);
            log.info("insertDocument response status:{},id:{}", response.status().getStatus(), response.getId());
            String status = response.status().toString();
            if (EsConstant.RESPONSE_STATUS_CREATED.equals(status) || EsConstant.RESPONSE_STATUS_OK.equals(status)) {
                return response.getId();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }

    /**
     * 删除文档信息
     *
     * @param index 索引
     * @param id    文档id
     */
    public boolean deleteDocument(String index, String id) {
        try {
            assertIndex(index);
            assertId(id);
            DeleteRequest request = new DeleteRequest(index, id);
            DeleteResponse response = restHighLevelClient.delete(request, RequestOptions.DEFAULT);
            log.info("deleteDocument response status:{},id:{}", response.status().getStatus(), response.getId());
            String status = response.status().toString();
            if (EsConstant.RESPONSE_STATUS_OK.equals(status)) {
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        throw new BusinessException(ExceptionCode.ES_DELETE_ERROR);
    }


    /**
     * 更新文档信息
     *
     */
    public <T extends EsDoc> boolean updateDocument(T doc) {
        try {
            String index = doc.getIndex();
            String id = doc.getDocId();
            assertIndex(index);
            assertId(id);
            UpdateRequest request = new UpdateRequest(index, id);
            Map<String, Object> map = JSONObject.parseObject(JSONObject.toJSONBytes(doc),Map.class);
            request.doc(map);
            UpdateResponse response = restHighLevelClient.update(request, RequestOptions.DEFAULT);
            log.info("updateDocument response status:{},id:{}", response.status().getStatus(), response.getId());
            String status = response.status().toString();
            if (EsConstant.RESPONSE_STATUS_OK.equals(status)) {
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        throw new BusinessException(ExceptionCode.ES_UPDATE_ERROR);
    }


    /**
     * 批量操作(新增)
     * @param opType   操作类型 PATCH_OP_TYPE_*
     * @param dataList 数据集 新增修改需要传递
     * @param timeout  超时时间 单位为秒
     */
    public <T extends EsDoc>boolean patch(EsEnum opType, List<T> dataList, long timeout) {
        try {
            BulkRequest bulkRequest = new BulkRequest();
            bulkRequest.timeout(TimeValue.timeValueSeconds(timeout));
            if(dataList == null || dataList.size() == 0 ){
                throw new BusinessException(ExceptionCode.ES_INDEX_PACH_ERROR);
            }
                if (EsEnum.INSERT.equals(opType)) {
                    insertBatch(bulkRequest,dataList);
                }else if(EsEnum.UPDATE.equals(opType)){
                    updateBatch(bulkRequest,dataList);
                }else if (EsEnum.DELETE.equals(opType)){
                    deleteBatch(bulkRequest,dataList);
                }
                BulkResponse response = restHighLevelClient.bulk(bulkRequest, RequestOptions.DEFAULT);
                if (!response.hasFailures()) {
                    return true;
                }
        } catch (Exception e) {
            e.printStackTrace();
        }
        throw new BusinessException(ExceptionCode.ES_PACH_ERROR);
    }
    public <T extends EsDoc> void insertBatch(BulkRequest bulkRequest,List<T> dataList){
        for (EsDoc obj : dataList) {
            String id = obj.getDocId();
            String index = obj.getIndex();
            IndexRequest request = new IndexRequest(index);
            request.id(id); // 文档id
            //传入id为空，默认给uuid
            if(StringUtils.isEmpty(id)){
                request.id(UUID.randomUUID().toString().replaceAll("-", "").toUpperCase());
            }
            Map<String, Object> map = JSONObject.parseObject(JSONObject.toJSONBytes(obj),Map.class);
            request.source(map, XContentType.JSON);
            bulkRequest.add(request);
        }
    }
    public <T extends EsDoc> void updateBatch(BulkRequest bulkRequest,List<T> dataList){
        for (EsDoc obj : dataList) {
            String id = obj.getDocId();
            String index = obj.getIndex();
            UpdateRequest request = new UpdateRequest(index,id);
            Map<String, Object> map = JSONObject.parseObject(JSONObject.toJSONBytes(obj),Map.class);
            request.doc(map);
            bulkRequest.add(request);
        }
    }
    public <T extends EsDoc> void deleteBatch(BulkRequest bulkRequest,List<T> dataList){
        for (EsDoc obj : dataList) {
            String id = obj.getDocId();
            String index = obj.getIndex();
            DeleteRequest request = new DeleteRequest(index,id);
            bulkRequest.add(request);
        }
    }

    /**
     *（筛选条件）获取数据集合分页
     * 如果使用排序则 sourceBuilder.sort("name",SortOrder.DESC)
     * 如果使用高亮则 :
     * HighlightBuilder highlightBuilder = new HighlightBuilder();
     * highlightBuilder.field("");
     * sourceBuilder.highlighter(highlightBuilder);
     * @param index         索引
     * @param sourceBuilder 请求条件
     * @param clazz         转换目标Class对象
     */
    public <T> EsPage selectDocumentPage(String index, SearchSourceBuilder sourceBuilder, int startPage, int pageSize ,Class<T> clazz) {
        try {
            SearchRequest request = new SearchRequest(index);
            if (sourceBuilder != null) {
                // 返回实际命中数
                sourceBuilder.from(startPage);
                sourceBuilder.size(pageSize);
                sourceBuilder.explain(true);
                sourceBuilder.trackTotalHits(true);
                request.source(sourceBuilder);
            }

            log.info("[es搜索]:es查询索引:{},查询语句:{}",index,sourceBuilder.toString());
            SearchResponse response = restHighLevelClient.search(request, RequestOptions.DEFAULT);
            if (response.getHits() != null) {
                long totalHits = Arrays.stream(response.getHits().getHits()).count();
                long length = response.getHits().getHits().length;
                long totalCount = response.getHits().getTotalHits().value;
                List<T> list = new ArrayList<>();
                SearchHit[] hits = response.getHits().getHits();
                for (SearchHit documentFields : hits) {
                    Map<String, Object> sourceAsMap = documentFields.getSourceAsMap();
                    // 高亮结果集特殊处理 -- 高亮信息会显示在highlight标签下  需要将实体类中的字段进行替换
                    Map<String, Object> map = this.highlightBuilderHandle(sourceAsMap, documentFields);
                    list.add(dealObject(map, clazz));
                }
                return new EsPage(startPage, pageSize, (int) totalHits,(int) totalCount, list);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
    /**
    * @Description: 不分页查询搜索数据
    * @Auther  Gilbert
    * @Date  2023/12/7
    */
    public <T> EsPage selectDocumentPage(String index,
                                         SearchSourceBuilder sourceBuilder,
                                         int startPage, int pageSize ,
                                         Class<T> clazz,
                                         List<T> list) {
        if(list == null){
            list = new ArrayList<>();
        }
        int totalHits = 0;
        int totalCount = 0;
        try {
            SearchRequest request = new SearchRequest(index);
            if (sourceBuilder != null) {
                // 返回实际命中数
                sourceBuilder.from(startPage);
                sourceBuilder.size(pageSize);
                sourceBuilder.explain(true);
                sourceBuilder.trackTotalHits(true);
                request.source(sourceBuilder);
            }

            log.info("[es搜索]:es查询索引:{},查询语句:{}",index,sourceBuilder.toString());
            SearchResponse response = restHighLevelClient.search(request, RequestOptions.DEFAULT);
            if (response.getHits() != null) {
                totalHits = (int)Arrays.stream(response.getHits().getHits()).count();
                long length = response.getHits().getHits().length;
                totalCount = (int)response.getHits().getTotalHits().value;

                SearchHit[] hits = response.getHits().getHits();

                if((totalHits < 1000  && totalHits >=0) || totalCount <=1000 ){
                    for (SearchHit documentFields : hits) {
                        Map<String, Object> sourceAsMap = documentFields.getSourceAsMap();
                        // 高亮结果集特殊处理 -- 高亮信息会显示在highlight标签下  需要将实体类中的字段进行替换
                        Map<String, Object> map = this.highlightBuilderHandle(sourceAsMap, documentFields);
                        list.add(dealObject(map, clazz));
                    }
                    return new EsPage(startPage, pageSize, totalHits,totalCount, list);

                }else{
                    //总数大于一千递归返回
                    for (SearchHit documentFields : hits) {
                        Map<String, Object> sourceAsMap = documentFields.getSourceAsMap();
                        // 高亮结果集特殊处理 -- 高亮信息会显示在highlight标签下  需要将实体类中的字段进行替换
                        Map<String, Object> map = this.highlightBuilderHandle(sourceAsMap, documentFields);
                        list.add(dealObject(map, clazz));
                    }
                    selectDocumentPage(index,sourceBuilder,startPage+=1000,pageSize,clazz,list);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return new EsPage(startPage, pageSize, (int) totalHits,(int) totalCount, list);
    }

    /**
     * 高亮结果集 特殊处理
     * @param sourceAsMap
     * @param documentFields
     */
    private Map<String, Object> highlightBuilderHandle(Map<String, Object> sourceAsMap,SearchHit documentFields){
        // 将高亮的字段替换到sourceAsMap中
        Map<String, HighlightField> fieldMap = documentFields.getHighlightFields();
        Set<Map.Entry<String, Object>> entries = sourceAsMap.entrySet();
        entries.forEach(source -> {
            if (fieldMap.containsKey(source.getKey())){
                Text[] fragments = fieldMap.get(source.getKey()).getFragments();
                if (fragments != null){
                    for (Text str : fragments) {
                        source.setValue(str.string());
                    }
                }
            }
        });
        return sourceAsMap;
    }


    private static <T> T dealObject(Map<String, Object> sourceAsMap, Class<T> clazz) {
        try {
            ignoreSource(sourceAsMap);
            Iterator<String> keyIterator = sourceAsMap.keySet().iterator();
            T t = clazz.newInstance();
            Field[] declaredFields = clazz.getDeclaredFields();
            while (keyIterator.hasNext()) {
                String key = keyIterator.next();
                String replaceKey = key.replaceFirst(key.substring(0, 1), key.substring(0, 1).toUpperCase());
                Method method = null;
                try {
                    Object sourceObject = sourceAsMap.get(key);
                    //里面是map
                    if (sourceObject instanceof Map){
                        Map<String, Object> stringObjectMap = (Map<String, Object>) sourceAsMap.get(key);

                            for (int i = 0; i < declaredFields.length; i++) {
                                String fieldName = declaredFields[i].getName();
                                if(fieldName.equals(key)){
                                    PropertyDescriptor descriptor = new PropertyDescriptor(fieldName, clazz);
                                    Method method1 = descriptor.getWriteMethod();
                                    Object c1 = Class.forName(declaredFields[i].getType().toString().replace("class ", "")).newInstance();
                                    Object o = dealObject(stringObjectMap, c1.getClass());
                                    method1.invoke(t,o);
                                }
                            }
                    }else if (sourceObject instanceof ArrayList){
                        for (int i = 0; i < declaredFields.length; i++) {
                            String fieldName = declaredFields[i].getName();
                            if(fieldName.equals(key)){
                                PropertyDescriptor descriptor = new PropertyDescriptor(fieldName, clazz);
                                Method method1 = descriptor.getWriteMethod();
                                method1.invoke(t,sourceAsMap.get(key));
                            }
                        }
                    }else{

                        Class<?> aClassBigDecimal = Class.forName("java.math.BigDecimal");
                        Class<?> type = t.getClass().getDeclaredField(key).getType();
                        //有病不知道id死活返回Integer类型，有空在研究吧。研究一天没弄明白
                        if("id".equals(key) && sourceAsMap.get(key).getClass() != t.getClass().getDeclaredField(key).getType()){
                            method = clazz.getMethod(EsConstant.SET_METHOD_PREFIX + replaceKey, Long.class);
                            method.invoke(t, Long.parseLong(sourceAsMap.get(key).toString()));
                        }else if(type  == aClassBigDecimal){
                            method = clazz.getMethod(EsConstant.SET_METHOD_PREFIX + replaceKey, BigDecimal.class);
                            method.invoke(t, new BigDecimal(sourceAsMap.get(key).toString()));
                        }else{
                            method = clazz.getMethod(EsConstant.SET_METHOD_PREFIX + replaceKey, sourceAsMap.get(key).getClass());
                            method.invoke(t, sourceAsMap.get(key));
                        }
                    }
                }catch (Exception e) {
                    if(e instanceof NoSuchFieldException){
                        try{
                            method = clazz.getMethod(EsConstant.SET_METHOD_PREFIX + replaceKey, sourceAsMap.get(key).getClass());
                            method.invoke(t, sourceAsMap.get(key));
                        }catch (Exception e1){
                            continue;
                        }

                    }
                    continue;
                }
            }
            return t;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }



    /**
     * 剔除指定文档数据,减少不必要的循环
     *
     * @param map 文档数据
     */
    private static void ignoreSource(Map<String, Object> map) {
        for (String key : EsConstant.IGNORE_KEY) {
            map.remove(key);
        }
    }
}
