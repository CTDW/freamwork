package com.seeease.seeeaseframework;

import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;

/**
 * @author Tiro
 * @date 2022/10/20
 */
@Slf4j
public final class TraceLocal {

    private TraceLocal() {
    }

    public static String TRACE_ID = "traceId";
    public static String TRACE_ID_DEF = "";

    private static ThreadLocal<String> LOCAL = new ThreadLocal<>();

    public static void set(String value) {
        try {
            LOCAL.set(value);
            MDC.put(TRACE_ID, value);
        } catch (Exception e) {
            log.error("TraceLocal.set() error:{}", e.getMessage(), e);
        }

    }

    public static String get() {
        return LOCAL.get();
    }

    public static void remove() {
        try {
            LOCAL.remove();
            MDC.remove(TRACE_ID);
        } catch (Exception e) {
            log.error("TraceLocal.remove() error:{}", e.getMessage(), e);
        }
    }

}
