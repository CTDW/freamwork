package com.seeease.seeeaseframework;

import javax.servlet.*;
import java.io.IOException;

/**
 * @author Tiro
 * @date 2022/10/20
 */
public class TraceFilter implements Filter {
    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        try {
            TraceLocal.set(TraceIdGenerator.generator());
            filterChain.doFilter(servletRequest, servletResponse);
        } finally {
            TraceLocal.remove();
        }

    }
}
