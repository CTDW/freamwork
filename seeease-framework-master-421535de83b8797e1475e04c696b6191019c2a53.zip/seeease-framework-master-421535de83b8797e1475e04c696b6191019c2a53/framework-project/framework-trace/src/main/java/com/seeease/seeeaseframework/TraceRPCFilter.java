package com.seeease.seeeaseframework;

import lombok.extern.slf4j.Slf4j;
import org.apache.dubbo.common.constants.CommonConstants;
import org.apache.dubbo.common.extension.Activate;
import org.apache.dubbo.rpc.*;

/**
 * @author Tiro
 * @date 2022/10/20
 */
@Slf4j
@Activate(group = {CommonConstants.CONSUMER, CommonConstants.PROVIDER})
public class TraceRPCFilter implements org.apache.dubbo.rpc.Filter {
    @Override
    public Result invoke(Invoker<?> invoker, Invocation invocation) throws RpcException {
        boolean isProviderSide = false;
        try {
            try {
                if (RpcContext.getContext().isConsumerSide()) {
                    RpcContext.getContext().setAttachment(TraceLocal.TRACE_ID, TraceLocal.get());
                } else {
                    TraceLocal.set(RpcContext.getContext().getAttachment(TraceLocal.TRACE_ID));
                    isProviderSide = true;
                }
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            return invoker.invoke(invocation);
        } finally {
            if (isProviderSide) {
                TraceLocal.remove();
            }
        }

    }
}
