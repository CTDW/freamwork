package com.seeease.seeeaseframework;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Arrays;
import java.util.UUID;
import java.util.stream.Collectors;

/**
 * 服务器 IP + ID 产生的时间 + UUID后7位 + 当前进程号
 *
 * @author Tiro
 * @date 2022/11/4
 */
public class TraceIdGenerator {

    private static String IP;

    static {
        try {
            IP = Arrays.stream(InetAddress.getLocalHost().getHostAddress().split("\\."))
                    .map(Integer::valueOf)
                    .map(Integer::toHexString)
                    .collect(Collectors.joining());
        } catch (UnknownHostException e) {
            IP = "000000";
        }
    }

    public static String generator() {
        String uuid = UUID.randomUUID().toString();
        uuid = uuid.substring(uuid.length() - 7);

        return new StringBuffer()
                .append(IP)
                .append(System.currentTimeMillis())
                .append(uuid)
                .append(Thread.currentThread().getId())
                .toString();
    }
}
