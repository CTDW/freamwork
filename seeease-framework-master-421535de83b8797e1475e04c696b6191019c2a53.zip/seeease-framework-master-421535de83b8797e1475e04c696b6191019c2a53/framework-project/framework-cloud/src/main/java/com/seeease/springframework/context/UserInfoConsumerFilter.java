package com.seeease.springframework.context;

import com.alibaba.fastjson.JSON;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.dubbo.common.constants.CommonConstants;
import org.apache.dubbo.common.extension.Activate;
import org.apache.dubbo.rpc.*;

import java.util.Objects;

/**
 * @author Tiro
 * @date 2023/2/15
 */

@Slf4j
@Activate(group = {CommonConstants.CONSUMER})
public class UserInfoConsumerFilter implements Filter {

    @Override
    public Result invoke(Invoker<?> invoker, Invocation invocation) throws RpcException {
        LoginUser user = UserContext.getUser();
        String userInfo;
        if (Objects.nonNull(user)) {
            userInfo = JSON.toJSONString(user);
        } else {
            userInfo = RpcContext.getContext().getAttachment(Constant.DUBBO_USER_KEY);
        }
        invocation.getAttachments().put(Constant.DUBBO_USER_KEY, StringUtils.isBlank(userInfo) ? JSON.toJSONString(new LoginUser()) : userInfo);
        return invoker.invoke(invocation);
    }
}