package com.seeease.springframework.context;

/**
 * @author Tiro
 * @date 2023/2/15
 */
public interface Constant {
    String DUBBO_USER_KEY = "rpcUser";
}
