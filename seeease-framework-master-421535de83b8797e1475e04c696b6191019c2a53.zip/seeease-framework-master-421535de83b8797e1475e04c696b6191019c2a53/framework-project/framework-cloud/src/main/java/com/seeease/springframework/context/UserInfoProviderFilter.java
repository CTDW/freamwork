package com.seeease.springframework.context;

import com.alibaba.fastjson.JSON;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.dubbo.common.constants.CommonConstants;
import org.apache.dubbo.common.extension.Activate;
import org.apache.dubbo.rpc.*;

/**
 * @author Tiro
 * @date 2023/2/15
 */

@Slf4j
@Activate(group = {CommonConstants.PROVIDER})
public class UserInfoProviderFilter implements Filter {

    @Override
    public Result invoke(Invoker<?> invoker, Invocation invocation) throws RpcException {
        String userInfo = RpcContext.getContext().getAttachment(Constant.DUBBO_USER_KEY);
        if (StringUtils.isBlank(userInfo)) {
            return invoker.invoke(invocation);
        }
        try {
            LoginUser user = JSON.parseObject(userInfo, LoginUser.class);
            UserContext.setUser(user);
            return invoker.invoke(invocation);
        } finally {
            UserContext.clear();
        }
    }
}
