package com.seeease.springframework.context;

/**
 * @author Tiro
 * @date 2023/2/14
 */
public final class UserContext {

    private static final ThreadLocal<LoginUser> USER_CONTEXT_HOLDER = new ThreadLocal<>();

    private UserContext() {
    }

    public static LoginUser getUser() {
        return USER_CONTEXT_HOLDER.get();
    }

    public static void setUser(LoginUser userVo) {
        USER_CONTEXT_HOLDER.set(userVo);
    }

    public static void clear() {
        USER_CONTEXT_HOLDER.remove();
    }

}
