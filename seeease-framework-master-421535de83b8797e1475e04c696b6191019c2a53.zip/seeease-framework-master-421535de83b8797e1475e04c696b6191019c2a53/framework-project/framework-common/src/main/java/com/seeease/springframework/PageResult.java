package com.seeease.springframework;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Collections;
import java.util.List;

/**
 * 分页结果
 *
 * @author trio
 * @date 2023/1/16
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PageResult<T> implements Serializable {
    /**
     * 结果
     */
    private List<T> result;
    /**
     * 总数量
     */
    private long totalCount;
    /**
     * 总页数
     */
    private long totalPage;
    /**
     * 拓展内容
     */
    private Object ext;


    public static <T> PageResult<T> buildEmpty(){
        PageResult<T> pageResult = new PageResult<T>();
        pageResult.setTotalPage(0);
        pageResult.setTotalCount(0);
        pageResult.setResult(Collections.emptyList());
        return pageResult;
    }

    public static <T> PageResult<T> buildEmpty(Object ext){
        PageResult<T> pageResult = new PageResult<T>();
        pageResult.setTotalPage(0);
        pageResult.setTotalCount(0);
        pageResult.setResult(Collections.emptyList());
        pageResult.setExt(ext);
        return pageResult;
    }
}
