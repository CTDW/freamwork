package com.seeease.springframework;

import lombok.Data;

import java.io.Serializable;

/**
 * @author Tiro
 * @date 2023/1/13
 */
@Data
public class Response implements Serializable {
    /**
     * response code
     */
    private int code;
    /**
     * response msg
     */
    private String msg;
}
