package com.seeease.springframework;

import lombok.Data;

/**
 * @author Tiro
 * @date 2023/1/13
 */
@Data
public class SingleResponse<T> extends Response {
    private T data;
    private Object ext;

    public boolean success() {
        return getCode() == 200;
    }
    public boolean fail() {
        return getCode() != 200;
    }

    public static SingleResponse buildSuccess() {
        SingleResponse response = new SingleResponse();
        response.setCode(200);
        response.setMsg("成功");
        return response;
    }

    public static SingleResponse buildFailure(int errCode, String errMessage) {
        SingleResponse response = new SingleResponse();
        response.setCode(errCode);
        response.setMsg(errMessage);
        return response;
    }

    public static <T> SingleResponse<T> of(T data) {
        SingleResponse<T> response = new SingleResponse();
        response.setCode(200);
        response.setMsg("成功");
        response.setData(data);
        return response;
    }
}
