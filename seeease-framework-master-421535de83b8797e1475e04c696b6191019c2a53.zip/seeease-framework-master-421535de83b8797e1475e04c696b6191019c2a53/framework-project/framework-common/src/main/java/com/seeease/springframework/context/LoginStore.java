package com.seeease.springframework.context;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author Tiro
 * @date 2023/2/28
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LoginStore implements Serializable {
    /**
     * 门店ID
     */
    private Integer id;

    /**
     * 门店名称
     */

    private String name;
}
