package com.seeease.springframework;

/**
 * <p>
 *     请求入参分组效验通用
 * </p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 11/2/23 10:47 上午
 **/
public interface RequestValidGroup {

    /**
     * 新增
     */
    interface Create{}

    /**
     * 更新
     */
    interface Update{}

    /**
     * 删除
     */
    interface Deleted{}

    /**
     * 控制状态开启或关闭
     */
    interface State{}
}
