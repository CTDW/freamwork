package com.seeease.springframework.context;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Tiro
 * @date 2023/2/14
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LoginUser implements Serializable {
    /**
     * 是否为超管
     */
    private boolean isAdmin;
    
    /**
     * 用户id，db主键
     */
    private Integer id;

    /**
     * 企业微信id
     */
    private String userid;

    /**
     * 成员名称
     */
    private String userName;

    /**
     * 应用id
     */
    private Integer appId;

    /**
     * 门店信息
     */
    private LoginStore store;

    /**
     * 当前登录角色列表
     */
    private List<LoginRole> roles = new ArrayList<>();

    /**
     * 过滤的敏感数据
     */
    private List<String> filterSensitiveDataList;
}
