package com.seeease.springframework;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author Tiro
 * @date 2024/4/11
 */
@Getter
@AllArgsConstructor
public enum SensitiveDataDefinitionEnum {
    TOB_PRICE("tobPrice", "2B价"),
    TOC_PRICE("tocPrice", "2C价"),
    PURCHASE_PRICE("purchasePrice", "采购价"),
    COST_PRICE("costPrice", "成本价"),
    TAG_PRICE("tagPrice", "吊牌价"),
    PUB_PRICE("pubPrice", "公价"),
    ALLOCATE_PRICE("allocatePrice", "调拨价"),
    CONSIGNMENT_PRICE("consignmentPrice", "寄售价"),
    FIX_COST_PRICE("fixCostPrice", "维修成本价"),

    ;
    private String code;
    private String desc;
}
