package com.seeease.seeeaseframework.mybatis.transitionstate;

import com.baomidou.mybatisplus.annotation.IEnum;

/**
 * @author Tiro
 * @date 2023/1/9
 */
public interface IStateEnum <T extends java.io.Serializable> extends IEnum<T> {
}