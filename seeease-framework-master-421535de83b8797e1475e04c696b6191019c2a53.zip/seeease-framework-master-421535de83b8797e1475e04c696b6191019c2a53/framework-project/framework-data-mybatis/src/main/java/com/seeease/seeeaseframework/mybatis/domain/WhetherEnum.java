package com.seeease.seeeaseframework.mybatis.domain;

import com.baomidou.mybatisplus.annotation.IEnum;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;

/**
 * @author Tiro
 * @date 2023/2/3
 */
@Getter
@AllArgsConstructor
public enum WhetherEnum implements IEnum<Integer> {

    YES(1, "是"),
    NO(0, "否"),
    ;
    private Integer value;
    private String desc;

    public static WhetherEnum fromValue(int value) {
        return Arrays.stream(WhetherEnum.values())
                .filter(t -> value == t.getValue())
                .findFirst()
                .orElseThrow(() -> new RuntimeException("不支持的枚举"));
    }
}
