package com.seeease.seeeaseframework.mybatis.transitionstate;

import java.lang.annotation.*;

/**
 * @author Tiro
 * @date 2023/1/9
 */
@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.FIELD, ElementType.ANNOTATION_TYPE})
public @interface TransitionState {
}
