package com.seeease.seeeaseframework.mybatis.type;

import com.alibaba.fastjson.TypeReference;

import java.util.Collections;
import java.util.List;

/**
 * @author Tiro
 * @date 2023/1/19
 */
public abstract class JsonArrayTypeHandler<T> extends JsonTypeHandler<List<T>> {


    /**
     * @param clazz
     */
    public JsonArrayTypeHandler(Class<List<T>> clazz) {
        super(clazz);
    }

    /**
     * 具体类型，由子类提供
     *
     * @return 具体类型
     */
    protected abstract TypeReference<List<T>> specificType();

    @Override
    protected List<T> toObject(String content, Class<List<T>> clazz) {
        if (content == null || content.length() == 0) {
            return Collections.emptyList();
        }
        return com.alibaba.fastjson.JSON.parseObject(content, specificType());
    }
}
