package com.seeease.seeeaseframework.mybatis.transitionstate;

/**
 * @author Tiro
 * @date 2023/2/3
 */
public class StateChangeRejectException extends RuntimeException {
    public StateChangeRejectException() {
        super();
    }

    public StateChangeRejectException(String message) {
        super(message);
    }
}
