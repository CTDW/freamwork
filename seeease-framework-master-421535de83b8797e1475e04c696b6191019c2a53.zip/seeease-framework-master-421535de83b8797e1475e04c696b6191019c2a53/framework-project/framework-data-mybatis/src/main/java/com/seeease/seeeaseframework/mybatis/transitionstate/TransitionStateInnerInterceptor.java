package com.seeease.seeeaseframework.mybatis.transitionstate;

import com.baomidou.mybatisplus.core.conditions.AbstractWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.core.metadata.TableFieldInfo;
import com.baomidou.mybatisplus.core.metadata.TableInfo;
import com.baomidou.mybatisplus.core.metadata.TableInfoHelper;
import com.baomidou.mybatisplus.core.toolkit.Constants;
import com.baomidou.mybatisplus.core.toolkit.ExceptionUtils;
import com.baomidou.mybatisplus.core.toolkit.StringPool;
import com.baomidou.mybatisplus.extension.plugins.inner.InnerInterceptor;
import org.apache.ibatis.executor.Executor;
import org.apache.ibatis.mapping.MappedStatement;
import org.apache.ibatis.mapping.SqlCommandType;

import java.lang.reflect.Field;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

/**
 * @author Tiro
 * @date 2023/1/9
 */
public class TransitionStateInnerInterceptor implements InnerInterceptor {

    public TransitionStateInnerInterceptor() {
    }

    @Override
    public void beforeUpdate(Executor executor, MappedStatement ms, Object parameter) throws SQLException {
        if (SqlCommandType.UPDATE != ms.getSqlCommandType()) {
            return;
        }
        if (parameter instanceof Map) {
            Map<String, Object> map = (Map<String, Object>) parameter;
            doOptimisticLocker(map, ms.getId());
        }
    }

    protected void doOptimisticLocker(Map<String, Object> map, String msId) {
        // updateById(et), update(et, wrapper);
        Object et = map.getOrDefault(Constants.ENTITY, null);
        if (Objects.nonNull(et)) {
            try {
                String methodName = msId.substring(msId.lastIndexOf(StringPool.DOT) + 1);
                // TransitionState field
                TableFieldInfo fieldInfo = this.getTransitionStateFieldInfo(et.getClass());
                if (null == fieldInfo) {
                    if (SeeeaseSqlMethod.UPDATE_BY_ID_CHECK_STATE.getMethod().equals(methodName)) {
                        throw new StateChangeRejectException("获取不到状态转换信息");
                    }
                    return;
                }

                if (!(et instanceof TransitionStateEntity)) {
                    throw new StateChangeRejectException("获取不到状态转换信息");
                }

                ITransitionStateEnum transitionStateEnum = ((TransitionStateEntity) et).getTransitionStateEnum();

                Field stateField = fieldInfo.getField();

                Object originalStateVal = stateField.get(et);

                //没有状态变更
//                if (Objects.isNull(transitionStateEnum) && Objects.isNull(originalStateVal)) {
//                    return;
//                }
                if (Objects.isNull(transitionStateEnum)) {
                    return;
                }

                if (Objects.isNull(transitionStateEnum) && Objects.nonNull(originalStateVal)) {
                    if ( !Objects.equals(transitionStateEnum.getToState(), originalStateVal) ||
                            !Objects.equals(transitionStateEnum.getFromState(), originalStateVal))

                        throw new StateChangeRejectException("状态变更数据不一致");
                }

//                if (Objects.nonNull(transitionStateEnum) && Objects.nonNull(originalStateVal) &&
//                        !Objects.equals(transitionStateEnum.getToState(), originalStateVal)) {
//                    throw new StateChangeRejectException("状态变更数据不一致");
//                }


                Object oldValue = transitionStateEnum.getFromState().getValue();
                String versionColumn = fieldInfo.getColumn();
                if ("update".equals(methodName)) {
                    AbstractWrapper<?, ?, ?> aw = (AbstractWrapper<?, ?, ?>) map.getOrDefault(Constants.WRAPPER, null);
                    if (aw == null) {
                        UpdateWrapper<?> uw = new UpdateWrapper<>();
                        uw.eq(versionColumn, oldValue);
                        map.put(Constants.WRAPPER, uw);
                    } else {
                        aw.apply(versionColumn + " = {0}", oldValue);
                    }
                } else if (SeeeaseSqlMethod.UPDATE_BY_ID_CHECK_STATE.getMethod().equals(methodName)) {
                    map.put(SeeeaseSqlMethod.UPDATE_BY_ID_CHECK_STATE.getKey(), oldValue);
                } else {
                    throw new StateChangeRejectException("不支持状态检查的方法");
                }
                stateField.set(et, transitionStateEnum.getToState());
            } catch (IllegalAccessException e) {
                throw ExceptionUtils.mpe(e);
            }
        }

    }

    protected TableFieldInfo getTransitionStateFieldInfo(Class<?> entityClazz) {
        return StateUtil.getTableFieldInfo(Optional.ofNullable(TableInfoHelper.getTableInfo(entityClazz))
                .map(TableInfo::getFieldList)
                .orElse(new ArrayList<>()));
    }

}
