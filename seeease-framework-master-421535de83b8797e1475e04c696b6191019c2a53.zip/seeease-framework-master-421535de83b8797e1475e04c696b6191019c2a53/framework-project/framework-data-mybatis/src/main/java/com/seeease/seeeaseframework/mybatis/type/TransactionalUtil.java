package com.seeease.seeeaseframework.mybatis.type;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionTemplate;

import java.util.function.Supplier;

/**
 * @author Tiro
 * @date 2023/3/8
 */
@Slf4j
@AllArgsConstructor
public class TransactionalUtil {
    private TransactionTemplate transactionTemplate;

    /**
     * 执行编程事务
     *
     * @param supplier
     * @param <R>
     * @return
     */
    public <R> R transactional(Supplier<R> supplier) {
        return transactionTemplate.execute(new TransactionCallback<R>() {
            @Override
            public R doInTransaction(TransactionStatus transactionStatus) {
                try {
                    return supplier.get();
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                    //回滚
                    transactionStatus.setRollbackOnly();
                    throw e;
                }
            }
        });
    }
}
