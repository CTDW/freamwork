package com.seeease.seeeaseframework.mybatis;

import com.baomidou.mybatisplus.annotation.DbType;
import com.baomidou.mybatisplus.core.config.GlobalConfig;
import com.baomidou.mybatisplus.extension.plugins.MybatisPlusInterceptor;
import com.baomidou.mybatisplus.extension.plugins.inner.BlockAttackInnerInterceptor;
import com.baomidou.mybatisplus.extension.plugins.inner.OptimisticLockerInnerInterceptor;
import com.baomidou.mybatisplus.extension.plugins.inner.PaginationInnerInterceptor;
import com.seeease.seeeaseframework.mybatis.handlers.AbstractMetaObjectHandler;
import com.seeease.seeeaseframework.mybatis.handlers.DefaultMetaObjectHandler;
import com.seeease.seeeaseframework.mybatis.transitionstate.TransitionStateInnerInterceptor;
import com.seeease.seeeaseframework.mybatis.type.TransactionalUtil;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.support.TransactionTemplate;

/**
 * @author Tiro
 * @date 2022/10/19
 */
@EnableTransactionManagement
@Configuration
public class MybatisPlusAutoConfiguration {

    @Bean
    public GlobalConfig globalConfiguration() {
        GlobalConfig conf = new GlobalConfig();
        conf.setSqlInjector(seeeaseSqlInjector());
        return conf;
    }

    @Bean
    public SeeeaseSqlInjector seeeaseSqlInjector() {
        return new SeeeaseSqlInjector();
    }

    @Bean
    public MybatisPlusInterceptor mybatisPlusInterceptor() {
        MybatisPlusInterceptor mybatisPlusInterceptor = new MybatisPlusInterceptor();
        //乐观锁插件
        mybatisPlusInterceptor.addInnerInterceptor(new OptimisticLockerInnerInterceptor());
        //防止全表更新与删除插件
        mybatisPlusInterceptor.addInnerInterceptor(new BlockAttackInnerInterceptor());

        //状态转换插件
        mybatisPlusInterceptor.addInnerInterceptor(new TransitionStateInnerInterceptor());

        //分页插件
        PaginationInnerInterceptor paginationInnerInterceptor = new PaginationInnerInterceptor();
        //单页分页条数限制

        paginationInnerInterceptor.setMaxLimit(Long.MAX_VALUE);
        //数据库类型
        paginationInnerInterceptor.setDbType(DbType.MYSQL);
        mybatisPlusInterceptor.addInnerInterceptor(paginationInnerInterceptor);

        return mybatisPlusInterceptor;
    }

    @Bean
    @ConditionalOnMissingBean(AbstractMetaObjectHandler.class)
    public DefaultMetaObjectHandler defaultMetaObjectHandler() {
        return new DefaultMetaObjectHandler();
    }

    @Bean
    public TransactionalUtil transactionalUtil(TransactionTemplate transactionTemplate) {
        return new TransactionalUtil(transactionTemplate);
    }

}
