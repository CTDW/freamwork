package com.seeease.seeeaseframework.mybatis.transitionstate;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author Tiro
 * @date 2023/1/10
 */
@Getter
@AllArgsConstructor
public enum SeeeaseSqlMethod {
    UPDATE_BY_ID_CHECK_STATE("updateByIdCheckState", "MP_CHECK_OLD_STATE","根据ID 选择修改数据检查状态变更", "<script>\nUPDATE %s %s WHERE %s=#{%s} %s\n</script>"),

    ;
    private final String method;
    private final String key;
    private final String desc;
    private final String sql;
}
