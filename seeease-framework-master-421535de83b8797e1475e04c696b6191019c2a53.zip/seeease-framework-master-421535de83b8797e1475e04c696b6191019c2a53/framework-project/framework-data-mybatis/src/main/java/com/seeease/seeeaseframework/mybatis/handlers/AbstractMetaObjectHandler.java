package com.seeease.seeeaseframework.mybatis.handlers;

import com.baomidou.mybatisplus.core.handlers.MetaObjectHandler;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.ibatis.reflection.MetaObject;

import java.io.Serializable;
import java.util.Date;
import java.util.Optional;

/**
 * @author Tiro
 * @date 2023/1/9
 */
public abstract class AbstractMetaObjectHandler implements MetaObjectHandler {
    private static String CREATED_ID = "createdId";
    private static String CREATED_BY = "createdBy";
    private static String CREATED_TIME = "createdTime";
    private static String UPDATED_ID = "updatedId";
    private static String UPDATED_BY = "updatedBy";
    private static String UPDATED_TIME = "updatedTime";
    private static String DELETED = "deleted";
    private static String REVISION = "revision";

    private static Integer DELETED_VALUE = 0;
    private static Integer REVISION_VALUE = 1;
    /**
     * 系统默认身份
     */
    protected static Identity DEFAULT_IDENTITY = Identity.builder()
            .id(0)
            .name("SYSTEM_DEFAULT")
            .build();

    /**
     * 插入时的填充策略
     *
     * @param metaObject
     */
    @Override
    public void insertFill(MetaObject metaObject) {
        Identity identity = Optional.ofNullable(getIdentity()).orElse(DEFAULT_IDENTITY);
        Date time = new Date();
        //创建
        this.strictInsertFill(metaObject, CREATED_ID, Integer.class, identity.getId());
        this.strictInsertFill(metaObject, CREATED_BY, String.class, identity.getName());
        this.strictInsertFill(metaObject, CREATED_TIME, Date.class, time);

        //更新
        this.strictInsertFill(metaObject, UPDATED_ID, Integer.class, identity.getId());
        this.strictInsertFill(metaObject, UPDATED_BY, String.class, identity.getName());
        this.strictInsertFill(metaObject, UPDATED_TIME, Date.class, time);

        //逻辑删除
        this.strictInsertFill(metaObject, DELETED, Integer.class, DELETED_VALUE);

        //乐观锁
        this.strictInsertFill(metaObject, REVISION, Integer.class, REVISION_VALUE);

    }

    /**
     * 更新时的填充策略
     *
     * @param metaObject
     */
    @Override
    public void updateFill(MetaObject metaObject) {
        Identity identity = Optional.ofNullable(getIdentity()).orElse(DEFAULT_IDENTITY);
        this.strictUpdateFill(metaObject, UPDATED_ID, Integer.class, identity.getId());
        this.strictUpdateFill(metaObject, UPDATED_BY, String.class, identity.getName());
        this.strictUpdateFill(metaObject, UPDATED_TIME, Date.class, new Date());
    }


    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Identity implements Serializable {
        /**
         * 用户id
         */
        private Integer id;
        /**
         * 用户名称
         */
        private String name;

    }

    /**
     * 获取用户信息
     *
     * @return
     */
    abstract public Identity getIdentity();
}
