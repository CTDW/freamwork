package com.seeease.seeeaseframework.mybatis;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.toolkit.Constants;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author Tiro
 * @date 2022/10/19
 */
public interface SeeeaseMapper<T> extends BaseMapper<T> {
    /**
     * 批量新增数据,自选字段 insert
     * <p> 不同的数据库支持度不一样!!!  只在 mysql 下测试过!!!  只在 mysql 下测试过!!!  只在 mysql 下测试过!!! </p>
     * <p> 除了主键是 <strong> 数据库自增的未测试 </strong> 外理论上都可以使用!!! </p>
     * <p> 如果你使用自增有报错或主键值无法回写到entity,就不要跑来问为什么了,因为我也不知道!!! </p>
     * <p>
     * 自己的通用 mapper 如下使用:
     * <pre>
     * int insertBatchSomeColumn(List<T> entityList);
     * </pre>
     * </p>
     *
     * <li> 注意: 这是自选字段 insert !!,如果个别字段在 entity 里为 null 但是数据库中有配置默认值, insert 后数据库字段是为 null 而不是默认值 </li>
     */
    int insertBatchSomeColumn(List<T> entityList);

    /**
     * 自定义批量更新，条件为主键
     * 如果要自动填充，@Param(xx) xx参数名必须是 list/collection/array 3个的其中之一
     */
    int updateBatch( List<T> list);


    /**
     * 更新状态
     *
     * @param entity
     * @return
     */
    int updateByIdCheckState(@Param(Constants.ENTITY) T entity);
}
