package com.seeease.seeeaseframework.mybatis.transitionstate;

import com.seeease.seeeaseframework.mybatis.SeeeaseMapper;

/**
 * 更新状态机，封装结果校验
 *
 * @author Tiro
 * @date 2023/2/3
 */
public class UpdateByIdCheckState {

    /**
     * @param mapper
     * @param t
     * @param <T>
     * @param <M>
     */
    public static <T extends TransitionStateEntity, M extends SeeeaseMapper<T>> void update(M mapper, T t) {
        if (1 != mapper.updateByIdCheckState(t)) {
            TransitionStateEntity entity = (TransitionStateEntity) t;
            throw new StateChangeRejectException("状态不可变更:" + entity.getTransitionStateEnum());
        }
    }

}
