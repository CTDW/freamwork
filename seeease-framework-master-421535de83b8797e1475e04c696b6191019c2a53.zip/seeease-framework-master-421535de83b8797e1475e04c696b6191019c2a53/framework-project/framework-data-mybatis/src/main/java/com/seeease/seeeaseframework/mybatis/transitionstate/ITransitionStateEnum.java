package com.seeease.seeeaseframework.mybatis.transitionstate;

/**
 * @author Tiro
 * @date 2023/1/9
 */
public interface ITransitionStateEnum {

    IStateEnum getFromState();

    IStateEnum getToState();
}
