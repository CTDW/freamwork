package com.seeease.seeeaseframework.mybatis.transitionstate;

import com.baomidou.mybatisplus.core.injector.AbstractMethod;
import com.baomidou.mybatisplus.core.metadata.TableFieldInfo;
import com.baomidou.mybatisplus.core.metadata.TableInfo;
import com.baomidou.mybatisplus.core.toolkit.sql.SqlScriptUtils;
import org.apache.ibatis.mapping.MappedStatement;
import org.apache.ibatis.mapping.SqlSource;

import java.util.Objects;

/**
 * @author Tiro
 * @date 2023/1/10
 */
public class UpdateByIdWithState extends AbstractMethod {


    public UpdateByIdWithState() {
        super(SeeeaseSqlMethod.UPDATE_BY_ID_CHECK_STATE.getMethod());
    }

    /**
     * @param name 方法名
     * @since 3.5.0
     */
    public UpdateByIdWithState(String name) {
        super(name);
    }

    @Override
    public MappedStatement injectMappedStatement(Class<?> mapperClass, Class<?> modelClass, TableInfo tableInfo) {
        SeeeaseSqlMethod sqlMethod = SeeeaseSqlMethod.UPDATE_BY_ID_CHECK_STATE;
        String additional = optlockVersion(tableInfo) + tableInfo.getLogicDeleteSql(true, true);

        TableFieldInfo fieldInfo = StateUtil.getTableFieldInfo(tableInfo.getFieldList());

        if (Objects.nonNull(fieldInfo)) {
            additional += String.format(" AND %s=%s ", fieldInfo.getColumn(), SqlScriptUtils.safeParam(sqlMethod.getKey()));
        }

        String sql = String.format(sqlMethod.getSql(), tableInfo.getTableName(),
                sqlSet(tableInfo.isWithLogicDelete(), false, tableInfo, false, ENTITY, ENTITY_DOT),
                tableInfo.getKeyColumn(), ENTITY_DOT + tableInfo.getKeyProperty(), additional);
        SqlSource sqlSource = languageDriver.createSqlSource(configuration, sql, modelClass);
        return addUpdateMappedStatement(mapperClass, modelClass, sqlSource);
    }

}
