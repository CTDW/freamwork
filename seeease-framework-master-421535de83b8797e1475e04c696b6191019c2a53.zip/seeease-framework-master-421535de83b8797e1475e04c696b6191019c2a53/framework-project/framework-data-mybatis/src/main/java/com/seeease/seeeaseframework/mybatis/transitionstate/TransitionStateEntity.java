package com.seeease.seeeaseframework.mybatis.transitionstate;

import java.io.Serializable;

/**
 * @author Tiro
 * @date 2023/1/9
 */
public interface TransitionStateEntity extends Serializable {
    ITransitionStateEnum getTransitionStateEnum();
}
