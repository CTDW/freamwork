/**
 * Created by trio on 2021/10/28.
 */
package com.seeease.seeeaseframework.mybatis.type;

import org.apache.ibatis.type.BaseTypeHandler;
import org.apache.ibatis.type.JdbcType;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * json type handler
 *
 * @Author: trio
 * @date 2022/10/19
 */
public class JsonTypeHandler<T extends Object> extends BaseTypeHandler<T> {
    /**
     * class info
     */
    private Class<T> clazz;

    /**
     * @param clazz
     */
    public JsonTypeHandler(Class<T> clazz) {
        if (clazz == null) {
            throw new IllegalArgumentException("Type argument cannot be null");
        }
        this.clazz = clazz;
    }

    /**
     * @param ps
     * @param i
     * @param parameter
     * @param jdbcType
     * @throws SQLException
     */
    @Override
    public void setNonNullParameter(PreparedStatement ps, int i, T parameter, JdbcType jdbcType) throws SQLException {
        ps.setString(i, this.toJson(parameter));
    }

    /**
     * @param rs
     * @param columnName
     * @return
     * @throws SQLException
     */
    @Override
    public T getNullableResult(ResultSet rs, String columnName) throws SQLException {
        return this.toObject(rs.getString(columnName), clazz);
    }

    /**
     * @param rs
     * @param columnIndex
     * @return
     * @throws SQLException
     */
    @Override
    public T getNullableResult(ResultSet rs, int columnIndex) throws SQLException {
        return this.toObject(rs.getString(columnIndex), clazz);
    }

    /**
     * @param cs
     * @param columnIndex
     * @return
     * @throws SQLException
     */
    @Override
    public T getNullableResult(CallableStatement cs, int columnIndex) throws SQLException {
        return this.toObject(cs.getString(columnIndex), clazz);
    }


    /**
     * @param t
     * @return
     */
    protected String toJson(T t) {
        return com.alibaba.fastjson.JSON.toJSONString(t);
    }


    /**
     * @param content
     * @param clazz
     * @return
     */
    protected T toObject(String content, Class<T> clazz) {
        if (content == null || content.length() == 0) {
            return emptyCollection(clazz);
        }
        return com.alibaba.fastjson.JSON.parseObject(content, clazz);
    }

    /**
     * @param clazz
     * @return
     */
    private T emptyCollection(Class<T> clazz) {
        if (List.class.isAssignableFrom(clazz)) {
            return (T) Collections.emptyList();
        } else if (Set.class.isAssignableFrom(clazz)) {
            return (T) Collections.emptySet();
        } else if (Map.class.isAssignableFrom(clazz)) {
            return (T) Collections.emptyMap();
        }
        return null;
    }

}