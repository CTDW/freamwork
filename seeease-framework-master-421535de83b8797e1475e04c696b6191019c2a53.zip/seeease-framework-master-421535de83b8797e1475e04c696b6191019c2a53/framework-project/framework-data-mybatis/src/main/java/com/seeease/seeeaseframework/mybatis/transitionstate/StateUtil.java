package com.seeease.seeeaseframework.mybatis.transitionstate;

import com.baomidou.mybatisplus.core.metadata.TableFieldInfo;

import java.util.List;
import java.util.stream.Collectors;

/**
 * @author Tiro
 * @date 2023/1/11
 */
public class StateUtil {

    public static TableFieldInfo getTableFieldInfo(List<TableFieldInfo> tableFieldInfos) {
        List<TableFieldInfo> fieldInfos = tableFieldInfos.stream()
                .filter(f -> f.getField().getAnnotation(TransitionState.class) != null)
                .collect(Collectors.toList());
        if (fieldInfos.size() > 1) {
            throw new StateChangeRejectException("状态检查不能多个字段使用");
        }
        return fieldInfos.stream().findFirst().orElse(null);
    }
}
