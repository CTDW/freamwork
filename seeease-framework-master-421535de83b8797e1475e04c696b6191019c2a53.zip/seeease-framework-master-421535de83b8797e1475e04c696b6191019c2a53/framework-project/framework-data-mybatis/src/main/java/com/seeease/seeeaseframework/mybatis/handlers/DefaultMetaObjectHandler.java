package com.seeease.seeeaseframework.mybatis.handlers;

import com.seeease.springframework.context.LoginUser;
import com.seeease.springframework.context.UserContext;

import java.util.Objects;

/**
 * @author Tiro
 * @date 2023/2/15
 */
public class DefaultMetaObjectHandler extends AbstractMetaObjectHandler {

    @Override
    public Identity getIdentity() {
        LoginUser loginUser = UserContext.getUser();
        if (Objects.isNull(loginUser) || Objects.isNull(loginUser.getId())) {
            return DEFAULT_IDENTITY;
        }
        return Identity.builder()
                .id(loginUser.getId())
                .name(loginUser.getUserName())
                .build();
    }
}
