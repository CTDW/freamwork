package com.seeease.seeeaseframework.mybatis.utils;

import com.baomidou.mybatisplus.annotation.IEnum;
import com.seeease.seeeaseframework.mybatis.transitionstate.IStateEnum;
import com.seeease.seeeaseframework.mybatis.transitionstate.ITransitionStateEnum;

import java.io.Serializable;
import java.util.Arrays;

/**
 * <p>枚举通用类</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 10/30/23 3:28 下午
 **/
public class EnumUtils {


    /**
     * 实现{@link IEnum}接口的枚举，都可以通过该接口将value装换为对应枚举对象
     * @param enumClass 枚举类型
     * @param value     输入值
     * @return 转换后的枚举
     */
    public static <I extends Serializable,E extends IEnum<I>> E of(Class<E> enumClass, I value){
         return Arrays.stream(enumClass.getEnumConstants())
                 .filter(v->v.getValue().equals(value))
                 .findFirst()
                 .orElseThrow(()-> new RuntimeException("枚举转换失败"));
    }

    /**
     * 实现{@link IEnum}接口的枚举，都可以通过该接口将value装换为对应枚举对象
     * @param enumClass 枚举类型
     * @return 转换后的枚举
     */
    public static <E extends ITransitionStateEnum> E of(Class<E> enumClass, IStateEnum from,IStateEnum to){
        return Arrays.stream(enumClass.getEnumConstants())
                .filter(v->v.getFromState() == from && v.getToState() == to)
                .findFirst()
                .orElseThrow(()-> new RuntimeException("枚举转换失败"));
    }
}
