package com.seeease.framework.synclock;

import java.lang.annotation.*;
import java.util.concurrent.TimeUnit;

/**
 * <p>同步锁注解</p>
 * 锁的全名称为 系统名称::锁描述符::锁后缀
 * @author 西门 游
 * @version 1.0
 * @since 11/13/23
 **/
@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface SyncLock {


    /**
     * 锁名称
     */
    String value();

    /**
     * 锁后缀支持el表达式获取参数值
     * 假设存在锁后缀，那么该数组长度请和锁描述符的数组长度一致，否则报错
     */
    String elSuffix() default "";

    /**
     * 过期时间
     */
    long expire() default 0L;

    /**
     * 过期时间单位
     */
    TimeUnit time() default TimeUnit.SECONDS;

    /**
     * 锁类型
     */
    LockType lockType() default LockType.NORMAL;


    enum LockType{
        READ,
        WRITE,
        NORMAL
    }
}
