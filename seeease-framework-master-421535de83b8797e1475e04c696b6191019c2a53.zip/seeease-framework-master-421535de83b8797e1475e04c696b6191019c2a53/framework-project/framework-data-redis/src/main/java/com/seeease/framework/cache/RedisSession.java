package com.seeease.framework.cache;

import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;

import java.util.Objects;
import java.util.Set;
import java.util.concurrent.TimeUnit;

/**
 * @author Tiro
 * @date 2024/4/17
 */
public class RedisSession {
    private static final String TOKEN_KEY = "LOGIN_TOKENS:%d:%d:";

    private final RedisTemplate redisTemplate;

    public RedisSession(RedisTemplate redisTemplate) {
        this.redisTemplate = redisTemplate;
    }

    /**
     * 获取会话
     *
     * @param appId
     * @param userId
     * @param tokenCode
     * @param <T>
     * @return
     */
    public <T> T getSession(Integer appId, Integer userId, String tokenCode) {
        ValueOperations<String, T> operation = redisTemplate.opsForValue();
        return operation.get(this.convertKey(appId, userId) + tokenCode);
    }

    /**
     * 创建/更新会话
     *
     * @param appId
     * @param userId
     * @param tokenCode
     * @param t
     * @param timeout
     * @param <T>
     */
    public <T> void setSession(Integer appId, Integer userId, String tokenCode, T t, long timeout) {
        //清除会话
        this.delSession(appId, userId);
        //设置会话

        ValueOperations<String, T> operation = this.redisTemplate.opsForValue();
        operation.set(this.convertKey(appId, userId) + tokenCode, t, timeout, TimeUnit.SECONDS);
    }


    /**
     * 清除用户登录会话
     *
     * @param appId
     * @param userId
     * @param <T>
     */
    public <T> void delSession(Integer appId, Integer userId) {
        Set<String> keys = redisTemplate.keys(this.convertKey(appId, userId) + "*");
        if (null != keys) {
            keys.forEach(redisTemplate::delete);
        }
    }

    /**
     * @param appId
     * @param userId
     * @return
     */
    private String convertKey(Integer appId, Integer userId) {
        return String.format(TOKEN_KEY, Objects.requireNonNull(appId),
                Objects.requireNonNull(userId));
    }
}
