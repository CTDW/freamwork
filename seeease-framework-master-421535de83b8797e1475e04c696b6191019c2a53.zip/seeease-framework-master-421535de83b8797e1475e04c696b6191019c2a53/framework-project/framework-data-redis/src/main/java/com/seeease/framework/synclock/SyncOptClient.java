package com.seeease.framework.synclock;


import com.seeease.framework.Utils;
import com.seeease.framework.e.GetLockFailException;
import org.redisson.api.RLock;
import org.redisson.api.RedissonClient;
import org.springframework.util.StringUtils;

import java.util.function.Supplier;

/**
 * <p>
 * 同比操作锁主键，暂不支持锁重入
 * </p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 11/1/23 6:23 下午
 **/

public class SyncOptClient {


    private final RedissonClient redissonClient;

    public SyncOptClient(RedissonClient redissonClient) {
        this.redissonClient = redissonClient;
    }

    /**
     * 获取同步锁
     * @param fd  同步操作枚举
     * @param suffix 同步锁后缀
     */
    public String getLockName(String fd, String suffix) {
        String applicationName = Utils.getApplicationName();
        fd = applicationName + "::" + fd;
        return StringUtils.isEmpty(suffix) ? fd : fd + "::" + suffix;
    }

    /**
     * 控制多个方法同步执行
     * 当方法A获取锁时，方法B无法同时执行
     *
     * @param fd     同步操作描述符
     * @param suffix 同步锁后缀
     * @param task   执行的任务
     */
    public void execWithoutResult(String fd, String suffix, Runnable task) throws RuntimeException {
        RLock lock = redissonClient.getLock(getLockName(fd, suffix));
        if (lock.tryLock()) {
            try {
                task.run();
            } finally {
                lock.unlock();
            }
        } else {
            throw new GetLockFailException();
        }
    }


    /**
     * 控制多个方法同步执行
     * 当方法A获取锁时，方法B无法同时执行
     *
     * @param fd       同步操作描述符
     * @param suffix   同步锁后缀
     * @param supplier 执行的任务
     */
    public <T> T execWithResult(String fd, String suffix, Supplier<T> supplier) throws RuntimeException{
        RLock lock = redissonClient.getLock(getLockName(fd, suffix));
        T ret;
        if (lock.tryLock()) {
            try {
                ret = supplier.get();
            } finally {
                lock.unlock();
            }
        } else {
            throw new GetLockFailException();
        }
        return ret;
    }

}
