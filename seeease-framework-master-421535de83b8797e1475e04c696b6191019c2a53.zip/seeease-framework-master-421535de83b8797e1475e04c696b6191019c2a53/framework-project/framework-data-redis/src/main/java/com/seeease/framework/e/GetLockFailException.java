package com.seeease.framework.e;

/**
 * <p>获取锁失败</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 11/13/23 下午
 **/
public class GetLockFailException extends RuntimeException{
    public GetLockFailException() {
        super();
    }
}
