package com.seeease.framework.synclock;



import java.lang.annotation.*;

/**
 * 同步锁控制
 */
@Target({ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface SyncControl {

    SyncLock[] value();

}
