package com.seeease.framework;

import org.springframework.core.env.Environment;

/**
 * <p>工具类</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 11/13/23 上午
 **/
public class Utils {

    public static Environment environment;



    public static String getApplicationName() {
        return environment.getProperty("spring.application.name");
    }
}
