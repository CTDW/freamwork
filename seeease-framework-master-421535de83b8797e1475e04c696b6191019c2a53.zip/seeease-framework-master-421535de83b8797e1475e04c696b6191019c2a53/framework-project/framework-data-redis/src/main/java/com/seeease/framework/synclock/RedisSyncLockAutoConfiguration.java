package com.seeease.framework.synclock;


import com.seeease.framework.Utils;
import org.redisson.Redisson;
import org.redisson.api.RedissonClient;
import org.redisson.config.Config;
import org.redisson.config.SingleServerConfig;
import org.redisson.config.TransportMode;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.data.redis.RedisProperties;
import org.springframework.context.EnvironmentAware;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.core.env.Environment;


/**
 * <p>redis 同步锁配置</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 11/13/23 下午
 **/
@EnableAspectJAutoProxy(exposeProxy = true)
public class RedisSyncLockAutoConfiguration implements EnvironmentAware {



    @Bean
    public RedissonClient redissonClient(RedisProperties redisProperties){
        Config config = new Config();
        config.setTransportMode(TransportMode.NIO);
        SingleServerConfig singleServerConfig = config.useSingleServer();
        //可以用"rediss://"来启用SSL连接
        singleServerConfig.setAddress("redis://"+redisProperties.getHost()+":"+redisProperties.getPort());
        singleServerConfig.setPassword(redisProperties.getPassword());
        singleServerConfig.setPingConnectionInterval(1000);//**此项务必设置为redisson解决之前bug的timeout问题关键*****
        return Redisson.create(config);
    }


    @Bean
    @ConditionalOnBean(RedissonClient.class)
    public SyncOptClient syncOptClient(RedissonClient redissonClient){
        return new SyncOptClient(redissonClient);
    }

    @Bean
    @ConditionalOnBean(RedissonClient.class)
    public LockFactory flyWheelLockFactory(RedissonClient redissonClient){
        return new LockFactory(redissonClient);
    }


    @Bean
    @ConditionalOnBean(RedissonClient.class)
    public SyncLockAspect syncLockAspect(){
        return new SyncLockAspect();
    }




    @Override
    public void setEnvironment(Environment environment) {
        Utils.environment = environment;
    }

}
