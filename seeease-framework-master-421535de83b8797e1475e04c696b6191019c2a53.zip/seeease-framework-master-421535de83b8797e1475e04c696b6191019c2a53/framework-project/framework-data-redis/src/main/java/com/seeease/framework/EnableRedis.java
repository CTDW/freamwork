package com.seeease.framework;

import org.springframework.context.annotation.Import;

import java.lang.annotation.*;

/**
 * <p>注解开启类</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 11/13/23 下午
 **/
@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Import(RedisConfigurationSelector.class)
public @interface EnableRedis {

    /**
     * 是否使用缓存
     */
    boolean useCache() default false;
    /**
     * 是否使用同步锁
     */
    boolean useSyncLock() default false;
}
