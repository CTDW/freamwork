package com.seeease.framework.synclock;

import com.seeease.framework.e.GetLockFailException;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.core.LocalVariableTableParameterNameDiscoverer;
import org.springframework.expression.Expression;
import org.springframework.expression.ExpressionParser;
import org.springframework.expression.spel.standard.SpelExpressionParser;
import org.springframework.expression.spel.support.StandardEvaluationContext;
import org.springframework.util.StringUtils;

import javax.annotation.Resource;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * <p>同步锁切面</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 11/13/23 上午
 **/
@Aspect
public class SyncLockAspect {

    @Resource
    private SyncOptClient syncOptClient;

    @Resource
    private LockFactory lockFactory;

    @Pointcut("@annotation(com.seeease.framework.synclock.SyncControl)")
    public void syncControlPointcut() {
    }

    @Around("syncControlPointcut() && @annotation(syncControl)")
    public Object syncControlAround(ProceedingJoinPoint joinPoint, SyncControl syncControl) throws Throwable {

        List<LockFactory.LockAdaptor> locks = adaptorLock(joinPoint, syncControl);
        ArrayList<LockFactory.LockAdaptor> locked = new ArrayList<>(locks.size());
        Object ret;
        try {
            for (LockFactory.LockAdaptor lock : locks) {
                if (!lock.tryLock()) {
                    throw new GetLockFailException();
                }
                locked.add(lock);
            }
            //执行方法
            ret = joinPoint.proceed();
        } finally {
            for (LockFactory.LockAdaptor lock : locked) {
                lock.unlock();
            }
        }
        return ret;
    }


    /**
     * 将注解内容 转换为适配锁
     */
    private List<LockFactory.LockAdaptor> adaptorLock(ProceedingJoinPoint joinPoint, SyncControl syncControl) {
        return Arrays.stream(syncControl.value()).map(v -> {
            String lockName = getLockName(joinPoint, v);
            return lockFactory.buildLockAdaptor(v, lockName);
        }).collect(Collectors.toList());
    }


    /**
     * 获取锁名称
     *
     * @param joinPoint
     * @param sl
     */
    private String getLockName(ProceedingJoinPoint joinPoint, SyncLock sl) {
        String suffix = null;
        if (!StringUtils.isEmpty(sl.elSuffix()) && sl.elSuffix().startsWith("#")) {
            StandardEvaluationContext standardEvaluationContext = new StandardEvaluationContext(joinPoint.getArgs());
            setContextVariables(standardEvaluationContext, joinPoint);
            suffix = getElValue(sl.elSuffix(), standardEvaluationContext);
        }
        return syncOptClient.getLockName(sl.value(), suffix);
    }


    /**
     * 通过key SEL表达式获取值
     */
    private String getElValue(String key, StandardEvaluationContext context) {
        if (StringUtils.isEmpty(key)) {
            return "";
        }
        ExpressionParser parser = new SpelExpressionParser();
        Expression exp = parser.parseExpression(key);

        return exp.getValue(context, String.class);

    }


    private void setContextVariables(StandardEvaluationContext standardEvaluationContext,
                                     JoinPoint joinPoint) {

        Object[] args = joinPoint.getArgs();
        MethodSignature methodSignature = (MethodSignature) joinPoint.getSignature();
        Method targetMethod = methodSignature.getMethod();
        LocalVariableTableParameterNameDiscoverer parameterNameDiscoverer
                = new LocalVariableTableParameterNameDiscoverer();
        String[] parametersName = parameterNameDiscoverer.getParameterNames(targetMethod);

        if (args == null || args.length <= 0) {
            return;
        }
        for (int i = 0; i < args.length; i++) {
            assert parametersName != null;
            standardEvaluationContext.setVariable(parametersName[i], args[i]);
        }
    }
}
