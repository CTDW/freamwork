package com.seeease.framework;

import com.seeease.framework.cache.RedisCacheAutoConfiguration;
import com.seeease.framework.synclock.RedisSyncLockAutoConfiguration;
import org.springframework.context.annotation.ImportSelector;
import org.springframework.core.type.AnnotationMetadata;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * <p>扫描器</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 11/13/23 下午
 **/
public class RedisConfigurationSelector implements ImportSelector {

    @Override
    public String[] selectImports(AnnotationMetadata importingClassMetadata) {
        Map<String, Object> attributes = importingClassMetadata.getAnnotationAttributes(EnableRedis.class.getName());

        boolean useCache = (boolean) attributes.get("useCache");
        boolean useSyncLock = (boolean) attributes.get("useSyncLock");

        List<String> imports = new ArrayList<>();

        if (useCache) {
            imports.add(RedisCacheAutoConfiguration.class.getName());
        }

        if (useSyncLock) {
            imports.add(RedisSyncLockAutoConfiguration.class.getName());
        }

        return imports.toArray(new String[0]);
    }
}
