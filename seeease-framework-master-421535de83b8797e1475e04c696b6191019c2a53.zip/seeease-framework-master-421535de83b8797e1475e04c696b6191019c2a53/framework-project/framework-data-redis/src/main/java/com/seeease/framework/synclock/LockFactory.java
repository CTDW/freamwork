package com.seeease.framework.synclock;


import org.redisson.api.RLock;
import org.redisson.api.RedissonClient;
import org.springframework.util.Assert;

import java.util.concurrent.TimeUnit;


/**
 * <p>锁工厂</p>
 *
 * @author 西门 游
 * @version 1.0
 * @since 11/18/23 下午
 **/
public class LockFactory {

    private final RedissonClient redissonClient;



    public LockFactory(RedissonClient redissonClient) {
        this.redissonClient = redissonClient;
    }

    public LockAdaptor buildLockAdaptor(SyncLock syncLock, String lockName) {
        Assert.hasLength(lockName,"lockName not empty");
        SyncLock.LockType lockType = syncLock.lockType();
        switch (lockType){
            case NORMAL:
                return new LockAdaptor(redissonClient.getLock(lockName), syncLock.expire(), syncLock.time());
            case WRITE:
                return new LockAdaptor(redissonClient.getReadWriteLock(lockName).writeLock(), syncLock.expire(), syncLock.time());
            case READ:
                return new LockAdaptor(redissonClient.getReadWriteLock(lockName).readLock(), syncLock.expire(), syncLock.time());
            default:
                throw new IllegalArgumentException("LockType unSupport");
        }
    }


    /**
     * <p>同步锁适配器</p>
     *
     * @author 西门 游
     * @version 1.0
     * @since 11/18/23 下午
     **/
    public static class LockAdaptor {

        /**
         * 锁源对象
         */
        private Object lockMate;
        /**
         * 过期时间
         */
        private long expire;
        /**
         * 时间类型
         */
        private TimeUnit timeUnit;

        public LockAdaptor(Object lockMate, long expire, TimeUnit timeUnit) {
            this.lockMate = lockMate;
            this.expire = expire;
            this.timeUnit = timeUnit;
        }

        public boolean tryLock() throws InterruptedException {
            Class<?> mateClass = lockMate.getClass();
            if (mateClass.isAssignableFrom(RLock.class)){
                if (expire != 0){
                    return ((RLock)lockMate).tryLock(expire,timeUnit);
                }
                return ((RLock)lockMate).tryLock();
            }
            throw new IllegalArgumentException("LockType unKnow");
        };


        public void unlock(){
            Class<?> mateClass = lockMate.getClass();
            if (mateClass.isAssignableFrom(RLock.class)){
                ((RLock)lockMate).unlock();
            }
            throw new IllegalArgumentException("LockType unKnow");
        };



    }


}
