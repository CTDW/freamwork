# 该模块整理了redis相关功能


- redis缓存：使用 @EnableRedis.useCache = true 开启。开启后可自动集成SpringCache功能使用（支持自定义key过期时间，使用#time(秒为单位，例如"loginSmsCode::userPhone::#60")），也可以使用RedisCacheUtil进行自定义使用

- 分布式锁：使用 @EnableRedis.useSyncLock = true 开启。开启后使用注解 @SyncControl作用在接口上即可。或者使用对象SyncOptClient进行函数式调用